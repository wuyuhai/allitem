$("#wxinzi1").change(function() {
	var text = $(this).children("option:selected").text(); //目前选择的值
	alert("薪资变化:" + text);
	if(text != '面谈') {
		$("#wxinzi2").show();
		var number = text.replace("K", '');
		var flag = true;
		var secondSize = number; //第二个选择框的数量大小
		$.each($("#wxinzi2").children("option"), function(i, item) {
			if(Number($(item).text().replace('K', '')) > Number(number)) {
				if(secondSize <= 0) {
					$(item).css("display", "none");
				} else {
					$(item).css("display", "block");
				}
				if(flag) {
					$(item).attr("selected", "selected");
					flag = false;
				}
				secondSize--;
			} else {
				$(item).css("display", "none");
			}
		});

	} else {
		$("#wxinzi2").hide();
	}
});

$("#wxinzi2").change(function() {
	var maxSalary = $(this).children("option:selected").text().replace('K', ''); //目前选择的值
	//如果wxinzi1的值大于该值的话，则改变wxinzi1的option的显示和隐藏状态
	var minSalary = $("#wxinzi1").children("option:selected").text().replace('K', '');
	if(minSalary > maxSalary) {
		$("#wxinzi1").children("option[value='" + (Number(maxSalary) - 1) + "']").attr("selected", "selected");
		$("#wxinzi1").change();
	}
});