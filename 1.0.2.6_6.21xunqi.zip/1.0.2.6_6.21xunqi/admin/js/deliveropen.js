//上传头像
function preview(file) { //预览图片得到图片base64
	var prevDiv = document.getElementById('headimg');
	if(file.files && file.files[0]) {
		var reader = new window.FileReader();
		reader.onload = function(evt) {
			prevDiv.innerHTML = '<img src="' + evt.target.result + '" />';
		}
		reader.readAsDataURL(file.files[0]);
	} else {
		prevDiv.innerHTML = '<div class="img" style="filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(sizingMethod=scale,src=\'' + file.value + '\'"></div>';
	}
	return file;
}
//	期望职位
history($('.w-want-box'), $('.w-want-res'), $('#wyanzhengma'));
//	期望行业
kills($('.select-box-hy'), $('.select-res-hy'));
// 公司职位
history($('.select-box-his'), $('.select-res-his'), $('#qw'));
//技能标签
kills($('.select-box-hiskills'), $('.select-res-hiskills'))

//期望城市请求
$('.addresss').on('keyup', function() {
	//发送请求
	//获得数据，占记
	$('#address').html('');
	var data_address = {
		"err_code": 0,
		"err_msg": "请求成功",
		"page": "-1",
		"data": [{
			"id": 1,
			"name": "大连"
		}, {
			"id": 2,
			"name": "大同"
		}, {
			"id": 3,
			"name": "大山"
		}, {
			"id": 4,
			"name": "大大"
		}]
	}
	if(data_address.err_code == 0) {
		$.each(data_address.data, function(i, item) {
			$('#address').append('<li value="' + item.id + '">' + item.name + '</li>')
		});
	} else {
		alert("请检查网络");
	}
	$('.wsuggest').show();
	var a = "",
		b = "";
	$('li', $('#address')).on('click', function() {
		item = $(this)[0];
		var fid = $(this).attr('value');
		$('.addresss')[0].value = item.innerText;
		a = item.innerText;
		b = $('.addresss')[0].value;
		$(document).bind('click', function() {
			if($('.addresss')[0].value == item.innerText) {
				$('.addresss')[0].value = item.innerText;
			} else {
				$('.addresss')[0].value = "";
			}
			$('.wsuggest').hide();
		})
	})
	$(document).bind('click', function() {
		if(b == a) {
			$('.addresss')[0].value = a;
		} else {
			$('.addresss')[0].value = "";
		}
		$('.wsuggest').hide();
	})
	if($('.addresss')[0].value == "") {
		$('.wsuggest').hide();
	}
})

//时间选择
function timexq(obj) {
	obj.on('click', function() {
		event.stopPropagation(); //阻止事件冒泡
		var tt = $(this).next();
		tt.show()
		//		$(this).next().show()
		onc($('#calendar'), $("#datetimepicker1"), tt)
		onc($('#calendar2'), $("#datetimepicker2"), tt)
		onc($('#calendar3'), $("#datetimepicker3"), tt)
		onc($('#calendar4'), $("#datetimepicker4"), tt)
	})
}

//时间函数
function onc(obj, obj2, tt) {
	var table = obj.find('.calendar-table')[0];
	var tds = table.getElementsByTagName('td');
	var a = "";
	var b = "";
	tt.toggle();
	var tag = tt.toggle();
	for(var i = 0; i < tds.length; i++) {
		tds[i].onclick = function() {
			obj2[0].value = $(this).parents('.calendar').find('.calendar-title')[0].innerText + "年" + this.innerText;
			//			console.log(this.innerText + $(this).parents('.calendar').find('.calendar-title')[0].innerText)
			a = $(this).parents('.calendar').find('.calendar-title')[0].innerText + "年" + this.innerText;
			b = obj2[0].value;
			$(this).parents('.calendar').hide()
		}
	}
	$('div.timefooter', obj).unbind('click').on('click', function() {
		obj2[0].value = this.innerText;
		console.log(1111)
		$(this).parents('.calendar').hide()
	})
	var flag = true;
	tt.unbind('click').on('click',function(){
//		if($(this))
		flag = false;
		console.log(111)
	})
	$(document).unbind('click').bind("click", function(e) { //点击空白处，设置的弹框消失
		var target = $(e.target);
		if(flag == true) {
			tag.hide();
			flag = false;
		}
	});

}
timexq($("#datetimepicker1"))
timexq($("#datetimepicker2"))
timexq($("#datetimepicker3"))
timexq($("#datetimepicker4"))

//时间逻辑
function timeb(a, b) {
	var date = new Date();
	var year = date.getFullYear()
	var q = a[0].value.split('月');
	w = b[0].value.split('月');
	var num1 = parseInt(q[0].substring(0, 4))
	num2 = parseInt(w[0].substring(0, 4));
	var num3, num4;		
	if(q[0].length = 6) {
		num3 = parseInt(q[0].substring(5, 6));
	} else {
		num3 = parseInt(q[0].substring(5, 7));
	}
	if(w[0].length = 6) {
		num4 = parseInt(w[0].substring(5, 6));
	} else {
		num4 = parseInt(w[0].substring(5, 7));
	}
	console.log(num3,num4)
	var bol = false;
	//1.0.2.2添加至今判断的逻辑
	if(num1 <= year && num2 <= year) {
		bol = true;
	} else if(num1 <= year && b[0].value == '至今') {
		bol = true;
	}
	if(bol == true) {
		if(b[0].value == '至今') {
			return true;
		} else {
			if(num1 < num2){
				return true;
			}else if(num1 > num2) {
				return false;
			} else if(num1 = num2) {
				if(num3 <= num4) {
					return true;
				} else {
					return false;
				}
			} else {
				return true;
			}
		}
	} else {
		return false
	}
	//1.0.2.2添加至今判断的逻辑
}

//发布
$('#deliver_fabubtn').on('click', function() {
	//个人信息
	//	console.log('头像' + preview(document.getElementById("com-doc")).value);//头像
	//	console.log('姓名' + $('.personname')[0].value);//姓名
	//	console.log('性别' + $('.person_sex')[0].value);//性别
	//	console.log('电话' + $('.person_phone')[0].value);//电话
	//	console.log('微信' + $('.person_wx')[0].value);//微信
	//	console.log('工作状态' + $('.worktime')[0].value);//工作状态
	//	console.log('开始工作时间' + $('.begin_time')[0].value);//开始工作时间
	//	console.log('我的优势' + $('#myyoushi')[0].value);//我的优势
	var num = 0;
	if(preview(document.getElementById("com-doc")).value == ""){
		if(num == 0){
			alert("请选择头像");
			num = 1;
		}
	}
	
	if($('.personname')[0].value == "") {
		if(num == 0){
			alert("请填写姓名");
			num = 1;
		}
	}
	
	if($('.person_sex')[0].value == 0){
		if(num == 0){
			alert("请填写性别");
			num = 1;
		}
	}
	
	var reg = /^1[3|4|5|7|8][0-9]{9}$/; //验证规则
	var p = $('.person_phone')[0].value; //手机号码
	var l = reg.test(p); //验证结果，true/false
	if(l == false) {
		if(num == 0){
			alert("请填写正确手机号码");
			num = 1;
		}
	}
	
	if($('#myyoushi')[0].value == ""){
		if(num == 0){
			alert("请填写我的优势");
			num = 1;
		}
	}
	

	//求职意向
	//	console.log('期望职位' + $('#wyanzhengma').find('p')[0].innerText + "id" + $('#wyanzhengma').find('p')[0].getAttribute('value'));//期望职位和id
	//	var arr_hy = "";
	//	for(var i = 0;i<$('.select-res-hy').find('p').length;i++){
	//		if(i==0){
	//			arr_hy += $('.select-res-hy').find('p')[i].innerText;
	//		}else{
	//			arr_hy += '*' + $('.select-res-hy').find('p')[i].innerText;
	//		}		
	//	}
	//	console.log('期望行业' + arr_hy);//期望行业
	//	console.log('地点' + $('.addresss')[0].value);//期望地点
	//	console.log('薪资' + $('#wxinzi1')[0].value + 'K-' + $('#wxinzi1')[0].value + 'K');//薪资
	if($('.w-want').find('.w-wantworks').length == 0) {
		if(num == 0){
			alert("请填写求职意向");
			num = 1;
		}
	}
	

	//工作经历 
	//	console.log('公司全称' + $('.companyallname')[0].value);
	//	console.log('职位名称' + $('.optionsname')[0].value);
	//	console.log('所属部门 ' + $('.ss_bumen')[0].value);
	//	console.log('所属行业' + $('#w_sshysl')[0].value);
	//	console.log('职位类型' + $('#qw').find('p')[0].innerText + '职位id' + $('#qw').find('p')[0].getAttribute('value') + '标记id' + fid_id1);
	//	var arrskills = "";
	//	for(var i = 0;i<$('.bq_skills').find('p').length;i++){
	//		if(i==0){
	//			arrskills += $('.bq_skills').find('p')[i].innerText;
	//		}else{
	//			arrskills += "*" + $('.bq_skills').find('p')[i].innerText;
	//		}
	//	}				
	//	console.log('技能标签' + arrskills);
	//	console.log('时间' + $('#datetimepicker1')[0].value + '-' + $('#datetimepicker2')[0].value);
	//	console.log('工作业绩' + $('#w-work-contants')[0].value);
	//	console.log('工作内容' + $('#w-work-howwell')[0].value);
	if($('.work_hislis').find('.history-work').length == 0){
		if(num == 0){
			alert("请填写工作经历");
			num = 1;
		}
	}
	

	//项目经验
	//	console.log('项目名称' + $('.itemname')[0].value);
	//	console.log('项目角色' + $('.itemplay')[0].value);
	//	console.log('时间' + $('#datetimepicker3')[0].value + '-' + $('#datetimepicker4')[0].value);
	//	console.log('项目URL' + $('.item_url')[0].value);
	//	console.log('项目描述' + $('#w-itemtatil')[0].value);
	//	console.log('项目成就' + $('#w-itemyj')[0].value);
//	if($('.item_hislis').find('.history-item').length == 0) alert("请填写项目经验");

	//教育经验
	//	console.log('学校名称' + $('.schoolname')[0].value);
	//	console.log('专业名称' + $('.schitemname')[0].value);
	//	console.log('专业名称' + $('#schoolwellage')[0].value);
	//	console.log('在校时间' + $('.goschooltime')[0].value + '-' + $('.moveschooltime')[0].value);
	//	console.log('在校经历' + $('#w-school_jl')[0].value);
	if($('.school_hislis').find('.history-school').length == 0) {
		if(num == 0){
			alert("请填写在校经历");
			num = 1;
		}
	}
	
	if($('.school_hislis').find('.history-school').length != 0 &&
		$('.work_hislis').find('.history-work').length != 0 &&
		$('.w-want').find('.w-wantworks').length != 0 &&
		preview(document.getElementById("com-doc")).value != "" &&
		$('.personname')[0].value != "" &&
		$('.person_sex')[0].value != 0 &&
		l == true &&
		$('#myyoushi')[0].value != "") {
		var qzyx = "",
			ww, num; //求职意向
		for(var i = 0; i < $('.w-want').children('.w-wantworks').length; i++) {
			num = i + 1
			qzyx += "求职意向" + num;
			ww = $('.w-want').children('.w-wantworks')[i];
			var $ww = $(ww)
			for(var j = 0; j < $ww.find('span').length; j++) {
				if(j == 0) {
					qzyx += $ww.find('span')[j].innerText;
				} else {
					qzyx += '*' + $ww.find('span')[j].innerText;
				}
			}
		}
		console.log(qzyx)

		var gzjl = "",
			num2, tt; //工作经历
		for(var i = 0; i < $('.work_hislis').children('.history-work').length; i++) {
			num2 = i + 1
			gzjl += "工作经历" + num2;
			tt = $('.work_hislis').children('.history-work')[i];
			var $tt = $(tt)
			console.log($tt.find('.opsname_zw'))
			gzjl += "公司名" + $tt.find('.companyname')[0].innerText +
				"时间" + $tt.find('.worktime')[0].innerText +
				"职位名称" + $tt.find('.opsname_zw')[0].innerText +
				"职位类型" + $tt.find('.opsname_ry')[0].innerText +
				"工作内容" + $tt.find('.comcont')[0].innerText +
				"工作业绩" + $tt.find('.comyeji')[0].innerText +
				"工作技能" + $tt.find('.skillname')[0].innerText;
		}
		console.log(gzjl)

		var itemhis = "",
			num3, ii; //项目经验
		for(var i = 0; i < $('.item_hislis').children('.history-item').length; i++) {
			num3 = i + 1
			itemhis += "项目经验" + num3;
			ii = $('.item_hislis').children('.history-item')[i];
			var $ii = $(ii)
			itemhis += "项目名称" + $ii.find('.p_itemname')[0].innerText +
				"时间" + $ii.find('.itemtime')[0].innerText +
				"项目角色" + $ii.find('.itt_name')[0].innerText +
				"项目内容" + $ii.find('.item_comcont')[0].innerText +
				"项目业绩" + $ii.find('.item_comyeji')[0].innerText +
				"项目URL" + $ii.find('.itemurl')[0].innerText;
		}
		console.log(itemhis)

		var schoolhis = "",
			num4, ss; //教育经历
		for(var i = 0; i < $('.school_hislis').children('.history-school').length; i++) {
			num4 = i + 1
			schoolhis += "教育经历" + num4;
			ss = $('.school_hislis').children('.history-school')[i];
			var $ss = $(ss)
			schoolhis += "学校名称" + $ss.find('.school_name')[0].innerText +
				"时间" + $ss.find('.itemtime')[0].innerText +
				"专业" + $ss.find('.school_skill')[0].innerText +
				"学历" + $ss.find('.school_good')[0].innerText +
				"在校经历" + $ss.find('.school_comcont')[0].innerText
		}
		console.log(schoolhis)

		alert("头像：" + preview(document.getElementById("com-doc")).value +
			"姓名：" + $('.personname')[0].value +
			"性别：" + $('.person_sex')[0].value +
			"手机号：" + $('.person_phone')[0].value +
			'工作状态' + $('.worktime')[0].value +
			"微信号：" + $('.person_wx')[0].value +
			'开始工作时间' + $('.begin_time')[0].value +
			"我的优势：" + $('#myyoushi')[0].value +
			"求职意向：" + qzyx +
			"工作经历" + gzjl +
			"项目经验" + itemhis +
			"教育经历" + schoolhis
		)
	}
})

$('.schitemname').on('input porpertychange', function(event) {
	event.stopPropagation(); //阻止事件冒泡
	var tt = $(this).parent('div').find('.wsuggest')
	tt.show()
	//发送请求
	//$.get
	tt.find('ul').show();
	tt.find('ul').html('');
	var data_schoolshill = {
		"err_code": 0,
		"err_msg": "请求成功",
		"page": "-1",
		"data": [{
			"id": 1,
			"name": "物流工程"
		}, {
			"id": 2,
			"name": "金融"
		}, {
			"id": 3,
			"name": "计算机"
		}, {
			"id": 4,
			"name": "机械工程"
		}]
	}
	if(data_schoolshill.err_code == 0) {
		$.each(data_schoolshill.data, function(i, item) {
			tt.find('ul').append('<li value="' + item.id + '">' + item.name + '</li>')
		});
		var a = "";
		var b = "";
		tt.toggle();
		var tag = tt.toggle();
		$('li', tt.find('ul')).on('click', function() {
			item = $(this)[0];
			var fid = $(this).attr('value');
			$('.schitemname')[0].value = item.innerText;
			a = item.innerText;
			b = $('.schitemname')[0].value;
		})
		var flag = true;
		$(document).bind("click", function(e) { //点击空白处，设置的弹框消失
			var target = $(e.target);
			if(flag == true) {
				tag.hide();
				flag = false;
			}
		});
	} else {
		alert('网络开小车了')
	}
})

$('.schoolname').on('input porpertychange', function(event) {
	event.stopPropagation(); //阻止事件冒泡
	var tt = $(this).parent('div').find('.wsuggest')
	tt.show()
	//发送请求
	//$.get
	tt.find('ul').show();
	tt.find('ul').html('');
	var data_school = {
		"err_code": 0,
		"err_msg": "请求成功",
		"page": "-1",
		"data": [{
			"id": 1,
			"name": "大连大学"
		}, {
			"id": 2,
			"name": "大连理工大学"
		}, {
			"id": 3,
			"name": "大连海事大学"
		}, {
			"id": 4,
			"name": "大连交通大学"
		}]
	}
	if(data_school.err_code == 0) {
		$.each(data_school.data, function(i, item) {
			tt.find('ul').append('<li value="' + item.id + '">' + item.name + '</li>')
		});
		var a = "";
		var b = "";
		tt.toggle();
		var tag = tt.toggle();
		$('li', tt.find('ul')).on('click', function() {
			item = $(this)[0];
			var fid = $(this).attr('value');
			$('.schoolname')[0].value = item.innerText;
			a = item.innerText;
			b = $('.schoolname')[0].value;
		})
		var flag = true;
		$(document).bind("click", function(e) { //点击空白处，设置的弹框消失
			var target = $(e.target);
			if(flag == true) {
				tag.hide();
				flag = false;
			}
		});
	} else {
		alert('网络开小车了')
	}
})

//文本框字数限制输入
function textlength(obj1, num, obj2) {
	var lenInput = obj1.val().length;
	obj1.keyup(function() {
		lenInput = $(this).val().length;
		if(lenInput > 0 && lenInput <= num) {
			obj1.next().find('.textareaInput').html(lenInput);
			obj2.attr('disabled', false);
		} else {
			obj2.attr('disabled', true);
		}
	});
}
textlength($('#w-school_jl'), 3000, $('.vali_btn-6'));
textlength($('#w-itemtatil'), 3000, $('.vali_btn-6'));
textlength($('#w-itemyj'), 3000, $('.vali_btn-6'));
textlength($('.itemname'), 24, $('.vali_btn-6'));
textlength($('.itemplay'), 24, $('.vali_btn-6'));
textlength($('#w-work-howwell'), 3000, $('.vali_btn-6'));
textlength($('#w-work-contants'), 3000, $('.vali_btn-6'));
textlength($('.companyallname'), 24, $('.vali_btn-6'));
textlength($('.ss_bumen'), 24, $('.vali_btn-6'));
textlength($('.optionsname'), 24, $('.vali_btn-6'));
textlength($('#myyoushi'), 3000, $('.vali_btn-6'));
textlength($('.personname'), 5, $('.vali_btn-6'));

//期望职位
$('.add_wants').on('click', function() {
	$('.wantops').show()
	$('.wantadds').children('button.btn-success').show();
	$('.wantadds').children('button.btn-default').hide();
})
$('body').on('click', '.close', function() {
	if($(this).parents('.wantops').find('.wanttitle').length != 0) {
		$(this).parent().parent().hide();
		//清除已选样式
		$('#wyanzhengma')[0].innerText = "期望职位不能为空";
		$('.bq_hy')[0].innerText = "不限";
		$('#wxinzi1')[0].value = "0";
		$('#wxinzi2').hide();
		$('.addresss').get(0).value = '';
	}
})
//添加期望职位
$('button.btn-success', $('.wantadds')).on('click', function() {
	var arr_hy = "";
	if($('.select-res-hy').find('p').length == 0) {
		arr_hy = 不限;
	} else {
		for(var i = 0; i < $('.select-res-hy').find('p').length; i++) {
			if(i == 0) {
				arr_hy += $('.select-res-hy').find('p')[i].innerText;
			} else {
				arr_hy += '*' + $('.select-res-hy').find('p')[i].innerText;
			}
		}
	}
	var arr_xinzi = "";
	if($('#wxinzi1')[0].value == 0) {
		arr_xinzi = '面谈';
	} else {
		arr_xinzi = $('#wxinzi1')[0].value + 'K-' + $('#wxinzi1')[0].value + 'K';
	}
	if($('#wyanzhengma').find('p')[0].innerText != "" && $('.addresss')[0].value != "") {
		var num = 5;
		var divs = document.createElement("div");
		divs.className = 'w-wantworks';
		divs.setAttribute('val', num);
		divs.innerHTML += '<div class="w-works">' +
			'<span class="label-text" val="' + $('#wyanzhengma').find('p')[0].getAttribute('value') + '">' +
			$('#wyanzhengma').find('p')[0].innerText +
			'</span>' +
			'<em class="vline"></em>' +
			'<span class="label-text">' +
			arr_xinzi +
			'</span>' +
			'<em class="vline"></em>' +
			'<span class="label-text">' +
			arr_hy +
			'</span>' +
			'<em class="vline"></em>' +
			'<span class="label-text">' +
			$('.addresss')[0].value +
			'</span>' +
			'<div class="op">' +
			'<a href="javascript:;" class="link-edit">编辑</a>' +
			'<em></em>' +
			'<a href="javascript:;" class="link-delete">删除</a>' +
			'</div>' +
			'</div>';

		//发送请i去
		//$.get
		var err_code = 0;
		if(err_code == 0) {
			$('.w-want').get(0).appendChild(divs);
			$('.wantops').hide();
			//清除已选样式
			$('#wyanzhengma')[0].innerText = "期望职位不能为空";
			$('.bq_hy')[0].innerText = "不限";
			$('#wxinzi1')[0].value = "0";
			$('#wxinzi2').hide();
			$('.addresss').get(0).value = '';
		}
	}
})
//编辑期望职位
$('body').on('click', '.link-edit', function() {
	if($(this).parents('.w-want').find('.w-works').length != 0) {
		var wtitem = $(this).parent().parent();
		$('.wantops').show()
		$('.wantadds').children('button.btn-success').hide();
		$('.wantadds').children('button.btn-default').show();
		//获取当前的值
		$('#wyanzhengma')[0].innerHTML = '<p value="' + $($(this).parent().parent().find('span')[0]).attr("val") + '">' + $(this).parent().parent().find('span')[0].innerText + '</p>';
		$('.bq_hy').html('');
		if($(this).parent().parent().find('span')[2].innerText == "不限") {
			$('.bq_hy')[0].innerHTML = $(this).parent().parent().find('span')[2].innerText;
			console.log(1)
		} else {
			var s = $(this).parent().parent().find('span')[2].innerText.split("*");
			for(var i = 0; i < s.length; i++) {
				$('.bq_hy')[0].innerHTML += '<p>' + s[i] + '</p>';
			}
			console.log(2)
		}
		if($(this).parent().parent().find('span')[1].innerText == "面谈") {
			$('#wxinzi1')[0].value = "0";
		} else {
			var x = $(this).parent().parent().find('span')[1].innerText.split('-');
			x1 = parseInt(x[0]);
			x2 = parseInt(x[1]);
			$('#wxinzi1')[0].value = x1;
			$('#wxinzi2').show();
			$('#wxinzi2')[0].value = x2;
		}
//		console.log(x1, x2)
		$('.addresss').get(0).value = $(this).parent().parent().find('span')[3].innerText;
		$('button.btn-default', $('.wantadds')).unbind('click').on('click', function() {
			if($('#wyanzhengma').find('p')[0].innerText != "" && $('.addresss')[0].value != "") {
				var arr_hy = ""; //技能
				if($('.select-res-hy').find('p').length == 0) {
					arr_hy = 不限;
				} else {
					for(var i = 0; i < $('.select-res-hy').find('p').length; i++) {
						if(i == 0) {
							arr_hy += $('.select-res-hy').find('p')[i].innerText;
						} else {
							arr_hy += '*' + $('.select-res-hy').find('p')[i].innerText;
						}
					}
				}

				var arr_xinzi = ""; //薪资
				if($('#wxinzi1')[0].value == 0) {
					arr_xinzi = '面谈';
				} else {
					arr_xinzi = $('#wxinzi1')[0].value + 'K-' + $('#wxinzi2')[0].value + 'K';
				}
				alert()
				//发送请求
				//￥。get
				var err_code = 0;
				if(err_code == 0) {
					$(wtitem.find('span')[0]).attr('val', $('#wyanzhengma').find('p')[0].getAttribute('value'))
					wtitem.find('span')[0].innerText = $('#wyanzhengma').find('p')[0].innerText;
					wtitem.find('span')[1].innerText = arr_xinzi;
					wtitem.find('span')[2].innerText = arr_hy;
					wtitem.find('span')[3].innerText = $('.addresss')[0].value;
					$('.wantops').hide();
					//清除已选样式
					$('#wyanzhengma')[0].innerText = "期望职位不能为空";
					$('.bq_hy')[0].innerText = "不限";
					$('#wxinzi1')[0].value = "0";
					$('#wxinzi2').hide();
					$('.addresss').get(0).value = '';
				} else {
					alert("网络开小差");
				}
			}
		})
	}
})

//删除
$('body').on('click', '.link-delete', function() {
	if($(this).parents('.w-want').find('.w-wantworks').length != 0) {
		//发送求情
		//$.get()
		var err_code = 0
		if(err_code == 0) {
			$(this).closest('.w-wantworks').remove();
		} else {
			alert('网络打酱油了')
		}
	}
})

//工作经历
$('.add_workhis').on('click', function() {
	$('#w-history-exp').show();
	$('.workadds').children('button.btn-success').show();
	$('.workadds').children('button.btn-default').hide();
})
$('body').on('click', '.close', function() {
	if($(this).parents('#w-history-exp').find('.worktitle').length != 0) {
		$(this).parent().parent().hide();
		//清除已选样式
		$('.companyallname')[0].value = "";
		$('.optionsname')[0].value = "";
		$('.ss_bumen')[0].value = "";
		$('#w_sshysl')[0].value = 0;
		$('#qw')[0].innerText = "选择期望职位";
		$('.bq_skills')[0].innerText = "必填";
		$('#datetimepicker1')[0].value = "";
		$('#datetimepicker2')[0].value = "";
		$('#w-work-contants')[0].value = "";
		$('#w-work-howwell')[0].value = "";
	}
})
$('button.btn-success', $('.workadds')).on('click', function() {
	fid_id1 = 0;
	var arrskills = "";
	for(var i = 0; i < $('.bq_skills').find('p').length; i++) {
		if(i == 0) {
			arrskills += $('.bq_skills').find('p')[i].innerText;
		} else {
			arrskills += "*" + $('.bq_skills').find('p')[i].innerText;
		}
	}
	if(timeb($("#datetimepicker1"), $("#datetimepicker2")) == false) alert('请填写正确时间段')
	if($('.companyallname')[0].value != "" &&
		$('.optionsname')[0].value != "" &&
		$('.ss_bumen')[0].value != "" &&
		$('#w_sshysl')[0].value != "" &&
		$('#qw').find('p').length != 0 &&
		$('.bq_skills').find('p').length != 0 &&
		timeb($("#datetimepicker1"), $("#datetimepicker2")) == true &&
		$('#w-work-contants')[0].value != "" &&
		$('#w-work-howwell')[0].value != "") {
		var divs = document.createElement("div");
		//给 divs 一个val值
		var num = 2;
		divs.className = 'history-work';
		divs.setAttribute('val', num);
		divs.innerHTML += '<div class="op">' +
			'<span class="worktime">' + $('#datetimepicker1')[0].value + '-' + $('#datetimepicker2')[0].value + '</span>' +
			'<a href="javascript:;" class="link-edit">编辑</a>' +
			'<a href="javascript:;" class="link-delete">删除</a>' +
			'</div>' +
			'<h4 class="companyname">' + $('.companyallname')[0].value + '</h4>' +
			'<p class="opsname">' +
			'<span class="opsname_zw">' + $('.optionsname')[0].value + '</span>' +
			'<span class="opsname_ry" val="' + $('#qw').find('p')[0].getAttribute('value') + '">' + $('#qw').find('p')[0].innerText +
			'<div class="jl_id" style="display:none;">' + fid_id1 + '</div>' +
			'</span>' +
			'<span class="opsname_bm" style="display:none;">' + $('.ss_bumen')[0].value + '</span>' +
			'<span class="opsname_hy" style="display:none;">' + $('#w_sshysl')[0].value + '</span>' +
			'</p>' +
			'<div class="text">' +
			'<h4>工作内容</h4>' +
			'<pre class="comcont">' + $('#w-work-contants')[0].value + '</pre>' +
			'</div>' +
			'<div class="text">' +
			'<h4>工作业绩</h4>' +
			'<pre class="comyeji">' + $('#w-work-howwell')[0].value + '</pre>' +
			'</div>' +
			'<p class="skillname">' + arrskills + '</p>';
		//发送请求
		//$.get
		var err_code = 0;
		if(err_code == 0) {
			$('.work_hislis').get(0).appendChild(divs);
			$('#w-history-exp').hide();
			//清除样式
			$('.companyallname')[0].value = "";
			$('.optionsname')[0].value = "";
			$('.ss_bumen')[0].value = "";
			$('#w_sshysl')[0].value = 0;
			$('#qw')[0].innerText = "选择期望职位";
			$('.bq_skills')[0].innerText = "必填";
			$('#datetimepicker1')[0].value = "";
			$('#datetimepicker2')[0].value = "";
			$('#w-work-contants')[0].value = "";
			$('#w-work-howwell')[0].value = "";
		}
	}

})

//编辑工作经历
$('body').on('click', '.link-edit', function() {
	if($(this).parents('.work_hislis').find('.history-work').length != 0) {
		var workitem = $(this).parent().parent();
		$('#w-history-exp').show();
		$('.workadds').children('button.btn-success').hide();
		$('.workadds').children('button.btn-default').show();
		$('.companyallname')[0].value = workitem.find('.companyname')[0].innerText; //公司全称
		$('.optionsname')[0].value = workitem.find('.opsname_zw')[0].innerText; //职位名称
		$('#qw')[0].innerHTML = '<p value="' + workitem.find('.opsname_ry')[0].getAttribute('val') + '">' + workitem.find('.opsname_ry')[0].innerText + '</p>';
		//		$($('#qw').find('p')[0]).attr('value', workitem.find('.opsname_ry')[0].getAttribute('val')); //职位类型id
		//		$('#qw').find('p')[0].innerText = workitem.find('.opsname_ry')[0].innerText; //职位类型
		fid_id1 = workitem.find('.jl_id')[0].innerText; //记录ID
		$('.ss_bumen')[0].value = workitem.find('.opsname_bm')[0].innerText; //所属部门
		$('#w_sshysl')[0].value = workitem.find('.opsname_hy')[0].innerText; //所属行业
		var skill = workitem.find('.skillname')[0].innerText.split("*"); //技能标签
		console.log(skill)
		$('.bq_skills').html('')
		for(var i = 0; i < skill.length; i++) {
			$('.bq_skills')[0].innerHTML += '<p>' + skill[i] + '</p>';
		}
		$('#datetimepicker1')[0].value = workitem.find('.worktime')[0].innerText.split("-")[0];
		$('#datetimepicker2')[0].value = workitem.find('.worktime')[0].innerText.split("-")[1];
		$('#w-work-contants')[0].value = workitem.find('.comcont')[0].innerText; //工作内容
		$('#w-work-howwell')[0].value = workitem.find('.comyeji')[0].innerText; //工作业绩

		$('button.btn-default', $('.workadds')).unbind('click').on('click', function() {
			if($('.companyallname')[0].value != "" &&
				$('.optionsname')[0].value != "" &&
				$('.ss_bumen')[0].value != "" &&
				$('#w_sshysl')[0].value != "" &&
				$('#qw').find('p').length != 0 &&
				$('.bq_skills').find('p').length != 0 &&
				timeb($("#datetimepicker1"), $("#datetimepicker2")) == true &&
				$('#w-work-contants')[0].value != "" &&
				$('#w-work-howwell')[0].value != "") {

				var arrskills = ""; //技能标签
				for(var i = 0; i < $('.bq_skills').find('p').length; i++) {
					if(i == 0) {
						arrskills += $('.bq_skills').find('p')[i].innerText;
					} else {
						arrskills += "*" + $('.bq_skills').find('p')[i].innerText;
					}
				}
				alert()
				//发送请求
				//￥。get
				var err_code = 0;
				if(err_code == 0) {
					workitem.find('.companyname')[0].innerText = $('.companyallname')[0].value;
					workitem.find('.opsname_zw')[0].innerText = $('.optionsname')[0].value;
					workitem.find('.opsname_bm')[0].innerText = $('.ss_bumen')[0].value;
					workitem.find('.opsname_hy')[0].innerText = $('#w_sshysl')[0].value;
					workitem.find('.opsname_ry')[0].innerHTML = '<span class="opsname_ry" val="' + $('#qw').find('p')[0].getAttribute('value') + '">' +
						$('#qw').find('p')[0].innerText +
						'<div class="jl_id" style="display:none;">' + fid_id1 + '</div>' +
						'</span>';
					workitem.find('.skillname')[0].innerText = arrskills;
					workitem.find('.worktime')[0].innerText = $('#datetimepicker1')[0].value + '-' + $('#datetimepicker2')[0].value;
					workitem.find('.comcont')[0].innerText = $('#w-work-contants')[0].value;
					workitem.find('.comyeji')[0].innerText = $('#w-work-howwell')[0].value;
					//清除样式
					$('#w-history-exp').hide();
					$('.companyallname')[0].value = "";
					$('.optionsname')[0].value = "";
					$('.ss_bumen')[0].value = "";
					$('#w_sshysl')[0].value = 0;
					$('#qw')[0].innerText = "选择期望职位";
					$('.bq_skills')[0].innerText = "必填";
					$('#datetimepicker1')[0].value = "";
					$('#datetimepicker2')[0].value = "";
					$('#w-work-contants')[0].value = "";
					$('#w-work-howwell')[0].value = "";
				}
			}
		})
	}
})
//删除
$('body').on('click', '.link-delete', function() {
	if($(this).parents('.work_hislis').find('.history-work').length != 0) {
		//发送求情
		//$.get()
		var err_code = 0
		if(err_code == 0) {
			$(this).closest('.history-work').remove();
		} else {
			alert('网络打酱油了')
		}
	}
})

//项目
$('.add_items').on('click', function() {
	$('.add_itemkuang').show();
	$('.itemadds').children('button.btn-success').show();
	$('.itemadds').children('button.btn-default').hide();
})
$('body').on('click', '.close', function() {
	if($(this).parents('.add_itemkuang').find('.worktitle').length != 0) {
		$(this).parent().parent().hide();
		//清除已选样式
		$('.itemname')[0].value = "";
		$('.itemplay')[0].value = "";
		$('#datetimepicker3')[0].value = "";
		$('#datetimepicker4')[0].value = "";
		$('.item_url')[0].value = "";
		$('#w-itemtatil')[0].value = "";
		$('#w-itemyj')[0].value = "";
	}
})
//添加
$('button.btn-success', $('.itemadds')).on('click', function() {
	console.log(1111)
	if(timeb($("#datetimepicker3"), $("#datetimepicker4")) == false) alert('请填写正确时间段');
	console.log($('.itemname')[0].value)
	if($('.itemname')[0].value != "" && $('.itemplay')[0].value != "" && timeb($("#datetimepicker3"), $("#datetimepicker4")) == true && $('#w-itemtatil')[0].value != "") {
		console.log(2)
		var divs = document.createElement("div");
		//给 divs 一个val值
		var num = 2;
		divs.className = 'history-item';
		divs.setAttribute('val', num);
		divs.innerHTML += '<div class="op">' +
			'<span class="itemtime">' + $('#datetimepicker3')[0].value + '-' + $('#datetimepicker4')[0].value + '</span>' +
			'<a href="javascript:;" class="link-edit">编辑</a>' +
			'<a href="javascript:;" class="link-delete">删除</a>' +
			'</div>' +
			'<h4 class="p_itemname">' + $('.itemname')[0].value + '</h4>' +
			'<p class="itt_name">' +
			$('.itemplay')[0].value +
			'</p>' +
			'<div class="text">' +
			'<h4>项目内容</h4>' +
			'<pre class="item_comcont">' + $('#w-itemtatil')[0].value + '</pre>' +
			'</div>' +
			'<div class="text" style="display: none;">' +
			'<h4>项目业绩</h4>' +
			'<pre class="item_comyeji">' + $('#w-itemyj')[0].value + '</pre>' +
			'</div>' +
			'<p class="itemurl" style="display: none;">' + $('.item_url')[0].value + '</p>';
		//发送请求
		//$.get
		var err_code = 0;
		if(err_code == 0) {
			console.log(3)
			$('.item_hislis').get(0).appendChild(divs);
			$('.add_itemkuang').hide();
			//清除样式
			$('.itemname')[0].value = "";
			$('.itemplay')[0].value = "";
			$('#datetimepicker3')[0].value = "";
			$('#datetimepicker4')[0].value = "";
			$('.item_url')[0].value = "";
			$('#w-itemtatil')[0].value = "";
			$('#w-itemyj')[0].value = "";
		}
	}
})

//编辑项目经验
$('body').on('click', '.link-edit', function() {
	if($(this).parents('.item_hislis').find('.history-item').length != 0) {
		var ititem = $(this).parent().parent();
		$('.add_itemkuang').show();
		$('.itemadds').children('button.btn-success').hide();
		$('.itemadds').children('button.btn-default').show();
		$('.itemname')[0].value = ititem.find('.p_itemname')[0].innerText;
		$('.itemplay')[0].value = ititem.find('.itt_name')[0].innerText;
		$('#datetimepicker3')[0].value = ititem.find('.itemtime')[0].innerText.split("-")[0];
		$('#datetimepicker4')[0].value = ititem.find('.itemtime')[0].innerText.split("-")[1];
		$('.item_url')[0].value = ititem.find('.itemurl')[0].innerText;
		$('#w-itemtatil')[0].value = ititem.find('.item_comcont')[0].innerText;
		$('#w-itemyj')[0].value = ititem.find('.item_comyeji')[0].innerText;

		$('button.btn-default', $('.itemadds')).unbind('click').on('click', function() {
			if(timeb($("#datetimepicker3"), $("#datetimepicker4")) == false) alert('请填写正确时间段')
			if($('.itemname')[0].value != "" && $('.itemplay')[0].value != "" && timeb($("#datetimepicker3"), $("#datetimepicker4")) == true && $('#w-itemtatil')[0].value != "") {
				alert();
				//发送请求
				//￥。get
				var err_code = 0;
				if(err_code == 0) {
					ititem.find('.p_itemname')[0].innerText = $('.itemname')[0].value;
					ititem.find('.itt_name')[0].innerText = $('.itemplay')[0].value;
					ititem.find('.itemtime')[0].innerText = $('#datetimepicker3')[0].value + $('#datetimepicker4')[0].value;
					ititem.find('.itemurl')[0].innerText = $('.item_url')[0].value;
					ititem.find('.item_comcont')[0].innerText = $('#w-itemtatil')[0].value;
					ititem.find('.item_comyeji')[0].innerText = $('#w-itemyj')[0].value;
					$('.add_itemkuang').hide();
					//清除样式
					$('.itemname')[0].value = "";
					$('.itemplay')[0].value = "";
					$('#datetimepicker3')[0].value = "";
					$('#datetimepicker4')[0].value = "";
					$('.item_url')[0].value = "";
					$('#w-itemtatil')[0].value = "";
					$('#w-itemyj')[0].value = "";
				}
			}
		})
	}
})
//删除
$('body').on('click', '.link-delete', function() {
	if($(this).parents('.item_hislis').find('.history-item').length != 0) {
		//发送求情
		//$.get()
		var err_code = 0
		if(err_code == 0) {
			$(this).closest('.history-item').remove();
		} else {
			alert('网络打酱油了')
		}
	}
})

//在校经历
$('.add_schools').on('click', function() {
	$('.school-his-kuang').show();
	$('.schooladds').children('button.btn-success').show();
	$('.schooladds').children('button.btn-default').hide();
})
$('body').on('click', '.close', function() {
	if($(this).parents('.school-his-kuang').find('.worktitle').length != 0) {
		$(this).parent().parent().hide();
		//清除已选样式
		$('.schoolname')[0].value = "";
		$('.schitemname')[0].value = "";
		$('#schoolwellage')[0].value = "中专以下";
		$('.goschooltime')[0].value = "请选择";
		$('.moveschooltime')[0].value = "至今";
		$('#w-school_jl')[0].value = "";
	}
})

//添加

$('button.btn-success', $('.schooladds')).on('click', function() {
	if(sctime() == false) alert('请选择正确的时间段')
	if($('.schoolname')[0].value != "" && $('.schitemname')[0].value != "" && sctime() == true) {
		var divs = document.createElement("div");
		//给 divs 一个val值
		var num = 2;
		divs.className = 'history-school';
		divs.setAttribute('val', num);
		console.log($('.schoolname')[0].value)
		divs.innerHTML += '<div class="op">' +
			'<span class="itemtime">' + $('.goschooltime')[0].value + '-' + $('.moveschooltime')[0].value + '</span>' +
			'<a href="javascript:;" class="link-edit">编辑</a>' +
			'<a href="javascript:;" class="link-delete">删除</a>' +
			'</div>' +
			'<h4 class="school_name">' + $('.schoolname')[0].value + '</h4>' +
			'<div class="schoolskill">' +
			'<span class="school_skill">' + $('.schitemname')[0].value + '</span><em></em>' +
			'<span class="school_good">【' + $('#schoolwellage')[0].value + '】</span>' +
			'</div>' +
			'<div class="text" style="display: none;">' +
			'<h4>在校经历</h4>' +
			'<pre class="school_comcont">' + $('#w-school_jl')[0].value + '</pre>' +
			'</div>';
		//发送请求
		//$.get
		var err_code = 0;
		if(err_code == 0) {
			$('.school_hislis').get(0).appendChild(divs);
			$('.school-his-kuang').hide();
			//清除样式
			$('.schoolname')[0].value = "";
			$('.schitemname')[0].value = "";
			$('#schoolwellage')[0].value = "中专以下";
			$('.goschooltime')[0].value = "请选择";
			$('.moveschooltime')[0].value = "至今";
			$('#w-school_jl')[0].value = "";
		}
	}
})

function sctime() {
	var t1, t2;
	if($('.goschooltime')[0].value == '请选择') {
		return false;
	}
	if($('.moveschooltime')[0].value == '至今') {
		return true
	} else {
		t1 = parseInt($('.goschooltime')[0].value.substring(0, 4));
		t2 = parseInt($('.moveschooltime')[0].value.substring(0, 4));
		if(t1 <= t2) {
			return true;
		} else {
			return false;
		}
	}
}

//编辑在校经历
$('body').on('click', '.link-edit', function() {
	if($(this).parents('.school_hislis').find('.history-school').length != 0) {
		var scitem = $(this).parent().parent();
		$('.school-his-kuang').show();
		$('.schooladds').children('button.btn-success').hide();
		$('.schooladds').children('button.btn-default').show();
		//教育经验
		//	console.log('学校名称' + $('.schoolname')[0].value);
		//	console.log('专业名称' + $('.schitemname')[0].value);
		//	console.log('学历' + $('#schoolwellage')[0].value);
		//	console.log('在校时间' + $('.goschooltime')[0].value + '-' + $('.moveschooltime')[0].value);
		//	console.log('在校经历' + $('#w-school_jl')[0].value);
		$('.schoolname')[0].value = scitem.find(".school_name")[0].innerText;
		$('.schitemname')[0].value = scitem.find(".school_skill")[0].innerText;
		console.log(scitem.find(".school_good")[0].innerText)
		var t = scitem.find(".school_good")[0].innerText;
		var g = t.substring(1,t.length-1);
		console.log(g)
		$('#schoolwellage')[0].value = g;
		$('.goschooltime')[0].value = scitem.find(".itemtime")[0].innerText.split("-")[0];
		$('.moveschooltime')[0].value = scitem.find(".itemtime")[0].innerText.split("-")[1];
		$('#w-school_jl')[0].value = scitem.find(".school_comcont")[0].innerText;
		$('button.btn-default', $('.schooladds')).unbind('click').on('click', function() {
			if(sctime() == false) alert('请选择正确的时间段')
			if($('.schoolname')[0].value != "" && $('.schitemname')[0].value != "" && sctime() == true) {
				alert()
				//发送请求
				//￥.get
				var err_code = 0;
				if(err_code == 0) {
					scitem.find(".school_name")[0].innerText = $('.schoolname')[0].value;
					scitem.find(".school_skill")[0].innerText = $('.schitemname')[0].value;
					scitem.find(".school_good")[0].innerText = '【' + $('#schoolwellage')[0].value + '】';
					scitem.find(".itemtime")[0].innerText = $('.goschooltime')[0].value + '-' + $('.moveschooltime')[0].value;
					scitem.find(".school_comcont")[0].innerText = $('#w-school_jl')[0].value;
					$('.school-his-kuang').hide();
					//清除样式
					$('.schoolname')[0].value = "";
					$('.schitemname')[0].value = "";
					$('#schoolwellage')[0].value = "中专以下";
					$('.goschooltime')[0].value = "请选择";
					$('.moveschooltime')[0].value = "至今";
					$('#w-school_jl')[0].value = "";
				}
			}
		})

	}
})
//删除
$('body').on('click', '.link-delete', function() {
	if($(this).parents('.school_hislis').find('.history-school').length != 0) {
		//发送求情
		//$.get()
		var err_code = 0
		if(err_code == 0) {
			$(this).closest('.history-school').remove();
		} else {
			alert('网络打酱油了')
		}
	}
})