//上传图片
function preview(file) { //预览图片得到图片base64
	var prevDiv = document.getElementById('comlogo');
	if(file.files && file.files[0]) {
		var reader = new window.FileReader();
		reader.onload = function(evt) {
			prevDiv.innerHTML = '<img src="' + evt.target.result + '" />';
		}
		reader.readAsDataURL(file.files[0]);
	} else {
		prevDiv.innerHTML = '<div class="img" style="filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(sizingMethod=scale,src=\'' + file.value + '\'"></div>';
	}
	return file;
}

var data1 = {
	"err_code": 0,
	"err_msg": "请求成功",
	"page": "-1",
	"data": ""
}

//职位发布 和 编辑
$('#ppub_fabubtn,#ppub_savebtn').unbind('click').on('click', function() {
	//	console.log("logo" + preview(document.getElementById("com-doc")).value)
	//	console.log("公司全称" + $('.companyallname')[0].value); //公司全称
	//	console.log("公司简称" + $('.companybabyname')[0].value); //公司简称
	//	console.log("人员规模" + $('.perpleall')[0].value); //人员规模
	//	console.log("所属行业" + $('.bq_hy').find('p')[0].innerText + 'id' + $('.bq_hy').find('p')[0].getAttribute('value')); //所属行业及id
	var strlight = "";
	for(var i = 0; i < $('#inter').find('p').length; i++) {
		if(i == 0) {
			strlight += $('#inter').find('p')[i].innerText;
		} else {
			strlight += "-" + $('#inter').find('p')[i].innerText;
		}
	}
	//	console.log("团队亮点" + strlight); //团队亮点及id
	//	console.log("融资阶段" + $('.com_rijd')[0].value); //融资阶段
	//	console.log("公司官网" + $('.w-www')[0].value); //公司官网
	//	console.log("职位名称" + $('.wopname')[0].value); //职位名称
	//	console.log("职位类型" + $('#qw').find('p')[0].innerText + 'id' + $('#qw').find('p')[0].getAttribute('value') + "技能请求id" + fid_id1); //职位类型及id和技能请求id
	var strskill = "";
	for(var i = 0; i < $('.bq_skills').find('p').length; i++) {
		if(i == 0) {
			strskill += $('.bq_skills').find('p')[i].innerText;
		} else {
			strskill += "-" + $('.bq_skills').find('p')[i].innerText;
		}
	}
	//	console.log("技能要求" + strskill); //技能要求
	//	console.log("工作城市" + $('.addresss')[0].value); //工作城市
	//	console.log("工作地点" + $('.workadd')[0].value); //工作点滴
	var xinzi = "";
	xinzi = $('#wxinzi1')[0].value + "K-" + $('#wxinzi2')[0].value + 'K';
	//	console.log("薪资范围" + xinzi); //薪资范围
	//	console.log("经验要求" + $('.workhis')[0].value); //经验要求
	//	console.log("学历要求" + $('.meducation')[0].value); //学历要求
	//	console.log("职位描述" + $('#w-txtrea')[0].value); //职位描述
	//	console.log("接收简历邮箱" + $('.inputElem')[0].value); //接收简历邮箱
	var reg = /^[a-z0-9]+([._\\-]*[a-z0-9])*@([a-z0-9]+[-a-z0-9]*[a-z0-9]+.){1,63}[a-z0-9]+$/; //邮箱验证
	var num = 0
	if(preview(document.getElementById("com-doc")).value == "") {
		if(num == 0) {
			alert('请填写公司logo');
			num = 1;
		}
	}
	if($('.companyallname')[0].value == "") {
		if(num == 0) {
			alert('请填写公司全称');
			num = 1;
		}
	}
	if($('.companybabyname')[0].value == "") {
		if(num == 0) {
			alert('请填写公司简称')
			num = 1;
		}
	}

	if($('.bq_hy').find('p').length == 0) {
		if(num == 0) {
			alert('请选择公司所属行业');
			num = 1;
		}
	}

	if($('.wopname')[0].value == "") {
		if(num == 0) {
			alert('请填写招聘职位名称');
			num = 1;
		}
	}

	if($('#qw').find('p').length == 0) {
		if(num == 0) {
			alert('请选填职位类型');
			num = 1;
		}
	}

	if($('.bq_skills').find('p').length == 0) {
		if(num == 0) {
			alert('请选填职位所需要的技能标签');
			num = 1;
		}
	}

	if($('.addresss')[0].value == "") {
		if(num == 0) {
			alert('请填写工作城市');
			num = 1;
		}
	}

	if($('.workadd')[0].value == "") {
		if(num == 0) {
			alert('请填写工作地点');
			num = 1;
		}
	}

	if($('#wxinzi1')[0].value == 0) {
		if(num == 0) {
			alert('请选择薪资范围');
			num = 1;
		}
	}

	if($('#w-txtrea')[0].value == "") {
		if(num == 0) {
			alert('请对职位进行简单描述');
			num = 1;
		}
	}
	
	if(reg.test($('.inputElem')[0].value) == false) {
		if(num == 0) {
			alert('请填写正确邮箱');
			num = 1;
		}
	}
	if(preview(document.getElementById("com-doc")).value != "" &&
		$('.companyallname')[0].value != "" &&
		$('.companybabyname')[0].value != "" &&
		$('.bq_hy').find('p').length != 0 &&
		$('.wopname')[0].value != "" &&
		$('#qw').find('p').length != 0 &&
		$('.bq_skills').find('p').length != 0 &&
		$('.addresss')[0].value != "" &&
		$('.workadd')[0].value != "" &&
		$('#wxinzi1')[0].value != 0 &&
		$('#w-txtrea')[0].value != "" &&
		reg.test($('.inputElem')[0].value) == true
	) {
		alert("logo" + preview(document.getElementById("com-doc")).value +
			";公司全称" + $('.companyallname')[0].value +
			";公司简称" + $('.companybabyname')[0].value +
			";人员规模" + $('.perpleall')[0].value +
			";所属行业" + $('.bq_hy').find('p')[0].innerText + 'id' + $('.bq_hy').find('p')[0].getAttribute('value') +
			";团队亮点" + strlight +
			";融资阶段" + $('.com_rijd')[0].value +
			";公司官网" + $('.w-www')[0].value +
			";职位名称" + $('.wopname')[0].value +
			";职位类型" + $('#qw').find('p')[0].innerText + 'id' + $('#qw').find('p')[0].getAttribute('value') + "技能请求id" + fid_id1 +
			";技能要求" + strskill +
			";工作城市" + $('.addresss')[0].value +
			";工作地点" + $('.workadd')[0].value +
			";薪资范围" + xinzi +
			";经验要求" + $('.workhis')[0].value +
			";学历要求" + $('.meducation')[0].value +
			";职位描述" + $('#w-txtrea')[0].value +
			";接收简历邮箱" + $('.inputElem')[0].value)
		//发送请求
		//$.get
		var data = {
			"err_code": 0,
			"err_msg": "请求成功",
			"page": "-1",
			"data": ""
		}
		if(data.err_code == 0) {
			var val = 4
			console.log(1111)
		} else {
			alert('网络正在火星上漫步')
		}
		console.log(111);
	} else {
		alert("请将标注必填和必选的信息填写完整");
	}
})

//文字框字数输入限制
//文本框字数限制输入
function textlength(obj1, num) {
	var lenInput = obj1.val().length;
	obj1.keyup(function() {
		lenInput = $(this).val().length;
		if($(this)[0].value == "") {
			lenInput = 0
		}
		if(lenInput >= 0 && lenInput <= num) {
			obj1.next().find('.textareaInput').html(lenInput);
		}
	});
}
textlength($('.companyallname'), 24); //公司全称
textlength($('.companybabyname'), 24); //公司昵称
textlength($('.w-www'), 50); //公司官网
textlength($('.workadd'), 80); //工作地点
textlength($('.wopname'), 12); //职位名称
textlength($('#w-txtrea'), 3000);
//编辑字数修正
function textlength_els(obj1) {
	var lenInput = obj1[0].value.length;
	console.log(obj1[0].value);
	obj1.next().find('.textareaInput').html(lenInput);
}

//删除职位
$('.ops_del').on('click', function() {
	var value = 5 //删除对应传过来该页编制职位的id  暂记5
	alert("删除职位" + val);
	//发送请求
	//$.get()
	var data = {
		"err_code": 0,
		"err_msg": "请求成功",
		"page": "-1",
		"data": ""
	}
	if(data.err_code == 0) {
		//成功 职位管理页面进行相应的改变

	} else {
		alert('网络开小车 了');
	}
})
//期望城市请求
var citybol = false;
$('.addresss').on('keyup', function() {
	//发送请求
	//获得数据，占记
	citybol = false;
	$('#address').html('');
	var data_address = {
		"err_code": 0,
		"err_msg": "请求成功",
		"page": "-1",
		"data": [{
			"id": 1,
			"name": "大连"
		}, {
			"id": 2,
			"name": "大同"
		}, {
			"id": 3,
			"name": "大山"
		}, {
			"id": 4,
			"name": "大大"
		}]
	}
	if(data_address.err_code == 0) {
		$.each(data_address.data, function(i, item) {
			$('#address').append('<li value="' + item.id + '">' + item.name + '</li>')
		});
	} else {
		alert("请检查网络");
	}
	$('.wsuggest').show();
	var a = "",
		b = "";
	$('li', $('#address')).on('click', function() {
		var item = $(this)[0];
		var fid = $(this).attr('value');
		$('.addresss')[0].value = item.innerText;
		a = item.innerText;
		b = $('.addresss')[0].value;
		$(document).bind('click', function() {
			console.log(11)
			if($('.addresss')[0].value == item.innerText) {
				$('.addresss')[0].value = item.innerText;
			} else {
				$('.addresss')[0].value = "";
			}
			$('.wsuggest').hide();
			citybol = true;
		})
	})
	$(document).bind('click', function() {
		if(b == a) {
			$('.addresss')[0].value = a;
		} else {
			$('.addresss')[0].value = "";
		}
		$('.wsuggest').hide();
	})
	if($('.addresss')[0].value == "") {
		$('.wsuggest').hide();
	}
})
//1.0.2.3	
//团队亮点
inter($(".inter_xuan"), $(".inter_p"));
//所属行业
hy($('.select-box-opkills'), $('.select-res-opkills'));
//职位类型
history($('.select-box-his'), $('.select-res-his'), $('#qw'), comeback);
//技能标签
kills($('.select-box-hiskills'), $('.select-res-hiskills'));

//地址
var addresxy
$('.workadd').on('click', function() {
	console.log(citybol)
	if($('.addresss')[0].value == "" || citybol == false) {
		alert("请先填写工作城市");
	} else{
		$('#baiduditu').show()
	}
	console.log(citybol)
})
$('.dzkclose').on('click', function() {
	$('#baiduditu').hide()
})
$('button.btn-success', $('.diz_tijiao')).on('click', function() {
	console.log($('.jiedao')[0].value)
	console.log(addresxy)
	if($('.jiedao')[0].value != "") {
		$('.workadd')[0].value = $('.jiedao')[0].value;
		$('.addressxy')[0].innerText = addresxy;
		$('#baiduditu').hide();
	} else {
		alert("街道或写字楼不能为空");
	}
})
var cpLock = false;
$(".jiedao").bind('compositionstart', function() {
	cpLock = true;
});
$(".jiedao").bind('compositionend', function() {
	cpLock = false;
});

$(".jiedao").bind('input', function() {
	$('.bddzlis').show()
	$('.bddzlis_ul').html('');
	var value = $(this).val();
	if(value == "") {
		$('.bddzlis').hide();
		return false;
	}
	if(!cpLock) {
		//		console.log(value);
		//		$.get("${pageContext.request.contextPath}/regionalHints", {
		//			region: "杭州",
		//			query: value
		//		}, function(data) {
		//发送请求
		//￥。get
		var data = {
			"err_code": 0,
			"err_msg": "请求成功",
			"page": "-1",
			"data": [{
				"id": 1,
				"name": "物流工程"
			}, {
				"id": 2,
				"name": "金融"
			}, {
				"id": 3,
				"name": "计算机"
			}, {
				"id": 4,
				"name": "机械工程"
			}]
		}
		if(data.err_code == 0) {
			$('.bddzlis_ul').html('');
			$.each(data.data, function(i, item) {
				$('.bddzlis_ul').append('<li value="110.110"><span class="addresskey">' + item.name + '</span><span class="fontcolorhui">' + 111 + '</span></li>');
			});
			var tt = $('.bddzlis');
			var a = "";
			var b = "";
			tt.toggle();
			var tag = tt.toggle();
			$('li', tt.find('ul')).unbind('click').on('click', function() {
				var item = $(this).find('.addresskey')[0];
				addresxy = $(this).attr('value');
				$('.jiedao')[0].value = item.innerText;
				a = item.innerText;
				b = $('.jiedao')[0].value;
				if($('.jiedao')[0].value != "") {
					//发送请求，地图定位
					//$，get
					$('.tisi').show()
				} else {
					$('.tisi').hide()
				}
			})
			var flag = true;
			$(document).bind("click", function(e) { //点击空白处，设置的弹框消失
				var target = $(e.target);
				if(flag == true) {
					tag.hide();
					flag = false;
				}
			});
		} else {
			console.log(data.err_msg);
		}
	}
});

function comeback() {
	$('.second_fid')[0].innerText = fid_id1;
}