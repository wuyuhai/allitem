function stime() {
	var num = 3
	var time = setInterval(function() {
		clearInterval
		num--;
		$('.stime')[0].innerText = num;
		if(num == 0) {
//			window.location.href = "business.html";
			clearInterval(time);
		}
	}, 1000)
}
//上一步，下一步
function nextp() {
	$("#basic1").on('click',function(){
		var t = $('#preview')[0].innerHTML,
		n = $('#u_name')[0].value,
		e = $('#wemail')[0].value,
		reg = /^[a-z0-9]+([._\\-]*[a-z0-9])*@([a-z0-9]+[-a-z0-9]*[a-z0-9]+.){1,63}[a-z0-9]+$/ //邮箱验证		
		if(t == ""){
			$('.pop').show()
		}else{
			$('.pop').hide()
		}
		if(n == "")$('#u_name').parent().find('.dpn').show()
		if(e == "")$('#wemail').parent().find('.dpn').show()
		if(t != "" && n != "" && e != "" && reg.test($('#wemail')[0].value) == true){
			alert('头像' + $('.hfile')[0].value + '，姓名' + n + ',性别' + $('#u_sexy')[0].value + ',公司邮箱' + e)
			//下一页
			$(this).closest('.dn').hide()
			$('.work_exp').show()
		}
	})
	//返回上一页
	$('#basic_prebtn').on('click',function(){
		$(this).closest('.dn').hide();
		$('.basic_inf').show()
	})
	$('#basic2').on('click',function(){
		var s = $('.wcompanyname')[0].value;
		if(s == ""){
			$('.wcompanyname').parent().find('.dpn').show()
		}else{
			alert("公司全称" + s)
			$(this).closest('.dn').hide();
			$('.education').show()
			stime()
		}
	})
}
nextp()
