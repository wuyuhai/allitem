//职位是否合适标记
function curchange(obj) {
	obj.click(function() {
		$('.links>a').removeClass("curchange");
		$(this).addClass("curchange")
	})
}
curchange($('.links>a'))

//点击显示，再点击隐藏
function openoff(obj1, obj2) {
	obj1.click(function() {
		if(obj2.css("display") == "none") {
			obj2.show()
		} else {
			obj2.hide();
		}
	})
}
openoff($('.w-saoxuan'), $('.w-filter'))
openoff($('.label-text'), $('.sec-filter'))
openoff($('.w-label-text1'), $('.w-dlist'))
openoff($('.w-label-text2'), $('.w-dlist2'))

//头像选择
function preview(file) { //预览图片得到图片base64
	var wheadimg = document.getElementsByClassName('w-headimg')[0];
	if(file.files && file.files[0]) {
		var reader = new FileReader();
		reader.onload = function(evt) {
			wheadimg.innerHTML = '<img src="' + evt.target.result + '" />';
		}
		reader.readAsDataURL(file.files[0]);
	} else {
		wheadimg.innerHTML = '<div class="img" style="filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(sizingMethod=scale,src=\'' + file.value + '\'"></div>';
	}
}

//文本框字数限制输入
function textlength(obj1, num, obj2) {
	var lenInput = obj1.val().length;
	obj1.keyup(function() {
		lenInput = $(this).val().length;
		if(lenInput > 0 && lenInput <= num) {
			obj1.next().find('.textareaInput').html(lenInput);
		}
	});
}
textlength($('#w-txtrea'), 500);
textlength($('.w-weixinnum'), 500);
textlength($('.w-weixinnum'), 500);
textlength($('.w-myoption'), 500);
textlength($('.wteamjj'), 500);
textlength($('.w-hrname'), 500);
textlength($('.wopname'), 500);
//导航页面的切换
function hrpagechange(obj1, obj2, obj3) {
	obj1.on('click', function() {
		if(obj1.closest('dl').length != 0) {
			obj1.closest('dl').siblings().removeClass("cur");
			obj1.closest('dl').addClass("cur");
		} else if(obj1.closest('div').get(0).className == "w-bordertop") {
			$('.w-bjoption').show();
			$('.ppub_btn .btn').show();
		} else if(obj1.closest('div').get(0).className == "") {
			$('.w-bjoption').hide();
			$('.ppub_btn .btn').hide();
		} else if(obj1.closest("div").find("span").length != 0) {
			$(this).closest("div").find("span").removeClass('cur');
			$(this).addClass('cur');
		}
		obj2.hide();
		obj3.show();
	})
}
hrpagechange($('.w-bjoption-on'), $('.woptionmanger'), $('.w-br_bottom'));
hrpagechange($('.backoption'), $('.w-br_bottom'), $('.woptionmanger'));
hrpagechange($('.w-openoptions'), $('.woptionmanger'), $('.w-br_bottom'));
hrpagechange($('.w-chatpageshow,.w-chating'), $('.page-container'), $('.chat-container'));
hrpagechange($('.w-conpanymes'), $('.page-container'), $('.w-hrcompany'));
hrpagechange($('.w-opmanger'), $('.page-container'), $('.w-hropput'));
hrpagechange($('.w-hrright'), $('.page-container'), $('.w-hrrightgo'));
//聊天页和简历切换
hrpagechange($('#w-chat-bjl1'), $('.chat-tab-content'), $(".w-change-chat"));
hrpagechange($('#w-chat-bjl2'), $('.chat-tab-content'), $(".resume-container"));

$('#submit_box1').on('click', function() {
	var t = $('.w-headimg')[0].innerHTML,
		a = $('.w-hrname')[0].value,
		b = $('.w-myoption')[0].value,
		c = $('#inter'),
		e = $('.inputElem')[0].value,
		w = $('.w-weixinnum')[0].value,
		op = $('.w-myoption')[0].value,
		img = $('.w-headimg').find('img').attr('src'),
		jj = $('.wteamjj')[0].innerText;
	if(img == 'assets/images/1-150630062413.jpg') {
		img = 'assets/images/1-150630062413.jpg';
	} else {
//		img = preview($('#doc'))[0].value
	}
	console.log(preview($('#doc')))
	var arr = [];
	for(var i = 0; i < c.find('p').length; i++) {
		arr.push($('#inter').find('p')[i].innerText)
	}
	arrstr = arr.join('-')
	if(a == "") $('.w-hrname').parent().find('p').show();
	if(c.find('p').length == 0) $('#inter').parent().find('p').show();
	if(op == "") $('.w-myoption').parent().find('p').show();
	if(a != "" && b != "" && c.find('p').length != 0) {
		alert("头像" + img + ',姓名' + b + '，邮箱' + e + ',微信号' + w + ',我的职位' + op + ',团队亮点' + arrstr + ",团队简介" + jj)
		alert('保存成功');
	}
})