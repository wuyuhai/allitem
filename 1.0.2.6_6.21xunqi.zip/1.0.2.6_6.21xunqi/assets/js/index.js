//搜索框
//1.0.1
$('.ipt-search').on('keyup', function(event) {
	event.stopPropagation(); //阻止事件冒泡
	$('.wsuggest').show()
	//发送请求
	//$.get
	$('.wsuggest').find('ul').show();
	$('.wsuggest').find('ul').html('');
	var data_ops = {
		"err_code": 0,
		"err_msg": "请求成功",
		"page": "-1",
		"data": [{
			"id": 1,
			"name": "前端"
		}, {
			"id": 2,
			"name": "前端工程师傅"
		}, {
			"id": 3,
			"name": "web前端"
		}, {
			"id": 4,
			"name": "前端架构"
		}]
	}
	if(data_ops.err_code == 0) {
		$.each(data_ops.data, function(i, item) {
			$('.wsuggest').find('ul').append('<li value="' + item.id + '">' + item.name + '</li>')
		});
		var a = "";
		var b = "";
		$('.wsuggest').toggle();
		var tag = $('.wsuggest').toggle();
		$('li', $('.wsuggest').find('ul')).on('click', function() {
			item = $(this)[0];
			var fid = $(this).attr('value');
			$('.ipt-search')[0].value = item.innerText;
			a = item.innerText;
			b = $('.ipt-search')[0].value;
		})
		var flag = true;
		$(document).bind("click", function(e) { //点击空白处，设置的弹框消失
			var target = $(e.target);
			if(flag == true) {
				tag.hide();
				flag = false;
			}
		});
	} else {
		alert('网络开小车了')
	}
})

//城市三联联动
$('.city-sel').on('click', function(event) {
	event.stopPropagation(); //阻止事件冒泡
	$('.city-box').show()
	$('.dorpdown-province').html('');
	$.each(city.data, function(i, item) {
		if(item.province_id == 1) {
			$('.dorpdown-province').append('<li value="' + item.province_id + '" class="cur">' + item.province_name + '</li>')
		} else {
			$('.dorpdown-province').append('<li value="' + item.province_id + '">' + item.province_name + '</li>')
		}
	});
	$('ul.dorpdown-province', $('.city-box')).on('mousemove touchstart', 'li', function() {
		$('.dorpdown-city').find('.show').html('');
		$(this).addClass('cur').siblings().removeClass('cur');
		var item = $(this);
		var fid = item.attr('value');
		var citylis = city.data[fid - 1].cities;
		for(i = 0; i < citylis.length; i++) {
			$('.dorpdown-city').find('.show').append('<li value="' + citylis[i].city_id + '">' + citylis[i].city_name + '</li>')
		}
	});
	$('ul.show', $('.dorpdown-city')).on('click touchstart', 'li', function() {
		var it = $(this)[0].innerText;
		console.log(it)
		$(".city-sel")[0].innerHTML = '<i class="line"></i><span class="label-text cur"><b>' + it + '</b><i class="icon-arrow-down"></i></span>';
		$('.city-box').hide()
	});
	$('.city-box').toggle();
	var tag = $('.city-box').toggle();
	var flag = true;
//	$(document).unbind('click touchstart').bind("click touchstart", function(e) { //点击空白处，设置的弹框消失
//		var target = $(e.target);
//		if(flag == true) {
//			tag.hide();
//			flag = false;
//		}
//	});
})
//1.0.1