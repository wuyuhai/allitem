/*
 * jQuery JSONP Core Plugin 2.4.0 (2012-08-21)
 *
 * https://github.com/jaubourg/jquery-jsonp
 *
 * Copyright (c) 2012 Julian Aubourg
 *
 * This document is licensed as free software under the terms of the
 * MIT License: http://www.opensource.org/licenses/mit-license.php
 */
(function($) {
	function noop() {}

	function genericCallback(data) {
		lastValue = [data]
	}

	function callIfDefined(method, object, parameters) {
		return method && method.apply(object.context || object, parameters)
	}

	function qMarkOrAmp(url) {
		return /\?/.test(url) ? "&" : "?";
	}
	var STR_ASYNC = "async",
		STR_CHARSET = "charset",
		STR_EMPTY = "",
		STR_ERROR = "error",
		STR_INSERT_BEFORE = "insertBefore",
		STR_JQUERY_JSONP = "_jqjsp",
		STR_ON = "on",
		STR_ON_CLICK = STR_ON + "click",
		STR_ON_ERROR = STR_ON + STR_ERROR,
		STR_ON_LOAD = STR_ON + "load",
		STR_ON_READY_STATE_CHANGE = STR_ON + "readystatechange",
		STR_READY_STATE = "readyState",
		STR_REMOVE_CHILD = "removeChild",
		STR_SCRIPT_TAG = "<script>",
		STR_SUCCESS = "success",
		STR_TIMEOUT = "timeout",
		win = window,
		Deferred = $.Deferred,
		head = $("head")[0] || document.documentElement,
		pageCache = {},
		count = 0,
		lastValue, xOptionsDefaults = {
			callback: STR_JQUERY_JSONP,
			url: location.href
		},
		opera = win.opera,
		oldIE = !!$("<div>").html("<!--[if IE]><i><![endif]-->").find("i").length;

	function jsonp(xOptions) {
		xOptions = $.extend({}, xOptionsDefaults, xOptions);
		var successCallback = xOptions.success,
			errorCallback = xOptions.error,
			completeCallback = xOptions.complete,
			dataFilter = xOptions.dataFilter,
			callbackParameter = xOptions.callbackParameter,
			successCallbackName = xOptions.callback,
			cacheFlag = xOptions.cache,
			pageCacheFlag = xOptions.pageCache,
			charset = xOptions.charset,
			url = xOptions.url,
			data = xOptions.data,
			timeout = xOptions.timeout,
			pageCached, done = 0,
			cleanUp = noop,
			supportOnload, supportOnreadystatechange, firstChild, script, scriptAfter, timeoutTimer;
		Deferred && Deferred(function(defer) {
			defer.done(successCallback).fail(errorCallback);
			successCallback = defer.resolve;
			errorCallback = defer.reject;
		}).promise(xOptions);
		xOptions.abort = function() {
			!(done++) && cleanUp();
		};
		if(callIfDefined(xOptions.beforeSend, xOptions, [xOptions]) === !1 || done) {
			return xOptions;
		}
		url = url || STR_EMPTY;
		data = data ? ((typeof data) == "string" ? data : $.param(data, xOptions.traditional)) : STR_EMPTY;
		url += data ? (qMarkOrAmp(url) + data) : STR_EMPTY;
		callbackParameter && (url += qMarkOrAmp(url) + encodeURIComponent(callbackParameter) + "=?");
		!cacheFlag && !pageCacheFlag && (url += qMarkOrAmp(url) + "_" + (new Date()).getTime() + "=");
		url = url.replace(/=\?(&|$)/, "=" + successCallbackName + "$1");

		function notifySuccess(json) {
			if(!(done++)) {
				cleanUp();
				pageCacheFlag && (pageCache[url] = {
					s: [json]
				});
				dataFilter && (json = dataFilter.apply(xOptions, [json]));
				callIfDefined(successCallback, xOptions, [json, STR_SUCCESS, xOptions]);
				callIfDefined(completeCallback, xOptions, [xOptions, STR_SUCCESS])
			}
		}

		function notifyError(type) {
			if(!(done++)) {
				cleanUp();
				pageCacheFlag && type != STR_TIMEOUT && (pageCache[url] = type);
				callIfDefined(errorCallback, xOptions, [xOptions, type]);
				callIfDefined(completeCallback, xOptions, [xOptions, type])
			}
		}
		if(pageCacheFlag && (pageCached = pageCache[url])) {
			pageCached.s ? notifySuccess(pageCached.s[0]) : notifyError(pageCached)
		} else {
			win[successCallbackName] = genericCallback;
			script = $(STR_SCRIPT_TAG)[0];
			script.id = STR_JQUERY_JSONP + count++;
			if(charset) {
				script[STR_CHARSET] = charset
			}
			opera && opera.version() < 11.60 ? ((scriptAfter = $(STR_SCRIPT_TAG)[0]).text = "document.getElementById('" + script.id + "')." + STR_ON_ERROR + "()") : (script[STR_ASYNC] = STR_ASYNC);
			if(oldIE) {
				script.htmlFor = script.id;
				script.event = STR_ON_CLICK
			}
			script[STR_ON_LOAD] = script[STR_ON_ERROR] = script[STR_ON_READY_STATE_CHANGE] = function(result) {
				if(!script[STR_READY_STATE] || !/i/.test(script[STR_READY_STATE])) {
					try {
						script[STR_ON_CLICK] && script[STR_ON_CLICK]()
					} catch(_) {}
					result = lastValue;
					lastValue = 0;
					result ? notifySuccess(result[0]) : notifyError(STR_ERROR)
				}
			};
			script.src = url;
			cleanUp = function(i) {
				timeoutTimer && clearTimeout(timeoutTimer);
				script[STR_ON_READY_STATE_CHANGE] = script[STR_ON_LOAD] = script[STR_ON_ERROR] = null;
				head[STR_REMOVE_CHILD](script);
				scriptAfter && head[STR_REMOVE_CHILD](scriptAfter)
			};
			head[STR_INSERT_BEFORE](script, (firstChild = head.firstChild));
			scriptAfter && head[STR_INSERT_BEFORE](scriptAfter, firstChild);
			timeoutTimer = timeout > 0 && setTimeout(function() {
				notifyError(STR_TIMEOUT)
			}, timeout)
		}
		return xOptions
	}
	jsonp.setup = function(xOptions) {
		$.extend(xOptionsDefaults, xOptions)
	};
	$.jsonp = jsonp
})(jQuery);