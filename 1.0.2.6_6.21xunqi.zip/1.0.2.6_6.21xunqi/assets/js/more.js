//展开，更多
var jconfirm, Jconfirm;
! function(e) {
	"use strict";
	e.fn.confirm = function(t, i) {
		return void 0 === t && (t = {}), "string" == typeof t && (t = {
			content: t,
			title: !!i && i
		}), e(this).each(function() {
			var i = e(this);
			i.on("click", function(n) {
				n.preventDefault();
				var s = e.extend({}, t);
				i.attr("data-title") && (s.title = i.attr("data-title")), i.attr("data-content") && (s.content = i.attr("data-content")), s.$target = i, i.attr("href") && !t.confirm && (s.confirm = function() {
					location.href = i.attr("href")
				}), e.confirm(s)
			})
		}), e(this)
	}, e.confirm = function(e, t) {
		return void 0 === e && (e = {}), "string" == typeof e && (e = {
			content: e,
			title: !!t && t
		}), jconfirm(e)
	}, e.alert = function(e, t) {
		return void 0 === e && (e = {}), "string" == typeof e && (e = {
			content: e,
			title: !!t && t
		}), e.cancelButton = !1, jconfirm(e)
	}, e.dialog = function(e, t) {
		return void 0 === e && (e = {}), "string" == typeof e && (e = {
			content: e,
			title: !!t && t
		}), e.cancelButton = !1, e.confirmButton = !1, e.confirmKeys = [13], jconfirm(e)
	}, jconfirm = function(t) {
		void 0 === t && (t = {}), jconfirm.defaults && e.extend(jconfirm.pluginDefaults, jconfirm.defaults);
		var t = e.extend({}, jconfirm.pluginDefaults, t);
		return new Jconfirm(t)
	}, Jconfirm = function(t) {
		e.extend(this, t), this._init()
	}, Jconfirm.prototype = {
		_init: function() {
			var e = this;
			this._rand = Math.round(99999 * Math.random()), this._buildHTML(), this._bindEvents(), setTimeout(function() {
				e.open(), e._watchContent()
			}, 0)
		},
		_buildHTML: function() {
			var t = this;
			this.animation = "anim-" + this.animation.toLowerCase(), this.closeAnimation = "anim-" + this.closeAnimation.toLowerCase(), this.theme = "jconfirm-" + this.theme.toLowerCase(), "anim-none" == this.animation && (this.animationSpeed = 0), this._lastFocused = e("body").find(":focus"), this.$el = e(this.template).appendTo(this.container).addClass(this.theme), this.$el.find(".jconfirm-box-container").addClass(this.columnClass), this.$el.find(".jconfirm-bg").css(this._getCSS(this.animationSpeed, 1)), this.$el.find(".jconfirm-bg").css("opacity", this.opacity), this.$b = this.$el.find(".jconfirm-box").css(this._getCSS(this.animationSpeed, this.animationBounce)).addClass(this.animation), this.$body = this.$b, this.rtl && this.$el.addClass("rtl"), this._contentReady = e.Deferred(), this._modalReady = e.Deferred(), this.$title = this.$el.find(".title"), this.contentDiv = this.$el.find("div.content"), this.$content = this.contentDiv, this.$contentPane = this.$el.find(".content-pane"), this.$icon = this.$el.find(".icon-c"), this.$closeIcon = this.$el.find(".closeIcon"), this.$contentPane.css(this._getCSS(this.animationSpeed, 1)), this.setTitle(), this.setIcon(), this._setButtons(), this.closeIconClass && this.$closeIcon.html('<i class="' + this.closeIconClass + '"></i>'), t._contentHash = this._hash(t.$content.html()), e.when(this._contentReady, this._modalReady).then(function() {
				t.setContent(), t.setTitle(), t.setIcon()
			}), this._getContent(), this._imagesLoaded(), this.autoClose && this._startCountDown()
		},
		_unwatchContent: function() {
			clearInterval(this._timer)
		},
		_hash: function() {
			if("function" == typeof btoa) return btoa(encodeURIComponent(this.$content.html()))
		},
		_watchContent: function() {
			var e = this;
			this._timer = setInterval(function() {
				var t = e._hash(e.$content.html());
				e._contentHash != t && (e._contentHash = t, e.setDialogCenter(), e._imagesLoaded())
			}, this.watchInterval)
		},
		_bindEvents: function() {
			var t = this,
				i = !1;
			this.$el.find(".jconfirm-scrollpane").click(function(e) {
				i || (t.backgroundDismiss ? (t.cancel(), t.close()) : (t.$b.addClass("hilight"), setTimeout(function() {
					t.$b.removeClass("hilight")
				}, 800))), i = !1
			}), this.$el.find(".jconfirm-box").click(function(e) {
				i = !0
			}), this.$confirmButton && this.$confirmButton.click(function(e) {
				e.preventDefault();
				var i = t.confirm(t.$b);
				t._stopCountDown(), t.onAction("confirm"), (void 0 === i || i) && t.close()
			}), this.$cancelButton && this.$cancelButton.click(function(e) {
				e.preventDefault();
				var i = t.cancel(t.$b);
				t._stopCountDown(), t.onAction("cancel"), (void 0 === i || i) && t.close()
			}), this.$closeButton && this.$closeButton.click(function(e) {
				e.preventDefault(), t._stopCountDown(), t.cancel(), t.onAction("close"), t.close()
			}), this.keyboardEnabled && setTimeout(function() {
				e(window).on("keyup." + this._rand, function(e) {
					t.reactOnKey(e)
				})
			}, 500), e(window).on("resize." + this._rand, function() {
				t.setDialogCenter(!0)
			})
		},
		_getCSS: function(e, t) {
			return {
				"-webkit-transition-duration": e / 1e3 + "s",
				"transition-duration": e / 1e3 + "s",
				"-webkit-transition-timing-function": "cubic-bezier(.36,1.1,.2, " + t + ")",
				"transition-timing-function": "cubic-bezier(.36,1.1,.2, " + t + ")"
			}
		},
		_imagesLoaded: function() {
			var t = this;
			e.each(this.$content.find("img:not(.loaded)"), function(i, n) {
				var s = setInterval(function() {
					"0px" !== e(n).css("height") && (e(n).addClass("loaded"), t.setDialogCenter(), clearInterval(s))
				}, 40)
			})
		},
		_setButtons: function() {
			this.$btnc = this.$el.find(".buttons"), this.confirmButton && "" !== e.trim(this.confirmButton) && (this.$confirmButton = e('<button type="button" class="btn">' + this.confirmButton + "</button>").appendTo(this.$btnc).addClass(this.confirmButtonClass)), this.cancelButton && "" !== e.trim(this.cancelButton) && (this.buttonsReverse ? this.$cancelButton = e('<button type="button" class="btn">' + this.cancelButton + "</button>").prependTo(this.$btnc).addClass(this.cancelButtonClass) : this.$cancelButton = e('<button type="button" class="btn">' + this.cancelButton + "</button>").appendTo(this.$btnc).addClass(this.cancelButtonClass)), this.buttonOther && "" !== e.trim(this.buttonOther) && e(this.buttonOther).prependTo(this.$btnc), this.confirmButton || this.cancelButton || this.$btnc.hide(), this.confirmButton || this.cancelButton || null !== this.closeIcon || (this.$closeButton = this.$b.find(".closeIcon").show()), this.closeIcon === !0 && (this.$closeButton = this.$b.find(".closeIcon").show())
		},
		setTitle: function(e) {
			this.title = void 0 !== e ? e : this.title, this.$title.html(this.title || "")
		},
		setIcon: function(e) {
			this.title = "undefined" != typeof string ? e : this.title, this.$icon.html(this.icon ? '<i class="' + this.icon + '"></i>' : "")
		},
		setContent: function(e) {
			this.content = void 0 === e ? this.content : e, "" == this.content ? (this.$content.html(this.content), this.$contentPane.hide()) : (this.$content.html(this.content), this.$contentPane.show()), this.$content.hasClass("loading") && (this.$content.removeClass("loading"), this.$btnc.find("button").prop("disabled", !1))
		},
		_getContent: function(t) {
			var i = this;
			if(t = t ? t : this.content, this._isAjax = !1, this.content)
				if("string" == typeof this.content)
					if("url:" === this.content.substr(0, 4).toLowerCase()) {
						this._isAjax = !0, this.$content.addClass("loading"), this.$btnc.find("button").prop("disabled", !0);
						var n = this.content.substring(4, this.content.length);
						e.get(n).done(function(e) {
							i.content = e, i._contentReady.resolve()
						}).always(function(e, t, n) {
							"function" == typeof i.contentLoaded && i.contentLoaded(e, t, n)
						})
					} else this.setContent(this.content), this._contentReady.reject();
			else if("function" == typeof this.content) {
				this.$content.addClass("loading"), this.$btnc.find("button").attr("disabled", "disabled");
				var s = this.content(this);
				"object" != typeof s ? console.error("The content function must return jquery promise.") : "function" != typeof s.always ? console.error("The object returned is not a jquery promise.") : (this._isAjax = !0, s.always(function(e, t) {
					i._contentReady.resolve()
				}))
			} else console.error("Invalid option for property content, passed: " + typeof this.content);
			else this.content = "", this.setContent(this.content), this._contentReady.reject();
			this.setDialogCenter()
		},
		_stopCountDown: function() {
			clearInterval(this.timerInterval), this.$cd && this.$cd.remove()
		},
		_startCountDown: function() {
			var t = this.autoClose.split("|");
			if(/cancel/.test(t[0]) && "alert" === this.type) return !1;
			if(/confirm|cancel/.test(t[0])) {
				this.$cd = e('<span class="countdown"></span>').appendTo(this["$" + t[0] + "Button"]);
				var i = this;
				i.$cd.parent().click();
				var n = t[1] / 1e3;
				this.timerInterval = setInterval(function() {
					i.$cd.html(" (" + (n -= 1) + ")"), 0 === n && (i.$cd.html(""), i.$cd.parent().trigger("click"), clearInterval(i.timerInterval))
				}, 1e3)
			} else console.error("Invalid option " + t[0] + ", must be confirm/cancel")
		},
		reactOnKey: function t(i) {
			var n = e(".jconfirm");
			if(n.eq(n.length - 1)[0] !== this.$el[0]) return !1;
			var t = i.which;
			if(this.contentDiv.find(":input").is(":focus") && /13|32/.test(t)) return !1;
			e.inArray(t, this.cancelKeys) !== -1 && (this.$cancelButton ? this.$cancelButton.click() : this.close()), e.inArray(t, this.confirmKeys) !== -1 && this.$confirmButton && this.$confirmButton.click()
		},
		setDialogCenter: function() {
			if("none" == this.$contentPane.css("display")) var t = 0,
				i = 0;
			else {
				var t = this.$content.outerHeight(),
					i = this.$contentPane.height();
				0 == i && (i = t)
			}
			var n = this.$content.outerWidth();
			this.$content.css({
				clip: "rect(0px " + (100 + n) + "px " + t + "px -100px)"
			}), this.$contentPane.css({
				height: t
			});
			var s = e(window).height(),
				a = this.$b.outerHeight() - i + t,
				o = (s - a) / 2;
			if(a > s - 100) {
				var r = {
					"margin-top": 50,
					"margin-bottom": 50
				};
				e("body").addClass("jconfirm-noscroll")
			} else {
				var r = {
					"margin-top": o
				};
				e("body").removeClass("jconfirm-noscroll")
			}
			this.$b.css(r)
		},
		close: function() {
			var t = this;
			if(this.isClosed()) return !1;
			"function" == typeof this.onClose && this.onClose(), this._unwatchContent(), t._lastFocused.focus(), e(window).unbind("resize." + this._rand), this.keyboardEnabled && e(window).unbind("keyup." + this._rand), t.$el.find(".jconfirm-bg").removeClass("seen"), e("body").removeClass("jconfirm-noscroll"), this.$b.addClass(this.closeAnimation);
			var i = "anim-none" == this.closeAnimation ? 0 : this.animationSpeed;
			return setTimeout(function() {
				t.$el.remove()
			}, 25 * i / 100), jconfirm.record.closed += 1, jconfirm.record.currentlyOpen -= 1, !0
		},
		open: function() {
			var e = this;
			if(this.isClosed()) return !1;
			e.$el.find(".jconfirm-bg").addClass("seen"), this.$b.removeClass(this.animation), this.$b.find("input[autofocus]:visible:first").focus(), jconfirm.record.opened += 1, jconfirm.record.currentlyOpen += 1, "function" == typeof this.onOpen && this.onOpen();
			var t = "jconfirm-box" + this._rand;
			return this.$b.attr("aria-labelledby", t).attr("tabindex", -1).focus(), this.$title ? this.$title.attr("id", t) : this.$content && this.$content.attr("id", t), setTimeout(function() {
				e.$b.css({
					"transition-property": e.$b.css("transition-property") + ", margin"
				}), e._modalReady.resolve()
			}, this.animationSpeed), !0
		},
		isClosed: function() {
			return "" === this.$el.css("display")
		}
	}, jconfirm.pluginDefaults = {
		template: '<div class="jconfirm"><div class="jconfirm-bg"></div><div class="jconfirm-scrollpane"><div class="container"><div class="row"><div class="jconfirm-box-container"><div class="jconfirm-box" role="dialog" aria-labelledby="labelled" tabindex="-1"><div class="closeIcon">&times;</div><div class="title-c"><span class="icon-c"></span><span class="title"></span></div><div class="content-pane"><div class="content"></div></div><div class="buttons"></div><div class="jquery-clear"></div></div></div></div></div></div></div>',
		title: "æç¤º",
		content: "ç¡®å®šå—",
		contentLoaded: function() {},
		icon: "",
		opacity: null,
		confirmButton: "ç¡®å®š",
		cancelButton: "å–æ¶ˆ",
		confirmButtonClass: "btn",
		cancelButtonClass: "btn btn-slight",
		buttonsReverse: !1,
		theme: "white",
		animation: "scale",
		closeAnimation: "scale",
		animationSpeed: 500,
		animationBounce: 1.2,
		keyboardEnabled: !1,
		rtl: !1,
		confirmKeys: [13],
		cancelKeys: [27],
		container: "body",
		confirm: function() {},
		cancel: function() {},
		backgroundDismiss: !0,
		autoClose: !1,
		closeIcon: null,
		closeIconClass: !1,
		watchInterval: 100,
		columnClass: "pop-container",
		onOpen: function() {},
		onClose: function() {},
		onAction: function() {}
	}, jconfirm.record = {
		opened: 0,
		closed: 0,
		currentlyOpen: 0
	}
}(jQuery),
function(e, t, n, s) {
	var a = function(t, i) {
		var n = this;
		n.$element = t, n.defaults = {
			width: 840,
			height: 256,
			start: 1,
			speed: 400,
			interval: 3e3,
			autoPlay: !1,
			dotShow: !0,
			navShow: !0,
			arrShow: !0,
			touch: !0,
			effect: "slide",
			fadeOut: !0,
			afterSlider: function() {}
		}, n.clickable = !0, n.options = e.extend({}, n.defaults, i)
	};
	a.prototype = {
		init: function() {
			var n = this,
				s = n.$element,
				a = s.children("ul"),
				o = a.children("li"),
				r = o.length,
				l = n.options.start,
				d = 0,
				c = 0;
			if(n.options.arrShow) {				
				s.append('<a href="javascript:;" class="btn-direction btn-prev"></a><a href="javascript:;" class="btn-direction btn-next"></a>')
			}
			for(i = 1; i <= r; i++) l == i && o.eq(l - 1).addClass("cur");
			if(n.options.dotShow) {
				var h = "";
				for(i = 1; i <= r; i++){
					h += l == i ? '<i data-index="' + i + '" class="cur"></i>' : '<i data-index="' + i + '"></i>';
				} 
				var u = '<div class="slider-dot">' + h + '</div>';
				s.append(u)
			}
			var p = function() {
				var e = s.width(),
					t = n.options.height / n.options.width * e;
				s.css("height", t)
			};
			if(s.css("height", n.options.height), p(), e(t).resize(function() {
					p()
				}), n.options.arrShow && (s.find(".next").on("click", function(e) {
					e.preventDefault(), n.clickable && (l >= r ? l = 1 : l += 1, n.moveTo(l, "next"))
				}), s.find(".prev").on("click", function(e) {
					e.preventDefault(), n.clickable && (1 == l ? l = r : l -= 1, n.moveTo(l, "prev"))
				})), n.options.dotShow && s.find(".slider-dot i").on("mouseover", function(t) {
					if(t.preventDefault(), n.clickable) {
						var i = e(this).data("index");
						dir = i > l ? "next" : "prev", i != l && (l = i, n.moveTo(l, dir))
					}
				}), n.options.navShow && s.parent().find(".slider-nav a").on("mouseover", function(t) {
					if(t.preventDefault(), n.clickable) {
						var i = e(this).data("index");
						dir = i > l ? "next" : "prev", i != l && (l = i, n.moveTo(l, dir))
					}
				}), n.options.autoPlay) {
				var f, m = function() {
					l++, l > r && (l = 1), n.moveTo(l, "next")
				};
				f = setInterval(m, n.options.interval), s.hover(function() {
					f = clearInterval(f)
				}, function() {
					f = setInterval(m, n.options.interval)
				})
			}
			n.options.touch && o.on({
				touchstart: function(e) {
					d = e.originalEvent.touches[0].clientY, c = e.originalEvent.touches[0].clientX
				},
				touchend: function(e) {
					var t = e.originalEvent.changedTouches[0].clientY,
						i = e.originalEvent.changedTouches[0].clientX,
						s = d - t,
						a = c - i;
					Math.abs(a) > Math.abs(s) && (a > 5 ? (l >= r ? l = 1 : l += 1, n.moveTo(l, "next")) : (1 == l ? l = r : l -= 1, n.moveTo(l, "prev"))), d = null, c = null
				},
				touchmove: function(e) {
					e.preventDefault && e.preventDefault()
				}
			})
		},
		moveTo: function(t, i) {
			var n = this,
				s = n.$element,
				a = n.clickable,
				o = s.find(".slider-dot i"),
				r = s.parent().find(".slider-nav a"),
				l = s.children("ul"),
				d = l.children("li");
			if(!a) return !1;
			if(n.clickable = !1, "fade" == n.options.effect) 1 == n.options.fadeOut ? l.children(".cur").fadeOut(function() {
				e(this).removeClass("cur")
			}) : l.children(".cur").hide().removeClass("cur"), d.eq(t - 1).fadeIn(function() {
				e(this).addClass("cur"), n.clickable = !0
			});
			else {
				var c = s.width();
				"prev" == i && (c *= -1), l.children(".cur").stop().animate({
					left: -c
				}, n.options.speed, function() {
					e(this).removeClass("cur")
				}), d.eq(t - 1).css("left", c + "px").addClass("cur").stop().animate({
					left: 0
				}, n.options.speed, function() {
					n.clickable = !0
				})
			}
			n.options.afterSlider.call(n), o.removeClass("cur"), o.eq(t - 1).addClass("cur"), r.removeClass("cur"), r.eq(t - 1).addClass("cur")
		}
	}, e.fn.hwSlider = function(e) {
		var t = new a(this, e);
		return this.each(function() {	
			t.init()		
		})
	}
}(jQuery, window, document);
var PlaceholderCheck = {
	init: function(e) {
		if(!placeholderSupport()) {
			var t;
			t = e ? e.find("[placeholder]") : $("[placeholder]"), t.focus(function() {
				var e = $(this);
				e.val() == e.attr("placeholder") && (e.val(""), e.removeClass("placeholder"))
			}).blur(function() {
				var e = $(this);
				"" != e.val() && e.val() != e.attr("placeholder") || (e.addClass("placeholder"), e.val(e.attr("placeholder")))
			}).blur()
		}
	}
};
$(function() {
	PlaceholderCheck.init()
}), $(function() {
	function e() {
		var e = arguments;
		a <= s - 1 && (n.eq(a).stop(!0).animate({
			width: "300px"
		}, 500).siblings().stop(!0).animate({
			width: "98px"
		}, 500), ++a == s && (a = 0)), i = setTimeout(e.callee, 5e3)
	}

	function t() {
		var e = (o.offset().top, $(window).scrollTop(), $("body").outerHeight(), d.height(), $(window).height() - ($("#footer").offset().top - $(document).scrollTop()));
		e > 0 ? r.css("bottom", e) : r.css("bottom", 0)
	}
	if($.fn.hoverDelay = function(e) {
			var t, i, n = {
					hoverDuring: 200,
					outDuring: 200,
					hoverEvent: function() {
						$.noop()
					},
					outEvent: function() {
						$.noop()
					}
				},
				s = $.extend(n, e || {});
			return $(this).each(function() {
				$(this).hover(function() {
					clearTimeout(i), t = setTimeout(s.hoverEvent, s.hoverDuring)
				}, function() {
					clearTimeout(t), i = setTimeout(s.outEvent, s.outDuring)
				})
			})
		}, $(".home-box .slider-main").length && ($(".home-box .slider-main").hwSlider({
			autoPlay: !0,
			arrShow: !0,
			dotShow: !0,
			navShow: !0,
			touch: !0,
			height: 240,
			interval: 5e3,
			effect: "fade"
		}), $(".slider-box .pic-all").length)) {
		var i, n = $(".slider-box .pic-all a"),
			s = n.length,
			a = 0;
		n.hover(function() {
			clearTimeout(i), 300 != $(this).width() && $(this).stop(!0).animate({
				width: "300px"
			}, 500).siblings().stop(!0).animate({
				width: "98px"
			}, 500)
		}, function() {
			a = $(this).index(), e()
		}), e()
	}
	if($(".semwrap .slider-main").length && $(".slider-main").hwSlider({
			autoPlay: !0,
			arrShow: !0,
			dotShow: !1,
			navShow: !0,
			touch: !0,
			interval: 5e3,
			width: 582,
			speed: 1e3,
			height: 426
		}), $(".manager-list .manager-inner").length && $(".manager-list li").length > 1 && ($(".manager-list h3").css("background", "none"), $(".manager-list .manager-inner").hwSlider({
			autoPlay: !0,
			arrShow: !1,
			dotShow: !0,
			interval: 5e3,
			speed: 500,
			width: 330,
			height: 163,
			navShow: !0,
			touch: !0,
			effect: "fade",
			fadeOut: !1,
			afterSlider: function() {
				$(".manager-list .fold-text").removeAttr("style"), $(".manager-list .more-view").html('展开<i class="fz fz-slidedown"></i></a>').show()
			}
		})), $(".picture-list .slider-main").length && $(".picture-list li").length > 1 && $(".picture-list .slider-main").hwSlider({
			autoPlay: !0,
			arrShow: !1,
			dotShow: !0,
			interval: 5e3,
			speed: 500,
			width: 330,
			height: 165,
			navShow: !0,
			touch: !0
		}), $(".job-menu dl").each(function(e) {
			var t = $(this);
			t.hoverDelay({
				hoverDuring: 200,
				hoverEvent: function() {
					switch(t.addClass("cur"), e) {
						case 0:
							break;
						case 1:
							t.children(".menu-sub").css({
								top: "-50px"
							});
							break;
						case 10:
							t.children(".menu-sub").css({
								top: "auto",
								bottom: "-1px"
							})
					}
					if(0 != e && 1 != e && 10 != e || 10 == e && $(".ie7").length) {
						var i = t.get(0).getBoundingClientRect().top,
							n = t.find(".menu-sub");
						n.height() < i ? n.css({
							"margin-top": 65 - n.height() + "px"
						}) : i < 70 && i > 0 ? n.css({
							"margin-top": "-1px"
						}) : i < 0 ? n.css({
							"margin-top": i + "px"
						}) : n.css({
							"margin-top": 59 - i + "px"
						})
					}
				},
				outEvent: function() {
					t.removeClass("cur").children(".menu-sub")
				}
			})
		}), $(".menu-all .sub-tab li").eq(0).css({
			"border-top-color": "#fff",
			"padding-top": "15px",
			"padding-bottom": "14px"
		}), $(".menu-all .sub-tab li").eq(1).css({
			"margin-top": "-1px"
		}), $(".menu-all .sub-tab li").on("click", function() {
			var e = $(this).index(),
				t = $(this).parent().find("li"),
				i = $(this).closest(".menu-sub").find(".sub-content ul");
			t.removeClass("cur"), $(this).addClass("cur"), i.removeClass("show"), i.eq(e).addClass("show"), 0 == e && $(this).css("border-top-color", "#fff"), e == t.length - 1 ? $(this).css({
				"border-bottom-color": "#fff",
				"margin-top": "-1px",
				"padding-top": "1px"
			}) : t.eq(t.length - 1).css({
				"border-bottom-color": "#FDFDFE",
				"margin-top": "0",
				"padding-top": "0"
			})
		}), $(".condition-insdustry .btn-all").on("click", function() {
			$(this).parent().toggleClass("show-all-insdustry")
		}), $(".condition-city .link-district").on("click", function() {
			$(".condition-district").toggleClass("show-condition-district"), $(".condition-area").removeClass("show-condition-area")
		}), $(".condition-city .link-area").on("click", function() {
			$(".condition-area").toggleClass("show-condition-area"), $(".condition-district").removeClass("show-condition-district")
		}), $(".siderbar-top").on("click", function() {
			$("html,body").animate({
				scrollTop: "0px"
			}, 400)
		}), $(window).on("scroll", function() {
			$(this).scrollTop() > 600 ? $("#siderbar").fadeIn() : $("#siderbar").hide()
		}), $(".footer-scan").length) {
		$("#siderbar").css({
			bottom: "304px",
			transition: "all 0.2s"
		});
		var o = $("#footer"),
			r = $(".footer-scan"),
			l = $(".home-box .job-list"),
			d = $(window);
		l.css("margin-bottom", "105px"), t(), $(window).scroll(function() {
			t()
		}), r.find(".footer-scan-close").click(function() {
			r.fadeOut(300, function() {
				l.css({
					"margin-bottom": "15px",
					transition: "all 0.2s"
				}), $("#siderbar").css({
					bottom: "214px",
					transition: "all 0.2s"
				})
			})
		})
	}
	$(window).width() < 1348 && $(".footer-scan .btns").css("margin-right", "84px"), $(window).resize(function() {
		$(window).width() < 1348 ? $(".footer-scan .btns").css("margin-right", "84px") : $(".footer-scan .btns").css("margin-right", "0")
	}), "cpc_job_index" == $("#page_key_name").val() && setTimeout(function() {
		if(window._T) {
			var e = window.screen.width,
				t = window.screen.height,
				i = window.innerWidth,
				n = window.innerHeight;
			_T.sendEvent("screen-" + e + "-" + t + "|avail-" + i + "-" + n)
		}
	}, 1e3)
});
var Detail = {
	init: function(e) {
		function t() {
			$(this).scrollTop() >= $(".job-box").offset().top - 80 ? r || (r = !0, o.slideDown(300, function() {
				r = !1
			})) : o.hide()
		}
		var i = $(".links label");
		if(Detail.firstIn = !0, 0 != i.length) {
			var n = !1,
				s = $(".links");
			i.click(function() {
				n ? (s.css("height", "70px"), n = !1, i.html('<span>展开</span><i class="fz fz-slidedown"></i>')) : (s.css("height", "auto"), n = !0, i.html('<span>关闭</span><i class="fz fz-slideup"></i>'))
			})
		}
		if($(".btn-signup").on("click", function() {
				Detail.showSign(1)
			}), $(".fold-text .more-view").on("click", function() {
				$(this).find(".fz-slidedown").length ? ($(this).parent().css({
					"max-height": "none",
					overflow: "visible"
				}), $(this).css("bottom", "-20px"), $(this).html('关闭<i class="fz fz-slideup"></i></a>').show()) : ($(this).parent().removeAttr("style"), $(this).removeAttr("style"), $(this).html('展开<i class="fz fz-slidedown"></i></a>').show())
			}), $(".company-card").on("click", function(e) {
				$(e.target).hasClass("btn") || (window.location.href = $(this).find(".btn").eq(0).attr("href"))
			}), $(".detail-content .job-sec .fold-text").text().length > 275 && $(".detail-content .job-sec .more-view").show(), $(".manager-list .fold-text").each(function() {
				$(this).text().length > 69 ? $(this).find(".more-view").show() : $(this).find(".more-view").remove()
			}), $(".detail-op").on("click", ".btn", function(e) {
				var t = $(this);
				t.hasClass("btn-outline") ? (Detail.deliveResume(t), e.preventDefault()) : t.hasClass("btn-startchat") && (Detail.startChat(t), e.preventDefault())
			}), "undefined" != typeof _userInfo) {
			this.showMes();
			var a = this;
			if(_userInfo.isLogin) {
				if(!_userInfo.isPerfect) {
					$(".container-tip");
					setTimeout(function() {
						Detail.canClick = !0, $(".avatar img").on("click", function() {
							a.showGuide()
						})
					}, 4e3), $(".tip-box a").attr("href", "/niurenweb/complete/guide.html")
				}
			} else {
				$(".container-tip");
				setTimeout(function() {
					Detail.canClick = !0, $(".avatar img").on("click", function() {
						$(".jconfirm").length && $(".jconfirm").remove(), Detail.canClick && a.showGuide()
					})
				}, 4e3), $(".container-tip .tip-box>a").on("click", function() {
					if($(".jconfirm").length && $(".jconfirm").remove(), 1 != $(this).data("load")) {
						var e = $(this);
						e.data("load", !0), $(".container-tip").fadeOut(function() {
							$.confirm({
								content: $("#pop-hide-container").html(),
								title: !1,
								confirmButton: !1,
								cancelButton: !1,
								closeIcon: !0,
								columnClass: "pop-sign-box",
								onOpen: function() {
									Singup.init()
								},
								onClose: function() {
									Singup.cdAni && (clearInterval(Singup.cdAni), Singup.cdAni = null), a.showMes()
								}
							}), e.data("load", !1)
						})
					}
				})
			}
			if(_userInfo.hasKaAnotherS) try {
				_T.sendEvent("detail_with_another_s_from_same_boss")
			} catch(e) {}
		}
		var o = ($(".job-banner"), $(".smallbanner")),
			r = !1;
		if(!($(document).height() - $(window).height() < 260)) return 0 != $(".job-banner").length && (t(), void $(window).scroll(function() {
			t()
		}))
	},
	deliveResume: function(e) {
		var t = e.attr("data-url");
		e.attr("redirect-url");
		e.hasClass("btn-loading") || e.hasClass("btn-disabled") || (e.html('<i class="icon-loading"></i>æŠ•é€’ä¸­').addClass("btn-loading"), $.ajax({
			url: t,
			type: "post",
			dataType: "json",
			data: {},
			success: function(t) {
				var t = t;
				t.rescode ? 1 == t.rescode ? $.confirm({
					content: '<div class="deliver-pop"><p class="text">æ‚¨çš„é™„ä»¶ç®€åŽ†å·²ç»å‘é€ç»™Bossï¼Œè¯·é™å€™ä½³éŸ³ã€‚</p></div>',
					title: "æŠ•é€’æˆåŠŸ",
					confirmButton: "ç¡®å®š",
					cancelButton: !1,
					closeIcon: !0,
					autoClose: "confirm|3000",
					columnClass: "pop-tip-box pop-detail",
					onOpen: function() {
						var e = this;
						$(".btn-sendresume").text("å·²æŠ•é€’"), e.$content.find(".btn").on("click", function() {
							$(".btn-sendresume").removeClass("btn-loading").addClass("btn-disabled"), e.close()
						})
					},
					onClose: function() {}
				}) : 3 == t.rescode || 4 == t.rescode ? (Detail.showSign(t.rescode), e.text("æŠ•é€’ç®€åŽ†").removeClass("btn-loading")) : 5 == t.rescode ? e.text("å·²æŠ•é€’").removeClass("btn-loading").addClass("btn-disabled") : 6 == t.rescode ? ($.confirm({
					content: '<div class="deliver-pop"><p class="text">è¯·æ‚¨ä¸Šä¼ é™„ä»¶ç®€åŽ†ï¼Œå³å¯å®ŒæˆæŠ•é€’ã€‚</p><div class="resume-attachment"></div><div class="btns"><input id="fileupload" type="file" name="file" class="file" /><button type="button" class="btn">ç«‹å³ä¸Šä¼ </button><button type="button" class="btn btn-outline">å…ˆèŠèŠ</button></div></div>',
					title: "ä¸Šä¼ é™„ä»¶ç®€åŽ†",
					confirmButton: !1,
					cancelButton: !1,
					closeIcon: !0,
					columnClass: "pop-tip-box pop-detail",
					onOpen: function() {
						var e = this;
						e.$content.find(".btn").on("click", function() {
							"ç¡®å®š" == $(this).text() && ($(".job-detail .btn-sendresume").click(), e.close()), "å…ˆèŠèŠ" == $(this).text() && ($(".job-detail .btn-startchat").click(), e.close())
						}), Resume.setUpload()
					},
					onClose: function() {}
				}), e.text("æŠ•é€’ç®€åŽ†").removeClass("btn-loading")) : 7 == t.rescode ? ($.confirm({
					content: '<div class="deliver-pop"><p class="text">' + t.resmsg + '</p><div class="btns"><button type="button" class="btn">å†çœ‹çœ‹</button><button type="button" class="btn btn-outline" data-url="' + e.attr("data-url") + '&isSureSend=1" redirect-url="' + e.attr("redirect-url") + '">ç»§ç»­æŠ•é€’</button></div></div>',
					title: "æ‚¨ä¸å¤ªç¬¦åˆè¯¥bossçš„è¦æ±‚",
					confirmButton: !1,
					cancelButton: !1,
					closeIcon: !0,
					columnClass: "pop-tip-box pop-detail",
					onOpen: function() {
						var e = this;
						e.$content.find(".btn").on("click", function() {
							"å†çœ‹çœ‹" == $(this).text() && e.close(), "ç»§ç»­æŠ•é€’" == $(this).text() && (Detail.deliveResume($(this)), e.close())
						})
					},
					onClose: function() {}
				}), e.text("æŠ•é€’ç®€åŽ†").removeClass("btn-loading")) : 8 == t.rescode && ($.confirm({
					content: '<div class="deliver-pop"><p class="text">æ­¤èŒä½ä¸æ”¯æŒæŠ•é€’ï¼Œè¯·ä¸ŽBossç›´æŽ¥æ²Ÿé€š</p><div class="btns"><button type="button" class="btn">ç¡®å®š</button></div></div>',
					title: "æç¤º",
					confirmButton: !1,
					cancelButton: !1,
					closeIcon: !0,
					columnClass: "pop-tip-box pop-detail",
					onOpen: function() {
						var e = this;
						e.$content.find(".btn").on("click", function() {
							"ç¡®å®š" == $(this).text() && e.close()
						})
					},
					onClose: function() {}
				}), e.text("æŠ•é€’ç®€åŽ†").removeClass("btn-loading")) : 1011 == t.code ? (Detail.showSign(1011), e.text("æŠ•é€’ç®€åŽ†").removeClass("btn-loading")) : (alert(t.resmsg), e.text("æŠ•é€’ç®€åŽ†").removeClass("btn-loading"))
			},
			error: function(t) {
				e.text("æŠ•é€’ç®€åŽ†").removeClass("btn-loading")
			}
		}))
	},
	startChat: function(e) {
		var e = e,
			t = e.attr("data-url");
		"javascript:;" == e.attr("href") && (e.addClass("btn-disabled"), $.ajax({
			type: "POST",
			url: t,
			dataType: "JSON",
			data: null,
			success: function(t) {
				t.rescode ? 1 == t.rescode ? (window.location.href = e.attr("redirect-url"), e.attr("href", e.attr("redirect-url")).text("ç»§ç»­æ²Ÿé€š"), e.removeClass("btn-disabled")) : 3 != t.rescode && 4 != t.rescode || (Detail.showSign(t.rescode), e.removeClass("btn-disabled")) : 1011 == t.code ? (Detail.showSign(1011), e.removeClass("btn-disabled")) : (alert(t.resmsg), e.removeClass("btn-disabled"))
			},
			error: function(t) {
				e.removeClass("btn-disabled")
			}
		}))
	},
	showSign: function(e) {
		$.confirm({
			content: $(".sign-wrap").html(),
			title: !1,
			confirmButton: !1,
			cancelButton: !1,
			closeIcon: !0,
			columnClass: "pop-sign-box",
			onOpen: function() {
				var t = this;
				Sign.init(t.$content), 4 == e ? (t.$content.find(".sign-welcome").show(), Sign.countDown(t.$content.find(".sign-welcome .welcome-box .count-down"), function() {
					window.location.href = t.$content.find(".sign-welcome .welcome-box .btn").attr("href")
				})) : t.$content.find(".sign-pwd").show()
			},
			onClose: function() {
				Sign.interCount && (clearInterval(Sign.interCount), Sign.interCount = null)
			}
		})
	},
	showMes: function() {
		if(!_userInfo.isLogin || !_userInfo.isPerfect) {
			var e = $(".message");
			Detail.canClick = !1, $.each(_userInfo.text, function(t, i) {
				e.find(".text").eq(t).html(i)
			}), Detail.firstIn ? (setTimeout(function() {
				$(".container-mes").fadeIn(), $(".container-mes").find(".avatar").css("display", "block")
			}, 1e3), setTimeout(function() {
				e.css("top", "40px"), e.fadeIn(), e.find("li").eq(0).fadeIn()
			}, 1800), setTimeout(function() {
				e.find("li").eq(1).fadeIn()
			}, 2600), setTimeout(function() {
				e.find("li").eq(2).fadeIn(), Detail.canClick = !0
			}, 3400), Detail.firstIn = !1) : (e.css("top", "40px"), e.fadeIn(200), $(".container-mes").find(".avatar").fadeIn(200), Detail.canClick = !0)
		}
	},
	showTip: function() {
		if((!_userInfo.isLogin || !_userInfo.isPerfect) && _userInfo.showTip) {
			var e = $(".avatar img");
			Detail.canClick = !1, setTimeout(function() {
				$(".message").css("z-index", "101"), $(".aladingtip").fadeIn(), e.addClass("avatar-ani"), e.mouseover(function() {
					$(this).removeClass("avatar-ani")
				}), e.mouseout(function() {
					$(this).addClass("avatar-ani")
				})
			}, 3400), $(".aladingtip").click(function() {
				$(this).fadeOut(function() {
					e.removeClass("avatar-ani"), e.unbind("mouseover mouseout")
				})
			})
		}
	},
	showGuide: function() {
		var e = $(".container-tip"),
			t = $(".container-mes"),
			i = this;
		t.find(".message").css({
			top: "20px",
			"-webkit-transition": "all linear .2s",
			transition: "all linear .2s"
		}).fadeOut(), t.find(".avatar").fadeOut(), $(".aladingtip").fadeOut(), e.fadeIn(200), e.find(".tip-box").css({
			"margin-bottom": "35px",
			"-webkit-transition": "all linear .2s",
			transition: "all linear .2s"
		}), e.find(".trangle").css({
			bottom: "69px",
			"-webkit-transition": "all linear .2s",
			transition: "all linear .2s"
		}), e.find("a.close").click(function() {
			e.find(".tip-box").css({
				"margin-bottom": "15px",
				"-webkit-transition": "all linear .2s",
				transition: "all linear .2s"
			}), e.find(".trangle").css({
				bottom: "49px",
				"-webkit-transition": "all linear .2s",
				transition: "all linear .2s"
			}), $(".message").css("top", "160px"), e.fadeOut(function() {
				i.showMes()
			}), $(".jconfirm").length && $(".jconfirm").remove()
		})
	}
};
$(function() {
	Detail.init()
});