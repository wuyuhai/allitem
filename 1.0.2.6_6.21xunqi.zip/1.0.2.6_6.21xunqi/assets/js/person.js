var data = {
	"err_code": 0,
	"err_msg": "请求成功",
	"page": "-1",
	"data": ""
}

//个人简历页
function Wopen(obj1, obj2) {
	obj1.on("click", function() {
		$('.item-form').hide();
		obj2.show();
	})
}

function Wclose(obj1, obj2) {
	obj1.on("click", function() {
		obj2.hide();
	})
}

//点击显示隐藏框，点击其他地方隐藏
function wshow(obj, obj2) {
	obj.bind('keyup', function() {
		obj2.show()
	})
	$(document).bind('click', function() {
		obj2.hide();
	})
}
wshow($('.w-wantkinds'), $('.bq_add'));
Wclose($(".btn-back-1"), $("#w-basicmessage"))

Wopen($('.w-myadness-a'), $('#w-myadness'));
Wclose($(".btn-back-2"), $("#w-myadness"));

Wclose($(".btn-back-3"), $("#w-add-purpose"))

Wopen($('.w-history-exp-a,#w-history-exp-a'), $("#w-history-exp"));
Wclose($(".btn-back-4"), $("#w-history-exp"));
$('#w-history-exp-b').on('click', function() {
	$("#w-history-exp").show();
})

//1.0.2调整了当项目经验为零的时候弹出框格式乱掉的位置
function Wopen1(obj1, obj2) {
	obj1.on("click", function() {
		$('.item-form').hide();
		obj2.show();
		console.log(obj2[0].offsetHeight)
		obj2.css({
			top: -(obj2[0].offsetHeight - obj2.parents('.resume-item')[0].clientHeight) + 'px',
		})
		$('html,body').animate({
			scrollTop: obj2.parents('.resume-item')[0].offsetTop - (obj2[0].offsetHeight - obj2.parents('.resume-item')[0].clientHeight)
		}, 500);
		//		obj2.parents('.resume-item')
	})
}
Wopen1($('.w-item-exp-a,#w-item-exp-a,.w-item-exp-b'), $("#w-item-exp"));
//1.0.2调整了当项目经验为零的时候弹出框格式乱掉的位置
Wclose($(".btn-back-5"), $("#w-item-exp"));
$('#w-item-exp-b').on('click', function() {
	$("#w-item-exp").show();
})

//1.0.2.3
Wopen1($('.w-edution-exp-a ,#w-edution-exp-a,.w-edution-exp-b'), $("#w-edution-exp"));
Wopen1($('.w-history-exp-a ,#w-history-exp-a,.w-history-exp-b'), $("#w-history-exp"));

Wclose($(".btn-back-6"), $("#w-edution-exp"));

//$('.w-edution-exp-b').on('click', function() {
//	$("#w-edution-exp").show();
//})

//导航定位
var nav = (function(navObj) {
	navObj.init = function() {
		this.n = 0;
		this.offsetTop = [];
		this.scrolltype = true;
		for(var i = 0; i < $('.resume-item').length; i++) {
			this.offsetTop.push($('.resume-item').eq(i).offset().top);
		};
		navObj.bindE();
	};
	navObj.bindE = function() { //滚动条滚动改变导航元素效果
		var self = this; //这里的this等同于上面的this
		$(window).bind('load scroll', function() {
			var stval = $(this).scrollTop();
			if(stval > 175) { //判断滚动条滚动距离大于或小于header高度时，让导航效果对应在第一个上
				if(stval < self.offsetTop[0]) {
					self.n = 0;
				} else {
					for(var j = 0; j < self.offsetTop.length; j++) {
						if(stval > (self.offsetTop[j] + 175) && stval < self.offsetTop[j + 1]) {
							self.n = j + 1;
							break;
						} //这里的300是常量
					};
				};
			}
		});
		$('.resume-nav li').delegate('a', 'click', function(e) { //   点击导航定位页面内容			
			self.n = $(this).index('.resume-nav li a');
			self.scrolltype = false;
			var t = self.offsetTop[self.n];
			$('html,body').animate({
				scrollTop: t
			}, 500, function() { //   滚动条滚动 页面不同内容的offsetTop值实现按钮对应效果
				self.scrolltype = true;
			});
			if(window.screen.width <= 414 && window.screen.width >= 320) {
				$('.deliver-sider').hide()
			}
		});
	};
	return navObj;
})(window.navObj || {});
nav.init();

//1.0.2字数修正函数
function textlength_els(obj1) {
	var lenInput = obj1[0].value.length;
	console.log(obj1[0].value)
	obj1.next().find('.textareaInput').html(lenInput);
}
//1.0.2字数修正函数

//基础信息
var myDate = new Date();
//获取当前年
var year = myDate.getFullYear();
console.log(year)
$('.w-basicmessage-a,#w-basicmessage-a').on('click', function() {
	$("#w-basicmessage").show();
	var wName = document.getElementsByClassName("w-name-2")[0];
	wName.value = $('.w-name-1')[0].innerHTML;
	//1.0.2.5
	var t = parseInt($('#wbwtime')[0].innerText.substring(0, 1))
	if($('#wbwtime')[0].innerText == "应届生") {
		$('#beginworkt')[0].value = 0;
	} else if($('#wbwtime')[0].innerText == "1年以内工作经验") {
		$('#beginworkt')[0].value = year;
	} else {
		$('#beginworkt')[0].value = year - t;
	}
	//1.0.2.5
	$('.wPhone-i')[0].value = $('.wPhone')[0].innerText
	$('.wWechat-i')[0].value = $('.wWechat')[0].innerText
})
$('.vali_btn-1').on('click', function() {
	var reg = /^1[3|4|5|7|8][0-9]{9}$/; //验证规则
	var p = $('.wPhone-i')[0].value; //手机号码
	var l = reg.test(p); //验证结果，true/false
	if(l == false) {
		$('.wPhone-i').next().show();
	} else {
		var wSection = document.getElementsByClassName("wSection")[0];
		var wPhone = document.getElementsByClassName("wPhone")[0];
		var wWechat = document.getElementsByClassName("wWechat")[0];
		if($('.w-name-2')[0].value != "") {
			var nm;
			if($('#beginworkt')[0].value == 0) {
				nm = 0
			} else {
				nm = year - parseInt($('#beginworkt')[0].value) + 1;
			}
			//1.0.2后台逻辑完善
			console.log()
			var htm = "";
			if($('#beginworkt')[0].value == 0) {} else if($('#beginworkt')[0].value == year) {
				htm = "1年以内工作经验";
			} else {
				year = year - $('#beginworkt')[0].value;
				htm = year + '年工作经验'
			};
			alert('姓名' + $('.w-name-2').get(0).value + '参加工作时间' + $('#beginworkt')[0][nm].innerText + '性别' + $('#sex')[0].value + '求职状态' + $('#w-work-section').get(0).value + '电话' + $('.wPhone-i').get(0).value + '微信号' + $('.wWechat-i').get(0).value)
			//发送求情，当返回的
			//$.get()
			var data = {
				"err_code": 0,
				"err_msg": "请求成功",
				"page": "-1",
				"data": ""
			}
			alert(data.err_code);
			if(data.err_code == 0) {
				$('.w-name-1')[0].innerHTML = $('.w-name-2').get(0).value;
				$('#wbwtime')[0].innerHTML = '<i class="fz-resume fz-experience"></i>' + htm
				$('#seximg').attr('class', '');
				if($('#sex')[0].value == 1) {
					$('#seximg').addClass("fz-resume fz-male")
				} else {
					$('#seximg').addClass("fz-resume fz-female")
				}
				wSection.innerHTML = '<i class="fz-resume fz-status"></i>' + $('#w-work-section').get(0).value;
				wPhone.innerHTML = '<i class="fz-resume fz-tel"></i>' + $('.wPhone-i').get(0).value;
				if($('.wWechat-i').get(0).value == "") {
					wWechat.innerHTML = "";
				} else {
					wWechat.innerHTML = '<i class="fz-resume fz-weixin"></i>' + $('.wWechat-i').get(0).value;
				};
				//alert('姓名' + $('.w-name-1')[0].innerHTML + '，性别' + $('#sex')[0].value + '，求职状态' + $('#w-work-section').get(0).value + '，工作经验' + $('#wbwtime')[0].innerText + ',电话' + p + '，微信号' + wWechat.innerText)
				alert('修改成功')
				$("#w-basicmessage").hide();
			} else {
				alert('修改失败');
			}
			//1.0.2后台逻辑完善
		}
	}
})
//我的优势
$('#w-myadness-a').on('click', function() {
	$('#w-myadness').show()
	$('#wmyadnesstxt')[0].innerHTML = $(".w-myness-p")[0].innerText
	//1.0.2字数修正
	textlength_els($('#wmyadnesstxt'));
	//1.0.2字数修正
})
$('.vali_btn-2').on('click', function() {
	var wmynessp = document.getElementsByClassName("w-myness-p")[0];
	if($('.w-myness-txt')[0].value != "") {
		//1.0.2后台逻辑完善
		//发送请求
		//$.get()
		alert('我的优势' + $('.w-myness-txt').get(0).value);
		var data = {
			"err_code": 1,
			"err_msg": "请求成功",
			"page": "-1",
			"data": ""
		}
		if(data.err_code == 0) {
			//请求成功			
			wmynessp.innerHTML = $('.w-myness-txt').get(0).value;
			alert('修改成功');
			$('#w-myadness').hide();
		} else {
			alert('网络开小车了')
		}
		//1.0.2后台逻辑完善
	}
})
//求职意向
//添加
$('#w-add-purpose-a, .w-add-purpose-a').on('click', function() {
	if($('#w-wantWook').find('.w-wantworks').length < 3) {
		$("#w-add-purpose").show()
		//1.0.2修正标题
		$('#w-add-purpose').find('h5')[0].innerText = "添加求职意向";
		//1.0.2修正标题
	} else {
		alert('期望职位达到上限');
	}
})
$('body').on('click', '.vali_btn-3', function() {
	var arr = [];
	for(var i = 0; i < $('.bq_hy').find('p').length; i++) {
		arr.push($('.bq_hy').find('p').eq(i).text())
	}
	var arrStr = arr.join("-");
	//为显示框添加的val值
	if($('.bq_hy').find('p').length != 0) {
		arrStr = arrStr
	} else {
		arrStr = '不限'
	}
	var num = 5;
	var divs = document.createElement("div");
	divs.className = 'w-wantworks';
	divs.setAttribute('val', num)
	var a = '<span class="label-text" val="' + $("#wyanzhengma").find('p')[0].getAttribute('value') + '"><i class="fz-resume fz-job"></i>';
	var b = '</span><em class="vline"></em><span class="label-text"><i class="fz-resume fz-salary"></i>';
	var c = '</span><em class="vline"></em><span class="label-text"><i class="fz-resume fz-industry"></i>';
	var d = '</span><em class="vline"></em><span class="label-text"><i class="fz-resume fz-place"></i>';
	var e = '</span><div class="op"><a href="javascript:;" class="link-edit"><i class="fz-resume fz-edit"></i>编辑</a><a href="javascript:;" class="link-delete"><i class="fz-resume fz-delete"></i>删除</a></div>';
	var xz = "";
	if($("#wxinzi1").get(0).value == "0") {
		xz = "面谈"
	} else {
		xz = $("#wxinzi1").get(0).value + " K" + "-" + $("#wxinzi2").get(0).value + " K";
	}
	divs.innerHTML = a + $("#wyanzhengma").get(0).textContent + b + xz + c + arrStr + d + $('.addresss').get(0).value + e;
	if($('.addresss')[0].value == '') $('.wsuggest').next().show();
	if($('.addresss')[0].value != '' && $("#wyanzhengma").find('p').length != 0) {
		alert('添加的val值为' + num + '，期望职位' + $("#wyanzhengma")[0].innerText + '，期望薪资' + xz + '，期望行业' + arrStr + '，期望地址' + $('.addresss').get(0).value)
		//向后台发送请求
		//$.get()
		if(data.err_code == 0) {
			//请求成功
			console.log(111)
			//			var app = "";
			$('#w-wantWook').get(0).appendChild(divs);
			alert('添加成功')
			$('#w-add-purpose').hide();
			$('#wyanzhengma')[0].innerText = "期望职位不能为空";
			$('#wxinzi1')[0].value = "0";
			$('#wxinzi2').hide();
			$('.bq_hy')[0].innerText = "不限";
			$('.addresss').get(0).value = '';
			var c = document.getElementById('wxinzi2').options;
			c.length = 0
			for(var i = 1; i < 25; i++) {
				var opts = document.createElement('option');
				var $opts = $(opts)
				opts.text = i + " K";
				$opts.attr('value', i)
				c.add(opts)
			}
		} else {
			alert('网络开小车了')
		}
	}
})

function hd(ob1, ob2) {
	ob1.on('focus', function() {
		ob2.hide()
	})
}
hd($('.addresss'), $('.wsuggest').next());
hd($('.bq_hy'), $('.select-box-hy').next());
//编辑
$('body').on('click', '.link-edit', function() {
	if($(this).parents('#w-wantWook').find('.w-wantworks').length != 0) {
		//1.0.2逻辑完善
		//1.0.2修正标题
		$('#w-add-purpose').find('h5')[0].innerText = "编辑求职意向";
		//1.0.2修正标题
		var item = $(this).parents('.w-wantworks')
		var val = $(this).parents('.w-wantworks').attr('val')
		$('.vali_btn-3').hide();
		$('.vali_btn-3-el').show();
		$(this).parents('.item-primary').find('#w-add-purpose').show();
		console.log(item.find('.label-text')[0].getAttribute('val'))
		$('#wyanzhengma').html('').append('<p val="' + item.find('.label-text')[0].getAttribute('val') + '">' + item.find('.label-text')[0].innerText + '</p>'); //期望职位
		if(item.find('.label-text')[1].innerText == "面谈") {
			$('#wxinzi1')[0].value = 0;
			$('#wxinzi2').hide();
		} else {
			var txt = item.find('.label-text')[1].innerText.split('-');
			$('#wxinzi2').show()
			$('#wxinzi1')[0].value = parseInt(txt[0]);
			$('#wxinzi2')[0].value = parseInt(txt[1]);
		}
		if(item.find('.label-text')[2].innerHTML != "不限") {
			$('.bq_hy').html('')
			for(var n = 0; n < item.find('.label-text')[2].innerText.split('-').length; n++) {
				$('.bq_hy').append('<p>' + item.find('.label-text')[2].innerText.split('-')[n] + '</P>')
			}
		} else {
			$('.bq_hy').html('')
			$('.bq_hy')[0].innerText = "不限"
		}
		$('.addresss').get(0).value = item.find('.label-text')[3].innerText;
		//1.0.2逻辑完善
		$('.vali_btn-3-el').unbind('click').on('click', function() {
			var arr = [];
			for(var i = 0; i < $('.bq_hy').find('p').length; i++) {
				arr.push($('.bq_hy').find('p').eq(i).text())
			}
			var arrStr = arr.join("-");
			//1.0.2修改编辑结束后显示技能重复的问题
			if($('.bq_hy').find('p').length != 0) {
				arrStr = arrStr
			} else {
				arrStr = '不限'
			}
			//1.0.2修改编辑结束后显示技能重复的问题
			if($('.addresss')[0].value == '') $('.wsuggest').next().show();
			if($('.addresss')[0].value != '' && $("#wyanzhengma").find('p').length != 0) {
				//1.0.2后台逻辑完善
				var xinz = ""
				if($('#wxinzi1')[0].value == "0") {
					xinz = '面谈'
				} else {
					xinz = $('#wxinzi1').get(0).value + " K" + '-' + $('#wxinzi2').get(0).value + " K";
				}
				alert('编辑val' + val + '期望职位' + $('#wyanzhengma').find('p')[0].innerHTML + '薪资要求' + xinz + '期望行业' + arrStr + '期望城市' + $('.addresss').get(0).value)
				//发送请求
				//$.get
				var data = {
					"err_code": 0,
					"err_msg": "请求成功",
					"page": "-1",
					"data": ""
				}
				if(data.err_code == 0) {
					//1.0.2修改薪资为空是不显示的问题
					//1.0.2修改薪资为空是不显示的问题
					item.find('.label-text')[0].innerHTML = '<i class="fz-resume fz-job"></i>' + $('#wyanzhengma').find('p')[0].innerHTML;
					//1.0.2修改薪资为空是不显示的问题
					item.find('.label-text')[1].innerHTML = '<i class="fz-resume fz-salary"></i>' + xinz;
					//1.0.2修改薪资为空是不显示的问题
					item.find('.label-text')[2].innerHTML = '<i class="fz-resume fz-industry"></i>' + arrStr;
					item.find('.label-text')[3].innerHTML = '<i class="fz-resume fz-place"></i>' + $('.addresss').get(0).value
					$('#w-add-purpose').hide()
					$('.vali_btn-3').show();
					$('.vali_btn-3-el').hide();
					$('#wyanzhengma')[0].innerText = "期望职位不能为空";
					//1.0.2修改关闭后薪资框变为默认值
					$('#wxinzi1')[0].value = "0";
					$('#wxinzi2').hide();
					//1.0.2修改关闭后薪资框变为默认值
					$('.bq_hy')[0].innerText = "不限";
					$('.addresss').get(0).value = '';
					var c = document.getElementById('wxinzi2').options;
					c.length = 0
					for(var i = 1; i < 25; i++) {
						var opts = document.createElement('option');
						var $opts = $(opts)
						opts.text = i + " K";
						$opts.attr('value', i)
						c.add(opts)
					}
					alert('保存成功')
				} else {
					alert('网络开小车了')
				}
				//1.0.2后台逻辑完善
			}
		})
	}
})
//1.0.2编辑框取消后值清空
$(".btn-back-3").unbind('click').on('click', function() {
	$('#w-add-purpose').hide()
	$('.vali_btn-3').show();
	$('.vali_btn-3-el').hide();
	$('#wyanzhengma')[0].innerText = "期望职位不能为空";
	$('#wxinzi1')[0].value = "0";
	$('#wxinzi2').hide();
	$('.bq_hy')[0].innerText = "不限";
	$('.addresss').get(0).value = '';
	var c = document.getElementById('wxinzi2').options;
	c.length = 0
	for(var i = 1; i < 25; i++) {
		var opts = document.createElement('option');
		var $opts = $(opts)
		opts.text = i + " K";
		$opts.attr('value', i)
		c.add(opts)
	}
})
//1.0.2编辑框取消后值清空
//删除
$('body').on('click', '.link-delete', function() {
	if($(this).parents('#w-wantWook').find('.w-wantworks').length != 0) {
		if($('#w-wantWook').find('.w-wantworks').length > 1) {
			alert('删除的val值' + $(this).parents('.w-wantworks').attr('val'))
			//发送求情
			//$.get()
			if(data.err_code == 0) {
				$(this).closest('.w-wantworks').remove();
				alert('删除成功')
			} else {
				alert('网络打酱油了')
			}
		} else {
			alert('期望职位不能为空')
		}
	}
})

//添加工作经历
//1.0.2修正标题
$('.w-history-exp-a,#w-history-exp-a').on('click', function() {
	$('#w-history-exp').find('h5')[0].innerText = "添加工作经验";
	//1.0.2字数修正
	textlength_els($('.w-work-contants')); //文字框下的字数
	textlength_els($('.w-work-howwell')); //文字框下的字数
	//1.0.2字数修正
})
//1.0.2修正标题
$('.vali_btn-4').on('click', function() {
	//1.0.1修改了技能标签的添加方法
	var spans = "";
	for(var i = 0; i < $('.bq_skills').find('p').length; i++) {
		spans += '<span>' + $('.bq_skills').find('p').eq(i).text() + '</span>'
	}
	//1.0.1
	var divs = document.createElement("div");
	//给 divs 一个val值
	var num = 2;
	divs.className = 'history-item';
	divs.setAttribute('val', num)
	var a, b, c, d, e, f, g, h, p;
	a = '<div class="op"><a href="javascript:;" class="link-edit w-history-exp-b"><i class="fz-resume fz-edit"></i>编辑</a><a href="javascript:;" class="link-delete"><i class="fz-resume fz-delete"></i>删除</a></div><span class = "period" >';
	b = '</span><h4 class = "name w-companyname" >';
	c = '</h4><div class = "text" ><h4 class="opt"><p val="' + $("#qw").find('p')[0].getAttribute('value') + '">';
	d = '</p><em class = "vline"></em><p>';
	e = '</p></h4><div class = "text" ><h4 >工作内容 </h4><pre class="comcont">';
	f = '</pre></div><div class="text"><h4>工作业绩</h4><pre class="comyeji">';
	g = '</pre></div></div><div class = "text"><h4>';
	h = '</h4></div>';
	//1.0.2。1添加新字段
	p = '<div style="display: none;">' +
		'<div class="w_sshy">' +
		'<p>所属行业</p>' +
		'<input type="" name="" id="" value="' + $('#w_sshysl')[0].value + '" />' +
		'</div>' +
		'<div class="w_ssbm">' +
		'<p>所属部门</p>' +
		'<span>' + $('#sscomm')[0].value + '</span>' +
		'</div>' +
		'<div>' +
		'<p>所属id</p>' +
		'<div class="ycidFid">' + fid_id1 + '</div>' +
		'</div>' +
		'</div>';
	//1.0.2.2修改时间间隔字段
	divs.innerHTML = a + $('#datetimepicker1').get(0).value + "-" + $('#datetimepicker2').get(0).value + b + $("#companyname").get(0).value + c + $("#qw")[0].innerText + d + $("#optionname").get(0).value + e + $(".w-work-contants").get(0).value + f + $(".w-work-howwell").get(0).value + g + spans + h + p;
	//1.0.2.2修改时间间隔字段
	if(timeb($("#datetimepicker1"), $("#datetimepicker2")) == false) alert('请填写正确时间段')
	if($("#qw").find('p').length != 0 && $('.bq_skills').find('p').length != 0 && $("#companyname").get(0).value != "" && $("#optionname").get(0).value != "" && $(".w-work-contants").get(0).value != "" && $(".w-work-howwell").get(0).value != "" && timeb($("#datetimepicker1"), $("#datetimepicker2")) == true) {
		alert('记录id' + fid_id1 + ",时间" + $('#datetimepicker1').get(0).value + '至' + $('#datetimepicker2').get(0).value + '，公司名称' + $("#companyname").get(0).value + '，职位类型' + $("#qw")[0].innerText + '，职位名称' + $("#optionname").get(0).value + '，技能标签' + spans + '，工作内容' + $(".w-work-contants").get(0).value + '，工作业绩' + $(".w-work-howwell").get(0).value + '所属行业' + $('#w_sshysl')[0].value + '所属部门' + $('#sscomm')[0].value)
		//1.0.2.1添加新字段
		//发送请求
		//$.get()
		if(data.err_code == 0) {
			$('.history-project-work').prepend(divs);
			$('.history-project-work')[0].selectedIndex = 0;
			$('.history-project-work').change();
			alert("添加成功");
			//1.0.2.1字段清空
			$('#w-history-exp').hide();
			$('#companyname')[0].value = ""
			$('#qw')[0].innerText = "必填"
			$('#optionname')[0].value = "";
			$('.bq_skills')[0].innerText = "必填"
			$('#datetimepicker1')[0].value = "";
			$('#datetimepicker2')[0].value = "";
			//1.0.2.1修正添加BUG
			$('.w-work-contants')[0].value = "";
			$('.w-work-howwell')[0].value = "";
			//1.0.2.1清空
			$('#w_sshysl')[0].value = 0;
			$('#sscomm')[0].value = "";
			//1.0.2.1清空
		} else {
			alert('网络开小车了')
		}
	}
})
//时间选择
function timexq(obj) {
	obj.on('click', function() {
		event.stopPropagation(); //阻止事件冒泡
		var tt = $(this).next();
		tt.show()
		//		$(this).next().show()
		onc($('#calendar'), $("#datetimepicker1"), tt)
		onc($('#calendar2'), $("#datetimepicker2"), tt)
		onc($('#calendar3'), $("#datetimepicker3"), tt)
		onc($('#calendar4'), $("#datetimepicker4"), tt)
	})
}

//时间函数
function onc(obj, obj2, tt) {
	var table = obj.find('.calendar-table')[0];
	var tds = table.getElementsByTagName('td');
	var a = "";
	var b = "";
	tt.toggle();
	var tag = tt.toggle();
	for(var i = 0; i < tds.length; i++) {
		tds[i].onclick = function() {
			obj2[0].value = $(this).parents('.calendar').find('.calendar-title')[0].innerText + "年" + this.innerText;
			//			console.log(this.innerText + $(this).parents('.calendar').find('.calendar-title')[0].innerText)
			a = $(this).parents('.calendar').find('.calendar-title')[0].innerText + "年" + this.innerText;
			b = obj2[0].value;
			//			$(this).parents('.calendar').hide()
		}
	}
	$('div.timefooter', obj).unbind('click').on('click', function() {
		obj2[0].value = this.innerText;
		console.log(1111)
		$(this).parents('.calendar').hide()
	})
	var flag = true;
	$(document).bind("click", function(e) { //点击空白处，设置的弹框消失
		var target = $(e.target);
		if(flag == true) {
			tag.hide();
			flag = false;
		}
	});

}

timexq($("#datetimepicker1"))
timexq($("#datetimepicker2"))
timexq($("#datetimepicker3"))
timexq($("#datetimepicker4"))
//时间逻辑
function timeb(a, b) {
	var date = new Date();
	var year = date.getFullYear()
	var q = a[0].value.split('月');
	w = b[0].value.split('月');
	var num1 = parseInt(q[0].substring(0, 4))
	num2 = parseInt(w[0].substring(0, 4));
	var num3, num4;
	if(q[0].length = 6) {
		num3 = parseInt(q[0].substring(5, 7));
		num4 = parseInt(w[0].substring(5, 7));
	} else {
		num3 = parseInt(q[0].substring(5, 7));
		num4 = parseInt(w[0].substring(5, 7));
	}
	var bol = false;
	//1.0.2.2添加至今判断的逻辑
	if(num1 <= year && num2 <= year) {
		bol = true;
	} else if(num1 <= year && b[0].value == '至今') {
		bol = true;
	}
	if(bol == true) {
		if(b[0].value == '至今') {
			return true;
		} else {
			if(num1 > num2) {
				return false;
			} else if(num1 = num2) {
				if(num3 <= num4) {
					return true;
				} else {
					return false;
				}
			} else {
				return true;
			}
		}
	} else {
		return false
	}
	//1.0.2.2添加至今判断的逻辑
}
//编辑
$('body').on('click', '.link-edit', function() {
	if($(this).parents('.history-project-work').find('.history-item').length != 0) {
		//1.0.2修正标题
		$('#w-history-exp').find('h5')[0].innerText = "编辑工作经验";
		//1.0.2修正标题
		//1.0.2.1获取隐藏id
		fid_id1 = $('.ycidFid')[0].innerText;
		//1.0.2.1获取隐藏id
		var item = $(this).parents('.history-item')
		$('.vali_btn-4-el').show();
		$('.vali_btn-4').hide();
		var val = $(this).parents('.history-item').attr('val');
		//1.0.2.2修改时间的从属
		var arr = item.find('.period')[0].innerText;
		//1.0.2.2修改时间的间隔字段
		ay = arr.split("-")
		$(this).parents('#resume-history').find('#w-history-exp').show();
		$('#companyname')[0].value = $(this).parents('.history-item').find('.w-companyname')[0].innerHTML;
		//1.0.2.1添加val值
		$('#qw').html('').append('<p val="' + $(this).parents('.history-item').find('p')[0].getAttribute('val') + '">' + $(this).parents('.history-item').find('p')[0].innerText + '</p>')
		$('#optionname')[0].value = $(this).parents('.history-item').find('p')[1].innerText;
		$('.bq_skills').html('');
		//1.0.2.1修正格式乱掉
		for(var i = 1; i < $(this).parents('.history-item').find('span').length - 1; i++) {
			$('.bq_skills').append('<p>' + $(this).parents('.history-item').find('span')[i].innerText + '</p>')
		}
		//1.0.2.1修正格式乱掉
		$('#datetimepicker1')[0].value = ay[0];
		console.log(ay[1])
		$('#datetimepicker2')[0].value = ay[1];
		//1.0.2.2从属关系
		$('.w-work-contants')[0].value = $(this).parents('.history-item').find('.comcont')[0].innerText;
		$('.w-work-howwell')[0].value = $(this).parents('.history-item').find('.comyeji')[0].innerText;
		//1.0.2字数修正
		textlength_els($('.w-work-contants')); //文字框下的字数
		textlength_els($('.w-work-howwell')); //文字框下的字数
		//1.0.2字数修正
		//1.0.2.2从属关系
		$('#w_sshysl')[0].value = item.find('.w_sshy').children('input')[0].value; //所属行业
		$('#sscomm')[0].value = item.find('.w_ssbm').children('span')[0].innerText; //所属部门
		//---1.0.2.2从属关系
		$('.vali_btn-4-el').unbind('click').on('click', function() {
			//1.0.1修改了技能标签的添加方法
			var arrsk = []
			for(var i = 0; i < $('.bq_skills').find('p').length; i++) {
				arrsk.push($('.bq_skills').find('p').eq(i).text())
			}
			//1.0.1修改了技能标签的添加方法
			if(timeb($("#datetimepicker1"), $("#datetimepicker2")) == false) alert('请填写正确时间段')
			if($("#qw").find('p').length != 0 && $('.bq_skills').find('p').length != 0 && $("#companyname").get(0).value != "" && $("#optionname").get(0).value != "" && $(".w-work-contants").get(0).value != "" && $(".w-work-howwell").get(0).value != "" && timeb($("#datetimepicker1"), $("#datetimepicker2")) == true) {
				//1.0.2后台逻辑完善
				//1.0.2.1添加隐藏字段
				alert('修改vol' + val + ',记录id' + fid_id1 + ",时间" + $('#datetimepicker1').get(0).value + '至' + $('#datetimepicker2').get(0).value + '，公司名称' + $("#companyname").get(0).value + '，职位类型' + $("#qw")[0].innerText + '，职位名称' + $("#optionname").get(0).value + '，技能标签' + arr + '，工作内容' + $(".w-work-contants").get(0).value + '，工作业绩' + $(".w-work-howwell").get(0).value + '所属行业' + $('#w_sshysl')[0].value + '所属部门' + $('#sscomm')[0].value)
				//1.0.2.1添加隐藏字段
				//发送请求
				//$.get()
				var data = {
					"err_code": 0,
					"err_msg": "请求成功",
					"page": "-1",
					"data": ""
				}
				if(data.err_code == 0) {
					//1.0.2.2从属关系
					$('h4', item.find('.skillszs')).html('')
					$('.w-companyname')[0].innerText = $('#companyname')[0].value; //公司名称
					item.find('p')[0].innerText = $("#qw")[0].innerText; //职业类型
					item.find('p')[1].innerText = $('#optionname')[0].value; //职业名称
					console.log($('#datetimepicker1')[0].value)
					item.find('.period')[0].innerText = $('#datetimepicker1')[0].value + '-' + $('#datetimepicker2')[0].value; //时间
					//1.0.1修改了技能标签的添加方法
					for(var i = 0; i < arrsk.length; i++) {
						$('h4', item.find('.skillszs')).append('<span>' + arrsk[i] + '</span>')
					}
					//1.0.1修改了技能标签的添加方法
					item.find('.comcont')[0].innerText = $('.w-work-contants')[0].value; //工作内容
					item.find('.comyeji')[0].innerText = $('.w-work-howwell')[0].value; //获得成就	
					item.find('.w_sshy').children('input')[0].value = $('#w_sshysl')[0].value; //所属行业
					item.find('.w_ssbm').children('span')[0].innerText = $('#sscomm')[0].value; //所属部门
					item.find('.ycidFid')[0].innerText = fid_id1;
					//1.0.2.2从属关系
					alert('修改成功')
					$('#w-history-exp').hide();
					$('.vali_btn-4').show();
					$('.vali_btn-4-el').hide();
					$('#companyname')[0].value = ""
					$('#qw')[0].innerText = "必填"
					//1.0.2.1清空
					$('#w_sshysl')[0].value = 0;
					$('#sscomm')[0].value = "";
					//1.0.2.1清空
					$('#optionname')[0].value = "";
					$('.bq_skills')[0].innerText = "必填"
					$('#datetimepicker1')[0].value = "";
					$('#datetimepicker2')[0].value = "";
					//1.0.2.1修正添加BUG
					$('.w-work-contants')[0].value = "";
					$('.w-work-howwell')[0].value = "";
					//1.0.2.1修正添加BUG
				} else {
					alert('网络开小车')
				}
				//1.0.2后台逻辑完善
			}
		})
	}
})
//1.0.2编辑框取消后值清空
$(".btn-back-4").unbind('click').on('click', function() {
	$('#w-history-exp').hide();
	$('.vali_btn-4').show();
	$('.vali_btn-4-el').hide();
	$('#companyname')[0].value = ""
	$('#qw')[0].innerText = "必填"
	$('#optionname')[0].value = "";
	$('.bq_skills')[0].innerText = "必填"
	$('#datetimepicker1')[0].value = "";
	$('#datetimepicker2')[0].value = "";
	//1.0.2.1修正添加BUG
	$('.w-work-contants')[0].value = "";
	$('.w-work-howwell')[0].value = "";
	//1.0.2.1修正添加BUG
	//1.0.2.1清空
	$('#w_sshysl')[0].value = 0;
	$('#sscomm')[0].value = "";
	//1.0.2.1清空
})
//1.0.2编辑框取消后值清空
//删除
$('.history-project-work').on('click', '.link-delete', function() {
	if($(this).parents('.history-project-work').find('.history-item').length != 0) {
		console.log($('.history-project-work').find('.history-item').length)
		if($('.history-project-work').find('.history-item').length > 1) {
			//发送请求
			//$.get()
			if(data.err_code == 0) {
				alert('删除的val值' + $(this).parents('.history-item').attr('val'))
				$(this).closest('.history-item').remove();
				alert('删除成功')
			} else {
				alert('网络开小车')
			}
		} else {
			alert("工作经历不能为空")
		}
	}
})

//项目经验
//1.0.2修正标题
$('.w-item-exp-a,#w-item-exp-a').on('click', function() {
	$('#w-item-exp').find('h5')[0].innerText = "添加项目经验";
	//1.0.2字数修正
	textlength_els($('.w-itemtatil')); //文字框下的字数修正
	//1.0.2。1字数修正
})
//1.0.2修正标题
$('.vali_btn-5').on('click', function() {
	//清样式
	var divs = document.createElement("div");
	divs.className = 'history-item';
	var num = 5; //记录值
	divs.setAttribute('val', num)
	var a, b, c, d, e, f, g, h;
	a = '<div class="op"><a href="javascript:;" class="link-edit w-item-exp-b"><i class="fz-resume fz-edit"></i>编辑</a><em class="vline"></em><a href="javascript:;" class="link-delete" id="w-item-exp-c"><i class="fz-resume fz-delete"></i>删除</a></div><span class="period">';
	b = '</span><h4 class="name"><div class="text"><span>';
	c = '</span><em class="vline"></em><span>';
	d = '<span></h4><h4>项目内容</h4><pre>';
	e = '</pre></div>';
	//1.0.2.1补全模块
	h = '<div class="text item_yj">' +
		'<h4>项目业绩</h4>' +
		'<pre class="item_yj_pre">' + $('.w-itemyj')[0].value + '</pre>' +
		'</div>' +
		'<div class="item_url" style="display: none;">' +
		'<h4>项目url</h4>' +
		'<span>' + $('#item-url')[0].value + '</span>' +
		'</div>';
	divs.innerHTML = a + $("#datetimepicker3")[0].value + '-' + $("#datetimepicker4")[0].value + b + $(".w-itemname").get(0).value + c + $(".w-itemplay").get(0).value + d + $(".w-itemtatil").get(0).value + e + h;
	var m = $("#datetimepicker3")[0].value + '至' + $("#datetimepicker4")[0].value,
		n = $(".w-itemname").get(0).value,
		o = $(".w-itemplay").get(0).value,
		p = $(".w-itemtatil").get(0).value;
	if(timeb($("#datetimepicker3"), $("#datetimepicker4")) == false) alert('请填写正确时间段')
	if(m != "" && n != "" && o != "" && p != "" && timeb($("#datetimepicker3"), $("#datetimepicker4")) == true) {
		alert("添加val值" + num + ',时间' + m + ",项目名称" + n + '，项目角色' + o + '，项目简介' + p + '，项目业绩' + $('.w-itemyj')[0].value + '，项目URL' + $('#item-url')[0].value)
		//------1.0.2.1
		//发送求情
		//$.get()
		if(data.err_code == 0) {
			$('.history-project-item').prepend(divs);
			$('.history-project-item')[0].selectedIndex = 0;
			$('.history-project-item').change();
			//1.0.2.1如果有显示，没有隐藏
			console.log($(divs).find('.item_yj_pre')[0].innerText)
			if($(divs).find('.item_yj_pre')[0].innerText != "") {
				$(divs).find('.item_yj').show();
			} else {
				$(divs).find('.item_yj').hide();
			}
			//------1.0.2.1如果有显示，没有隐藏
			alert("添加成功")
			$('#w-item-exp').hide();
			$("#datetimepicker3")[0].value = "";
			$("#datetimepicker4")[0].value = "";
			$(".w-itemname").get(0).value = "";
			$(".w-itemplay").get(0).value = "";
			$(".w-itemtatil").get(0).value = "";
			//1.0.2.1清除
			$('.w-itemyj')[0].value = "";
			$('#item-url')[0].value = "";
			//-----1.0.2.1
		} else {
			alert('网络开小车了')
		}
	}
})
//编辑
$('body').on('click', '.link-edit', function() {
	if($(this).parents('.history-project-item').find('.history-item').length != 0) {
		//1.0.2修正标题
		$('#w-item-exp').find('h5')[0].innerText = "编辑项目经验";
		//1.0.2修正标题
		var item = $(this).parents('.history-item')
		$('.vali_btn-5-el').show();
		$('.vali_btn-5').hide();
		$('#w-item-exp').show();
		var val = $(this).parents('.history-item').attr('val');
		op = item.find('.period')[0].innerText.split('-')
		$("#datetimepicker3")[0].value = op[0];
		$("#datetimepicker4")[0].value = op[1];
		$(".w-itemname").get(0).value = item.find('span')[1].innerText
		$(".w-itemplay").get(0).value = item.find('span')[2].innerText
		$(".w-itemtatil").get(0).value = item.find('pre')[0].innerHTML;
		//1.0.2.1
		$('.w-itemyj')[0].value = item.find('.item_yj_pre')[0].innerText;
		$('#item-url')[0].value = item.find('.item_url').children('span')[0].innerText;
		//1.0.2字数修正
		textlength_els($('.w-itemtatil')); //文字框下的字数修正
		//1.0.2。1字数修正
		textlength_els($('.w-itemyj')); //文字框下的字数修正
		$('.vali_btn-5-el').unbind('click').on('click', function() {
			if(timeb($("#datetimepicker3"), $("#datetimepicker4")) == false) alert('请填写正确时间段')
			if($(".w-itemname").get(0).value != "" && $(".w-itemplay").get(0).value != "" && $(".w-itemtatil").get(0).value != "" && timeb($("#datetimepicker3"), $("#datetimepicker4")) == true) {
				//1.0.2后台逻辑完善
				var m = $("#datetimepicker3")[0].value + '-' + $("#datetimepicker4")[0].value;
				alert("修改的val值" + val + ',时间' + m + ",项目名称" + $(".w-itemname").get(0).value + '，项目角色' + $(".w-itemplay").get(0).value + '项目简介' + $(".w-itemtatil").get(0).value + '，项目业绩' + $('.w-itemyj')[0].value + ',项目URL' + $('#item-url')[0].value)
				//————--1.0.2.1
				//发送请求
				//$.get
				var data = {
					"err_code": 0,
					"err_msg": "请求成功",
					"page": "-1",
					"data": ""
				}
				if(data.err_code == 0) {
					item.find('.period')[0].innerText = $("#datetimepicker3")[0].value + '-' + $("#datetimepicker4")[0].value
					item.find('span')[1].innerText = $(".w-itemname").get(0).value
					item.find('span')[2].innerText = $(".w-itemplay").get(0).value
					item.find('pre')[0].innerHTML = $(".w-itemtatil").get(0).value
					//1.0.2.1
					item.find('.item_yj_pre')[0].innerText = $('.w-itemyj')[0].value;
					item.find('.item_url').children('span')[0].innerText = $('#item-url')[0].value;
					//成就，有显示，没有隐藏
					if(item.find('.item_yj_pre')[0].innerText != "") {
						item.find('.item_yj').show()
					} else {
						item.find('.item_yj').hide()
					}
					//1.0.2.1
					alert('修改成功');
					$('#w-item-exp').hide();
					$('.vali_btn-5-el').hide();
					$('.vali_btn-5').show();
					$("#datetimepicker3")[0].value = "";
					$("#datetimepicker4")[0].value = "";
					$(".w-itemname").get(0).value = "";
					$(".w-itemplay").get(0).value = "";
					$(".w-itemtatil").get(0).value = "";
					//1.0.2.1清空
					$('.w-itemyj')[0].value = "";
					$('#item-url')[0].value = "";
					//1.0.2.1清空
				} else {
					alert('网络开小车了')
				}
				//1.0.2后台逻辑完善
			}
		})
	}
})
//1.0.2编辑框取消后值清空
$(".btn-back-5").unbind('click').on('click', function() {
	$('#w-item-exp').hide();
	$('.vali_btn-5-el').hide();
	$('.vali_btn-5').show();
	$("#datetimepicker3")[0].value = "";
	$("#datetimepicker4")[0].value = "";
	$(".w-itemname").get(0).value = "";
	$(".w-itemplay").get(0).value = "";
	$(".w-itemtatil").get(0).value = "";
	//1.0.2.1清空
	$('.w-itemyj')[0].value = "";
	$('#item-url')[0].value = "";
	//1.0.2.1清空
})
//1.0.2编辑框取消后值清空
//删除
$('#resume-project').on('click', '.link-delete', function() {
	if($(this).parents('#resume-project').find('.history-item').length != 0) {
		if($('#resume-project').find('.history-item').length > 1) {
			//发送请求
			//$.get()
			if(data.err_code == 0) {
				alert('删除的val值' + $(this).parents('.history-item').attr('val'))
				$(this).closest('.history-item').remove();
				alert('删除成功')
			} else {
				alert('网络开小差')
			}
		} else {
			alert("项目经验不能为空")
		}
	}
})

//教育经历
//添加
//1.0.2修正标题
$('.w-edution-exp-a ,#w-edution-exp-a').on('click', function() {
	$('#w-edution-exp').find('h5')[0].innerText = "添加在校经验";
})
//1.0.2修正标题
$('.vali_btn-6').on('click', function() {
	var divs = document.createElement("div");
	divs.className = 'history-item';
	var num = 2
	divs.setAttribute('val', num)
	var t, t1, t2;
	if($('#time2')[0].value == '在读') {
		t = $('#time2')[0].value + '-' + "至今";
	} else {
		t1 = parseInt($('#time1')[0].value.substring(0, 4));
		t2 = parseInt($('#time2')[0].value.substring(0, 4));
		if(t1 > t2) alert('请填写 正确时间段')
		t = $('#time1')[0].value + '-' + $('#time2')[0].value;
	}
	console.log(t.indexOf('至今') != -1)
	var a, b, c, d, e, f;
	//1.0.2.3
	a = '<div class="op"><a href="javascript:;" class="link-edit w-edution-exp-b"><i class="fz-resume fz-edit"></i>编辑</a><em class="vline"></em><a href="javascript:;" class="link-delete"><i class="fz-resume fz-delete"></i>删除</a></div><span class="period">';
	//1.0.2.3
	b = '</span><h4 class="name">';
	c = '</h4><div class="text"><h4><span>';
	d = '</span><em class="vline"></em><span>';
	e = '</span></h4></div>';
	//1.0.2.1添加在校经验
	f = '<div class="school-jl" style="display: none;">' +
		'<h4>在校经历</h4>' +
		'<pre class="school_jl">' + $('.w-school_jl')[0].value + '</pre>' +
		'</div>';
	divs.innerHTML = a + t + b + $(".schoolname").get(0).value + c + $(".schitemname").get(0).value + d + $(".schoolwellage").get(0).value + e + f;
	if((t1 <= t2 || t.indexOf('至今') != -1) && $(".schoolname").get(0).value != "" && $(".schitemname").get(0).value != "") {
		alert(",添加val" + num + '，时间' + t + ',学校名称' + $(".schoolname").get(0).value + ',专业名称' + $(".schitemname").get(0).value + '，学历' + $(".schoolwellage").get(0).value + ',在校经历' + $('.w-school_jl')[0].value)
		//1.0.2.1添加在校经验
		//发送求情
		//$.get
		if(data.err_code == 0) {
			$('.history-education').prepend(divs);
			$('.history-education')[0].selectedIndex = 0;
			$('.history-education').change();
			//1.0.2.1在校经验，如果有显示，没有隐藏
			if($(divs).find('.school_jl')[0].innerText != "") {
				$(divs).find('.school-jl').show();
			} else {
				$(divs).find('.school-jl').hide();
			}
			//1.0.2.1成就，如果由显示，没有隐藏
			alert("添加成功")
			$('#w-edution-exp').hide();
			//1.0.2.1清空
			$('.w-school_jl')[0].value = "";
			//1.0.2.1清空
			$(".schoolname").get(0).value = ""
			$(".schitemname").get(0).value = ""
		} else {
			alert("网络开小车了")
		}
	} else {
		alert('提交内容不符合要求，请按要求修改')
	}
})
//编辑修改
$('body').on('click', '.link-edit', function() {
	if($(this).parents('#resume-education').find('.history-item').length != 0) {
		//1.0.2.1修正标题
		$('#w-edution-exp').find('h5')[0].innerText = "编辑在校经验";
		//1.0.2.1修正标题
		var item = $(this).parents('.history-item');
		$('.vali_btn-6-el').show();
		$('.vali_btn-6').hide();
		$("#w-edution-exp").show();
		var val = $(this).parents('.history-item').attr('value');
		var a = $(this).parents('.history-item').find('span')[0].innerText.split('-');
		console.log(a[0].substr(0, 4))
		$(".schoolname").get(0).value = $(this).parents('.history-item').find('.name')[0].innerText;
		$(".schitemname").get(0).value = $(this).parents('.history-item').find('span')[1].innerText;
		$('.w-school_jl')[0].value = item.find('.school_jl')[0].innerText;
		//1.0.2字数修正
		textlength_els($('.schoolname')); //文字框的字数修正
		textlength_els($('.schitemname')); //文字框的字数修正
		//1.0.2字数修正
		//1.0.2.1字数修正
		textlength_els($('.w-school_jl')); //文字框的字数修正
		$(".schoolwellage")[0].value = $(this).parents('.history-item').find('span')[2].innerText;
		$('#time1')[0].value = a[0].substr(0, 4) + '年';
		$('#time2')[0].value = a[0].substr(0, 4) + '年';
		$('.vali_btn-6-el').unbind('click').on('click', function() {
			var t, t1, t2;
			if($('#time2')[0].value == '在读') {
				t = $('#time2')[0].value + '-' + "至今";
			} else {
				t1 = parseInt($('#time1')[0].value.substring(0, 4));
				t2 = parseInt($('#time2')[0].value.substring(0, 4));
				if(t1 > t2) alert('请填写 正确时间段')
				t = $('#time1')[0].value + '-' + $('#time2')[0].value;
			}
			if((t1 <= t2 || t.indexOf('至今') != -1) && $(".schoolname").get(0).value != "" && $(".schitemname").get(0).value != "") {
				//1.0.2后台逻辑完善
				alert('编辑的val' + val + '，时间' + t + ',学校名称' + $(".schoolname").get(0).value + ',专业名称' + $(".schitemname").get(0).value + '，学历' + $(".schoolwellage").get(0).value + ',在校经历' + $('.w-school_jl')[0].value)
				//发送请求
				//$.get()
				var data = {
					"err_code": 0,
					"err_msg": "请求成功",
					"page": "-1",
					"data": ""
				}
				if(data.err_code == 0) {
					item.find('.name')[0].innerText = $(".schoolname").get(0).value;
					item.find('span')[1].innerText = $(".schitemname").get(0).value;
					item.find('span')[2].innerText = $(".schoolwellage")[0].value;
					item.find('span')[0].innerText = $('#time1')[0].value + '-' + $('#time2')[0].value
					//1.0.2.1添加在校经验，如果由显示，没有不显示
					item.find('.school_jl')[0].innerText = $('.w-school_jl')[0].value;
					if(item.find('.school_jl')[0].innerText != "") {
						item.find('.school-jl').show()
					} else {
						item.find('.school-jl').hide()
					}
					//1.0.2.1添加在校经验，如果由显示，没有不显示
					alert('修改成功')
					$('#w-edution-exp').hide();
					$('.vali_btn-6-el').hide();
					$('.vali_btn-6').show();
					$(".schoolname").get(0).value = '';
					$(".schitemname").get(0).value = '';
					//1.0.2.1完成后清除
					$('.w-school_jl')[0].value = "";
					//1.0.2.1完成后清除
				} else {
					alert('网络开小车')
				}
				//1.0.2后台逻辑完善
			}
		})
	}
})
//1.0.2编辑框取消后值清空
$(".btn-back-6").unbind('click').on('click', function() {
	$('#w-edution-exp').hide();
	$('.vali_btn-6-el').hide();
	$('.vali_btn-6').show();
	$(".schoolname").get(0).value = '';
	$(".schitemname").get(0).value = '';
	//1.0.2.1完成后清除
	$('.w-school_jl')[0].value = "";
	//1.0.2.1完成后清除
})
//1.0.2编辑框取消后值清空
//删除
$('#resume-education').on('click', '.link-delete', function() {
	console.log(1111)
	if($(this).parents('#resume-education').find('.history-item').length != 0) {
		console.log($('#resume-education').find('.history-item').length)
		if($('#resume-education').find('.history-item').length > 1) {
			alert('删除的val值' + $(this).parents('.history-item').attr('val'))
			//发送求情
			//$.get
			if(data.err_code == 0) {
				$(this).closest('.history-item').remove();
				alert("删除成功")
			} else {
				alert('网络开小车了')
			}
		} else {
			alert("教育经历不能为空")
		}
	}
})

$('.addresss').on('keydown', function() {
	//发送请求
	//获得数据，占记
	$('#address').html('');
	var data_address = {
		"err_code": 0,
		"err_msg": "请求成功",
		"page": "-1",
		"data": [{
			"id": 1,
			"name": "大连"
		}, {
			"id": 2,
			"name": "大同"
		}, {
			"id": 3,
			"name": "大山"
		}, {
			"id": 4,
			"name": "大大"
		}]
	}
	if(data_address.err_code == 0) {
		$.each(data_address.data, function(i, item) {
			$('#address').append('<li value="' + item.id + '">' + item.name + '</li>')
		});
	} else {
		alert("请检查网络");
	}
	$('.wsuggest').show()
	var a = "",
		b = "";
	$('li', $('#address')).on('click', function() {
		var item = $(this)[0];
		var fid = $(this).attr('value');
		$('.addresss')[0].value = item.innerText;
		console.log($(this))
		a = item.innerText;
		b = $('.addresss')[0].value;
		$(document).bind('click', function() {
			if($('.addresss')[0].value == item.innerText) {
				$('.addresss')[0].value = item.innerText;
			} else {
				$('.addresss')[0].value = "";
			}
			$('.wsuggest').hide();
		})
	})
	$(document).bind('click', function() {
		if(b == a) {
			$('.addresss')[0].value = a;
		} else {
			$('.addresss')[0].value = "";
		}
		$('.wsuggest').hide();
	})
})

$('.schoolname').on('input porpertychange', function(event) {
	event.stopPropagation(); //阻止事件冒泡
	var tt = $(this).parent('div').find('.wsuggest')
	tt.show()
	//发送请求
	//$.get
	tt.find('ul').show();
	tt.find('ul').html('');
	var data_school = {
		"err_code": 0,
		"err_msg": "请求成功",
		"page": "-1",
		"data": [{
			"id": 1,
			"name": "大连大学"
		}, {
			"id": 2,
			"name": "大连理工大学"
		}, {
			"id": 3,
			"name": "大连海事大学"
		}, {
			"id": 4,
			"name": "大连交通大学"
		}]
	}
	if(data_school.err_code == 0) {
		$.each(data_school.data, function(i, item) {
			tt.find('ul').append('<li value="' + item.id + '">' + item.name + '</li>')
		});
		var a = "";
		var b = "";
		tt.toggle();
		var tag = tt.toggle();
		$('li', tt.find('ul')).on('click', function() {
			item = $(this)[0];
			var fid = $(this).attr('value');
			$('.schoolname')[0].value = item.innerText;
			a = item.innerText;
			b = $('.schoolname')[0].value;
		})
		var flag = true;
		$(document).bind("click", function(e) { //点击空白处，设置的弹框消失
			var target = $(e.target);
			if(flag == true) {
				tag.hide();
				flag = false;
			}
		});
	} else {
		alert('网络开小车了')
	}
})

$('.schitemname').on('input porpertychange', function(event) {
	event.stopPropagation(); //阻止事件冒泡
	var tt = $(this).parent('div').find('.wsuggest')
	tt.show()
	//发送请求
	//$.get
	tt.find('ul').show();
	tt.find('ul').html('');
	var data_schoolshill = {
		"err_code": 0,
		"err_msg": "请求成功",
		"page": "-1",
		"data": [{
			"id": 1,
			"name": "物流工程"
		}, {
			"id": 2,
			"name": "金融"
		}, {
			"id": 3,
			"name": "计算机"
		}, {
			"id": 4,
			"name": "机械工程"
		}]
	}
	if(data_schoolshill.err_code == 0) {
		$.each(data_schoolshill.data, function(i, item) {
			tt.find('ul').append('<li value="' + item.id + '">' + item.name + '</li>')
		});
		var a = "";
		var b = "";
		tt.toggle();
		var tag = tt.toggle();
		$('li', tt.find('ul')).on('click', function() {
			item = $(this)[0];
			var fid = $(this).attr('value');
			$('.schitemname')[0].value = item.innerText;
			a = item.innerText;
			b = $('.schitemname')[0].value;
		})
		var flag = true;
		$(document).bind("click", function(e) { //点击空白处，设置的弹框消失
			var target = $(e.target);
			if(flag == true) {
				tag.hide();
				flag = false;
			}
		});
	} else {
		alert('网络开小车了')
	}
})

//1.0.2.3选填函数整理
//	期望职位
history($('.w-want-box'), $('.w-want-res'), $('#wyanzhengma'));
//	期望行业
kills($('.select-box-hy'), $('.select-res-hy'))
//技能标签
kills($('.select-box-hiskills'), $('.select-res-hiskills'))
//职位类型
history($('.select-box-his'), $('.select-res-his'), $('#qw'));

//1.0.2.3移动端适配
console.log(window.screen.width)
if(window.screen.width <= 414 && window.screen.width >= 320) {
	$('#wmyadnesstxt').attr('cols', '');
	$('.w-work-contants').attr('cols', '');
	$('.w-work-howwell').attr('cols', '');
	$('.w-itemtatil').attr('cols', '');
	$('.w-itemyj').attr('cols', '');
	$('.w-school_jl').attr('cols', '');
}
$('.deliver-sider-nav').unbind('click').on('click', function() {
	$('.deliver-sider').show();
})
$('.deliver-sider-navs').unbind('click').on('click', function() {
	$('.deliver-sider').hide();
})
//------1.0.2.3移动端适配