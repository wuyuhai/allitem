/**
 * Created by hx on 2017/4/14.
 */
var data_op = {
	"err_code": 0,
	"err_msg": "请求成功",
	"page": "-1",
	"data": [{
		"id": 1,
		"name": "技术"
	}, {
		"id": 2,
		"name": "产品"
	}, {
		"id": 3,
		"name": "设计"
	}, {
		"id": 4,
		"name": "运营"
	}, {
		"id": 5,
		"name": "市场"
	}, {
		"id": 6,
		"name": "职能/高级管理"
	}, {
		"id": 7,
		"name": "销售"
	}, {
		"id": 8,
		"name": "传媒"
	}, {
		"id": 9,
		"name": "金融"
	}, {
		"id": 10,
		"name": "汽车"
	}, {
		"id": 11,
		"name": "教育培训"
	}, {
		"id": 12,
		"name": "医疗健康"
	}, {
		"id": 13,
		"name": "采购/贸易"
	}, {
		"id": 14,
		"name": "供应链/物流"
	}, {
		"id": 15,
		"name": "房地产/建筑"
	}, {
		"id": 16,
		"name": "咨询/翻译/法律"
	}, {
		"id": 17,
		"name": "实习生/管培生"
	}, {
		"id": 18,
		"name": "其他"
	}]
}
var data_id_data = {
	"err_code": 0,
	"err_msg": "请求成功",
	"page": "-1",
	"data": [{
		"id": 1,
		"name": "后端开发"
	}, {
		"id": 2,
		"name": "移动开发"
	}, {
		"id": 3,
		"name": "测试"
	}, {
		"id": 4,
		"name": "运维/技术支持"
	}, {
		"id": 5,
		"name": "数据"
	}, {
		"id": 6,
		"name": "项目管理"
	}, {
		"id": 7,
		"name": "硬件开发"
	}, {
		"id": 8,
		"name": "前端开发"
	}, {
		"id": 9,
		"name": "通信"
	}, {
		"id": 10,
		"name": "高端技术职位"
	}, {
		"id": 11,
		"name": "人工智能"
	}, {
		"id": 12,
		"name": "软件销售支持"
	}, {
		"id": 13,
		"name": "其他技术职位"
	}]
}
var data_id_id_data = {
	"err_code": 0,
	"err_msg": "请求成功",
	"page": "-1",
	"data": [{
		"id": 1,
		"name": "Java"
	}, {
		"id": 2,
		"name": "C++"
	}, {
		"id": 3,
		"name": "PHP"
	}, {
		"id": 4,
		"name": "数据挖掘"
	}, {
		"id": 5,
		"name": "C"
	}, {
		"id": 6,
		"name": "C#"
	}, {
		"id": 7,
		"name": ".NET"
	}, {
		"id": 8,
		"name": "Hadoop"
	}, {
		"id": 9,
		"name": "Python"
	}, {
		"id": 10,
		"name": "Delphi"
	}, {
		"id": 11,
		"name": "VB"
	}, {
		"id": 12,
		"name": "Perl"
	}, {
		"id": 13,
		"name": "Ruby"
	}, {
		"id": 14,
		"name": "Node.js"
	}, {
		"id": 15,
		"name": "搜索算法"
	}, {
		"id": 16,
		"name": "Golang"
	}, {
		"id": 17,
		"name": "自然语言处理"
	}, {
		"id": 18,
		"name": "推荐算法"
	}, {
		"id": 19,
		"name": "Erlang"
	}, {
		"id": 20,
		"name": "算法工程师"
	}, {
		"id": 21,
		"name": "语音/视频/图形开发"
	}, {
		"id": 22,
		"name": "数据采集"
	}]
}
var data_skill = {
	"err_code": 0,
	"err_msg": "请求成功",
	"page": "-1",
	"data": [{
		"id": 1,
		"name": "Java爬虫"
	}, {
		"id": 2,
		"name": "html"
	}, {
		"id": 3,
		"name": "css3"
	}, {
		"id": 4,
		"name": "JQ"
	}, {
		"id": 5,
		"name": "BOOTSTRAP"
	}, {
		"id": 6,
		"name": "C#"
	}, {
		"id": 7,
		"name": "VOE"
	}, {
		"id": 8,
		"name": "ANJULAR"
	}, {
		"id": 9,
		"name": "NODE"
	}, {
		"id": 10,
		"name": "Delphi"
	}]
}
var data_hy = {
	"err_code": 0,
	"err_msg": "请求成功",
	"page": "-1",
	"data": [{
		"id": 1,
		"name": "金融"
	}, {
		"id": 2,
		"name": "旅游"
	}, {
		"id": 3,
		"name": "教育"
	}, {
		"id": 4,
		"name": "多媒体"
	}, {
		"id": 5,
		"name": "物流"
	}, {
		"id": 6,
		"name": "互联网"
	}, {
		"id": 7,
		"name": "销售"
	}, {
		"id": 8,
		"name": "美工"
	}, {
		"id": 9,
		"name": "仓储"
	}, {
		"id": 10,
		"name": "Delphi"
	}]
}
var data_inter = {
	"err_code": 0,
	"err_msg": "请求成功",
	"page": "-1",
	"data": [{
		"id": 1,
		"name": "股票期权"
	}, {
		"id": 2,
		"name": "带薪休假"
	}, {
		"id": 3,
		"name": "年度旅游"
	}, {
		"id": 4,
		"name": "不打卡"
	}, {
		"id": 5,
		"name": "年终分红"
	}, {
		"id": 6,
		"name": "美女多"
	}, {
		"id": 7,
		"name": "美女如云"
	}, {
		"id": 8,
		"name": "扁平管理"
	}, {
		"id": 9,
		"name": "只能硬件"
	}, {
		"id": 10,
		"name": "电子商务"
	}]
}

function fillData(ob1, ob2) {
	if(ob1.err_code == 0) {
		$.each(ob1.data, function(i, item) {
			ob2.append('<li value="' + item.id + '">' + item.name + '</li>')
		});
	} else {
		alert("请检查网络");
	}
}
var fid_id1 = 0;
var fid_id2 = 0;

function history(ob1, ob2, op,comeback) {
	$('span', ob2).on('click', function() {
		op.html("");
		if($(this).parents('.form-group').find('.select-res-his').length == 1 || $(this).parents('#wkind').find('.select-res-his').length == 1) {
			fid_id1 = 0
			$('.select-res-hiskills').children().html("");
		}
		ob1.show();
		$('.w_second').hide();
		$('.w_third').hide();
		$('.w_first').show();
		$('ul', ob1).html('');
		fillData(data_op, $('.w_first'))
	})
	//第一个列表
	$('ul.w_first', ob1).on('click', 'li', function() {
		$('ul.w_second').html('');
		$('ul.w_third').html('');
		$('ul.w_third').hide();
		$(this).addClass('w_selected').siblings().removeClass('w_selected');
		var item = $(this);
		var fid = item.attr('value');
		//用fid做下一个就扣的请求标记
		//		$.get("www.baidu.com/id=fid");暂记 data_id_data							
		fillData(data_id_data, $('.w_second'));
		$('ul.w_second').show();
	});
	//第二个列表 
	$('ul.w_second', ob1).on('click', 'li', function() {
		$('ul.w_third').html('');
		var item = $(this);
		if($(this).parents('.form-group').find('.select-box-his').length == 1 || $(this).parents('#wkind').find('.select-res-his').length == 1) fid_id1 = item.attr('value');
		var fid = item.attr('value');
		$(this).addClass('w_selected').siblings().removeClass('w_selected');
		//继续用 fid 做第三个列表的的请求标记
		//		$.get("www.baidu.com/id=fid");暂记 data_id_id_data
		fillData(data_id_id_data, $('.w_third'));
		$('ul.w_third').show();
	});
	$('ul.w_third', ob1).on('click', 'li', function() {
		var cname = $(this).text();
		var item = $(this);
		var fid = item.attr('value');
		//1.0.2将标记的 val添加到标签里面去
		op.html("").append('<p value="' + fid + '">' + cname + '</p>');
		ob1.hide();
		//返回的 fid_id 是做为技能标签请求接口的id
		comeback && comeback();
	});
}



function kills(ob1, ob2) {
	var cname;
	//选择框的位置
	ob1.css({
		width: ob2.css('width'),
		top: ob2.outerHeight(true)
	});
	//点击选择框弹出
	$('span', ob2).on('click', function() {
		console.log(fid_id1)
		if($(this).parents('.form-group').find('.select-res-hiskills').length == 1 || $(this).parents('#skills').find('.select-res-hiskills').length == 1) {
			if(fid_id1 == 0) {
				alert('请 选择职位类型')
			} else {
				$('.bq_skills').html("");
				ob1.find('li').removeClass('select_li');
				ob1.show();
				$('ul', ob1).html('');
				//请求技能标签
				//用fid_id发送请求请求标记
				//$.get("www.baidu.com/id=fid");暂记 data_skill
				fillData(data_skill, $('.bq_box1'));
			}
		} else {
			$('.bq_hy').html("");
			ob1.find('li').removeClass('select_li');
			ob1.show();
			$('ul', ob1).html('');
			//请求期望行业
			//$.get("www.baidu.com/id=fid");暂记 data_skill
			fillData(data_hy, $('.bq_box2'));
		}
	});
	$('span', ob1).on('click', function() {
		ob1.hide();
	});
	$('ul', ob1).on('click', 'li', function() {
		if($('li[class="select_li"]', ob1).length < 3) {
			cname = $(this).text();
			var value = $(this).attr('value')
			var hasExist2 = !1;
			ob2.find("p").each(function() {
				if($(this).text() == cname) hasExist2 = !0
			})
			$(this).addClass('select_li');
			hasExist2 ? alert('所选标签已被添加！') : ob2.find('span').append('<p class="' + value + '">' + cname + '</p>');
			console.log(ob2.find('span').children().length)
			if(ob2.find('span').children().length == 3) {
				ob1.hide();
			}

		}
	});
}
//kills($('.select-box-ss'), $('.select-res-ss'))

//团队优势
function inter(ob1, ob2) {
	var cname;
	//选择框的位置
	ob1.css({
		width: ob2.css('width'),
		top: ob2.outerHeight(true)
	});
	//点击选择框弹出
	$('span', ob2).on('click', function() {
		$('#inter').html("");
		ob1.find('li').removeClass('select_li');
		ob1.show();
		$('ul', ob1).html('');
		console.log(111)
		//请求期望行业
		//$.get("www.baidu.com");暂记 data_inter
		fillData(data_inter, $('#inter_ul'));
	});
	$('span', ob1).on('click', function() {
		ob1.hide();
	});
	$('ul', ob1).on('click', 'li', function() {
		if($('li[class="select_li"]', ob1).length < 3) {
			cname = $(this).text();
			var value = $(this).attr('value');
			var hasExist2 = !1;
			ob2.find("p").each(function() {
				if($(this).text() == cname) hasExist2 = !0
			})
			$(this).addClass('select_li');
			hasExist2 ? alert('所选标签已被添加！') : ob2.find('span').append('<p class="' + value + '">' + cname + '</p>');
		}
	});
}

//所属行业单选
function hy(ob1, ob2) {
	var cname;
	//选择框的位置
	ob1.css({
		width: ob2.css('width'),
		top: ob2.outerHeight(true)
	});
	//点击选择框弹出
	$('span', ob2).on('click', function() {
		$(this).html("");
		ob1.find('li').removeClass('select_li');
		ob1.show();
		$('ul', ob1).html('');
		console.log(111)
		//请求期望行业
		//$.get("www.baidu.com");暂记 data_inter
		fillData(data_hy, $('.bq_box2'));
	});
	$('span', ob1).on('click', function() {
		ob1.hide();
	});
	$('ul', ob1).on('click', 'li', function() {
		if($('li[class="select_li"]', ob1).length < 3) {
			cname = $(this).text();
			var value = $(this).attr('value')
			ob2.find('span').append('<p value="' + value + '">' + cname + '</p>');
			ob1.hide();
		}
	});
}
