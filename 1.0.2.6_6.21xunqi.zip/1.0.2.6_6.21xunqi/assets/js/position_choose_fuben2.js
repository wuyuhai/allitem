var profession_two_type = 0;
function history(ob1,ob2,op) {
	var l1 = 0,
	l2 = 0;
	var cname1, cname2, cname3;
	var cid1, cid2, cid3;
	var canClick = !0;
	var canClose = !1;
	$('span', ob2).on('click', function() {
		op.html("")
		ob1.show();
		$('.w_first').show();
		$('.w_second').show();
		if(canClick) {
			$('ul', ob1).html('');
			fillData();
			canClick = !1;
		}
	});
	$('span', ob1).on("click", function() {
		canClose ? ob1.hide() : alert('请选择下级品类！');
		canClick = !0;
	});

	ob2.on('click', 'a', function() {
		$(this).parent().remove();
		ob1.css({
			// top: ob2.offset().top + ob2.outerHeight(true)
			top: ob2.outerHeight(true)
		});
	})
	if(document.body.clientWidth <= 768) {
		ob1.css({
			width: ob2.css('width')
		});
		//  $('#qw').html("")
		$('ul.w_first', ob1).on('click', 'li', function() {
			//	    $(this).addClass('w_selected').siblings().removeClass('w_selected');
			profession_two_type=0;
			$('ul.w_third').html('');
			$('ul.w_second').html('');
			fillData($(this).index());
			l1 = $(this).index();
			cname1 = $(this).text();
			cid1 = $(this).attr('val');
			canClose = !1;
			$('input.cid', ob2).val(cid1);
			$('input.cname', ob2).val(cname1);
			$('.w_first').hide();
		});
		$('ul.w_second', ob1).on('click', 'li', function() {
			//	    $(this).addClass('w_selected').siblings().removeClass('w_selected');
			fillData(l1, $(this).index());
			l2 = $(this).index();
			cname2 = $(this).text();
			cid2 = $(this).attr('val');
			profession_two_type = cid2;
			canClose = !1;
			$('input.cid', ob2).val(cid1 + ',' + cid2);
			$('input.cname', ob2).val(cname1 + ',' + cname2);
			$('.w_second').hide();
			$('.w_first').hide();
		});
	} else {
		ob1.css({
			top: ob2.outerHeight(true)
		});
		$('ul.w_first', ob1).on('click', 'li', function() {
			$(this).addClass('w_selected').siblings().removeClass('w_selected');
			profession_two_type=0;
			$('ul.w_third').html('');
			fillData($(this).index());
			l1 = $(this).index();
			cname1 = $(this).text();
			cid1 = $(this).attr('val');
			canClose = !1;
			$('input.cid', ob2).val(cid1);
			$('input.cname', ob2).val(cname1);
		});
		$('ul.w_second', ob1).on('click', 'li', function() {
			$(this).addClass('w_selected').siblings().removeClass('w_selected');
			fillData(l1, $(this).index());
			l2 = $(this).index();
			cname2 = $(this).text();
			cid2 = $(this).attr('val');
			profession_two_type = cid2;
			canClose = !1;
			$('input.cid', ob2).val(cid1 + ',' + cid2);
			$('input.cname', ob2).val(cname1 + ',' + cname2);
		});
	}

	//工作过的职位选择
	$('ul.w_third', ob1).on('click', 'li', function() {
		//  $(this).addClass('w_selected').siblings().removeClass('w_selected');
		cname3 = $(this).text();
		cid3 = $(this).attr('val');
		op.html("").append('<p value="'+cid3+'">' + cname3 + '</p>');
		ob1.css({
			// top: ob2.offset().top + ob2.outerHeight(true)
			top: ob2.outerHeight(true)
		});
		ob1.hide();
	});
}
history($('.select-box-his'),$('.select-res-his'),$('#qw'));
history($('.w-want-box'),$('.w-want-res'),$('#qw'));
history($('.select-box-want'),$('.select-res-want'),$('#wantqw'));

//期望职业
function wantop(ob1,ob2){
	var l1 = 0,
    l2 = 0;
var cname1, cname2, cname3;
var canClick = !0;
ob1.css({
    // left: ob2.offset().left,
    // top: ob2.offset().top + ob2.outerHeight(true)
    top:ob2.outerHeight(true)
});
$('span', ob2).on('click', function() {
    ob1.show();
    if (canClick) {
        $('ul', ob1).html('');
        fillData();
        canClick = !1;
    }
});
$('span', ob1).on("click", function() {
    canClose ? ob1.hide() : alert('请选择下级品类！');
    canClick = !0;
});

ob2.on('click', 'a', function() {
    $(this).parent().remove();
    ob1.css({
        // top: ob2.offset().top + ob2.outerHeight(true)
        top: ob2.outerHeight(true)
    });
})

$('ul.w_first', ob1).on('click', 'li', function() {
    $(this).addClass('w_selected').siblings().removeClass('w_selected');
    $('ul.third').html('');
    fillData($(this).index());
    l1 = $(this).index();
    cname1 = $(this).text();
    cid1 = $(this).attr('val');
    canClose = !1;
    $('input.cid', ob2).val(cid1);
    $('input.cname', ob2).val(cname1);
});
$('ul.w_second', ob1).on('click', 'li', function() {
    $(this).addClass('w_selected').siblings().removeClass('w_selected');
    fillData(l1, $(this).index());
    l2 = $(this).index();
    cname2 = $(this).text();
    cid2 = $(this).attr('val');
    canClose = !1;
    $('input.cid', ob2).val(cid1 + ',' + cid2);
    $('input.cname', ob2).val(cname1 + ',' + cname2);
});
$('ul.w_third', ob1).on('click', 'li', function() {
    $(this).addClass('w_selected').siblings().removeClass('w_selected');
    cname3 = $(this).text();
    cid3 = $(this).attr('val');
    canClose = !0;
    var hasExist = !1;
    ob2.find("p").each(function() {
        if ($(this).text().split(' > ')[2] == cname3) hasExist = !0;
    })
    if($('#wantqw').children("p").length < 3){
        if($('#wantqw').html() == "选择期望职位"){
            hasExist ? alert('所选品类已被添加！') : $('#wantqw').html("").append('<p>'  + cname3 + '</p>');
        }else{
            hasExist ? alert('所选品类已被添加！') : $('#wantqw').append('<p>'  + cname3 + '</p>');
        }
    }else{
        alert("对不起，你选择职位已到上限")
    }
    ob1.css({
        // top: ob2.offset().top + ob2.outerHeight(true)
        top:ob2.outerHeight(true)
    });
});
}
//wantop($('.select-box-want'),$('.select-res-want'))



var dataJson1 = "";
var dataJson2 = "";
var dataJson3 = "";
function fillData(l1, l2) {
	var temp_html = "";
	var length = arguments.length;
	if(length == 0){
		$.get("http://localhost:8989/xq/gapto",function(data){
			if(data.err_code==0){
				dataJson1 = data.data;
				$.each(data.data, function(i, pro) {
					temp_html += '<li val="' + pro.id + '">' + pro.name + '</li>';
				});
				$('.select-box-his ul:eq(' + length + ')').html(temp_html);
				$('.select-box-want ul:eq(' + length + ')').html(temp_html);
				$('.w-want-box ul:eq(' + length + ')').html(temp_html);
			}else{
				alert(data.err_msg);
			}
			
		});
	}
	if(length == 1){
		$.get("http://localhost:8989/xq/gptt/"+dataJson1[l1].id,function(data){
			if(data.err_code==0){
				dataJson2 = data.data;
				$.each(data.data, function(i, pro) {
					temp_html += '<li val="' + pro.id + '">' + pro.name + '</li>';
				});
				
				$('.select-box-his ul:eq(' + length + ')').html(temp_html);
				$('.select-box-want ul:eq(' + length + ')').html(temp_html);
				$('.w-want-box ul:eq(' + length + ')').html(temp_html);
			}else{
				alert(data.err_msg);
			}
			
		});
	}
	if(length == 2){
		$.get("http://localhost:8989/xq/gpthirdt/"+dataJson2[l2].id,function(data){
			if(data.err_code==0){
				dataJson3 = data.data;
				$.each(data.data, function(i, pro) {
					temp_html += '<li val="' + pro.id + '">' + pro.name + '</li>';
				});
				
				$('.select-box-his ul:eq(' + length + ')').html(temp_html);
				$('.select-box-want ul:eq(' + length + ')').html(temp_html);
				$('.w-want-box ul:eq(' + length + ')').html(temp_html);
			}else{
				alert(data.err_msg);
			}
			
		});
	}
	
	/*if(typeof(dataJson.option) != 'undefined' && arguments.length == 0) {
		
	} else if(typeof(dataJson.option[l1].child) != 'undefined' && arguments.length == 1) {
		$.each(dataJson.option[l1].child, function(i, pro) {
			temp_html += '<li val="' + pro.id + '">' + pro.name + '</li>';
		});
	} else if(typeof(dataJson.option[l1].child[l2].child) != 'undefined' && arguments.length == 2) {
		$.each(dataJson.option[l1].child[l2].child, function(i, pro) {
			temp_html += '<li val="' + pro.id + '">' + pro.name + '</li>';
		});
	}
	*/
	
}



//技能标签
function kills(ob1,ob2) {
	var cname;
	var canClick2 = !0;

	//选择框的位置
	ob1.css({
		width: ob2.css('width'),
		top: ob2.outerHeight(true)
	});

	//点击选择框弹出
	$('span', ob2).on('click', function() {
		$('.bq_skills').html("");
		ob1.find('li').removeClass('select_li');
		ob1.show();
		if(canClick2) {
			$('ul', ob1).html('');
			fillData2();
			canClick2 = !1;
		}
	});
	$('span', ob1).on('click', function() {
		ob1.hide();
	});
	$('ul', ob1).on('click', 'li', function() {
		if($('li[class="select_li"]',ob1).length < 3) {
			cname = $(this).text();
			var hasExist2 = !1;
			ob2.find("p").each(function() {
				if($(this).text() == cname) hasExist2 = !0
			})
			$(this).addClass('select_li');
			hasExist2 ? alert('所选标签已被添加！') : ob2.find('span').append('<p name="skillName">' + cname + '</p>');
			}
//		console.log($('li[class="select_li"]',ob1))
	});
}
kills($('.w-box-hiskills'),$('.w-res-hiskills'))
kills($('.select-box-hiskills'),$('.select-res-hiskills'))
kills($('.select-box-opkills'),$('.select-res-opkills'))
function fillData2() {
	var temp_html = "";
	if(profession_two_type==0){
		//注意一号重新选择，只绑定一个选择器
		alert("请先选择职业类型");
		return false;
	}
	//发送网络请求
	$.get("http://localhost:8989/xq/gskillbid/"+profession_two_type,function(data){
		if(data.err_code==0){
			$.each(data.data, function(i, pro) {
				temp_html += '<li val="' + pro.id + '">' + pro.name + '</li>';
			});
			$('.bq_wrap1 .bq_box1').html(temp_html);
			$('.bq_wrap2 .bq_box2').html(temp_html);
			$('.bq_wrap3 .bq_box3').html(temp_html);
		}else{
			alert(data.err_msg);
		}
		
	});
	
	

}

function wantHy(ob1,ob2) {
	var cname;
	var canClick2 = !0;

	//点击选择框弹出
	$('span', ob2).on('click', function() {
		$('.bq_hy').html("");
		ob1.find('li').removeClass('select_li');
		ob1.show();
		if(canClick2) {
			$('ul', ob1).html('');
			fillData3();
			canClick2 = !1;
		}
	});
	$('span', ob1).on('click', function() {
		ob1.hide();
	});
	$('ul', ob1).on('click', 'li', function() {
		if($('li[class="select_li"]',ob1).length < 3) {
			cname = $(this).text();
			var hasExist2 = !1;
			ob2.find("p").each(function() {
				if($(this).text() == cname) hasExist2 = !0
			})
			$(this).addClass('select_li');
			hasExist2 ? alert('所选标签已被添加！') : ob2.find('span').append('<p>' + cname + '</p>');
			}
	});
}
wantHy($('.select-box-hy'),$('.select-res-hy'))
function fillData3() {
	var temp_html = "";
	if(typeof(dataJson3.option) != 'undefined' && arguments.length == 0) {
		$.each(dataJson3.option, function(i, pro) {
			temp_html += '<li val="' + pro.id + '">' + pro.name + '</li>';
		})
	}
	$('.bq_wrap-hy .bq_box-hy').html(temp_html);
}