//地点
function wshow(obj, obj2) {
	obj.bind('keyup', function() {
		obj2.show()
	})
	$(document).bind('click', function() {
		obj2.hide();
	})
}

//picture preview,头像预览
function preview(file) { //预览图片得到图片base64
	var prevDiv = document.getElementById('preview');
	if(file.files && file.files[0]) {
		var reader = new window.FileReader();
		reader.onload = function(evt) {
			prevDiv.innerHTML = '<img src="' + evt.target.result + '" />';
		}
		reader.readAsDataURL(file.files[0]);
	} else {
		prevDiv.innerHTML = '<div class="img" style="filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(sizingMethod=scale,src=\'' + file.value + '\'"></div>';
	}
	return file
}

$(function() {
	//    工作经历的时间段
	$('#datetimepicker1').datetimepicker({
		locale: 'zh-cn',
		format: 'YYYY年MM月'
	});
	$('#datetimepicker2').datetimepicker({
		locale: 'zh-cn',
		format: 'YYYY年MM月'
	});

	$('#datetimepicker3').datetimepicker({
		locale: 'zh-cn',
		format: 'YYYY年MM月'
	});
	$('#datetimepicker4').datetimepicker({
		locale: 'zh-cn',
		format: 'YYYY年MM月'
	});
});

//1.0.2修改了字数限制的判断函数，且添加了学校和学校专业限制的判断
function textlength(obj1, num) {
	var lenInput = obj1.val().length;
	obj1.on('input porpertychange', function() {
		lenInput = $(this).val().length;
		if(lenInput >= 0 && lenInput <= num) {
			obj1.next().find('.textareaInput').html(lenInput);
		}
	})
}
textlength($('#u_name'), 4);
textlength($('.companyname'), 24);
textlength($('.workcontant'), 500);
textlength($('.schooljl'), 500);
textlength($('#wschoolname'), 24);
textlength($('#wzhuanyename'), 24);
textlength($('.myadwantage'), 2000);

//上一步，下一步
function nextpg() {
	//基础页
	$("#basic_inf_nbtn").on('click', function() {
		var t = $('#preview')[0].innerHTML,
			n = $('#u_name')[0].value;
		if(t == "") {
			$('#preview').parent().find('.dpn').show()
		} else {
			$('#preview').parent().find('.dpn').hide()
		}
		if(n == "") $('#u_name').parent().find('.dpn').show()
		if(t != "" && n != "") {
			alert('图片' + preview(document.getElementById("doc")).value + '，姓名' + n + '，性别' + $('#u_sexy')[0].value + ',工作年份' + $('#jjob')[0].value)
			//进入工作经历
			$('.basic_inf').hide()
			$('.work_exp').show()
		}
	})
	//返回基础页级
	$('#wexp_prebtn').on('click', function() {
		$('.work_exp').hide();
		$('.basic_inf').show()
		$('#preview').find('div').attr('src', $('#doc')[0].value)
	})
	//工作经历
	$('#wexp_nebtn').on('click', function() {
		var a = $('.companyname')[0].value, //公司名称
			b = $('#qw')[0].innerHTML, //职位类型
			//			b1 = $('#qw').find('p')[0].innerText,
			c = $('.select-res-hiskills').find('.bq_skills')[0].innerHTML, //技能标签			
			d = $('.workcontant')[0].value, //工作内容	
			t = $('.t1')[0].value,
			e = false;
		var c1 = "";
		for(var i = 0; i < $('.select-res-hiskills').find('.bq_skills').find('p').length; i++) {
			c1 += $('.select-res-hiskills').find('.bq_skills').find('p')[i].innerText + "-";
		}
		if($('#checkbox').prop('checked') == false) {
			if(timeb($('.t1'), $('.t2')) == false) alert('请输入正确时间段')
		}

		function op() {
			if($('#checkbox').prop('checked') == false) {
				if(timeb($('.t1'), $('.t2')) == false) {
					return false
				} else {
					return true;
				}
			} else {
				return true
			}
		}
		console.log(timeb($('.t1'), $('.t2')))
		if($('.t1')[0].value != "" && ($('.t2')[0].value != "" || $('#checkbox').prop('checked'))) e = true;
		if(a == "") $('.companyname').parent().find('.dpn').show()
		if(b == "") $('#qw').parents('.we_jobtype').find('.dpn').show()
		if(c == "") $('.bq_skills').parents('.wskills').find('.dpn').show()
		if(d == "") $('.workcontant').parent().find('.dpn').show();
		if(a != "" && b != "" && c != "" && d != "" && e && op() == true) {			
			alert("公司名称" + a + "，开始时间" + t + "结束时间（0代表至今）" + t2() + ",职位类型" + $('#qw').find('p')[0].innerText + ",记录id" + fid_id1 + ",技能标签" + c1 + ",工作内容" + d)
			//进入学校经历
			$('.work_exp').hide();
			$('.education').show();
		}
	})
	//返回工作经历
	$('#edu_prebtn').on('click', function() {
		$('.work_exp').show();
		$('.education').hide();
	})
	//教育经历、
	$('#edu_nebtn').on('click', function() {
		var a = $('#wschoolname')[0].value, //学校名称
			b = $('#wzhuanyename')[0].value, //专业名称
			c = $('#wschoolgood')[0].value, //学历
			d = $('.schooljl')[0].value; //在校经历
		if(a == "") $('#wschoolname').next().show();
		if(b == "") $('#wzhuanyename').next().show();
		if(timeb($('.t3'), $('.t4')) == false) alert('请输入正确时间段')
		if($('.t3')[0].value == "" || $('.t4')[0].value == "") {
			$('.t3').parents('#edu_time').find('.dpn').show();
		} else {
			$('.t3').parents('#edu_time').find('.dpn').hide();
		}
		if(c == 0) $('#wschoolgood').parents('.col-xs-8').find('.dpn').show();
		if(d == "") $('.schooljl').parents('.col-xs-8').find('.dpn').show();
		if(timeb($('.t3'), $('.t4')) == true && a != "" && b != "" && c != 0 && d != "" && ($('.t3')[0].value != "" && $('.t4')[0].value != "")) {
			alert("学校名称" + a + "，专业名称" + b + ",学历" + c + "，开始时间" + $('.t3')[0].value + "，结束时间" + $('.t4')[0].value + "，在校经历" + d);
			//在校经历页面 隐藏，我的优势显示
			$('.education').hide();
			$('.my_merit').show();
		}
	})
	//返回在校经历
	$('#mymt_prebtn').on('click', function() {
		$('.education').show();
		$('.my_merit').hide();
	})
	$('#mymt_nebtn').on('click', function() {
		var a = $('.myadwantage')[0].value;
		if(a == "") {
			$('.myadwantage').parents('.col-xs-8').find('.dpn').show()
		} else {
			alert("我的优势为" + a)
			//我的优势隐藏期望职位显示
			$('.my_merit').hide();
			$('.job_will').show();
		}
	})
	//返回我的优势
	$('#jobwi_prebtn').on('click', function() {
		$('.my_merit').show();
		$('.job_will').hide()
	})
	$('#jobwi_nebtn').on('click', function() {
		var a = $('#wqiuop')[0].value,
			b = $('#wantqw').find('p').length,
			//			b1 = $('#wantqw').find('p')[0].innerText,
			c = $('#wxinzi1')[0].value,
			d = $('#wxinzi2')[0].value,
			e = $(".select-res-opkills").find('.bq_hy').find('p').length;
		f = $('.addresss')[0].value
		var e1 = "";
		if($("#wxinzi1").get(0).value == "面谈") {
			xz = "面谈"
		} else {
			xz = $("#wxinzi1").get(0).value + "-" + $("#wxinzi2").get(0).value
		}
		for(var i = 0; i < e; i++) {
			e1 += $(".select-res-opkills").find('.bq_hy').find('p')[i].innerText + "*";
		}
		if(a == 0) $('#wqiuop').parents('.col-xs-8').find('.dpn').show()
		if(b == 0) $('#wantqw').parents('.col-xs-8').find('.dpn').show()
		if(e == 0) $(".select-res-opkills").parents('.col-xs-8').find('.dpn').show()
		if(f == "") $('.addresss').parents('.col-xs-8').find('.dpn').show()
		if(a != "" && b != "" && e != "" && f != "") {
			alert("求职状态" + a + ",期望职位" + $('#wantqw').find('p')[0].innerText + "标记id" + fid_id2 + "，薪资范围" + xz + "期望行业" + e1 + ",期望地点" + f)
			//提交数据，跳到个人求职状栏
		}
	})

	function phide(obj) {
		obj.on('focus', function() {
			$(this).parent().find('.dpn').hide();
		})
	}

	function qhide(obj) {
		obj.on('click', function() {
			$(this).parents('.col-xs-8').find('.dpn').hide()
		})
	}
	phide($('#u_name'))
	phide($('.companyname'))
	qhide($('.bq_skills'))
	qhide($('#qw'))
	phide($('.workcontant'))
	phide($('#wschoolname'))
	qhide($('#wzhuanyename'))
	qhide($('#wschoolgood'))
	phide($('.schooljl'))
	phide($('.myadwantage'))
	phide($('#wqiuop'))
	qhide($('#wantqw'))
	phide($(".select-res-opkills"))
	phide($('.addresss'))

}
nextpg()
$('#checkbox').on('click', function() {
	if($('#checkbox').prop('checked')) {
		$('#checkbox').parents('.job_tchk').prev().hide();
	} else {
		$('#checkbox').parents('.job_tchk').prev().show();
	}
})

function t2() {
	var t;
	if($('#checkbox').prop('checked')) {
		t = "0"
	} else {
		t = $('.t2')[0].value;
	}
	return t;
}
$('.addresss').on('keydown', function() {
	//发送请求
	//获得数据，占记
	$('#address').html('');
	var data_address = {
		"err_code": 0,
		"err_msg": "请求成功",
		"page": "-1",
		"data": [{
			"id": 1,
			"name": "大连"
		}, {
			"id": 2,
			"name": "大同"
		}, {
			"id": 3,
			"name": "大山"
		}, {
			"id": 4,
			"name": "大大"
		}]
	}
	if(data_address.err_code == 0) {
		$.each(data_address.data, function(i, item) {
			$('#address').append('<li value="' + item.id + '">' + item.name + '</li>')
		});
	} else {
		alert("请检查网络");
	}
	$('.wsuggest').show()
	var a = "",
		b = "";
	$('li', $('#address')).on('click', function() {
		item = $(this)[0];
		var fid = $(this).attr('value');
		$('.addresss')[0].value = item.innerText;
		a = item.innerText;
		b = $('.addresss')[0].value;
		$(document).bind('click', function() {
			console.log(11)
			if($('.addresss')[0].value == item.innerText) {
				$('.addresss')[0].value = item.innerText;
			} else {
				$('.addresss')[0].value = "";
			}
			$('.wsuggest').hide();
		})
	})
	$(document).bind('click', function() {
		if(b == a) {
			$('.addresss')[0].value = a;
		} else {
			$('.addresss')[0].value = "";
		}
		$('.wsuggest').hide();
	})
})
wshow($('.addresss'), $('.wsuggest'));

//时间比较
function timeb(a, b) {
	var date = new Date();
	var year = date.getFullYear()
	var p1 = a[0].value.split("年");
	var p2 = b[0].value.split("年")
	var num1 = parseInt(p1[0]),
		num2 = parseInt(p2[0]),
		a1 = p1.join("月"),
		a2 = p2.join("月");
	var p3 = a1.split("月"),
		p4 = a2.split("月"),
		num3 = parseInt(p3[1]),
		num4 = parseInt(p4[1]);
	var b = false;
	if(num1 <= year && num2 <= year) b = true;
	//1.0.2 修改了时间的判断逻辑
	if(b == true) {
		if(num1 > num2) {
			return false;
		} else if(num1 < num2) {
			return true;
		} else if(num1 = num2) {
			if(num3 <= num4) {
				return true;
			} else {
				return false;
			}
		}
	} else {
		return false
	}
}


//技能标签
kills($('.select-box-hiskills'), $('.select-res-hiskills'))
//所属行业
history($('.select-box-his'), $('.select-res-his'), $('#qw'));
//期望职位，期望行业
history($('.select-box-want'), $('.select-res-want'), $('#wantqw'));
kills($('.select-box-opkills'), $('.select-res-opkills'))