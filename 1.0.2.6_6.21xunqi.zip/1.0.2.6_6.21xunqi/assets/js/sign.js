
$('.sign-form').css({
			height: document.documentElement.clientHeight
		})
console.log($('.sign-form').css('height'))
$('.w-btns').on('click', function() {
	var reg = /^1[3|4|5|7|8][0-9]{9}$/; //验证规则
	var l = reg.test($('.inputuname')[0].value);
	var datacode
	var data = {
			"err_code": 0,
			"err_msg": "请求成功",
			"page": null,
			"data": 'qwer'
		}
	if(l == true) {
		//发送请求 调验证码接口
		
		if(data.err_code == 0) {
			//接口接入成功
			time($(this))
		}
	} else {
		alert('请输入正确的电话号码')
	}
//	1.0.2.6
	//注册页面当验证通过时候
	$("#w-signup").on("click", function() {
		var code = $('.getcode')[0].value;
		var bor = false;
		//差验证码控件
		console.log($('#inputPassworda')[0].value.length)
		if($('#inputPassworda')[0].value == $('#inputPasswordaa')[0].value && $('#inputnickname')[0].value != "" && $('#inputPassworda')[0].value.length >= 6 && $('#shenfen')[0].value != 0) bor = true;
		console.log(bor)
		if($('#inputnickname')[0].value == "") $('#inputnickname').next().show();
		if($('#inputPassworda')[0].value.length <= 6) $('#inputPassworda').next().show();
		if($('#inputPassworda')[0].value != $('#inputPasswordaa')[0].value) $('#inputPasswordaa').next().show()
		if($('#shenfen')[0].value == 0) alert('请选择身份');
		if(bor) {
			alert("手机是" + $('.inputuname')[0].value + ",验证码" + code + "，姓名是" + $('#inputnickname')[0].value + "，密码是" + $('#inputPassworda')[0].value + '，选择身份' + $('#shenfen').get(0).value)			
		}
		$('#inputPassworda')[0].value = "";
		$('#inputPasswordaa')[0].value = "";
	});
})

$('.w-btns2').on('click', function() {
	var reg = /^1[3|4|5|7|8][0-9]{9}$/; //验证规则
	var t = reg.test($('.inputuname2')[0].value);
	var datacode
	var data = {
			"err_code": 0,
			"err_msg": "请求成功",
			"page": null,
			"data": 'qwer'
		}
	if(t == true) {
		//发送请求 调验证码接口
		
		if(data.err_code == 0) {
			//接口接入成功
			time($(this))
		}
	} else {
		alert('请输入正确的电话号码')
	}
	$("#repassword").on("click", function() {
		var code = $('.getcode')[1].value;
		var bor = false;
		//差验证码控件
		if($('#reinputPasswordaa')[0].value == $('#reinputPassworda')[0].value && $('#reinputPassworda')[0].value != "" && $('#reinputPassworda')[0].value.length >= 6) bor = true;
		console.log(bor)
		if($('#reinputPassworda')[0].value == "") $('#reinputPassworda').next().show();
		if($('#reinputPassworda')[0].value.length <= 6) $('#reinputPassworda').next().show();
		if($('#reinputPassworda')[0].value != $('#reinputPasswordaa')[0].value) alert("两次输入密码不一样")
		if(bor) {
			alert("手机是" + $('.inputuname2')[0].value + ",验证码" + code + "，新密码是" + $('#reinputPassworda')[0].value)			
		}
		$('#reinputPassworda')[0].value = "";
		$('#reinputPasswordaa')[0].value = "";
	});
})

var timebol = true;

function time(obj) {
	var num = 60;
	if(timebol) {
		timebol = false;
		var timer = setInterval(function() {
			num--;
			if(num > 0) {
				obj.get(0).innerHTML = num + "s后将会重发";
			} else {
				clearInterval(timer);
				obj.get(0).innerHTML = '获取短信验证码';
				timebol = true
			}
		}, 1000)
	}
}

//登陆注册
function Wsign(obj1, obj2, obj3) {
	obj1.on("click", function() {
		obj2.hide();
		obj3.show();
	})
}
Wsign($(".w-link-signin"), $(".sign-form"), $(".w-sign-pwd"));
Wsign($(".w-link-signup"), $(".sign-form"), $(".w-sign-register"));
//1.0.2.6
Wsign($("button.btn",$(".wjmm")), $(".sign-form"), $(".w-repassword"));
Wsign($('#return'), $(".sign-form"), $(".w-sign-pwd"));



//登陆验证码
var code; //在全局定义验证码      
//产生验证码     
window.onload = function() {
	createCode();
}

function createCode() {
	code = "";
	var codeLength = 5; //验证码的长度     
	var checkCode = document.getElementById("checkCode");
	var random = new Array(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R',
		'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'); //随机数     
	for(var i = 0; i < codeLength; i++) { //循环操作     
		var charIndex = Math.floor(Math.random() * 36); //取得随机数的索引     
		code += random[charIndex]; //根据索引取得随机数加到code上     
	}
	checkCode.value = code; //把code值赋给验证码     
}
//校验验证码     
function validate() {
	var inputCode = document.getElementById("input").value.toUpperCase(); //取得输入的验证码并转化为大写           
	if(inputCode.length <= 0) { //若输入的验证码长度为0     
		alert("请输入验证码！"); //则弹出请输入验证码     
	} else if(inputCode != code) { //若输入的验证码与产生的验证码不一致时     
		alert("验证码输入错误！"); //则弹出验证码输入错误     
		createCode(); //刷新验证码     
	} else { //输入正确时     
		alert("^-^"); //弹出^-^     
	}
}
//密码验证正确以后
$(".w-sign-success").on("click", function() {
	var reg = /^1[3|4|5|7|8][0-9]{9}$/; //验证规则
	var p = $('.ipt-phone')[0].value; //手机号码
	var m = $('.ipt-pwd')[0].value; //密码
	var l = reg.test(p); //验证结果，true/false	
	var inputCode = document.getElementById("input").value.toUpperCase(); //取得输入的验证码并转化为大写      
	if(l == true && (m != "" && m.length >= 6) && inputCode == code) {
		alert("手机是" + p + ",密码是" + m);
		window.location.href = "index.html";
	} else if(l == true && (m != "" && m.length >= 6) && inputCode != code) {
		$('.ipt-pwd')[0].value = "";
		alert("验证码输入错误！"); //则弹出验证码输入错误 
		createCode(); //刷新验证码
	} else {
		$('.ipt-pwd')[0].value = "";
		alert('账号密码有误')
	}
})

//手机和邮箱验证
function zz(obj) {
	var reg = /^1[3|4|5|7|8][0-9]{9}$/; //验证规则
	var reg2 = /^[a-z0-9]+([._\\-]*[a-z0-9])*@([a-z0-9]+[-a-z0-9]*[a-z0-9]+.){1,63}[a-z0-9]+$/ //邮箱验证
	if(obj[0].value.length == 11) {
		if(reg.test(obj[0].value) == false) {
			obj.parent().next().show()
			obj.next().show()
		}
	} else {
		obj.parent().next().show()
		obj.next().show()
	}
}

function ktt(obj) {
	obj.on('blur', function() {
		//		console.log($(this).parent().prev()[0].innerText)
		if($(this).parent().prev()[0].innerText == "姓名") {
			if($(this)[0].value == "") {
				$(this).next().show()
			}
		} else if($(this).parent().prev()[0].innerText == "密码") {
			if($(this)[0].value.length < 6) {
				$(this).next().show()
			}
		}
	})
}
ktt($('#inputnickname'))
ktt($('#inputPassworda'))

