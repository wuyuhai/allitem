

//首页职位选择
function placeholderSupport() {
	return "placeholder" in document.createElement("input")
}
var DEBUG = !0,
	UA = window.navigator.userAgent,
	isIE, isWebkit, isTouch = !1;
if((UA.indexOf("Edge/") > -1 || UA.indexOf("MSIE ") > -1 || UA.indexOf("Trident/") > -1) && (isIE = !0), "ontouchstart" in window) {
	var isTouch = !0;
	document.addEventListener("touchstart", function() {}, !1)
}
var PlaceholderCheck = {
	init: function(e) {
		if(!placeholderSupport()) {
			var t;
			t = e ? e.find("[placeholder]") : $("[placeholder]"), t.focus(function() {
				var e = $(this);
				e.val() == e.attr("placeholder") && (e.val(""), e.removeClass("placeholder"))
			}).blur(function() {
				var e = $(this);
				"" != e.val() && e.val() != e.attr("placeholder") || (e.addClass("placeholder"), e.val(e.attr("placeholder")))
			}).blur()
		}
	}
};
$(function() {
	PlaceholderCheck.init()
}), $(function() {
	function e() {
		var e = arguments;
		a <= s - 1 && (n.eq(a).stop(!0).animate({
			width: "300px"
		}, 500).siblings().stop(!0).animate({
			width: "98px"
		}, 500), ++a == s && (a = 0)), i = setTimeout(e.callee, 5e3)
	}

	function t() {
		var e = (o.offset().top, $(window).scrollTop(), $("body").outerHeight(), d.height(), $(window).height() - ($("#footer").offset().top - $(document).scrollTop()));
		e > 0 ? r.css("bottom", e) : r.css("bottom", 0)
	}
	if($.fn.hoverDelay = function(e) {
			var t, i, n = {
					hoverDuring: 200,
					outDuring: 200,
					hoverEvent: function() {
						$.noop()
					},
					outEvent: function() {
						$.noop()
					}
				},
				s = $.extend(n, e || {});
			return $(this).each(function() {
				$(this).hover(function() {
					clearTimeout(i), t = setTimeout(s.hoverEvent, s.hoverDuring)
				}, function() {
					clearTimeout(t), i = setTimeout(s.outEvent, s.outDuring)
				})
			})
		}, $(".home-box .slider-main").length && ($(".home-box .slider-main").hwSlider({
			autoPlay: !0,
			arrShow: !0,
			dotShow: !0,
			navShow: !0,
			touch: !0,
			height: 240,
			interval: 5e3,
			effect: "fade"
		}), $(".slider-box .pic-all").length)) {
		var i, n = $(".slider-box .pic-all a"),
			s = n.length,
			a = 0;
		n.hover(function() {
			clearTimeout(i), 300 != $(this).width() && $(this).stop(!0).animate({
				width: "300px"
			}, 500).siblings().stop(!0).animate({
				width: "98px"
			}, 500)
		}, function() {
			a = $(this).index(), e()
		}), e()
	}
	if($(".semwrap .slider-main").length && $(".slider-main").hwSlider({
			autoPlay: !0,
			arrShow: !0,
			dotShow: !1,
			navShow: !0,
			touch: !0,
			interval: 5e3,
			width: 582,
			speed: 1e3,
			height: 426
		}), $(".manager-list .manager-inner").length && $(".manager-list li").length > 1 && ($(".manager-list h3").css("background", "none"), $(".manager-list .manager-inner").hwSlider({
			autoPlay: !0,
			arrShow: !1,
			dotShow: !0,
			interval: 5e3,
			speed: 500,
			width: 330,
			height: 163,
			navShow: !0,
			touch: !0,
			effect: "fade",
			fadeOut: !1,
			afterSlider: function() {
				$(".manager-list .fold-text").removeAttr("style"), $(".manager-list .more-view").html('...å±•å¼€<i class="fz fz-slidedown"></i></a>').show()
			}
		})), $(".picture-list .slider-main").length && $(".picture-list li").length > 1 && $(".picture-list .slider-main").hwSlider({
			autoPlay: !0,
			arrShow: !1,
			dotShow: !0,
			interval: 5e3,
			speed: 500,
			width: 330,
			height: 165,
			navShow: !0,
			touch: !0
		}), $(".job-menu dl").each(function(e) {
			var t = $(this);
			t.hoverDelay({
				hoverDuring: 200,
				hoverEvent: function() {
					switch(t.addClass("cur"), e) {
						case 0:
							break;
						case 1:
							t.children(".menu-sub").css({
								top: "-50px"
							});
							break;
						case 10:
							t.children(".menu-sub").css({
								top: "auto",
								bottom: "-1px"
							})
					}
					if(0 != e && 1 != e && 10 != e || 10 == e && $(".ie7").length) {
						var i = t.get(0).getBoundingClientRect().top,
							n = t.find(".menu-sub");
						n.height() < i ? n.css({
							"margin-top": 65 - n.height() + "px"
						}) : i < 70 && i > 0 ? n.css({
							"margin-top": "-1px"
						}) : i < 0 ? n.css({
							"margin-top": i + "px"
						}) : n.css({
							"margin-top": 59 - i + "px"
						})
					}
				},
				outEvent: function() {
					t.removeClass("cur").children(".menu-sub")
				}
			})
		}), $(".menu-all .sub-tab li").eq(0).css({
			"border-top-color": "#fff",
			"padding-top": "15px",
			"padding-bottom": "14px"
		}), $(".menu-all .sub-tab li").eq(1).css({
			"margin-top": "-1px"
		}), $(".menu-all .sub-tab li").on("click", function() {
			var e = $(this).index(),
				t = $(this).parent().find("li"),
				i = $(this).closest(".menu-sub").find(".sub-content ul");
			t.removeClass("cur"), $(this).addClass("cur"), i.removeClass("show"), i.eq(e).addClass("show"), 0 == e && $(this).css("border-top-color", "#fff"), e == t.length - 1 ? $(this).css({
				"border-bottom-color": "#fff",
				"margin-top": "-1px",
				"padding-top": "1px"
			}) : t.eq(t.length - 1).css({
				"border-bottom-color": "#FDFDFE",
				"margin-top": "0",
				"padding-top": "0"
			})
		}), $(".condition-insdustry .btn-all").on("click", function() {
			$(this).parent().toggleClass("show-all-insdustry")
		}), $(".condition-city .link-district").on("click", function() {
			$(".condition-district").toggleClass("show-condition-district"), $(".condition-area").removeClass("show-condition-area")
		}), $(".condition-city .link-area").on("click", function() {
			$(".condition-area").toggleClass("show-condition-area"), $(".condition-district").removeClass("show-condition-district")
		}), $(".siderbar-top").on("click", function() {
			$("html,body").animate({
				scrollTop: "0px"
			}, 400)
		}), $(window).on("scroll", function() {
			$(this).scrollTop() > 600 ? $("#siderbar").fadeIn() : $("#siderbar").hide()
		}), $(".footer-scan").length) {
		$("#siderbar").css({
			bottom: "304px",
			transition: "all 0.2s"
		});
		var o = $("#footer"),
			r = $(".footer-scan"),
			l = $(".home-box .job-list"),
			d = $(window);
		l.css("margin-bottom", "105px"), t(), $(window).scroll(function() {
			t()
		}), r.find(".footer-scan-close").click(function() {
			r.fadeOut(300, function() {
				l.css({
					"margin-bottom": "15px",
					transition: "all 0.2s"
				}), $("#siderbar").css({
					bottom: "214px",
					transition: "all 0.2s"
				})
			})
		})
	}
	$(window).width() < 1348 && $(".footer-scan .btns").css("margin-right", "84px"), $(window).resize(function() {
		$(window).width() < 1348 ? $(".footer-scan .btns").css("margin-right", "84px") : $(".footer-scan .btns").css("margin-right", "0")
	}), "cpc_job_index" == $("#page_key_name").val() && setTimeout(function() {
		if(window._T) {
			var e = window.screen.width,
				t = window.screen.height,
				i = window.innerWidth,
				n = window.innerHeight;
			_T.sendEvent("screen-" + e + "-" + t + "|avail-" + i + "-" + n)
		}
	}, 1e3)
});
