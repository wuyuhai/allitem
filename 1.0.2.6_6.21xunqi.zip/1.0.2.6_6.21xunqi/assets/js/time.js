(function() {
	/*
	 * 用于记录日期，显示的时候，根据dateObj中的日期的年月显示
	 */
	var dateObj = (function() {
		var _date = new Date(); // 默认为当前系统时间
		return {
			getDate: function() {
				return _date;
			},
			setDate: function(date) {
				_date = date;
			}
		};
	})();

	// 设置calendar div中的html部分
	//	renderHtml();
	renderHtml("calendar")
	renderHtml("calendar2")
	renderzijin("calendar2")
	renderHtml("calendar3")
	renderHtml("calendar4")
	renderzijin("calendar4")
	// 表格中显示日期
	//	showCalendarData();
	showCalendarData($('#calendar'))
	showCalendarData($('#calendar2'))
	showCalendarData($('#calendar3'))
	showCalendarData($('#calendar4'))
	// 绑定事件
	//	bindEvent();
	bindEvent($('#calendar'))
	bindEvent($('#calendar2'))
	bindEvent($('#calendar3'))
	bindEvent($('#calendar4'))
	/**
	 * 渲染html结构
	 */
	function renderHtml(obj) {
		calendar = document.getElementById(obj);
		var titleBox = document.createElement("div"); // 标题盒子 设置上一月 下一月 标题
		var bodyBox = document.createElement("div"); // 表格区 显示数据

		// 设置标题盒子中的html
		titleBox.className = 'calendar-title-box';
		titleBox.innerHTML = "<span class='prev-month'></span>" +
			"<span class='calendar-title'></span>" +
			"<span class='next-month'></span>";
		calendar.appendChild(titleBox); // 添加到calendar div中

		// 设置表格区的html结构
		bodyBox.className = 'calendar-body-box';
		var _headHtml = "<tr>" +
			"<th>2014</th>" +
			"<th>2015</th>" +
			"<th>2016</th>" +
			"<th>2017</th>" +
			"</tr>";
		var _bodyHtml = "";

		// 一个月最多31天，所以一个月最多占6行表格
		for(var i = 0; i < 3; i++) {
			_bodyHtml += "<tr>" +
				"<td></td>" +
				"<td></td>" +
				"<td></td>" +
				"<td></td>" +
				"</tr>";
		}
		bodyBox.innerHTML = "<table class='calendar-table'>" +
			_headHtml + _bodyHtml +
			"</table>";
		// 添加到calendar div中
		calendar.appendChild(bodyBox);
	}
	//1.0.2.2为第二个时间段添加至今选项
	function renderzijin(obj){
		calendar = document.getElementById(obj);
		var footer = document.createElement("div");
		footer.className = 'timefooter';
		footer.innerHTML = '至今';
		calendar.appendChild(footer);
	}
	//1.0.2.2为第二个时间段添加至今选项
	/**
	 * 表格中显示数据，并设置类名
	 */
	function showCalendarData(obj) {
		var _year = dateObj.getDate().getFullYear();
		var _monthStr = getDateStr(dateObj.getDate());
		//				var _month = dateObj.getDate().getMonth() + 1;
		//				var _dateStr = getDateStr(dateObj.getDate());

		// 设置顶部标题栏中的 年、月信息
		var calendarTitle = obj.find(".calendar-title")[0];
		var titleStr = _monthStr.substr(0, 4); //年
		calendarTitle.innerText = titleStr;
		// 设置表格中的日期数据
		var _table = obj.find(".calendar-table")[0];
		//		document.getElementById("calendarTable");
		var _ths = _table.getElementsByTagName("th");
		var _tds = _table.getElementsByTagName("td");
		var _firstMonth = new Date(_year, 1); // 当年的第一月
		for(var i = 0; i < _ths.length; i++) {
			_ths[i].innerText = +titleStr + i - 2
		}
		for(var i = 0; i < _tds.length; i++) {
			_tds[i].innerText = i + 1 + '月';
		}
	}

	/**
	 * 绑定上一年下一年事件
	 */
	function bindEvent(obj) {
		var prevYear = obj.find('.prev-month')[0]
		//		document.getElementById("prevMonth");
		var nextYear = obj.find('.next-month')[0]
		//		document.getElementById("nextMonth");
		addEvent(prevYear, 'click', toPrevYear);
		addEvent(nextYear, 'click', toNextYear);
	}

	/**
	 * 绑定事件
	 */
	function addEvent(dom, eType, func) {
		if(dom.addEventListener) { // DOM 2.0
			dom.addEventListener(eType, function(e) {
				func(e);
			});
		} else if(dom.attachEvent) { // IE5+
			dom.attachEvent('on' + eType, function(e) {
				func(e);
			});
		} else { // DOM 0
			dom['on' + eType] = function(e) {
				func(e);
			}
		}
	}

	/**
	 * 点击上一年图标触发
	 */
	function toPrevYear() {
		var date = dateObj.getDate();
		dateObj.setDate(new Date(date.getFullYear() - 1, 1));
		//		showCalendarData(ob)
		showCalendarData($('#calendar'))
		showCalendarData($('#calendar2'))
		showCalendarData($('#calendar3'))
		showCalendarData($('#calendar4'))
	}
	/**
	 * 点击下一年图标触发
	 */
	function toNextYear() {
		var date = dateObj.getDate();
		dateObj.setDate(new Date(date.getFullYear() + 1, 1));
		//		showCalendarData(ob)
		//		showCalendarData($('#calendar2'))
		showCalendarData($('#calendar'))
		showCalendarData($('#calendar2'))
		showCalendarData($('#calendar3'))
		showCalendarData($('#calendar4'))
	}
	/**
	 * 日期转化为字符串， 4位年+2位月
	 */
	function getDateStr(date) {
		var _year = date.getFullYear();
		var _month = date.getMonth() + 1; // 月从0开始计数
		_month = (_month > 9) ? ("" + _month) : ("0" + _month);
		return _year + _month;
	}
})();
