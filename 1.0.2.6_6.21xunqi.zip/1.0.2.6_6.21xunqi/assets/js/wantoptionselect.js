var dataJson = {
	"option": [{
		"id": "1",
		"name": "技术",
		"child": [{
			"id": "11",
			"name": "后端开发",
			"child": [{
				"id": "1101",
				"name": "java"
			}, {
				"id": "1102",
				"name": "C++"
			}, {
				"id": "1103",
				"name": "PHP"
			}, {
				"id": "1104",
				"name": "数据挖掘"
			}, {
				"id": "1105",
				"name": "C"
			}, {
				"id": "1106",
				"name": "C#"
			}, {
				"id": "1107",
				"name": ".NET"
			}, {
				"id": "1108",
				"name": "Hadoop"
			}, {
				"id": "1109",
				"name": "Python"
			}, {
				"id": "1110",
				"name": "Delphi"
			}, {
				"id": "1111",
				"name": "VB"
			}, {
				"id": "1112",
				"name": "Perl"
			}, {
				"id": "1113",
				"name": "Ruby"
			}, {
				"id": "1114",
				"name": "Node.js"
			}, {
				"id": "1115",
				"name": "搜索算法"
			}, {
				"id": "1116",
				"name": "Golang"
			}, {
				"id": "1117",
				"name": "自然语言处理"
			}, {
				"id": "1118",
				"name": "推荐算法"
			}, {
				"id": "1119",
				"name": "Erlang"
			}, {
				"id": "1120",
				"name": "算法工程师"
			}, {
				"id": "1121",
				"name": "语音/视频/图形开发"
			}, {
				"id": "1122",
				"name": "数据采集"
			}]
		}, {
			"id": "12",
			"name": "移动开发",
			"child": [{
				"id": "1201",
				"name": "HTML5"
			}, {
				"id": "1202",
				"name": "Android"
			}, {
				"id": "1203",
				"name": "IOS"
			}, {
				"id": "1204",
				"name": "WP"
			}, {
				"id": "1205",
				"name": "Web前端"
			}, {
				"id": "1206",
				"name": "Flash"
			}, {
				"id": "1207",
				"name": "JavaScript"
			}, {
				"id": "1208",
				"name": "U3D"
			}, {
				"id": "1209",
				"name": "COCOS2DX"
			}]
		}, {
			"id": "13",
			"name": "测试",
			"child": [{
				"id": "1301",
				"name": "测试工程师"
			}, {
				"id": "1302",
				"name": "自动化测试"
			}, {
				"id": "1303",
				"name": "功能测试"
			}, {
				"id": "1304",
				"name": "性能测试"
			}, {
				"id": "1305",
				"name": "测试开发"
			}, {
				"id": "1306",
				"name": "移动端测试"
			}, {
				"id": "1307",
				"name": "游戏测试"
			}, {
				"id": "1308",
				"name": "硬件测试"
			}, {
				"id": "1309",
				"name": "软件测试"
			}]
		}, {
			"id": "14",
			"name": "运维和技术支持",
			"child": [{
				"id": "1401",
				"name": "系统工程师"
			}, {
				"id": "1402",
				"name": "IT技术支持"
			}, {
				"id": "1403",
				"name": "系统管理员"
			}, {
				"id": "1404",
				"name": "网络安全"
			}, {
				"id": "1405",
				"name": "系统安全"
			}, {
				"id": "1406",
				"name": "DBA"
			}]
		}, {
			"id": "15",
			"name": "数据",
			"child": [{
				"id": "1501",
				"name": "ETLHive"
			}, {
				"id": "1502",
				"name": "数据仓库"
			}, {
				"id": "1503",
				"name": "数据开发"
			}, {
				"id": "1504",
				"name": "数据挖掘"
			}, {
				"id": "1505",
				"name": "系统处理工程师"
			}, {
				"id": "1506",
				"name": "数据分析师"
			}, {
				"id": "1507",
				"name": "数据架构师"
			}]
		}, {
			"id": "16",
			"name": "项目管理",
			"child": [{
				"id": "1601",
				"name": "项目主管"
			}, {
				"id": "1602",
				"name": "项目助理"
			}, {
				"id": "1603",
				"name": "项目专员"
			}, {
				"id": "1604",
				"name": "实施顾问"
			}, {
				"id": "1605",
				"name": "实施工程师"
			}, {
				"id": "1606",
				"name": "需求分析工程师"
			}, {
				"id": "1607",
				"name": "项目经理"
			}]
		}, {
			"id": "17",
			"name": "硬件开发",
			"child": [{
				"id": "1701",
				"name": "硬件"
			}, {
				"id": "1702",
				"name": "嵌入式"
			}, {
				"id": "1703",
				"name": "自动化"
			}, {
				"id": "1704",
				"name": "单片机"
			}, {
				"id": "1705",
				"name": "电路设计"
			}, {
				"id": "1706",
				"name": "驱动开发"
			}, {
				"id": "1707",
				"name": "系统集成"
			}, {
				"id": "1708",
				"name": "FPGA开发"
			}, {
				"id": "1709",
				"name": "DSP开发"
			}, {
				"id": "1710",
				"name": "ARM开发"
			}, {
				"id": "1711",
				"name": "PCB工艺"
			}, {
				"id": "1712",
				"name": "模具设计"
			}, {
				"id": "1713",
				"name": "然传导"
			}, {
				"id": "1714",
				"name": "材料工程师"
			}, {
				"id": "1715",
				"name": "精益工程师"
			}, {
				"id": "1716",
				"name": "射频工程师"
			}]
		}, {
			"id": "18",
			"name": "前段开发",
			"child": [{
				"id": "1801",
				"name": "web前端"
			}, {
				"id": "1802",
				"name": "Javascript"
			}, {
				"id": "1803",
				"name": "Flash"
			}, {
				"id": "1804",
				"name": "HTML5"
			}]
		}, {
			"id": "18",
			"name": "前段开发",
			"child": [{
				"id": "1801",
				"name": "web前端"
			}, {
				"id": "1802",
				"name": "Javascript"
			}, {
				"id": "1803",
				"name": "Flash"
			}, {
				"id": "1804",
				"name": "HTML5"
			}]
		}, {
			"id": "18",
			"name": "前段开发",
			"child": [{
				"id": "1801",
				"name": "web前端"
			}, {
				"id": "1802",
				"name": "Javascript"
			}, {
				"id": "1803",
				"name": "Flash"
			}, {
				"id": "1804",
				"name": "HTML5"
			}]
		}, {
			"id": "18",
			"name": "前段开发",
			"child": [{
				"id": "1801",
				"name": "web前端"
			}, {
				"id": "1802",
				"name": "Javascript"
			}, {
				"id": "1803",
				"name": "Flash"
			}, {
				"id": "1804",
				"name": "HTML5"
			}]
		}, {
			"id": "19",
			"name": "通信",
			"child": [{
				"id": "1901",
				"name": "通信技术工程师"
			}, {
				"id": "1902",
				"name": "通信研发工程师"
			}, {
				"id": "1903",
				"name": "数据通信工程师"
			}, {
				"id": "1904",
				"name": "移动通信工程师"
			}, {
				"id": "1905",
				"name": "电信网络工程师"
			}, {
				"id": "1906",
				"name": "电信交换工程师"
			}, {
				"id": "1907",
				"name": "有线传输工程师"
			}, {
				"id": "1908",
				"name": "无线射频工程师"
			}, {
				"id": "1909",
				"name": "通信电源工程师"
			}, {
				"id": "1910",
				"name": "通信标准化工程师"
			}, {
				"id": "1911",
				"name": "通信项目专员"
			}, {
				"id": "1912",
				"name": "通信项目经理"
			}, {
				"id": "1913",
				"name": "核心网工程师"
			}, {
				"id": "1914",
				"name": "通信测试工程师"
			}, {
				"id": "1915",
				"name": "通信设备工程师"
			}, {
				"id": "1916",
				"name": "光通信工程师"
			}, {
				"id": "1917",
				"name": "光传输工程师"
			}, {
				"id": "1918",
				"name": "光网络工程师"
			}]
		}, {
			"id": "1a",
			"name": "高端技术职位",
			"child": [{
				"id": "1a01",
				"name": "技术经理"
			}, {
				"id": "1a02",
				"name": "技术总监"
			}, {
				"id": "1a03",
				"name": "测试经理"
			}, {
				"id": "1a04",
				"name": "架构师"
			}, {
				"id": "1a05",
				"name": "CTO"
			}, {
				"id": "1a06",
				"name": "运维总监"
			}, {
				"id": "1a07",
				"name": "技术合伙人"
			}]
		}, {
			"id": "1b",
			"name": "人工智能",
			"child": [{
				"id": "1b01",
				"name": "机器学习"
			}, {
				"id": "1b02",
				"name": "深度学习"
			}, {
				"id": "1b03",
				"name": "图像算法"
			}, {
				"id": "1b04",
				"name": "图像处理"
			}, {
				"id": "1b05",
				"name": "语音识别"
			}, {
				"id": "1b06",
				"name": "图像识别"
			}]
		}, {
			"id": "1c",
			"name": "软件销售支持",
			"child": [{
				"id": "1c01",
				"name": "售前工程师"
			}, {
				"id": "1c02",
				"name": "售后工程师"
			}]
		}, {
			"id": "1d",
			"name": "其他技术职位",
			"child": [{
				"id": "1d01",
				"name": "其他技术职位"
			}]
		}]
	}, {
		"id": "2",
		"name": "产品",
		"child": [{
			"id": "21",
			"name": "产品经理",
			"child": [{
				"id": "2101",
				"name": "产品经理"
			}, {
				"id": "2102",
				"name": "网页产品经理"
			}, {
				"id": "2103",
				"name": "移动产品经理"
			}, {
				"id": "2104",
				"name": "产品助理"
			}, {
				"id": "2105",
				"name": "数据产品经理"
			}, {
				"id": "2106",
				"name": "电商产品经理"
			}, {
				"id": "2107",
				"name": "游戏策划"
			}]
		}, {
			"id": "22",
			"name": "产品设计师",
			"child": [{
				"id": "2201",
				"name": "网页产品设计"
			}, {
				"id": "2202",
				"name": "无线产品设计"
			}]
		}, {
			"id": "23",
			"name": "高端产品职位",
			"child": [{
				"id": "2301",
				"name": "产品部经理"
			}, {
				"id": "2302",
				"name": "产品总监"
			}, {
				"id": "2303",
				"name": "游戏制作人"
			}, {
				"id": "2304",
				"name": "产品VP"
			}, {
				"id": "170",
				"name": "电子积木"
			}]
		}, {
			"id": "24",
			"name": "其他产品职位",
			"child": [{
				"id": "2401",
				"name": "其他产品职位"
			}]
		}]
	}, {
		"id": "3",
		"name": "设计",
		"child": [{
			"id": "31",
			"name": "视觉设计",
			"child": [{
				"id": "3101",
				"name": "视觉设计师"
			}, {
				"id": "3102",
				"name": "网页设计师"
			}, {
				"id": "3103",
				"name": "Flash设计师"
			}, {
				"id": "3104",
				"name": "APP设计师"
			}, {
				"id": "3105",
				"name": "UI设计师"
			}, {
				"id": "3106",
				"name": "平面设计师"
			}, {
				"id": "3107",
				"name": "美术设计师"
			}, {
				"id": "3108",
				"name": "（2D/3D）"
			}, {
				"id": "3109",
				"name": "广告设计师"
			}, {
				"id": "3110",
				"name": "多媒体设计师"
			}, {
				"id": "3111",
				"name": "原画师"
			}, {
				"id": "3112",
				"name": "游戏特效"
			}, {
				"id": "3113",
				"name": "游戏界面设计师"
			}, {
				"id": "3114",
				"name": "游戏场景"
			}, {
				"id": "3115",
				"name": "游戏角色"
			}, {
				"id": "3116",
				"name": "游戏动作"
			}, {
				"id": "3117",
				"name": "三维/CAD/制图"
			}, {
				"id": "3118",
				"name": "美工"
			}, {
				"id": "3119",
				"name": "包装设计"
			}, {
				"id": "3120",
				"name": "设计师助理"
			}, {
				"id": "3121",
				"name": "动画设计师"
			}]
		}, {
			"id": "32",
			"name": "交互设计",
			"child": [{
				"id": "3201",
				"name": "交互设计师"
			}, {
				"id": "、3202",
				"name": "无线交互设计师"
			}, {
				"id": "3203",
				"name": "网页交互设计师"
			}, {
				"id": "3204",
				"name": "硬件交互设计师"
			}]
		}, {
			"id": "33",
			"name": "用户研究",
			"child": [{
				"id": "3301",
				"name": "数据分析师"
			}, {
				"id": "3302",
				"name": "用户研究员"
			}, {
				"id": "3303",
				"name": "游戏数值策划"
			}, {
				"id": "3304",
				"name": "UX设计师"
			}, {
				"id": "3305",
				"name": "用户研究经理"
			}, {
				"id": "3306",
				"name": "用户研究总监"
			}]
		}, {
			"id": "34",
			"name": "高端设计职位",
			"child": [{
				"id": "3401",
				"name": "设计经理主管"
			}, {
				"id": "3402",
				"name": "设计总监"
			}, {
				"id": "3403",
				"name": "视觉设计经理"
			}, {
				"id": "3404",
				"name": "视觉实际总监"
			}, {
				"id": "3405",
				"name": "交互设计经理/主管"
			}, {
				"id": "3406",
				"name": "交互设计总监"
			}]
		}, {
			"id": "35",
			"name": "非视觉设计",
			"child": [{
				"id": "3501",
				"name": "服装设计"
			}, {
				"id": "3502",
				"name": "工业设计"
			}, {
				"id": "3503",
				"name": "橱柜设计"
			}, {
				"id": "3504",
				"name": "家具设计"
			}, {
				"id": "3505",
				"name": "家居设计"
			}, {
				"id": "3506",
				"name": "珠宝设计"
			}]
		}, {
			"id": "36",
			"name": "其他设计职位",
			"child": [{
				"id": "3601",
				"name": "其他设计职位"
			}]
		}]
	}, {
		"id": "4",
		"name": "运营",
		"child": [{
			"id": "41",
			"name": "运营",
			"child": [{
				"id": "4101",
				"name": "用户运营"
			}, {
				"id": "4102",
				"name": "产品运用"
			}, {
				"id": "4103",
				"name": "数据运营"
			}, {
				"id": "4104",
				"name": "内容运营"
			}, {
				"id": "4105",
				"name": "活动运营"
			}, {
				"id": "4106",
				"name": "商家运营"
			}, {
				"id": "4107",
				"name": "品类运营"
			}, {
				"id": "4108",
				"name": "游戏运营"
			}, {
				"id": "4109",
				"name": "网络推广"
			}, {
				"id": "4110",
				"name": "网站运营"
			}, {
				"id": "4111",
				"name": "新媒体运营"
			}, {
				"id": "4112",
				"name": "社区运营"
			}, {
				"id": "4113",
				"name": "微信运营"
			}, {
				"id": "4114",
				"name": "策略运营"
			}, {
				"id": "4115",
				"name": "线下拓展运营"
			}, {
				"id": "4116",
				"name": "电商运营"
			}, {
				"id": "4117",
				"name": "运营助理/专员"
			}, {
				"id": "4118",
				"name": "销售运营"
			}]
		}, {
			"id": "42",
			"name": "编辑",
			"child": [{
				"id": "4201",
				"name": "副编辑"
			}, {
				"id": "4202",
				"name": "内容编辑"
			}, {
				"id": "4203",
				"name": "文案策划"
			}, {
				"id": "4204",
				"name": "网站编辑"
			}, {
				"id": "4205",
				"name": "记者"
			}, {
				"id": "4206",
				"name": "采编"
			}]
		}, {
			"id": "43",
			"name": "客服",
			"child": [{
				"id": "4301",
				"name": "售前咨询"
			}, {
				"id": "4302",
				"name": "售后客服"
			}, {
				"id": "4303",
				"name": "淘宝客户"
			}, {
				"id": "4304",
				"name": "客服经理"
			}, {
				"id": "4305",
				"name": "客户专员"
			}]
		}, {
			"id": "44",
			"name": "高端运营职位",
			"child": [{
				"id": "4401",
				"name": "主编"
			}, {
				"id": "4402",
				"name": "运营总监"
			}, {
				"id": "4403",
				"name": "COO"
			}, {
				"id": "4404",
				"name": "客户总监"
			}, {
				"id": "4405",
				"name": "运营经理主管"
			}]
		}, {
			"id": "45",
			"name": "其他运营职位",
			"child": [{
				"id": "4501",
				"name": "其他运营职位"
			}]
		}]
	}, {
		"id": "5",
		"name": "市场",
		"child": [{
			"id": "51",
			"name": "市场/营销",
			"child": [{
				"id": "5101",
				"name": "市场营销"
			}]
		}, {
			"id": "52",
			"name": "公关每天",
			"child": [{
				"id": "5201",
				"name": "媒介经理"
			}]
		}, {
			"id": "53",
			"name": "公务会展",
			"child": [{
				"id": "5301",
				"name": "会议活动销售"
			}, {
				"id": "5302",
				"name": "会议活动策划"
			}]
		}, {
			"id": "54",
			"name": "广告",
			"child": [{
				"id": "5401",
				"name": "广告创意"
			}, {
				"id": "5402",
				"name": "美术指导"
			}]
		}, {
			"id": "55",
			"name": "高端市场职位",
			"child": [{
				"id": "5501",
				"name": "市场总监"
			}, {
				"id": "502",
				"name": "CMO"
			}]
		}, {
			"id": "56",
			"name": "其他市场职位",
			"child": [{
				"id": "5601",
				"name": "其他市场职位"
			}]
		}]
	}, {
		"id": "6",
		"name": "职能/高级管理",
		"child": [{
			"id": "61",
			"name": "人力资源",
			"child": [{
				"id": "6101",
				"name": "人力资源"
			}, {
				"id": "6102",
				"name": "招聘"
			}]
		}, {
			"id": "62",
			"name": "行政",
			"child": [{
				"id": "6201",
				"name": "助理/文员"
			}, {
				"id": "6202",
				"name": "前台"
			}]
		}, {
			"id": "63",
			"name": "财务",
			"child": [{
				"id": "6301",
				"name": "会计"
			}, {
				"id": "6302",
				"name": "出纳"
			}]
		}, {
			"id": "64",
			"name": "法务",
			"child": [{
				"id": "6401",
				"name": "法务"
			}, {
				"id": "6402",
				"name": "律师"
			}]
		}, {
			"id": "65",
			"name": "高级管理职位",
			"child": [{
				"id": "6501",
				"name": "行政总监/经理"
			}, {
				"id": "6502",
				"name": "财务总监/经理"
			}]
		}, {
			"id": "66",
			"name": "其他管理职位",
			"child": [{
				"id": "6601",
				"name": "其他管理职位"
			}]
		}]
	}, {
		"id": "7",
		"name": "销售",
		"child": [{
			"id": "71",
			"name": "销售",
			"child": [{
				"id": "7101",
				"name": "销售专员"
			}, {
				"id": "7102",
				"name": "销售经理"
			}]
		}, {
			"id": "72",
			"name": "销售管理",
			"child": [{
				"id": "7201",
				"name": "销售总监"
			}, {
				"id": "7202",
				"name": "商务总监"
			}]
		}, {
			"id": "73",
			"name": "其他销售职位",
			"child": [{
				"id": "7301",
				"name": "其他销售职位"
			}]
		}]
	}]
};

$(function() {
	var l1 = 0,
	l2 = 0;
	var cname1, cname2, cname3;
	var cid1, cid2, cid3;
	var canClick = !0;
	var canClose = !1;
	//console.log($('.select-res').css('width'));
	//console.log(document.body.clientWidth)
	$('span', $('.select-res')).on('click', function() {
		$('#qw').html("")
		$('.select-box').show();
		$('.w_first').show();
		$('.w_second').show();
		if(canClick) {
			$('ul', $('.select-box')).html('');
			fillData();
			canClick = !1;
		}
	});
	$('span', $('.select-box')).on("click", function() {
		canClose ? $('.select-box').hide() : alert('请选择下级品类！');
		canClick = !0;
	});

	$('.select-res').on('click', 'a', function() {
		$(this).parent().remove();
		$('.select-box').css({
			// top: $('.select-res').offset().top + $('.select-res').outerHeight(true)
			top: $('.select-res').outerHeight(true)
		});
	})
	if(document.body.clientWidth <= 768) {
		$('.select-box').css({
			width: $('.select-res').css('width')
		});
		//  $('#qw').html("")
		$('ul.w_first', $('.select-box')).on('click', 'li', function() {
			//	    $(this).addClass('w_selected').siblings().removeClass('w_selected');
			$('ul.third').html('');
			fillData($(this).index());
			l1 = $(this).index();
			cname1 = $(this).text();
			cid1 = $(this).attr('val');
			canClose = !1;
			$('input.cid', $('.select-res')).val(cid1);
			$('input.cname', $('.select-res')).val(cname1);
			$('.w_first').hide();
		});
		$('ul.w_second', $('.select-box')).on('click', 'li', function() {
			//	    $(this).addClass('w_selected').siblings().removeClass('w_selected');
			fillData(l1, $(this).index());
			l2 = $(this).index();
			cname2 = $(this).text();
			cid2 = $(this).attr('val');
			canClose = !1;
			$('input.cid', $('.select-res')).val(cid1 + ',' + cid2);
			$('input.cname', $('.select-res')).val(cname1 + ',' + cname2);
			$('.w_second').hide();
			$('.w_first').hide();
		});
	} else {
		$('.select-box').css({
			top: $('.select-res').outerHeight(true)
		});
		$('ul.w_first', $('.select-box')).on('click', 'li', function() {
			$(this).addClass('w_selected').siblings().removeClass('w_selected');
			$('ul.third').html('');
			fillData($(this).index());
			l1 = $(this).index();
			cname1 = $(this).text();
			cid1 = $(this).attr('val');
			canClose = !1;
			$('input.cid', $('.select-res')).val(cid1);
			$('input.cname', $('.select-res')).val(cname1);
		});
		$('ul.w_second', $('.select-box')).on('click', 'li', function() {
			$(this).addClass('w_selected').siblings().removeClass('w_selected');
			fillData(l1, $(this).index());
			l2 = $(this).index();
			cname2 = $(this).text();
			cid2 = $(this).attr('val');
			canClose = !1;
			$('input.cid', $('.select-res')).val(cid1 + ',' + cid2);
			$('input.cname', $('.select-res')).val(cname1 + ',' + cname2);
		});
	}

	//工作过的职位选择
	$('ul.w_third', $('.select-box')).on('click', 'li', function() {
		//  $(this).addClass('w_selected').siblings().removeClass('w_selected');
		cname3 = $(this).text();
		cid3 = $(this).attr('val');
		$('#qw').html("").append('<p>' + cname3 + '</p>');
		$('.select-box').css({
			// top: $('.select-res').offset().top + $('.select-res').outerHeight(true)
			top: $('.select-res').outerHeight(true)
		});
		$('input.cid', $('.select-res')).val(cid1 + ',' + cid2 + ',' + cid3);
		$('input.cname', $('.select-res')).val(cname1 + ',' + cname2 + ',' + cname3);
		$('.select-box').hide();
	});
})

function fillData(l1, l2) {
	var temp_html = "";
	if(typeof(dataJson.option) != 'undefined' && arguments.length == 0) {
		$.each(dataJson.option, function(i, pro) {
			temp_html += '<li val="' + pro.id + '">' + pro.name + '</li>';
		});
	} else if(typeof(dataJson.option[l1].child) != 'undefined' && arguments.length == 1) {
		$.each(dataJson.option[l1].child, function(i, pro) {
			temp_html += '<li val="' + pro.id + '">' + pro.name + '</li>';
		});
	} else if(typeof(dataJson.option[l1].child[l2].child) != 'undefined' && arguments.length == 2) {
		$.each(dataJson.option[l1].child[l2].child, function(i, pro) {
			temp_html += '<li val="' + pro.id + '">' + pro.name + '</li>';
		});
	}
	$('.select-box ul:eq(' + arguments.length + ')').html(temp_html);
}
