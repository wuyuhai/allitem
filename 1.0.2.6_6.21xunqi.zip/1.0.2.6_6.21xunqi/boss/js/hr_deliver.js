$('#tjsx').click(function() {
	if($('.w-filter').get(0).style.display == "none") {
		$('.w-filter').show();
	} else {
		$('.w-filter').hide();
	}
})

function tjxs(ob, ob2) {
	$(ob, ob2).on('click', 'a', function() {
		if($(this)[0].innerText == "不限") {
			$(this).addClass('cur').siblings().removeClass('cur');
		} else {
			if($(this).get(0).className == 'cur') {
				$(this).removeClass('cur')
				if($(this).parent('dd').find('.cur').length - 1 == 0) {
					$(this).parent('dd').find('a')[0].innerHTML = '<a href="javascript:;" class="cur">不限</a>'
				}
			} else {
				$(this).parent('dd').find('a')[0].innerHTML = '<a href="javascript:;">不限</a>'
				$(this).addClass('cur');
			}
		}
	})
}
tjxs('dd.xinzi', $('.w-filter'))
tjxs('dd.jinyan', $('.w-filter'))
tjxs('dd.edu', $('.w-filter'))

var data = {
	"err_code": 0,
	"err_msg": "请求成功",
	"page": "-1",
	"data": ""
}
//设置不合适
$('.btn-fail').click(function() {
	var val = $(this).parents('.qz-deliver').attr('val')
	alert("投递val值" + val)
	var lis = $(this).parents('.qz-deliver');
	//发送请求
	//$.get
	if(data.err_code == 0) {
		//请求成功
		$(this).addClass('btn-fail_on');
		$(this).parent('.btns').find('.btn-pass').removeClass('btn-pass_on')
		//同时该元素置底
		//		lis.fadeOut().fadeIn();
		//		$(this).parents('ul').append(lis);
		//同时在不合适页面添加该简历
	} else {
		alert('网络开小车了')
	}
})
//设置合适
$('.btn-pass').click(function() {
	var val = $(this).parents('.qz-deliver').attr('val')
	alert("投递val值" + val)
	//发送请求
	//$.get
	if(data.err_code == 0) {
		//请求成功
		$(this).addClass('btn-pass_on');
		$(this).parent('.btns').find('.btn-fail').removeClass('btn-fail_on')
		//同时在合适页面添加该简历
	} else {
		alert('网络开小车了')
	}
})
//设置置顶
$('.btn-communication').click(function() {
	var val = $(this).parents('.qz-deliver').attr('val')
	alert("投递val值" + val)
	var lis = $(this).parents('.qz-deliver');

	//发送请求
	//$.get
	if(data.err_code == 0) {
		//请求成功
		$(this).parent('.btns').find('.btn-pass').addClass('btn-pass_on')
		$(this).parent('.btns').find('.btn-fail').removeClass('btn-fail_on')
		//将该 val在展示框的第一行显示
		//		lis.fadeOut().fadeIn();
		//		$(this).parents('ul').prepend(lis);
		//同时在合适页面添加该简历
	} else {
		alert('网络开小车了')
	}
})

function sshide(obj){
	if(obj.find('li').length == 0){
		obj.parents('li').hide();
	}else{
		obj.parents('li').show()
	}
}
//牛人搜索
var items = ""
$('.ipt-search').on('keydown', function() {
	$('.tankuang').show()
	//发送请求
	//$.get
	//	$('.kdown').show();
	$('.skill_font').html('');
	$('.ul_first').html('');
	$('.ul_second').html('');
	$('.ul_firth').html('');
	var data_ops = {
		"err_code": 0,
		"err_msg": "请求成功",
		"page": "-1",
		"data": [{
			"skill_font": "前端", //关键字
			//曾任职位
			"his_ops": [{
				"id": 11,
				"name": "web前端"
			}, {
				"id": 12,
				"name": "助理文员"
			}, {
				"id": 13,
				"name": "网页设计师"
			}],
			//曾在公司
			"his_comp": [],
			//技能
			"skills": "",
			//教育经历
			"his_edu": [{
				"id": 31,
				"name": "北京大学"
			}, {
				"id": 32,
				"name": "清华大学"
			}],
		}]
	}
	if(data_ops.err_code == 0) {
		$('.skill_font').append('<li value="1">' + data_ops.data[0].skill_font + '</li>'); //关键字
		//曾任职位
		$.each(data_ops.data[0].his_ops, function(i, item) {
			$('.ul_first').append('<li value="' + item.id + '">' + item.name + '</li>')
		});
		//曾在公司
		$.each(data_ops.data[0].his_comp, function(i, item) {
			$('.ul_second').append('<li value="' + item.id + '">' + item.name + '</li>')
		});
		//毕业学校
		$.each(data_ops.data[0].his_edu, function(i, item) {
			$('.ul_firth').append('<li value="' + item.id + '">' + item.name + '</li>')
		});
		//技能
		$.each(data_ops.data[0].skills, function(i, item) {
			$('.ul_forth').append('<li value="' + item.id + '">' + item.name + '</li>')
		});
		sshide($('.ul_first'))
		sshide($('.ul_second'))
		sshide($('.ul_firth'))
		sshide($('.ul_forth'))
	} else {
		alert('网络开小车了')
	}
	var a = "";
	var b = "";
	$('ul.kdwon_li_ul').on('mousemove', 'li', function() {
		items = $(this);
		var fid = $(this).attr('value');
		$(this).parents(".kdown").find(".cur").removeClass("cur")
		$(this).addClass('cur');
		$(this).unbind('click').on('click', function() {
			$('.ipt-search')[0].value = items[0].innerText;
			a = items[0].innerText;
			b = $('.ipt-search')[0].value;
			$(document).unbind('click').bind('click', function() {
				if($('.ipt-search')[0].value == items[0].innerText) {
					$('.ipt-search')[0].value = items[0].innerText;
				} else {
					$('.ipt-search')[0].value = "";
				}
				$('.tankuang').hide();
			})
		})
	})
	$(document).bind('click', function() {
		if(b == a) {
			$('.ipt-search')[0].value = a;
		} else {
			$('.ipt-search')[0].value = "";
		}
		$('.tankuang').hide();
	})
})

//1.0.2完善搜索条件
$('.btn-search').on('click', function() {
	var arrspan = [];
	for(var j = 0; j < $('#tjkuang').find('.cur').length; j++) {
		arrspan.push($('#tjkuang').find('.cur')[j].innerText)
	}
	var str = "";
	for(var i = 0; i < $('#tjkuang').find('.nr_li').length; i++) {
		str += $('#tjkuang').find('.nr_li')[i].innerText + ";";
	}
	console.log(arrspan)
	if($('#tjkuang').find('img').length >= 4) alert("搜索条件不能超过四个")
	if($('.ipt-search')[0].value == "" && $('#tjkuang').find('img').length < 4) {
		var arr = "";
		for(var i = 0; i < $('#fb_ops')[0].innerText.length; i++) {
			if(isNaN($('#fb_ops')[0].innerText[i])) {
				arr += $('#fb_ops')[0].innerText[i];
			} else {
				break;
			}
		}
		str += '关键词' + arr;
		if($.inArray(arr, arrspan) == -1) {
			alert(str)
			//发送请求
			//后台返回对应的职位牛人 
			if(data.err_code == 0) {
				$('#tjkuang').append('<span class="nr_li">' + '关键字' + '<span class="cur">' + arr + '</span><img src="../assets/images/pop-resume-close.png"/></span>');
				alert('后台返回对应的职位牛人 ');
			} else {
				alert('网络打酱油去了')
			}
		} else {
			alert('搜索条件重复')
		}
	} else if($('.ipt-search')[0].value != "" && $('#tjkuang').find('img').length < 4) {
		if($.inArray($('.ipt-search')[0].value, arrspan) == -1) {
			alert(str + items.parents('li').find('div')[0].innerText + $('.ipt-search')[0].value)
			//发送请求
			//后台返回对应的职位牛人 
			if(data.err_code == 0) {
				$('#tjkuang').append('<span class="nr_li">' + items.parents('li').find('div')[0].innerText + '<span class="cur">' + $('.ipt-search')[0].value + '</span><img src="../assets/images/pop-resume-close.png"/></span>');
				alert('后台返回对应的职位牛人 ');
			} else {
				alert('网络打酱油去了')
			}
		} else {
			alert('搜索条件重复')
		}
	}
	$('.ipt-search')[0].value = ""
})
//1.0.2完善搜索条件

$('#tjkuang').on('click', 'img', function() {
	$(this).parent().remove()
})
//1.0.1
$('#fb_ops').on('click', function(event) {
	event.stopPropagation(); //阻止事件冒泡
	//发送请求，获得已经发布的职位数据
	//$.get
	var data_ops = {
		"err_code": 0,
		"err_msg": "请求成功",
		"page": "-1",
		"data": [{
			"id": 1,
			"name": "前端",
			"xinzi": "3K-4K"
		}, {
			"id": 2,
			"name": "前端工程师傅",
			"xinzi": "8K-12K"
		}, {
			"id": 3,
			"name": "web前端",
			"xinzi": "6K-12K"
		}, {
			"id": 4,
			"name": "前端架构",
			"xinzi": "5K-8K"
		}]
	}
	if(data.err_code == 0) {
		$('#fb_ops_kuang').find('ul').html("");
		$.each(data_ops.data, function(i, item) {
			$('#fb_ops_kuang').find('ul').append('<li value="' + item.id + '">' + item.name + '<em class="vline"></em>' + item.xinzi + '</li>')
		});
		$('#fb_ops_kuang').show();
		$('#fb_ops_kuang').toggle();
		var tag = $('#fb_ops_kuang').toggle();
		$('ul.ops_lis', $('#fb_ops_kuang')).on('click', 'li', function() {
			var item = $(this);
			$('#fb_ops')[0].innerHTML = item[0].innerHTML + '<i class="fz fz-arrow-down"></i>';
			$('#fb_ops_kuang').hide();
		})
		var flag = true;
		$(document).bind("click", function(e) { //点击空白处，设置的弹框消失
			var target = $(e.target);
			if(flag == true) {
				tag.hide();
				flag = false;
			}
		});
	} else {
		alert("网络不好，请一会再试")
	}
})
//1.0.1

//点击弹出简历
$('.qz-supermen').on('click', 'a', function() {
	//发送请求
	//$.get
	var data_wjj = {
		"err_code": 0,
		"err_msg": "请求成功",
		"page": "-1",
		"data": {
			"id": 3,
			"name": "胖渊改",
			"pictures": [{
				"id": 6,
				"logoUrl": "http://127.0.0.1:8989/xq/pic/PCDY1494293463546227_80_80.png",
				"url": "http://img5.imgtn.bdimg.com/it/u=53135405,935511012&fm=23&gp=0.jpg"
			}],
			"sex": 0,
			"workYear": "2016年",
			"workTime": "1年工作经验",
			"eduLevel": "本科",
			"workExperiences": [{
				"id": 1,
				"companyName": "蓝塘网络2",
				"startDate": "2016-06",
				"endDate": "2017-06",
				"noEnd": 1,
				"professionThirdType": {
					"id": 1,
					"name": "Java"
				},
				"professionName": "技术总监",
				"industry": {
					"id": 1,
					"name": "健康医疗"
				},
				"label": "Java",
				"department": "开发部门",
				"workContent": "开发开发开发开发",
				"achievement": "开发开发开发1",
				"shield": 1
			}],
			"itemExperiences": [{
				"id": 1,
				"itemName": "阿里巴巴建设",
				"startDate": "2016-09",
				"endDate": "2016-12",
				"itemKinds": "网站建设",
				"itemJshao": "此项目是公司的电商平台网站，包括主页、产品分类、产品展示、购物车、会员积分、配送、后台服务登模块。此次项目主要是针对即将过年"
			}],
			"eduExperiences": [{
				"id": 1,
				"schoolName": "江西科技师范大学",
				"majorName": "信息与计算科学",
				"eduLevel": "本科",
				"startYear": 1338480000000,
				"endYear": 1464710400000,
				"schoolExp": "在校经历\r\n在校经历",
				"eduLevelNumber": 3
			}],
			"intentions": [{
				"id": 1,
				"professionThirdType": {
					"id": 2,
					"name": "C++"
				},
				"minSalary": 20,
				"maxSalary": 30,
				"faceChat": 0,
				"industryName": "智能硬件",
				"cityName": "杭州"
			}],
			"projectExperiences": [],
			"accounts": [],
			"advantage": "我的优势\r\n我的优势",
			"state": "在职-暂不考虑",
			"lastDate": "2017-05-09 09:42",
			"wxNumber": "652749242"
		}
	}
	if(data_wjj.err_code == 0) {
		$('#wjj').show();
		$('#wjj').html("");
		$('#wjj').append('<img class="wjjimg" src="../assets/images/close_btn.jpg"/>')
		var divjj = document.createElement('div');
		var htm = '<div class="resume-content-load">' +
			'<div class="resume-box">' +
			'<div class="resume-item">' +
			'<div class="figure">';
		$.each(data_wjj.data.pictures, function(i, item) {
			htm += '<img src="' + item.url + '" />' +
				'</div>';
		});
		htm += '<h4>' + data_wjj.data.name + '<i class="fz fz-male"></i></h4>' +
			'<div class="info-labels">' +
			'<span class="label-text"><i class="fz fz-experience"></i>' + data_wjj.data.workTime + '</span><em class="vline"></em><span class="label-text"><i class="fz fz-degree"></i>' + data_wjj.data.eduLevel + '大专学历</span><em class="vline"></em><span class="label-text"><i class="fz fz-status"></i>' + data_wjj.data.state + '</span>' +
			'</div>' +
			'</div>' +
			'<div class="resume-item">' +
			'<h4 class="title">联系方式</h4>' +
			'<div class="text">尚未获取联系方式</div>' +
			'</div>' +
			'<div class="resume-item">' +
			'<h4 class="text">期望职位</h4>' +
			'<div class="info-labels">';
		$.each(data_wjj.data.intentions, function(i, item) {
			htm += '<span class="label-text"><i class="fz fz-job"></i>' + item.professionThirdType.name + '</span>';
			var qxinzi = ""
			if(item.faceChat != 0) {
				qxinzi == '面议'
			} else {
				qxinzi = item.minSalary + 'K-' + item.maxSalary + 'K';
			}
			htm += '<em class="vline"></em><span class="label-text"><i class="fz fz-salary"></i>' + qxinzi + '</span><em class="vline"></em><span><i class="fz fz-industry"></i>' + item.industryName + '</span><em class="vline"></em><span><i class="fz fz-location"></i>' + item.cityName + '</span>';

		});
		//			htm += '<span class="label-text"><i class="fz fz-job"></i>web前端 </span><em class="vline"></em><span class="label-text"><i class="fz fz-salary"></i>3k-5k</span><em class="vline"></em><span><i class="fz fz-industry"></i>不限</span><em class="vline"></em><span><i class="fz fz-location"></i>杭州</span>' +
		htm += '</div>' +
			'</div>' +
			'<div class="resume-item">' +
			'<h4 class="text">我的优势 </h4>' +
			'<div class="text">' +
			'<p>' + data_wjj.data.advantage + '</p>' +
			'</div>' +
			'</div>' +
			'<div class="resume-item">' +
			'<h4 class="text">工作经验</h4>' +
			'<div class="text">';
		$.each(data_wjj.data.workExperiences, function(i, item) {
			var comtime = ""
			if(item.noEnd == 1) {
				comtime = item.startDate + "至今";
			} else {
				comtime = item.startDate + item.endDate;
			}
			htm += '<span class="label-text">' + item.companyName + '</span><em class="vline"></em><span class="label-text">' + item.professionThirdType.name + '</span><em class="vline"></em><span>' + item.professionName + '</span><em class="vline"></em><span>' + comtime + '</span>' +
				'<p>工作内容：</br>' + item.workContent + '</p>' +
				'<p>工作业绩：</br>' + item.achievement + '</p>';
		});
		htm += '</div>' +
			'</div>' +
			'<div class="resume-item">' +
			'<h4 class="text">项目经验</h4>' +
			'<div class="text">';
		$.each(data_wjj.data.itemExperiences, function(i, item) {
			var itemtime = ""
			itemtime = item.startDate + item.endDate;
			htm += '<span class="label-text">' + item.itemName + '</span><em class="vline"></em><span class="label-text">' + item.itemKinds + '</span><em class="vline"></em><span>' + itemtime + '</span>' +
				'<p>项目简介：' + item.itemJshao + '</p>';
		});
		htm += '</div>' +
			'</div>' +
			'<div class="resume-item">' +
			'<h4 class="text">教育经历</h4>' +
			'<div class="history-item">';
		$.each(data_wjj.data.eduExperiences, function(i, item) {
			var edutime = ""
			edutime = item.startYear + '-' + item.endYear;
			htm += '<span class="period">' + edutime + '</span>' +
				'<h4 class="name">' + item.schoolName + '</h4>' +
				'<div>' +
				'<h4>' + item.majorName +
				'<em class="vline"></em>' + item.eduLevel;
		});
		htm += '</h4>' +
			'</div>' +
			'</div>' +
			'</div>' +
			'</div>' +
			'</div>'
		divjj.innerHTML = htm;
		$('#wjj').append(divjj)
	}
	$('.wjjimg').on('click', function() {
		console.log(111)
		$(this).parent().hide();
	})
})