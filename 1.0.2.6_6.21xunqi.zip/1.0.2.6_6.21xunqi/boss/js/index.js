//头像选择
function preview(file, obj) { //预览图片得到图片base64
	if(file.files && file.files[0]) {
		var reader = new FileReader();
		reader.onload = function(evt) {
			obj[0].innerHTML = '<img src="' + evt.target.result + '" />';
		}
		reader.readAsDataURL(file.files[0]);
		return file.files[0]
	} else {
		obj[0].innerHTML = '<div class="img" style="filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(sizingMethod=scale,src=\'' + file.value + '\'"></div>';
	}
	return file
}

$('#submit_box1').on('click', function() {
	var t = $('#w-headimg')[0].innerHTML, //头像
		a = $('.w-hrname')[0].value, //姓名
		c = $('#inter'), //团队亮点
		e = $('.inputElem')[0].value, //邮箱
		w = $('.w-weixinnum')[0].value, //微信
		op = $('.w-myoption')[0].value, //公司职位
		jj = $('.wteamjj')[0].innerText; //公司简介
	var	reg = /^[a-z0-9]+([._\\-]*[a-z0-9])*@([a-z0-9]+[-a-z0-9]*[a-z0-9]+.){1,63}[a-z0-9]+$/; //邮箱验证	
	if(reg.test(e) == false){
		$('.inputElem').next().show();
	} 
	var arr = [];
	for(var i = 0; i < c.find('p').length; i++) {
		arr.push($('#inter').find('p')[i].innerText)
	}
	arrstr = arr.join('-')
	if(a == "") $('.w-hrname').parent().find('p').show();
	if(c.find('p').length == 0) $('#inter').parent().find('p').show();
	if(op == "") $('.w-myoption').parent().find('p').show();
	if(a != "" && op != "" && c.find('p').length != 0 && reg.test(e) == true) {
		//发送请求
		//$.get（）
		if(data.err_code == 0) {
			alert("头像" + preview($('#doc'), $('#w-header'))[0].value + ',姓名' + a + '，邮箱' + e + ',微信号' + w + ',我的职位' + op + ',团队亮点' + arrstr + ",团队简介" + jj)
			alert('保存成功');
		}
	} else {
		alert('你还有一些重要信息没有填完了，请耐心再检查一遍')
	}
})
function hd(ob){
	ob.on('click',function(){
		ob.parent().find('p').hide()
	})
}
hd($('.w-hrname'))
hd($('.inputElem'))
hd($('.w-myoption'))
hd($('#inter'))



var data = {
	"err_code": 0,
	"err_msg": "请求成功",
	"page": "-1",
	"data": ""
}
//公司信息保存
$('#submit_box1_com').on('click', function() {
	var a = $('.w-comname')[0].value, //公司全称
		b = $('.w-comname-1')[0].value, //公司简称
		c = $('.bq_hy'),
		d = $('#compeople')[0].value,
		e = $('#comjd')[0].value,
		w = $('.w-www')[0].value;					
	if(a == "") $('.w-comname').parent().find('.dn').show()
	if(c.find('p').length == 0) $('.bq_hy').next().show()
	if(w == "") $('.w-www').parent().find('.dn').show()
	if(a != "" && b != "" && c.find('p').length != 0 && d != "" && e != "" && w != "") {
		alert("logo" + preview($('#com-doc'), $('#comlogo'))[0].value + "公司全称" + a + ',公司简称' + b + '，所属行业' + c.find('p')[0].innerText + ',人员规模' + d + ",公司阶段" + e + '公司网站' + w)
		//发送请求
		//$.get
		if(data.err_code == 0) {
			alert('保存成功')
		} else {
			alert('网络又调皮了')
		}
	} else {
		alert('你还有一些重要信息没有填完了，请耐心再检查一遍')
	}
})

function fillData(ob1, ob2) {
	if(ob1.err_code == 0) {
		$.each(ob1.data, function(i, item) {
			ob2.append('<li value="' + item.id + '">' + item.name + '</li>')
		});
	} else {
		alert("请检查网络");
	}
}
var data_inter = {
	"err_code": 0,
	"err_msg": "请求成功",
	"page": "-1",
	"data": [{
		"id": 1,
		"name": "股票期权"
	}, {
		"id": 2,
		"name": "带薪休假"
	}, {
		"id": 3,
		"name": "年度旅游"
	}, {
		"id": 4,
		"name": "不打卡"
	}, {
		"id": 5,
		"name": "年终分红"
	}, {
		"id": 6,
		"name": "美女多"
	}, {
		"id": 7,
		"name": "美女如云"
	}, {
		"id": 8,
		"name": "扁平管理"
	}, {
		"id": 9,
		"name": "只能硬件"
	}, {
		"id": 10,
		"name": "电子商务"
	}]
}

function qh(ob, ob2) {
	ob.on('click', function() {
		$(this).addClass('cur').siblings().removeClass('cur');
		$(this).parents('').find('.dn').hide();
		ob2.show();
	})
}
qh($('#peokuang'), $('.peokuang'))
qh($('#comkuang'), $('.comkuang'))

//文字框字数输入限制
//文本框字数限制输入
function textlength(obj1, num) {
	var lenInput = obj1.val().length;
	obj1.keyup(function() {
		lenInput = $(this).val().length;
		if(lenInput > 0 && lenInput <= num) {
			obj1.next().find('.textareaInput').html(lenInput);
		}
	});
}
textlength($('.w-hrname'), 5)
textlength($('.w-weixinnum'), 50)
textlength($('.w-myoption'), 12)
textlength($('.wteamjj'), 500)
textlength($('.w-comname'), 24)
textlength($('.w-comname-1'), 24)
textlength($('.w-www'), 50)

var data_hy = {
	"err_code": 0,
	"err_msg": "请求成功",
	"page": "-1",
	"data": [{
		"id": 1,
		"name": "金融"
	}, {
		"id": 2,
		"name": "旅游"
	}, {
		"id": 3,
		"name": "教育"
	}, {
		"id": 4,
		"name": "多媒体"
	}, {
		"id": 5,
		"name": "物流"
	}, {
		"id": 6,
		"name": "互联网"
	}, {
		"id": 7,
		"name": "销售"
	}, {
		"id": 8,
		"name": "美工"
	}, {
		"id": 9,
		"name": "仓储"
	}, {
		"id": 10,
		"name": "Delphi"
	}]
}
//所属行业单选
function hy(ob1, ob2) {
	var cname;
	//选择框的位置
	ob1.css({
		width: ob2.css('width'),
		top: ob2.outerHeight(true)
	});
	//点击选择框弹出
	$('span', ob2).on('click', function() {
		$('.bq_box2').html("");
		ob1.show();
		$('ul', ob1).html('');
		console.log(111)
		//请求期望行业
		//$.get("www.baidu.com");暂记 data_inter
		fillData(data_hy, $('.bq_box2'));
	});
	$('span', ob1).on('click', function() {
		ob1.hide();
	});
	$('ul', ob1).on('click', 'li', function() {
		if($('li[class="select_li"]', ob1).length < 3) {

			cname = $(this).text();
			ob2.find('span').html('').append('<p>' + cname + '</p>');
			ob1.hide();
		}
	});
}

//团队优势
//团队优势
function inter(ob1, ob2) {
	var cname;
	//选择框的位置
	ob1.css({
		width: ob2.css('width'),
		top: ob2.outerHeight(true)
	});
	//点击选择框弹出
	$('span', ob2).on('click', function() {
		$('#inter').html("");
		ob1.find('li').removeClass('select_li');
		ob1.show();
		$('ul', ob1).html('');	
		//请求期望行业
		//$.get("www.baidu.com");暂记 data_inter
		fillData(data_inter, $('#inter_ul'));
	});
	$('span', ob1).on('click', function() {
		ob1.hide();
	});
	$('ul', ob1).on('click', 'li', function() {
		if($('li[class="select_li"]', ob1).length < 3) {
			cname = $(this).text();
			var hasExist2 = !1;
			ob2.find("p").each(function() {
				if($(this).text() == cname) hasExist2 = !0
			})
			$(this).addClass('select_li');
			hasExist2 ? alert('所选标签已被添加！') : ob2.find('span').append('<p>' + cname + '</p>');
		}
	});
}
//1.0.2.3	
	//团队亮点
inter($(".inter_xuan"), $(".inter_p"))
	//所属行业
hy($('.select-box-opkills'), $('.select-res-opkills'))
//1.0.2.3