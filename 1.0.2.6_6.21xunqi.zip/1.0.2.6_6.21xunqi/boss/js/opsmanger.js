var data = {
	"err_code": 0,
	"err_msg": "请求成功",
	"page": "-1",
	"data": ""
}

function openoff(obj1, obj2) {
	obj1.click(function() {
		if(obj2.css("display") == "none") {
			obj2.show()
		} else {
			obj2.hide();
		}
	})
}
openoff($('#w-opssx'), $('.sec-filter'))
$('.w-bjoption-close').on('click', function() {
	alert($(this).parents('.position-meaus').attr('val'))
	//发送请求 将该职位打开
	//$.get.....
	if(data.err_code == 0) {
		if($(this)[0].innerText == "打开职位") {
			$(this)[0].innerHTML ='<i class="fz fz-location"></i>' + '关闭职位';
			$(this).parents('.position-meaus').find('.close').css('opacity',0);
		}else{
			$(this).parents('.position-meaus').find('.close').css('opacity',0.5);
			$(this)[0].innerHTML ='<i class="fz fz-location"></i>' + '打开职位';
		}
	} else {
		alert('网络开小车了')
	}

})