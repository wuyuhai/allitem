var data1 = {
	"err_code": 0,
	"err_msg": "请求成功",
	"page": "-1",
	"data": ""
}

//1.0.2.3
//职位类型
history($('.select-box-his'), $('.select-res-his'), $('#qw'));
//技能标签
kills($('.select-box-hiskills'), $('.select-res-hiskills'))
//1.0.2.3

var val;
$('#ppub_savebtn').on('click', function() {
	//传递过来的val值暂记2
	val = 2
	var displine = document.getElementsByClassName('displine')[0]
	var reg = /^[a-z0-9]+([._\\-]*[a-z0-9])*@([a-z0-9]+[-a-z0-9]*[a-z0-9]+.){1,63}[a-z0-9]+$/ //邮箱验证
	var a = $('.wopname')[0].value, //职位名称
		b = $('#qw'), //职位类型
		c = $('.bq_skills'), //技能要求
		d = $('.addresss')[0].value, //工作城市
		e = $('.workadd')[0].value, //工作地点
		f = $('#wxinzi1'),
		g = $('#wxinzi2'),
		h = $('.workhis')[0].value, //工作经验
		edu = $('.meducation')[0].value, //学历要求
		ms = $('#w-txtrea')[0].value, //职位描述
		emil = $('.inputElem')[0].value;
	var t = reg.test(emil)
	console.log(displine.style.display)
	if(displine.style.display == "none") {
		alert('请先填写公司信息');
		$('.displine').hide()
	} else {
		var arr = ""
		for(var i = 0; i < $('.displine').find('span').length; i++) {
			arr += $('.displine').find('span')[i].innerText;
		}
		alert('公司基本信息' + arr)
	}
	console.log(t)
	var arrskill = "";
	//1.0.2修复字符串拼接错问题
	for(var i = 0; i < c.find('p').length; i++) {
		if(i == c.find('p').length - 1) {
			arrskill += c.find('p')[i].innerText;
		} else {
			arrskill += c.find('p')[i].innerText + "*";
		}
	}
	//1.0.2修复字符串拼接错问题
	console.log(arrskill)
	if(a == "") $('.wopname').parents('.form-group').find('p').show();
	if(b.find('p').length == 0) b.parents('.form-group').find('p').show();
	if(c.find('p').length == 0) c.parents('.form-group').find('p').show();
	if(d == "") $('.addresss').parents('.form-group').find('p').show();
	if(ms == "") $('#w-txtrea').parents('.form-group').find('p').show();
	if(emil == "" || t == false) $('.inputElem').parents('.form-group').find('p').show();
	qshow($('.wopname'));
	qshow(b);
	qshow(c);
	qshow($('.addresss'));
	qshow($('#w-txtrea'));
	qshow($('.inputElem'));
	//1.0.2设置弹出的b.find('p')文本改成id
	console.log(b.find('p').attr('value'))
	if(displine.style.display != "none" && a != "" && b.find('p').length != 0 && c.find('p').length != 0 && d != "" && ms != "" && t == true) {
		alert("保存职位val值" + val + '职位名称' + a + ',职位类型' + b.find('p').attr('value') + '标记id' + ',技能要求' + arrskill + ',工作城市' + d + ',工作地点' + e + ',薪资' + f[0].value + '至' + g[0].value + '工作经验' + h + '学历要求' + edu + '职位描述' + ms + '邮箱' + emil)
		//1.0.2设置弹出的b.find('p')文本改成id
		//发送请求
		//$.get()
		if(data1.err_code == 0) {
			//请求成功
		} else {
			alert('网络打酱油')
		}
	}
})

//文字框字数输入限制
//文本框字数限制输入
function textlength(obj1, num) {
	var lenInput = obj1.val().length;
	obj1.keyup(function() {
		lenInput = $(this).val().length;
		if(lenInput > 0 && lenInput <= num) {
			obj1.next().find('.textareaInput').html(lenInput);
		}
	});
}
textlength($('.wopname'), 12)
textlength($('#w-txtrea'), 500)

//点击提示隐藏
function qshow(ob) {
	ob.on('click', function() {
		$(this).parents('.form-group').find('p').hide()
	})
}

//关闭职位
$('.ops_close').on('click', function() {
	alert("关闭职位的" + val)
	//发送请求
	//$.get()
	if(data.err_code == 0) {
		//成功 职位管理页面进行相应的改变

	} else {
		alert('网络开小车 了')
	}
})
//删除职位
$('.ops_del').on('click', function() {
	alert("删除职位" + val)
	//发送请求
	//$.get()
	if(data.err_code == 0) {
		//成功 职位管理页面进行相应的改变

	} else {
		alert('网络开小车 了')
	}
})
//期望城市请求
$('.addresss').on('keydown', function() {
	console.log(111)
	//发送请求
	//获得数据，占记
	$('#address').html('');
	var data_address = {
		"err_code": 0,
		"err_msg": "请求成功",
		"page": "-1",
		"data": [{
			"id": 1,
			"name": "大连"
		}, {
			"id": 2,
			"name": "大同"
		}, {
			"id": 3,
			"name": "大山"
		}, {
			"id": 4,
			"name": "大大"
		}]
	}
	if(data_address.err_code == 0) {
		$.each(data_address.data, function(i, item) {
			$('#address').append('<li value="' + item.id + '">' + item.name + '</li>')
		});
	} else {
		alert("请检查网络");
	}
	$('.wsuggest').show()
	console.log(222)
	var a = "",
		b = "";
	$('li', $('#address')).on('click', function() {
		item = $(this)[0];
		var fid = $(this).attr('value');
		$('.addresss')[0].value = item.innerText;
		a = item.innerText;
		b = $('.addresss')[0].value;
//1.0.2.5
//		$(document).bind('click', function() {
//			console.log(11)
//			if($('.addresss')[0].value == item.innerText) {
//				$('.addresss')[0].value = item.innerText;
//			} else {
//				$('.addresss')[0].value = "";
//			}
//			$('.wsuggest').hide();
//		})
//1.0.2.5
	})
	$(document).bind('click', function() {
		if(b == a) {
			$('.addresss')[0].value = a;
		} else {
			$('.addresss')[0].value = "";
		}
		$('.wsuggest').hide();
	})
})


//1.0.2.5
var addresxy
$('.workadd').on('click', function() {
	if($('.addresss')[0].value == "") {
		alert("请先填写工作城市");
	} else {
		$('#baiduditu').show()
	}
})
$('.dzkclose').on('click', function() {
	$('#baiduditu').hide()
})
$('button.btn-success', $('.diz_tijiao')).on('click', function() {
	console.log($('.jiedao')[0].value)
	console.log(addresxy)
	if($('.jiedao')[0].value != "") {
		$('.workadd')[0].value = $('.jiedao')[0].value;
		$('.addressxy')[0].innerText = addresxy;
		$('#baiduditu').hide();		
	}else{
		alert("街道或写字楼不能为空");
	}
})
var cpLock = false;
$(".jiedao").bind('compositionstart', function() {
	cpLock = true;
});
$(".jiedao").bind('compositionend', function() {
	cpLock = false;
});

$(".jiedao").bind('input', function() {
	$('.bddzlis').show()
	$('.bddzlis_ul').html('');
	var value = $(this).val();
	if(value == "") {
		$('.bddzlis').hide();
		return false;
	}
	if(!cpLock) {
		//		console.log(value);
		//		$.get("${pageContext.request.contextPath}/regionalHints", {
		//			region: "杭州",
		//			query: value
		//		}, function(data) {
		//发送请求
		//￥。get
		var data = {
			"err_code": 0,
			"err_msg": "请求成功",
			"page": "-1",
			"data": [{
				"id": 1,
				"name": "物流工程"
			}, {
				"id": 2,
				"name": "金融"
			}, {
				"id": 3,
				"name": "计算机"
			}, {
				"id": 4,
				"name": "机械工程"
			}]
		}
		if(data.err_code == 0) {
			$('.bddzlis_ul').html('');
			$.each(data.data, function(i, item) {
				$('.bddzlis_ul').append('<li value="110.110"><span class="addresskey">' + item.name + '</span><span class="fontcolorhui">' + 111  + '</span></li>');
			});
			var tt = $('.bddzlis');
			var a = "";
			var b = "";
			tt.toggle();
			var tag = tt.toggle();
			$('li', tt.find('ul')).on('click', function() {
				item = $(this).find('.addresskey')[0];
				addresxy = $(this).attr('value');
				$('.jiedao')[0].value = item.innerText;
				a = item.innerText;
				b = $('.jiedao')[0].value;
				if($('.jiedao')[0].value != ""){
					//发送请求，地图定位
					//$，get
					$('.tisi').show()
				}else{
					$('.tisi').hide()
				}
			})
			var flag = true;
			$(document).bind("click", function(e) { //点击空白处，设置的弹框消失
				var target = $(e.target);
				if(flag == true) {
					tag.hide();
					flag = false;
				}
			});
		} else {
			console.log(data.err_msg);
		}
	}
});
//1.0.2.5