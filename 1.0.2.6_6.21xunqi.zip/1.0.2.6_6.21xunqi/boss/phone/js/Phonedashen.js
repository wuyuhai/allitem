$('.ops_yaoqiu').on('click', function() {
	if($("#sxtj_ct").css("display") == "none") {
		event.stopPropagation(); //阻止事件冒泡
		var tt = $('#sxtj_ct');
		tt.show();
		aclick($('dd.xinzi'));
		jyorjy($('dd.jinyan'));
		jyorjy($('dd.edu'));
		tt.toggle();
		var tag = tt.toggle();
		var flag = true;
		$('.sxtj_ct_bg').unbind('click').on('click',function(){
			flag = false;
			console.log(1111111)
		})
		$('.sx_sure_yes').unbind('click').on('click', function() {
			var xz = ""
			for(var i = 0; i < $('.xinzi').find('.cur').length; i++) {
				if(i == 0) {
					xz += $($('.xinzi').find('.cur')[i])[0].innerText;
				} else {
					xz += "*" + $($('.xinzi').find('.cur')[i])[0].innerText;
				}
			}
			alert('推荐条件：薪资' + xz + '；经验' + $('.jinyan').find('.cur')[0].innerText + '；学历' + $('.edu').find('.cur')[0].innerText)
			$('#sxtj_ct').hide();
		})	
		$(document).unbind('click').bind("click", function(e) { //点击空白处，设置的弹框消失		
			var target = $(e.target);
			console.log(flag)
			if(flag == false) {
				tag.hide();
				flag = true;
			}
		});
	} else {
		$('#sxtj_ct').hide();
	}
})

function aclick(obj) {
	obj.on('click', 'a', function() {
		console.log($(this))
		if($(this)[0].innerText == "不限") {
			$(this).addClass('cur');
			$(this).siblings().removeClass('cur');
		} else {
			if($(this)[0].className == 'cur') {
				$(this).removeClass('cur');
				if(obj.find('.cur').length == 0) {
					$(obj.find('a')[0]).addClass('cur');
				}
			} else {
				$(obj.find('a')[0]).removeClass('cur');
				$(this).addClass('cur');
			}
		}
	})
}

function jyorjy(obj) {
	obj.on('click', 'a', function() {
		$(this).addClass('cur');
		$(this).siblings().removeClass('cur');
	})
}

opson()

function opson() {
	//	console.log(111)
	var width = 0;
	for(var i = 0; i < $('.ops_nav_lis').find('li').length; i++) {
		width += $('.ops_nav_lis').find('li')[i].offsetWidth;
	}
	console.log(width)
	$('.ops_nav_lis').css({
		width: width + 7.5 + 'px'
	})
	console.log($('.ops_nav_lis').css("width"));
	for(var i = 0; i < $('.ops_nav_lis').find('li').length; i++) {
		(function(i) {
			var lileft = 0;
			$('.ops_nav_lis').find('li')[i].onclick = function() {
				$(this).addClass('cur').siblings().removeClass('cur')
				for(var j = 0; j < i; j++) {
					lileft += $('.ops_nav_lis').find('li')[j].offsetWidth;
				}
				lileft += $(this)[0].offsetWidth / 2;
				if(lileft > $('.ops_nav')[0].offsetWidth / 2) {
					$('.ops_nav')[0].scrollLeft = (lileft - 120) / (width + 22.5 - $('.ops_nav')[0].offsetWidth) * ($('.ops_nav')[0].scrollWidth - $('.ops_nav')[0].offsetWidth)
					console.log(lileft, $('.ops_nav')[0].scrollLeft)
				} else {
					$('.ops_nav')[0].scrollLeft = 0;
				}
				//				console.log(lileft,$('.ops_nav'))
				lileft = 0
			}
		})(i);
	}
}
console.log($('body')[0].scrollHeight - document.documentElement.clientHeight)
console.log($('body')[0].scrollHeight)

var T = 0;
$(window).scroll(function() {
	T = $(document).scrollTop();
	if(T >= $('body')[0].scrollHeight - document.documentElement.clientHeight) {
		//		发送请求
		//     ￥。get
		var err_code = 0;
		if(err_code == 0) {
			for(var i = 0; i < 15; i++) {
				var lis = document.createElement('li');
				lis.innerHTML += '<a href="">' +
					'<div class="want_ops">' +
					'<h4>' +
					'<span>期望职位</span>' +
					'<span>前端实习</span>' +
					'</h4>' +
					'</div>' +
					'<div class="personal">' +
					'<div class="headimg">' +
					'<img src="../../assets/images/1-150630062413.jpg" />' +
					'</div>' +
					'<div class="ps_xx">' +
					'<h5>' +
					'<span class="name">吴玉海</span>' +
					'<span class="sex">男</span>' +
					'</h5>' +
					'<p>' +
					'<span class="opszt">曾任</span>' +
					'<em></em>' +
					'<span class="company">阿里巴巴</span>' +
					'<em></em>' +
					'<span class="com_ops cur">前端</span>' +
					'</p>' +
					'</div>' +
					'</div>' +
					'	<div class="myys">' +
					'<p class="myys_c">' +
					'前端实习前端实习前端实习前端实习前端实习前端实习前端实习前端实习前端实习前端实习前端实习前端实习前端实习前端实习' +
					'</p>' +
					'</div>' +
					'</a>';
				$('.tj_lis').append(lis);
				console.log(i)
			}
		}
	}
	console.log(T)
});

if($('.tj_lis').find('li').length >= 15) {
	$('.jzmore').show();
}