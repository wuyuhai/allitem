/**
 * Created by hx on 2017/4/14.
 */
var data_op = {
	"err_code": 0,
	"err_msg": "请求成功",
	"page": "-1",
	"data": [{
		"id": 1,
		"name": "技术"
	}, {
		"id": 2,
		"name": "产品"
	}, {
		"id": 3,
		"name": "设计"
	}, {
		"id": 4,
		"name": "运营"
	}, {
		"id": 5,
		"name": "市场"
	}, {
		"id": 6,
		"name": "职能/高级管理"
	}, {
		"id": 7,
		"name": "销售"
	}, {
		"id": 8,
		"name": "传媒"
	}, {
		"id": 9,
		"name": "金融"
	}, {
		"id": 10,
		"name": "汽车"
	}, {
		"id": 11,
		"name": "教育培训"
	}, {
		"id": 12,
		"name": "医疗健康"
	}, {
		"id": 13,
		"name": "采购/贸易"
	}, {
		"id": 14,
		"name": "供应链/物流"
	}, {
		"id": 15,
		"name": "房地产/建筑"
	}, {
		"id": 16,
		"name": "咨询/翻译/法律"
	}, {
		"id": 17,
		"name": "实习生/管培生"
	}, {
		"id": 18,
		"name": "其他"
	}]
}
var data_id_data = {
	"err_code": 0,
	"err_msg": "请求成功",
	"page": "-1",
	"data": [{
		"id": 1,
		"name": "后端开发"
	}, {
		"id": 2,
		"name": "移动开发"
	}, {
		"id": 3,
		"name": "测试"
	}, {
		"id": 4,
		"name": "运维/技术支持"
	}, {
		"id": 5,
		"name": "数据"
	}, {
		"id": 6,
		"name": "项目管理"
	}, {
		"id": 7,
		"name": "硬件开发"
	}, {
		"id": 8,
		"name": "前端开发"
	}, {
		"id": 9,
		"name": "通信"
	}, {
		"id": 10,
		"name": "高端技术职位"
	}, {
		"id": 11,
		"name": "人工智能"
	}, {
		"id": 12,
		"name": "软件销售支持"
	}, {
		"id": 13,
		"name": "其他技术职位"
	}]
}
var data_id_id_data = {
	"err_code": 0,
	"err_msg": "请求成功",
	"page": "-1",
	"data": [{
		"id": 1,
		"name": "Java"
	}, {
		"id": 2,
		"name": "C++"
	}, {
		"id": 3,
		"name": "PHP"
	}, {
		"id": 4,
		"name": "数据挖掘"
	}, {
		"id": 5,
		"name": "C"
	}, {
		"id": 6,
		"name": "C#"
	}, {
		"id": 7,
		"name": ".NET"
	}, {
		"id": 8,
		"name": "Hadoop"
	}, {
		"id": 9,
		"name": "Python"
	}, {
		"id": 10,
		"name": "Delphi"
	}, {
		"id": 11,
		"name": "VB"
	}, {
		"id": 12,
		"name": "Perl"
	}, {
		"id": 13,
		"name": "Ruby"
	}, {
		"id": 14,
		"name": "Node.js"
	}, {
		"id": 15,
		"name": "搜索算法"
	}, {
		"id": 16,
		"name": "Golang"
	}, {
		"id": 17,
		"name": "自然语言处理"
	}, {
		"id": 18,
		"name": "推荐算法"
	}, {
		"id": 19,
		"name": "Erlang"
	}, {
		"id": 20,
		"name": "算法工程师"
	}, {
		"id": 21,
		"name": "语音/视频/图形开发"
	}, {
		"id": 22,
		"name": "数据采集"
	}]
}
var data_skill = {
	"err_code": 0,
	"err_msg": "请求成功",
	"page": "-1",
	"data": [{
		"id": 1,
		"name": "Java爬虫"
	}, {
		"id": 2,
		"name": "html"
	}, {
		"id": 3,
		"name": "css3"
	}, {
		"id": 4,
		"name": "JQ"
	}, {
		"id": 5,
		"name": "BOOTSTRAP"
	}, {
		"id": 6,
		"name": "C#"
	}, {
		"id": 7,
		"name": "VOE"
	}, {
		"id": 8,
		"name": "ANJULAR"
	}, {
		"id": 9,
		"name": "NODE"
	}, {
		"id": 10,
		"name": "Delphi"
	}]
}
var data_hy = {
	"err_code": 0,
	"err_msg": "请求成功",
	"page": "-1",
	"data": [{
		"id": 1,
		"name": "金融"
	}, {
		"id": 2,
		"name": "旅游"
	}, {
		"id": 3,
		"name": "教育"
	}, {
		"id": 4,
		"name": "多媒体"
	}, {
		"id": 5,
		"name": "物流"
	}, {
		"id": 6,
		"name": "互联网"
	}, {
		"id": 7,
		"name": "销售"
	}, {
		"id": 8,
		"name": "美工"
	}, {
		"id": 9,
		"name": "仓储"
	}, {
		"id": 10,
		"name": "Delphi"
	}]
}
var data_inter = {
	"err_code": 0,
	"err_msg": "请求成功",
	"page": "-1",
	"data": [{
		"id": 1,
		"name": "股票期权"
	}, {
		"id": 2,
		"name": "带薪休假"
	}, {
		"id": 3,
		"name": "年度旅游"
	}, {
		"id": 4,
		"name": "不打卡"
	}, {
		"id": 5,
		"name": "年终分红"
	}, {
		"id": 6,
		"name": "美女多"
	}, {
		"id": 7,
		"name": "美女如云"
	}, {
		"id": 8,
		"name": "扁平管理"
	}, {
		"id": 9,
		"name": "只能硬件"
	}, {
		"id": 10,
		"name": "电子商务"
	}]
}

function fillData(ob1, ob2) {
	if(ob1.err_code == 0) {
		$.each(ob1.data, function(i, item) {
			ob2.append('<li value="' + item.id + '">' + item.name + '</li>')
		});
	} else {
		alert("请检查网络");
	}
}
$('.com_name').on('click', function() {
	$('.tk_name').show();
})

var fid_id1 = 0
$('.com_xx_one').unbind('click').on('click', function() {
	$('.tk_opstatial').show();
	//	fid_id1 = 0;
	$('.w_first').show();
	$('ul.w_first').html('')
	$('.w_second').hide();
	$('.w_third').hide();
	fillData(data_op, $('.w_first'));
	//第一个列表
	var tt = $('.w_second_bg1');
	var a = "";
	var b = "";
	tt.toggle();
	var tag = tt.toggle();
	var flag;
	$('ul.w_first').on('click', 'li', function() {
		$('.w_second_bg1').show();
		$('ul.w_second').html('');
		$('ul.w_third').html('');
		$('ul.w_third').hide();
		$(this).addClass('w_selected').siblings().removeClass('w_selected');
		var item = $(this);
		var fid = item.attr('value');
		//用fid做下一个就扣的请求标记
		//		$.get("www.baidu.com/id=fid");暂记 data_id_data							
		fillData(data_id_data, $('.w_second'));
		$('.w_second_bg1').css({
			height: document.documentElement.clientHeight - 55 + "px"
		})
		$('.w_second_bg2').css({
			height: document.documentElement.clientHeight - 55 + "px"
		})
		console.log(document.documentElement.clientHeight)
		console.log($('.w_second_bg1').css("height"))
		$('.w_second_bg1').show();
		$('ul.w_second').show();
		flag = true;
	});
	//第二个列表 
	$('ul.w_second').on('click', 'li', function() {
		$('ul.w_third').html('');
		var item = $(this);
		fid_id1 = item.attr('value');
		var fid = item.attr('value');
		$(this).addClass('w_selected').siblings().removeClass('w_selected');
		//继续用 fid 做第三个列表的的请求标记
		//		$.get("www.baidu.com/id=fid");暂记 data_id_id_data
		fillData(data_id_id_data, $('.w_third'));
		$('ul.w_third').show();
		flag = true;
	});
	$('ul.w_third').on('click', 'li', function() {
		var cname = $(this).text();
		var item = $(this);
		var fid = item.attr('value');
		//1.0.2将标记的 val添加到标签里面去
		$('.ops_tatial')[0].innerText = cname;
		//		op.html("").append('<p value="' + fid + '">' + cname + '</p>');	
		$('.tk_opstatial').hide();
		flag = false;
		//返回的 fid_id 是做为技能标签请求接口的id
		$('.jl_fid')[0].innerText = fid_id1;
	});
	$('.w_second_bg2').unbind('click').on('click', function() {
		flag = false
	})
	$(document).unbind('click').bind("click", function(e) { //点击空白处，设置的弹框消失		
		var target = $(e.target);
		if(flag == false) {
			tag.hide();
			flag = true;
		}
	});
})

$('.com_xx_two').on('click', function() {
	$('.tk_ops_name').show();
	$('.btn-default', $('.ops_nameInput_y')).on('click', function() {
		if($('.ops_nameInput')[0].value != "") {
			$('.ops_name')[0].innerText = $('.ops_nameInput')[0].value;
			$('.tk_ops_name').hide();
			$('.ops_nameInput')[0].value = "";
		}
	})
})
var ary = [];
var skill_str = "";
$('.com_xx_three').on('click', function() {
	fid_id1 = $('.jl_fid')[0].innerText;
	if(fid_id1 == 0) {
		alert('请选择职位')
	} else {
		$('.tk_ops_skill').show();
		$('ul.bq_box').html("");
		fillData(data_skill, $('.bq_box'));
		$('ul.bq_box').unbind('click').on('click', 'li', function() {
			console.log(11)
			if($('li[class="select_li"]').length < 3) {
				cname = $(this).text();
				var value = $(this).attr('value')
				var hasExist2 = !1;
				console.log($(this).get(0).className)
				if($(this).get(0).className != "select_li") {
					$(this).addClass('select_li');
				} else {
					$(this).get(0).className = "";
				}
			} else if($('li[class="select_li"]').length == 3) {
				if($(this).get(0).className == "select_li") {
					$(this).get(0).className = "";
				}
			}
		});
		$('.btn-default', $('.tk_ops_skill_y')).unbind('click').on('click', function() {
			if($('li[class="select_li"]').length != 0) {
				ary.length == 0;
				for(var i = 0; i < $('li[class="select_li"]').length; i++) {
					ary.push($('li[class="select_li"]')[i].getAttribute('value'));
					if(i == 0) {
						skill_str += $('li[class="select_li"]')[i].innerText;
					} else {
						skill_str += "*" + $('li[class="select_li"]')[i].innerText;
					}
				}
				console.log(ary)
				console.log(skill_str)
				$('.ops_skill')[0].innerText = $('li[class="select_li"]').length + "技能标签";
				$('.tk_ops_skill').hide();
			} else {
				alert("请选择技能标签")
			}
		})
	}
})

$('.com_xx_four').unbind('click').on('click', function() {
	$('.tk_ops_xinzi').show();
	$('.tk_ops_xinzi').css({
		height: window.screen.height + 'px'
	})
	$('.tk_ops_xinzi_sure').unbind('click').on('click', function() {
		$('.ops_xinzi')[0].innerText = $('#wxinzi1')[0].value + "-" + $('#wxinzi2')[0].value;
		$('.tk_ops_xinzi').hide();
	})
})
$('.com_xx_five').unbind('click').on('click', function() {
	$('.tk_whis').show();
	$('.tk_whis_sure').unbind('click').on('click', function() {
		$('.ops_jingyan')[0].innerText = $('.work_histime')[0].value;
		$('.tk_whis').hide();
	})
})

$('.com_xx_six').unbind('click').on('click', function() {
	$('.tk_schis').show();
	$('.tk_schis_sure').unbind('click').on('click', function() {
		$('.ops_school')[0].innerText = $('.school_histime')[0].value;
		$('.tk_schis').hide();
	})
})

$('.com_xx_seven').unbind('click').on('click', function() {
	$('.tk_adds').show();
	$('#wc_city').on('keydown', function() {
		//发送请求
		//获得数据，占记
		$('.city_lis').html('');
		var data_address = {
			"err_code": 0,
			"err_msg": "请求成功",
			"page": "-1",
			"data": [{
				"id": 1,
				"name": "大连"
			}, {
				"id": 2,
				"name": "大同"
			}, {
				"id": 3,
				"name": "大山"
			}, {
				"id": 4,
				"name": "大大"
			}]
		}
		if(data_address.err_code == 0) {
			$.each(data_address.data, function(i, item) {
				$('.city_lis').append('<li value="' + item.id + '">' + item.name + '</li>')
			});
		} else {
			alert("请检查网络");
		}
		$('.wsuggest').show()
		var a = "",
			b = "";
		$('li', $('.city_lis')).on('click', function() {
			item = $(this)[0];
			var fid = $(this).attr('value');
			$('#wc_city')[0].value = item.innerText;
			a = item.innerText;
			b = $('#wc_city')[0].value;
			console.log(1)
		})
		$(document).bind('click', function() {
			if(b == a) {
				$('#wc_city')[0].value = a;
			} else {
				$('#wc_city')[0].value = "";
			}
			$('.wsuggest').hide();
		})
	})
	var addresxy
	$('#wc_jiedao').on('click', function() {
		if($('#wc_city')[0].value == "") {
			alert("请先填写工作城市");
		} else {
			$('#baiduditu').show()
		}
	})
	$('.dzkclose').on('click', function() {
		$('#baiduditu').hide()
	})
	$('button.btn-success', $('.diz_tijiao')).on('click', function() {
		if($('.jiedao')[0].value != "") {
			$('#wc_jiedao')[0].value = $('.jiedao')[0].value + " " + $('.menpai')[0].value;
			$('.addressxy')[0].innerText = addresxy;
			$('#baiduditu').hide();
		} else {
			alert("街道或写字楼不能为空");
		}
	})
	var cpLock = false;
	$(".jiedao").bind('compositionstart', function() {
		cpLock = true;
	});
	$(".jiedao").bind('compositionend', function() {
		cpLock = false;
	});

	$(".jiedao").bind('input', function() {
		$('.bddzlis').show()
		$('.bddzlis_ul').html('');
		var value = $(this).val();
		if(value == "") {
			$('.bddzlis').hide();
			return false;
		}
		if(!cpLock) {
			//		console.log(value);
			//		$.get("${pageContext.request.contextPath}/regionalHints", {
			//			region: "杭州",
			//			query: value
			//		}, function(data) {
			//发送请求
			//￥。get
			var data = {
				"err_code": 0,
				"err_msg": "请求成功",
				"page": "-1",
				"data": [{
					"id": 1,
					"name": "物流工程"
				}, {
					"id": 2,
					"name": "金融"
				}, {
					"id": 3,
					"name": "计算机"
				}, {
					"id": 4,
					"name": "机械工程"
				}]
			}
			if(data.err_code == 0) {
				$('.bddzlis_ul').html('');
				$.each(data.data, function(i, item) {
					$('.bddzlis_ul').append('<li value="110.110"><span class="addresskey">' + item.name + '</span><span class="fontcolorhui">' + 111 + '</span></li>');
				});
				var tt = $('.bddzlis');
				var a = "";
				var b = "";
				tt.toggle();
				var tag = tt.toggle();
				$('li', tt.find('ul')).on('click', function() {
					item = $(this).find('.addresskey')[0];
					addresxy = $(this).attr('value');
					$('.jiedao')[0].value = item.innerText;
					a = item.innerText;
					b = $('.jiedao')[0].value;
					if($('.jiedao')[0].value != "") {
						//发送请求，地图定位
						//$，get
						$('.tisi').show()
					} else {
						$('.tisi').hide()
					}
				})
				var flag = true;
				$(document).bind("click", function(e) { //点击空白处，设置的弹框消失
					var target = $(e.target);
					if(flag == true) {
						tag.hide();
						flag = false;
					}
				});
			} else {
				console.log(data.err_msg);
			}
		}
	})
	$('.tk_adds_sure').unbind('click').on('click', function() {
		if($('#wc_city')[0].value != "" && $('#wc_jiedao')[0].value != "") {
			$('.ops_addres')[0].innerText = $('#wc_city')[0].value + ' ' + $('#wc_jiedao')[0].value;
			$('.add_xy')[0].innerHTML = addresxy;
			$('.tk_adds').hide();
		} else {
			alert('请填写工作城市和工作地点')
		}
	})
})

$('.com_xx_eight').on('click', function() {
	console.log(111)
	$('.ops_miaos').show();
	$('.btn-default', $('.miaosu_y')).unbind('click').on('click', function() {
		if($('.miaoshu')[0].value != "") {
			$('.ops_ms')[0].innerText = "修改";
			$('.ms_contan')[0].innerText = $('.miaoshu')[0].value;
			$('.ops_miaos').hide();
			//			$('.miaoshu')[0].value = "";
		} else {
			alert("职位描述不能为空")
		}
	})
})

$('.com_xx_nine').on('click', function() {
	$('.ops_emal').show();
	$('.btn-default', $('.js_emal_y')).unbind('click').on('click', function() {
		var reg = /^[a-z0-9]+([._\\-]*[a-z0-9])*@([a-z0-9]+[-a-z0-9]*[a-z0-9]+.){1,63}[a-z0-9]+$/ //邮箱验证
		var Ebol = reg.test($('.js_emal')[0].value);
		console.log(Ebol)
		if($('.js_emal')[0].value != "" && Ebol == true) {
			$('.ops_Em')[0].innerText = $('.js_emal')[0].value;
			$('.ops_emal').hide();
			//			$('.miaoshu')[0].value = "";
		} else {
			alert("邮箱输入有误或者不能为空")
		}
	})
})

//返回
$('.reback').unbind('click').on('click', function() {
	//公司
	if($(this).parent().parent().get(0).className.indexOf("tk_name") != -1) {
		$('.fix_kuang').hide();
	}
	//职位
	if($(this).parent().parent().get(0).className.indexOf("tk_opstatial") != -1) {
		$('.fix_kuang').hide();
		$('.w_second_bg1').hide();
	}
	//职位名称
	if($(this).parent().parent().get(0).className.indexOf("tk_ops_name") != -1) {
		if($('.ops_nameInput')[0].value == "") {
			$('.fix_kuang').hide();
		} else {
			$('.tuichutishi').show();
			$('.btn-sure').unbind('click').on('click', function() {
				$('.tuichutishi').hide();
				$('.fix_kuang').hide();
			})
			$('.btn-no,.closeimg').unbind('click').on('click', function() {
				$('.tuichutishi').hide();
			})
		}
	}
	//技能标签
	if($(this).parent().parent().get(0).className.indexOf("tk_ops_skill") != -1) {
		console.log(1)
		if($('li[class="select_li"]').length == 0) {
			console.log(2)
			$('.fix_kuang').hide();
		} else {
			console.log(3)
			$('.tuichutishi').show();
			$('.btn-sure').unbind('click').on('click', function() {
				$('.tuichutishi').hide();
				$('.fix_kuang').hide();
			})
			$('.btn-no,.closeimg').unbind('click').on('click', function() {
				$('.tuichutishi').hide();
			})
		}

	}
	//薪资
	if($(this).parent().parent().get(0).className.indexOf("tk_ops_xinzi") != -1) {
		$('.fix_kuang').hide();
	}
	//经验要求
	if($(this).parent().parent().get(0).className.indexOf("tk_whis") != -1) {
		$('.fix_kuang').hide();
	}
	//学历要求
	if($(this).parent().parent().get(0).className.indexOf("tk_schis") != -1) {
		$('.fix_kuang').hide();
	}
	//工作地点
	if($(this).parent().parent().get(0).className.indexOf("tk_adds") != -1) {
		if($('#wc_city')[0].value == "" && $('#wc_jiedao')[0].value == "") {
			$('.fix_kuang').hide();
		} else {
			$('.tuichutishi').show();
			$('.btn-sure').unbind('click').on('click', function() {
				$('.tuichutishi').hide();
				$('.fix_kuang').hide();
			})
			$('.btn-no,.closeimg').unbind('click').on('click', function() {
				$('.tuichutishi').hide();
			})
		}
	}
	//职位描述
	if($(this).parent().parent().get(0).className.indexOf("ops_miaos") != -1) {
		if($('.miaoshu')[0].value == "") {
			$('.fix_kuang').hide();
		} else {
			$('.tuichutishi').show();
			$('.btn-sure').unbind('click').on('click', function() {
				$('.tuichutishi').hide();
				$('.fix_kuang').hide();
			})
			$('.btn-no,.closeimg').unbind('click').on('click', function() {
				$('.tuichutishi').hide();
			})
		}
	}

	//邮箱
	if($(this).parent().parent().get(0).className.indexOf("ops_emal") != -1) {
		$('.fix_kuang').hide();
	}
})
$('.return').unbind('click').on('click', function() {
	JavaScript: window.history.back(-1);
})

//文本框字数限制输入
function textlength(obj, num) {
	var lenInput = obj.val().length;
	obj.keyup(function() {
		lenInput = $(this).val().length;
		if(lenInput > 0 && lenInput <= num) {
			obj.parent().find('.textareaInput').html(lenInput);
		}
	});
}
textlength($('.ops_nameInput'), 24)
textlength($('.miaoshu'), 5000);

$('button.btn-default', $('.open_sure')).on('click', function() {
	if($('.ops_tatial')[0].innerText != "请选择" &&
		$('.ops_name')[0].innerText != "请填写" &&
		$('.ops_skill')[0].innerText != "请选择" &&
		$('.ops_xinzi')[0].innerText != "请选择" &&
		$('.ops_jingyan')[0].innerText != "请选择" &&
		$('.ops_school')[0].innerText != "请选择" &&
		$('.ops_addres')[0].innerText != "请填写" &&
		$('.ops_ms')[0].innerText != "请填写"
	) {
		alert('公司信息:简称' + $('.com-two')[0].innerText + '所属行业' + $('.com-one')[0].innerText + '融资阶段' + $('.com-three')[0].innerText +
			'发布职位 </br>' + '职位情况' + $('.ops_tatial')[0].innerText + '职位名称' + $('.ops_name')[0].innerText +
			'技能标签' + skill_str + '薪资' + $('.ops_xinzi')[0].innerText +
			'经验要求' + $('.ops_jingyan')[0].innerText + '学历' + $('.ops_school')[0].innerText +
			'工作地址' + $('.ops_addres')[0].innerText + "工作内容" + $('.ms_contan')[0].innerText
		)
	}

})