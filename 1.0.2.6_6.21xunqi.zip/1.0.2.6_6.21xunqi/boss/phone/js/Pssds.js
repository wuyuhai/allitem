$('.ipt-search').unbind('click').on('click', function() {
	event.stopPropagation(); //阻止事件冒泡
	$('.city_sel_lis').css({
		height: document.documentElement.clientHeight - 45 + 'px'
	})
	var tt = $('.city_sel_lis');
	$('#sxtj_ct').hide()
	$('.city_sel_lis').show();
	tt.toggle();
	var tag = tt.toggle();
	var flag;
	$('.city-ds')[0].innerText = $('.label-text')[0].innerText;
	$('.czds').unbind('click').on('click', function() {
		if($('.ipt-search')[0].value == "" && $('.ops_tatial')[0].innerText == "不限") alert('请输入一个公司名或选择一个职位类型');
		if($('.ipt-search')[0].value != "" || $('.ops_tatial')[0].innerText != "不限") {
			alert("关键字为：" + $('.ipt-search')[0].value + "职位类型为" + sjname + "职位ID为" + sjfid + "大神工作地点" +it)
			//发送请求
			//￥。get
			var err_code = 0;
			if(err_code == 0) {				
				$('.show_tj')[0].innerText = $('.ipt-search')[0].value;
				$('.show_tj')[0].innerText += " " + sjname;
				$('.label-text')[0].innerText = it;
				$('.ops_t')[0].innerText = sjname;
				//数据展示，并对数据进行关键词字符段进行颜色处理
				
			} else {
				alert('网络不太好，我的锅')
			}
			$('.city_sel_lis').hide();
		}
	})
	$('.ds_tj').unbind('click').on('click', function() {
		flag = true;
	})
	$('.ds_tj_zz').unbind('click').on('click', function() {
		flag = false;
	})
	$(document).unbind('click').bind("click", function(e) { //点击空白处，设置的弹框消失		
		var target = $(e.target);
		if(flag == false) {
			tag.hide();
			flag = true;
		}
	});
})

var data_op = {
	"err_code": 0,
	"err_msg": "请求成功",
	"page": "-1",
	"data": [{
		"id": 1,
		"name": "技术"
	}, {
		"id": 2,
		"name": "产品"
	}, {
		"id": 3,
		"name": "设计"
	}, {
		"id": 4,
		"name": "运营"
	}, {
		"id": 5,
		"name": "市场"
	}, {
		"id": 6,
		"name": "职能/高级管理"
	}, {
		"id": 7,
		"name": "销售"
	}, {
		"id": 8,
		"name": "传媒"
	}, {
		"id": 9,
		"name": "金融"
	}, {
		"id": 10,
		"name": "汽车"
	}, {
		"id": 11,
		"name": "教育培训"
	}, {
		"id": 12,
		"name": "医疗健康"
	}, {
		"id": 13,
		"name": "采购/贸易"
	}, {
		"id": 14,
		"name": "供应链/物流"
	}, {
		"id": 15,
		"name": "房地产/建筑"
	}, {
		"id": 16,
		"name": "咨询/翻译/法律"
	}, {
		"id": 17,
		"name": "实习生/管培生"
	}, {
		"id": 18,
		"name": "其他"
	}]
}
var data_id_data = {
	"err_code": 0,
	"err_msg": "请求成功",
	"page": "-1",
	"data": [{
		"id": 1,
		"name": "后端开发"
	}, {
		"id": 2,
		"name": "移动开发"
	}, {
		"id": 3,
		"name": "测试"
	}, {
		"id": 4,
		"name": "运维/技术支持"
	}, {
		"id": 5,
		"name": "数据"
	}, {
		"id": 6,
		"name": "项目管理"
	}, {
		"id": 7,
		"name": "硬件开发"
	}, {
		"id": 8,
		"name": "前端开发"
	}, {
		"id": 9,
		"name": "通信"
	}, {
		"id": 10,
		"name": "高端技术职位"
	}, {
		"id": 11,
		"name": "人工智能"
	}, {
		"id": 12,
		"name": "软件销售支持"
	}, {
		"id": 13,
		"name": "其他技术职位"
	}]
}
var data_id_id_data = {
	"err_code": 0,
	"err_msg": "请求成功",
	"page": "-1",
	"data": [{
		"id": 1,
		"name": "Java"
	}, {
		"id": 2,
		"name": "C++"
	}, {
		"id": 3,
		"name": "PHP"
	}, {
		"id": 4,
		"name": "数据挖掘"
	}, {
		"id": 5,
		"name": "C"
	}, {
		"id": 6,
		"name": "C#"
	}, {
		"id": 7,
		"name": ".NET"
	}, {
		"id": 8,
		"name": "Hadoop"
	}, {
		"id": 9,
		"name": "Python"
	}, {
		"id": 10,
		"name": "Delphi"
	}, {
		"id": 11,
		"name": "VB"
	}, {
		"id": 12,
		"name": "Perl"
	}, {
		"id": 13,
		"name": "Ruby"
	}, {
		"id": 14,
		"name": "Node.js"
	}, {
		"id": 15,
		"name": "搜索算法"
	}, {
		"id": 16,
		"name": "Golang"
	}, {
		"id": 17,
		"name": "自然语言处理"
	}, {
		"id": 18,
		"name": "推荐算法"
	}, {
		"id": 19,
		"name": "Erlang"
	}, {
		"id": 20,
		"name": "算法工程师"
	}, {
		"id": 21,
		"name": "语音/视频/图形开发"
	}, {
		"id": 22,
		"name": "数据采集"
	}]
}

function fillData(ob1, ob2) {
	if(ob1.err_code == 0) {
		$.each(ob1.data, function(i, item) {
			ob2.append('<li value="' + item.id + '">' + item.name + '</li>')
		});
	} else {
		alert("请检查网络");
	}
}
var sjname = "";
var sjfid = 0;
$('.ds_tj_one,.ops_t').unbind('click').on('click', function() {
	console.log($(this))
	var lisitem = $(this);
	console.log($(this)[0].className)
	$('.tk_opstatial').show();
	//	fid_id1 = 0;
	$('.w_first').show();
	$('ul.w_first').html('')
	$('.w_second').hide();
	$('.w_third').hide();
	fillData(data_op, $('.w_first'));
	//第一个列表
	var tt = $('.w_second_bg1');
	var a = "";
	var b = "";
	tt.toggle();
	var tag = tt.toggle();
	var flag;
	$('ul.w_first').unbind('click').on('click', 'li', function() {
		$('.w_second_bg1').show();
		$('ul.w_second').html('');
		$('ul.w_third').html('');
		$('ul.w_third').hide();
		$(this).addClass('w_selected').siblings().removeClass('w_selected');
		var item = $(this);
		var fid = item.attr('value');
		//用fid做下一个就扣的请求标记
		//		$.get("www.baidu.com/id=fid");暂记 data_id_data							
		fillData(data_id_data, $('.w_second'));
		$('.w_second_bg1').css({
			height: document.documentElement.clientHeight - 55 + "px"
		})
		$('.w_second_bg2').css({
			height: document.documentElement.clientHeight - 55 + "px"
		})
		$('.w_second_bg').show();
		$('ul.w_second').show();
		flag = true;
	});
	//第二个列表 
	$('ul.w_second').unbind('click').on('click', 'li', function() {
		$('ul.w_third').html('');
		var item = $(this);
		fid_id1 = item.attr('value');
		var fid = item.attr('value');
		$(this).addClass('w_selected').siblings().removeClass('w_selected');
		//继续用 fid 做第三个列表的的请求标记
		//		$.get("www.baidu.com/id=fid");暂记 data_id_id_data
		fillData(data_id_id_data, $('.w_third'));
		$('ul.w_third').show();
		flag = true;
	});
	//第三个列表
	$('ul.w_third').unbind('click').on('click', 'li', function() {
		var cname = $(this).text();
		var item = $(this);
		var fid = item.attr('value');
		sjname = cname;
		sjfid = fid;
		//		op.html("").append('<p value="' + fid + '">' + cname + '</p>');	
		console.log(lisitem[0].className)
		if(lisitem[0].className.indexOf('ops_t') != -1) {
			alert("职位类型为" + cname + "职位ID" + fid);
			console.log(1)
			//发送请求
			//$.get
			var err_code = 0;
			if(err_code == 0) {				
				$('.show_tj')[0].innerText = $('.ipt-search')[0].value;
				$('.show_tj')[0].innerText += " " + sjname;
				$('.ops_tatial')[0].innerText = cname;
				$('.sanjifid')[0].innerText = fid;
				$('.ops_t')[0].innerText = $('.ops_tatial')[0].innerText;				
				//列表框展示对应职位的大神
				
				$('.tk_opstatial').hide();
			}
		} else if(lisitem[0].className.indexOf('ds_tj_one') != -1) {
			$('.ops_tatial')[0].innerText = cname;
			$('.sanjifid')[0].innerText = fid;
			console.log(2)
			$('.tk_opstatial').hide();
		}
		flag = false;
	});
	$('.w_second_bg2').unbind('click').on('click', function() {
		flag = false
	})
	$('.tk_opstatial').unbind('click').bind("click", function(e) { //点击空白处，设置的弹框消失		
		var target = $(e.target);
		if(flag == false) {
			tag.hide();
			flag = true;
		}
	});
})

//返回
$('.reback').unbind('click').on('click', function() {
	//职位
	if($(this).parent().parent().get(0).className.indexOf("tk_opstatial") != -1) {
		$('.fix_kuang').hide();
		$('.w_second_bg1').hide();
	}
	if($(this).parent().parent().get(0).className.indexOf("city_sel_ul") != -1) {
		$('.fix_kuang').hide();
		
		$('.city_two_bg1').hide();
	}
})

//城市三联联动
var it = $('.city-sel')[0].innerText;
$('.city-sel,.ds_tj_six').on('click', function(event) {
	var cityName = $(this);
	event.stopPropagation(); //阻止事件冒泡
	var tt = $('.city_two_bg1');
	$('.city_sel_ul').show()
	tt.hide();
	$('.city_first').html('');
	$.each(city.data, function(i, item) {
		if(item.province_id == 1) {
			$('.city_first').append('<li value="' + item.province_id + '" class="cur">' + item.province_name + '</li>')
		} else {
			$('.city_first').append('<li value="' + item.province_id + '">' + item.province_name + '</li>')
		}
	});
	tt.toggle();
	var tag = tt.toggle();
	var flag = true;
	$('ul.city_first', $('.city_wrap')).unbind('click').on('click', 'li', function() {
		$('.city_two_bg1').css({
			height: document.documentElement.clientHeight - $('.tk_header')[1].clientHeight + 'px'
		})
		$('.city_two_bg2').css({
			height: $('.city_two_bg1').css('height')
		})
		$('.city_two').css({
			height: $('.city_two_bg1').css('height')
		})
		console.log($('.city_two_bg1').css('height'))
		$('.city_two_bg1').show();
		$('.city_two').html('');
		$(this).addClass('cur').siblings().removeClass('cur');
		var item = $(this);
		var fid = item.attr('value');
		var citylis = city.data[fid - 1].cities;
		for(i = 0; i < citylis.length; i++) {
			$('.city_two').append('<li value="' + citylis[i].city_id + '">' + citylis[i].city_name + '</li>')
		}
		flag = true;
	});
	$('ul.city_two', $('.city_two_bg1')).unbind('click').on('click', 'li', function() {
		it = $(this)[0].innerText;
		console.log(it)
		if(cityName[0].className.indexOf('city-sel') != -1) {
			alert("大神期望工作城市名" + it);
			console.log(1)
			//发送请求
			//$.get
			var err_code = 0;
			if(err_code == 0) {								
				$(".city-sel")[0].innerHTML = '<span class="label-text">' + it + '<i class="icon-arrow-down"></i></span>';
				$('.city-ds')[0].innerText = $('.label-text')[0].innerText;		
				$('.city_sel_ul').hide()
				//列表框展示对应职位的大神
				
				$('.tk_opstatial').hide();
			}
		} else if(cityName[0].className.indexOf('ds_tj_six') != -1) {
			$('.city-ds')[0].innerHTML = '<span class="label-text">' + it + '<i class="icon-arrow-down"></i></span>';
			$('.city_sel_ul').hide()
		}
		
	});

	$('.city_two_bg2').unbind('click').on('click', function() {
		console.log(111)
		flag = false
	})
	console.log(flag = false)
	$('.city_sel_ul').unbind('click').bind("click", function(e) { //点击空白处，设置的弹框消失		
		var target = $(e.target);
		if(flag == false) {
			tag.hide();
			flag = true;
		}
	});
})

$('.ops_yaoqiu').on('click', function() {
	if($('.ipt-search')[0].value != "" || $('.ops_tatial')[0].innerText != "不限") {
		console.log(111)
		if($("#sxtj_ct").css("display") == "none") {
			event.stopPropagation(); //阻止事件冒泡
			var tt = $('#sxtj_ct');
			tt.show();
			aclick($('dd.xinzi'));
			jyorjy($('dd.jinyan'));
			jyorjy($('dd.edu'));
			tt.toggle();
			var tag = tt.toggle();
			var flag = true;
			$('.sxtj_ct_bg').unbind('click').on('click', function() {
				flag = false;
				console.log(1111111)
			})
			$('.sx_sure_yes').unbind('click').on('click', function() {
				var xz = ""
				for(var i = 0; i < $('.xinzi').find('.cur').length; i++) {
					if(i == 0) {
						xz += $($('.xinzi').find('.cur')[i])[0].innerText;
					} else {
						xz += "*" + $($('.xinzi').find('.cur')[i])[0].innerText;
					}
				}
				alert('搜索要求：薪资' + xz + '；经验' + $('.jinyan').find('.cur')[0].innerText + '；学历' + $('.edu').find('.cur')[0].innerText);
				//发送请求
				//$.get
				var err_code = 0;
				if(err_code == 0) {
					//返回对应的条件的大神，

					$('#sxtj_ct').hide();
				} else {
					alert("网络有问题");
				}
			})
			$(document).unbind('click').bind("click", function(e) { //点击空白处，设置的弹框消失		
				var target = $(e.target);
				console.log(flag)
				if(flag == false) {
					tag.hide();
					flag = true;
				}
			});
		} else {
			$('#sxtj_ct').hide();
		}
	} else {
		alert('请输入一个公司名或选择一个职位类型');
	}
})

function aclick(obj) {
	obj.unbind('click').on('click', 'a', function() {
		console.log($(this))
		if($(this)[0].innerText == "不限") {
			$(this).addClass('cur');
			$(this).siblings().removeClass('cur');
		} else {
			if($(this)[0].className == 'cur') {
				$(this).removeClass('cur');
				if(obj.find('.cur').length == 0) {
					$(obj.find('a')[0]).addClass('cur');
				}
			} else {
				$(obj.find('a')[0]).removeClass('cur');
				$(this).addClass('cur');
			}
		}
	})
}

function jyorjy(obj) {
	obj.on('click', 'a', function() {
		$(this).addClass('cur');
		$(this).siblings().removeClass('cur');
	})
}

//加载更多
function jiazai() {
	var T = 0;
	$(window).scroll(function() {
		T = $(document).scrollTop();
		if(T >= $('body')[0].scrollHeight - document.documentElement.clientHeight) {
			//		发送请求
			//     ￥。get
			var err_code = 0;
			if(err_code == 0) {
				for(var i = 0; i < 15; i++) {
					var lis = document.createElement('li');
					lis.innerHTML += '<a href="">'+
						'<div class="tjds_lis">'+
							'<div>'+
								'<div class="ds_img">'+
									'<img src="../../assets/images/1-150630062413.jpg" alt="" />'+
								'</div>'+
								'<div class="ds_xx">'+
									'<h6 class="ds_name">吴玉海</h6>'+
									'<p>'+
										'<span>曾任</span><span class="show_op">前端工程师</span><span class="show_op">web前端开发工程师</span>'+
									'</p>'+
									'<p>'+
										'<span>2年</span><span>本科</span><span>7K-12K</span>'+
									'</p>'+
								'</div>'+
							'</div>'+
							'<div style="clear: both;"></div>'+
							'<div>'+
								'<p class="ds_ys">'+
									'1.熟练泡妞36式，</br>'+
									'2.熟读泡妞兵法,前端'+
								'</p>'+
							'</div>'+
						'</div>'+
					'</a>';
					$('.tjds_ul').append(lis);
					console.log(i)
				}
			}
		}
		console.log(T)
	});
	if($('.tjds_ul').find('li').length >= 15) {
		$('.jzmore')[0].innerText = "向下滑动加载更多";
	} else {}
}
jiazai()