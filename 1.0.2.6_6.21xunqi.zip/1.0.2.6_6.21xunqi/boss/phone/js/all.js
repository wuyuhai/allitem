var opsidarr = [];
$('.btnsaoxuan').unbind('click').on('click', function() {
	if($('#saixuankuang').css('display') == "none") {
		$('#saixuankuang').show();
	} else {
		$('#saixuankuang').hide();
	}
	$('.btnshouqi').unbind('click').on('click', function() {
		$('#saixuankuang').hide();
	})
	$('div.ops_lis', $('.common_tj')).on('click', 'span', function() {
		console.log($(this).get(0).getAttribute('value'))
		if($(this).get(0).getAttribute('value') == 0) {
			$(this).addClass('cur');
			$(this).siblings().removeClass('cur');
		} else {
			if($(this)[0].className == 'cur') {
				$(this).removeClass('cur');
				if($('.ops_lis').find('.cur').length == 0) {
					$($('.ops_lis').find('span')[0]).addClass('cur');
				}
			} else {
				$($('.ops_lis').find('span')[0]).removeClass('cur');
				$(this).addClass('cur');
			}
		}
	})
	$('div.ops_xiaoxi', $('.common_tj')).on('click', 'span', function() {
		console.log($(this).get(0).getAttribute('value'))
		$(this).addClass('cur');
		$(this).siblings().removeClass('cur');
	})
	//确定搜索类型
	$('.ops_lis_sure').unbind('click').on('click', function() {
		for(var i = 0; i < $('.ops_lis').find('.cur').length; i++) {
			opsidarr.push($('.ops_lis').find('.cur')[i].getAttribute('value'));
		}
		console.log(opsidarr)
		//获取到需要请求的id值,即value值，发送请求
		//$.get
		var err_code = 0;
		if(err_code == 0) {
			var ids = "";
			for(var i = 0; i < opsidarr.length; i++) {
				ids += opsidarr[i] + ',';
			}
			alert('请求职位的id分别为' + ids + '是否已读（1为已读，2为未读，0为全部）' + $('.ops_xiaoxi').find('.cur')[0].getAttribute('value'));
			$('#saixuankuang').hide();
			opsidarr.length = 0;
		}
	})
})

$('.deliver').unbind('click').on('click', function() {
	$(this).addClass('cur').siblings().removeClass('cur');
	$('#contant_look').hide();
	$('#contant_td').show();
	$('.btnsaoxuan').show();
})

$('.lookedme').unbind('click').on('click', function() {
	$(this).addClass('cur').siblings().removeClass('cur');
	$('#contant_td').hide();
	$('#contant_look').show();
	$('.btnsaoxuan').hide();
})

function jiazai() {
	var T = 0;
	$(window).scroll(function() {
		T = $(document).scrollTop();
		if(T >= $('body')[0].scrollHeight - document.documentElement.clientHeight) {
			if($('#contant_td').css("display") != "none") {
					//		发送请求
					//     ￥。get
					var err_code = 0;
				if(err_code == 0) {
					for(var i = 0; i < 15; i++) {
						var lis = document.createElement('li');
						lis.innerHTML += '<a href="delivertt.html">' +
							'<div class="lis">' +
							'<div class="lis_img">' +
							'<img src="../../assets/images/1-150630062413.jpg" />' +
							'</div>' +
							'<div class="lis_xx">' +
							'<h5>' +
							'<span class="name">吴玉海</span>' +
							'<span class="sex">男</span>' +
							'</h5>' +
							'<p>' +
							'<span>投递职位</span>' +
							'<em>：</em>' +
							'<span class="ops">前端实习</span>' +
							'</p>' +
							'<p class="myyousi">长的帅算不算优势帅算不算优势帅算不算优势帅算不算优势帅算不算优势</p>' +
							'</div>' +
							'<div class="time">2天前</div>' +
							'</div>' +
							'</a>';
						$('.dl_lis').append(lis);
						console.log(i)
					}
				}
			}
			if($('#contant_look').css('display') != "none") {
				console.log(2222);
				//发送请求
				//￥.get
				var err_code2 = 0;
				if(err_code2 == 0) {
					for(var i = 0; i < 15; i++) {
						var lis = document.createElement('li');
						lis.innerHTML += '<a href="delivertt.html">'+
								'<div class="lis">'+
									'<div class="lis_img">'+
										'<img src="../../assets/images/1-150630062413.jpg" />'+
									'</div>'+
									'<div class="lis_xx">'+
										'<h5>'+
											'<span class="name">吴玉海</span>'+
											'<span class="sex">男</span>'+
										'</h5>'+
										'<p>'+
											'<span>曾任</span>'+
											'<span class="company">阿里巴巴</span>'+
											'<span class="ops">前端开发</span>'+
										'</p>'+
										'<p>'+
											'<span>杭州</span>'+
											'<span>1年</span>'+
											'<span>本科</span>'+
										'</p>'+
									'</div>'+
									'<div class="time">2天前</div>'+
									'<div class="work_zhuangtai">'+
										'离职正在寻找工作'+
									'</div>'+
									'<div class="looke_ops">'+
										'<span>看过</span>'+
										'<span class="open_ops">前端实习</span>'+
									'</div>'+
								'</div>'+
							'</a>';
						$('.dlook_lis').append(lis);
						console.log(i)
					}
				}
			}
		}
		console.log(T)
	});
	if($('.dl_lis').find('li').length >= 15) {
		$('.jzm1')[0].innerText = "向下滑动加载更多";
	}else{}
	if($('.dlook_lis').find('li').length >= 15) {
		$('.jzm2')[0].innerText = "向下滑动加载更多";
	}
}
jiazai()