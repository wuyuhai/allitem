$('body').css({
	height: window.screen.availHeight
})
//对话框滑动条始终据下
function xx() {
	$('.chat_ul')[0].scrollTop = $('.chat_ul')[0].scrollHeight - $('.chat_ul').css('height').substring(0, $('.chat_ul').css('height').length - 2);
}
xx()

//评论输入框换行
var autoTextarea = function(elem, extra, maxHeight) {
	extra = extra || 0;
	var isFirefox = !!document.getBoxObjectFor || 'mozInnerScreenX' in window,
		isOpera = !!window.opera && !!window.opera.toString().indexOf('Opera'),
		addEvent = function(type, callback) {
			elem.addEventListener ?
				elem.addEventListener(type, callback, false) :
				elem.attachEvent('on' + type, callback);
		},
		getStyle = elem.currentStyle ? function(name) {
			var val = elem.currentStyle[name];

			if(name === 'height' && val.search(/px/i) !== 1) {
				var rect = elem.getBoundingClientRect();
				return rect.bottom - rect.top -
					parseFloat(getStyle('paddingTop')) -
					parseFloat(getStyle('paddingBottom')) + 'px';
			};

			return val;
		} : function(name) {
			return getComputedStyle(elem, null)[name];
		},
		minHeight = parseFloat(getStyle('height'));

	elem.style.resize = 'none';

	var change = function() {
		var scrollTop, height,
			padding = 0,
			style = elem.style;

		if(elem._length === elem.value.length) return;
		elem._length = elem.value.length;

		if(!isFirefox && !isOpera) {
			padding = parseInt(getStyle('paddingTop')) + parseInt(getStyle('paddingBottom'));
		};
		scrollTop = document.body.scrollTop || document.documentElement.scrollTop;

		elem.style.height = minHeight + 'px';
		if(elem.scrollHeight > minHeight) {
			if(maxHeight && elem.scrollHeight > maxHeight) {
				height = maxHeight - padding;
				style.overflowY = 'auto';
			} else {
				height = elem.scrollHeight - padding;
				style.overflowY = 'hidden';
			};
			style.height = height + extra + 'px';
			scrollTop += parseInt(style.height) - elem.currHeight;
			document.body.scrollTop = scrollTop;
			document.documentElement.scrollTop = scrollTop;
			elem.currHeight = parseInt(style.height);

			//			1.0.2.1
			if($('#saytext').val() != "") {
				$('.chat_fs').css({
					background: "#1e8ae8",
				})
			} else {
				$('.chat_fs').css({
					background: "#DCDCDC",
				})
			}
		};
	};

	addEvent('propertychange', change);
	addEvent('input', change);
	addEvent('focus', change);
	change();
};
var text = document.getElementById("saytext");
autoTextarea(text); // 调用

//消息
function pinglun(ob) {
	$('.chat_fs').unbind('click').on('click', function() {
		//	$('button.sub_btn', $('#fasong_sure')).unbind('click').on('click', function() {
		//1.0.2.1s
		if($('#saytext').val() != ""){
			console.log(1)
			var divhtml
			divhtml = '<div class="time">下午 4：03</div>' +
				'<a href="" class="headimg"><img src="images/3.png" /></a>' +
				'<p class="chat_ct">' + $("#saytext").val() + '</p>';
			var lis = document.createElement('li');
			lis.innerHTML = divhtml;
			lis.setAttribute('value', '1');
			lis.className = 'myself';
			//发送请求
			//	$.get
			var errcoed = 0;
			if(errcoed == 0) {
				ob.get(0).appendChild(lis);
				//			var st = $(ob).find('.pl_ctt')[0]
				//			console.log(st)
				console.log($(ob).find('li').length)
				var i = $(ob).find('li').length - 1;
				var str = $(ob).find('.chat_ct')[i].innerHTML;
				$(ob).find('.chat_ct')[i].innerHTML = replace_em(str);
				$("#saytext")[0].value = "";
				$('.qqFace').hide();
				xx();
				//1.0.2.1
				$('#saytext').css({
					height: 24 + 'px',
				})
				$('.chat_fs').css({
					background: "#DCDCDC",
				})
				
			}
		}
	})
}
pinglun($('.chat_ul'));

//表情转换
function replace_em(str) {
	str = str.replace(/\</g, '&lt;');
	str = str.replace(/\>/g, '&gt;');
	str = str.replace(/\n/g, '<br/>');
	str = str.replace(/\[em_([0-9]*)\]/g, '<img src="face/$1.gif" border="0" />');
	return str;
}
$('#contant').click(function(e) {
	$('.qqFace').hide();
})
$('#saytext').on('click',function(){
	$('.qqFace').hide();
})




$('.more').unbind('click').on('click', function() {
	//发送请求
	//￥。get
	var errcode = 0;
	if(errcode == 0) {
		$('.more').hide();
		//请求成功
		//是否有聊天记录消息if有加载，没有提示  1代表有；
		var hadchat = 1;
		if(hadchat == 1) {
			var divhtml = '<li class="friend">' +
				'<div class="time">下午 4：03</div>' +
				'<a href="" class="headimg"><img src="images/4.png" /></a>' +
				'<p class="chat_ct">我已经很丑了，但是你比我还吓人</p>' +
				'</li>' +
				'<li class="myself">' +
				'<div class="time">下午 4：03</div>' +
				'<a href="" class="headimg"><img src="images/3.png" /></a>' +
				'<p class="chat_ct">我严重怀疑你是个智障</p>' +
				'</li>' +
				'<li class="friend">' +
				'<div class="time">下午 4：03</div>' +
				'<a href="" class="headimg"><img src="images/4.png" /></a>' +
				'<p class="chat_ct">我已经很丑了，但是你比我还吓人</p>' +
				'</li>' +
				'<li class="myself">' +
				'<div class="time">下午 4：03</div>' +
				'<a href="" class="headimg"><img src="images/3.png" /></a>' +
				'<p class="chat_ct">我严重怀疑你是个智障</p>' +
				'</li>' +
				'<li class="friend">' +
				'<div class="time">下午 4：03</div>' +
				'<a href="" class="headimg"><img src="images/4.png" /></a>' +
				'<p class="chat_ct">我操你大姨</p>' +
				'</li>';
			$('.chat_ul').prepend(divhtml);
		} else {
			//没有记录
			alert('没有更多消息了')
		}

		//向上滑动加载更多
		var T;
		$('.chat_ul').scroll(function() {
			T = $('.chat_ul').scrollTop();
			if(T <= 5) {
				console.log(1)
				//		发送请求
				//     ￥。get
				var err_code = 0;
				if(err_code == 0) {
					if(hadchat == 1) {
						//			for(var i = 0; i < 15; i++) {
						var divhtml = '<li class="friend">' +
							'<div class="time">下午 4：03</div>' +
							'<a href="" class="headimg"><img src="images/4.png" /></a>' +
							'<p class="chat_ct">我已经很丑了，但是你比我还吓人</p>' +
							'</li>' +
							'<li class="myself">' +
							'<div class="time">下午 4：03</div>' +
							'<a href="" class="headimg"><img src="images/3.png" /></a>' +
							'<p class="chat_ct">我严重怀疑你是个智障</p>' +
							'</li>' +
							'<li class="friend">' +
							'<div class="time">下午 4：03</div>' +
							'<a href="" class="headimg"><img src="images/4.png" /></a>' +
							'<p class="chat_ct">我已经很丑了，但是你比我还吓人</p>' +
							'</li>' +
							'<li class="myself">' +
							'<div class="time">下午 4：03</div>' +
							'<a href="" class="headimg"><img src="images/3.png" /></a>' +
							'<p class="chat_ct">我严重怀疑你是个智障</p>' +
							'</li>' +
							'<li class="friend">' +
							'<div class="time">下午 4：03</div>' +
							'<a href="" class="headimg"><img src="images/4.png" /></a>' +
							'<p class="chat_ct">我操你大姨</p>' +
							'</li>';
						$('.chat_ul').prepend(divhtml);
					} else {
						//没有记录
						alert('没有更多消息了')
					}
					//			}
				}
			}
			console.log(T)
		});
	}
});