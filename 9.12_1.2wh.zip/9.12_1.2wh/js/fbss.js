$('#contant').unbind('click').on('click', 'div', function() {
	if($(this)[0].className == "ss_ctt") {
		$('#pl_kuang').show();
		$('#facebox').hide();
	} else {
		$('#pl_kuang').hide();
	}
})

//发布
$('.fbss_sure').unbind('click').on('click', function() {
	var str = utf16toEntities($('#saytext')[0].value);
	alert(str)
	if($('#saytext')[0].value != "" || $('#tupianji').find('input').length != 1) {
		alert('说说字段' + str)
		//发送求情
		//	$.get
		var errcode = 0;
		if(errcode == 0) {
			alert('发布说说成功');
			$('#saytext')[0].value = "";
			//			1.0.2.1
			$('.img-list').html("");
		}
	} else {
		$('.tishi').fadeIn();
		var t = setInterval(function() {
			$('.tishi').fadeOut();
			clearInterval(t);
		}, 1500)
	}
})
var startDate = null;

//语音
$('.yuyin').unbind('click').on('click', function() {
	//语音监测，获取语音内容，放开，传语音数据
	//发送请求
	//￥。get
	var errcode = 0;
	if(errcode == 0) {
		alert('语音功能')
	}
})

//
var filechooser = document.getElementById("choose");
//    用于压缩图片的canvas
var canvas = document.createElement("canvas");
var ctx = canvas.getContext('2d');
//    瓦片canvas
var tCanvas = document.createElement("canvas");
var tctx = tCanvas.getContext("2d");
var maxsize = 100 * 1024;
$("#upload").on("click", function() {
		filechooser.click();
		if($('.img-list').find('li').length >= 9) {
			alert("最多同时只可上传9张图片");
			return;
		}
	})
	.on("touchstart", function() {
		$(this).addClass("touch")
	})
	.on("touchend", function() {
		$(this).removeClass("touch")
	});

function selectFileImage(file) {
	startDate = new Date().getTime();
	if(!file.files.length) return;
	var files = Array.prototype.slice.call(file.files);
	var Orientation = null;
	if(files.length + $('.img-list').find('li').length > 9) {
		alert("最多同时只可上传9张图片");
		return;
	};

	files.forEach(function(file, i) {
		if(!/\/(?:jpeg|png|gif)/i.test(file.type)) return;

		EXIF.getData(file, function() {
			// alert(EXIF.pretty(this));  
			EXIF.getAllTags(this);
			//alert(EXIF.getTag(this, 'Orientation'));   
			Orientation = EXIF.getTag(this, 'Orientation');
			//return;  
		});
		var reader = new FileReader();
		//获取图片的角度属性

		var li = document.createElement("li");
		//          获取图片大小
		console.log(file.size)
		//		var size = file.size / 1024 > 1024 ? (~~(10 * file.size / 1024 / 1024)) / 10 + "MB" : ~~(file.size / 1024) + "KB";
		li.innerHTML = '<div class="progress"><span></span></div><span class="shanchu"></span>';
		//		alert("步骤1" + "添加li")
		$(".img-list").append($(li));
		reader.onload = function(e) {
			var result = this.result;
			var img = new Image();
			img.src = result;
			img.addEventListener('load', function() {
				console.log(1)
				var expectWidth = this.naturalWidth;
				var expectHeight = this.naturalHeight;

				if(this.naturalWidth > this.naturalHeight && this.naturalWidth > 800) {
					expectWidth = 800;
					expectHeight = expectWidth * this.naturalHeight / this.naturalWidth;
				} else if(this.naturalHeight > this.naturalWidth && this.naturalHeight > 1200) {
					expectHeight = 1200;
					expectWidth = expectHeight * this.naturalWidth / this.naturalHeight;
				}
				var canvas = document.createElement("canvas");
				var ctx = canvas.getContext("2d");
				canvas.width = expectWidth;
				canvas.height = expectHeight;
				ctx.drawImage(this, 0, 0, expectWidth, expectHeight);
				var base64 = null;
				//修复ios 
				if(navigator.userAgent.match(/iphone/i)) {
					console.log('iphone');
					console.log(Orientation)
					//alert(expectWidth + ',' + expectHeight); 
					//如果方向角不为1，都需要进行旋转 added by lzk 
					if(Orientation != "" && Orientation != 1 && Orientation != undefined) {
//						alert('旋转处理');
						switch(Orientation) {
							case 6: //需要顺时针（向左）90度旋转 
//								alert('需要顺时针（向左）90度旋转');
								rotateImg(this, 'left', canvas);
								break;
							case 8: //需要逆时针（向右）90度旋转 
//								alert('需要顺时针（向右）90度旋转');
								rotateImg(this, 'right', canvas);
								break;
							case 3: //需要180度旋转 
//								alert('需要180度旋转');
								rotateImg(this, 'right', canvas); //转两次 
								rotateImg(this, 'right', canvas);
								break;
						}
					}

					base64 = canvas.toDataURL("image/jpeg", 1);
				} else if(navigator.userAgent.match(/Android/i)) { // 修复android 
					var encoder = new JPEGEncoder();
					base64 = encoder.encode(ctx.getImageData(0, 0, expectWidth, expectHeight), 100);
				} else {
					//alert(Orientation); 
					if(Orientation != "" && Orientation != 1) {
						//alert('旋转处理'); 
						switch(Orientation) {
							case 6: //需要顺时针（向左）90度旋转 
//								alert('需要顺时针（向左）90度旋转');
								rotateImg(this, 'left', canvas);
								break;
							case 8: //需要逆时针（向右）90度旋转 
//								alert('需要顺时针（向右）90度旋转');
								rotateImg(this, 'right', canvas);
								break;
							case 3: //需要180度旋转 
//								alert('需要180度旋转');
								rotateImg(this, 'right', canvas); //转两次 
								rotateImg(this, 'right', canvas);
								break;
						}
					}
					base64 = canvas.toDataURL("image/jpeg", 1);
				}
				//uploadImage(base64); 
				var image = new Image()
				var $image = $(image)
				$image.attr("src", base64);
				$(li).append(image);
			}, false);
			//如果图片大小小于100kb，则直接上传
			if(result.length <= maxsize) {
				img = null;
				upload(result, file.type, $(li));
				return;
			}
			//      图片加载完毕之后进行压缩，然后上传 complete(图片加载完以后属性才为 真)
			if(img.complete) { //如果图片已经存在于浏览器缓存，直接调用回调函数     
				//				alert("步骤2" + "分支1")
				callback();
			} else {
				img.onload = callback;
			}

			function callback() {
				console.log(5)
				//				alert("步骤2" + "分支2")
				var data = compress(img,file);
				upload(data, file.type, $(li));
				img = null;
			}
		};
		reader.readAsDataURL(file);
	})

};
//    使用canvas对大图片进行压缩
function compress(img,file) {
	console.log(6)
	var Orientation = null;
	var ndata = null;
	EXIF.getData(file, function() {
			// alert(EXIF.pretty(this));  
			EXIF.getAllTags(this);
			//alert(EXIF.getTag(this, 'Orientation'));   
			Orientation = EXIF.getTag(this, 'Orientation');
			//return;  
		});
	//	alert("步骤3" + "压缩开始")
	var initSize = img.src.length;
	var width = img.width;
	var height = img.height;
	//如果图片大于四百万像素，计算压缩比并将大小压至400万以下
	var ratio;
	if((ratio = width * height / 4000000) > 1) {
		//		alert("步骤3" + "压缩画布1")
		ratio = Math.sqrt(ratio); //返回数字的平方根
		width /= ratio;
		height /= ratio;
	} else {
		ratio = 1;
	}
	canvas.width = width;
	canvas.height = height;
	//        铺底色
	ctx.fillStyle = "#fff";
	ctx.fillRect(0, 0, canvas.width, canvas.height);
	//如果图片像素大于100万则使用瓦片绘制
	if((count = width * height / 1000000) > 1) {
		//		alert("步骤3" + "压缩画布2")
		count = ~~(Math.sqrt(count) + 1); //计算要分成多少块瓦片  ~~按位数取反运算部分，作用取整数
		//            计算每块瓦片的宽和高
		var nw = ~~(width / count);
		var nh = ~~(height / count);
		tCanvas.width = nw;
		tCanvas.height = nh;
		for(var i = 0; i < count; i++) {
			for(var j = 0; j < count; j++) {
				//图片进行裁剪并添加到画布里面 drawImage（9个参数）
				// drawImage（img,4个裁剪的位置，4个放置的位置）
				tctx.drawImage(img, i * nw * ratio, j * nh * ratio, nw * ratio, nh * ratio, 0, 0, nw, nh);
				ctx.drawImage(tCanvas, i * nw, j * nh, nw, nh);
			}
		}
	} else {
		//		alert("步骤3" + "压缩画布3")
		ctx.drawImage(img, 0, 0, width, height);
	}
	var ndata = canvas.toDataURL('image/jpeg', 0.7);
	if(navigator.userAgent.match(/iphone/i)) {
		console.log(Orientation);
		//alert(expectWidth + ',' + expectHeight); 
		//如果方向角不为1，都需要进行旋转 added by lzk 
		if(Orientation != "" && Orientation != 1 && Orientation != undefined) {
//			alert('旋转处理');
			switch(Orientation) {
				case 6: //需要顺时针（向左）90度旋转 
//					alert('需要顺时针（向左）90度旋转');
					rotateImg(img, 'left', canvas);
					break;
				case 8: //需要逆时针（向右）90度旋转 
//					alert('需要顺时针（向右）90度旋转');
					rotateImg(img, 'right', canvas);
					break;
				case 3: //需要180度旋转 
//					alert('需要180度旋转');
					rotateImg(img, 'right', canvas); //转两次 
					rotateImg(img, 'right', canvas);
					break;
			}
		}
		ndata = canvas.toDataURL('image/jpeg', 0.2);
	} else if(navigator.userAgent.match(/Android/i)) { // 修复android 
		var encoder = new JPEGEncoder();
	} else {
		//alert(Orientation); 
		if(Orientation != "" && Orientation != 1) {
			//alert('旋转处理'); 
			switch(Orientation) {
				case 6: //需要顺时针（向左）90度旋转 
//					alert('需要顺时针（向左）90度旋转');
					rotateImg(img, 'left', canvas);
					break;
				case 8: //需要逆时针（向右）90度旋转 
//					alert('需要顺时针（向右）90度旋转');
					rotateImg(img, 'right', canvas);
					break;
				case 3: //需要180度旋转 
//					alert('需要180度旋转');
					rotateImg(img, 'right', canvas); //转两次 
					rotateImg(img, 'right', canvas);
					break;
			}
		}
		ndata = canvas.toDataURL('image/jpeg', 0.2);
	}

	//进行最小压缩
	//https://developer.mozilla.org/zh-CN/docs/Web/API/HTMLCanvasElement/toDataURL
	//	alert("步骤3" + "压缩图片")
	
		$('#tupianji22').append('<p>' + initSize + '</p>'+'<p>' + ndata.length + '</p>'
		                         +'<img src="'+ndata +'">')
	console.log('压缩前：' + initSize);
		alert("步骤3" + "压缩后" + ndata.length);
	console.log('压缩后：' + ndata.length);
	//	alert("步骤3" + "压缩率" + ~~(100 * (initSize - ndata.length) / initSize) + "%");
	console.log('压缩率：' + ~~(100 * (initSize - ndata.length) / initSize) + "%");
	tCanvas.width = tCanvas.height = canvas.width = canvas.height = 0;
	return ndata;
}
//    图片上传，将base64的图片转成二进制对象，塞进formdata上传
function upload(basestr, type, $li) {
	//	alert("步骤" + "上传后台开始");
	//函数用来解码一个已经被base-64编码过的数据  https://developer.mozilla.org/zh-CN/docs/Web/API/WindowBase64/atob
	//window.btoa() 方法来编码一个可能在传输过程中出现问题的数据
	var text = window.atob(basestr.split(",")[1]);
	//8 位无符号整数值的类型化数组。内容将初始化为 0。如果无法分配请求数目的字节，则将引发异常。  https://msdn.microsoft.com/library/br212477(v=vs.94).aspx
	var buffer = new Uint8Array(text.length);
	console.log("buffer"+buffer.length);
	var pecent = 0,
		loop = null;
	for(var i = 0; i < text.length; i++) {
		//charCodeAt() 方法可返回指定位置的字符的 Unicode 编码。这个返回值是 0 - 65535 之间的整数
		buffer[i] = text.charCodeAt(i);
	}
	var blob = getBlob([buffer], type);
	//异步请求
	var xhr = new XMLHttpRequest();
	//获取formdata
	var formdata = getFormData();
	formdata.append('imagefile', blob);
	//	alert("加载毫秒数"+(new Date().getTime() -startDate) )
	return false;
	//	alert("步骤" + "上传后台地址");
	xhr.open('post', 'http://www.wenhewo.com/uploadLogo');
	//	alert("步骤" + "上传后台地址后");
	//请求后的函数
	xhr.onreadystatechange = function() {
		//请求状态
		if(xhr.readyState == 4 && xhr.status == 200) {
			//JSON.parse() 方法解析一个JSON字符串，构造由字符串描述的JavaScript值或对象。可以提供可选的reviver函数以在返回之前对所得到的对象执行变换。
			var jsonData = JSON.parse(xhr.responseText);
			var imagedata = jsonData[0] || {};
			var text = imagedata.path ? '上传成功' : '上传失败';
			console.log(text + '：' + imagedata.path);
			clearInterval(loop);
			//当收到该消息时上传完毕
			$li.find(".progress span").animate({
				'width': "100%"
			}, pecent < 95 ? 200 : 0, function() {
				$(this).html(text);
			});
			if(!imagedata.path) return;
		}
	};
	//数据发送进度，前50%展示该进度
	xhr.upload.addEventListener('progress', function(e) {
		if(loop) return;
		pecent = ~~(100 * e.loaded / e.total) / 2;
		$li.find(".progress span").css('width', pecent + "%");
		if(pecent == 50) {
			mockProgress();
		}
	}, false);
	//数据后50%用模拟进度
	function mockProgress() {
		if(loop) return;
		loop = setInterval(function() {
			pecent++;
			$li.find(".progress span").css('width', pecent + "%");
			if(pecent == 99) {
				clearInterval(loop);
			}
		}, 100)
	}
	xhr.send(formdata);
}
/**
 * 获取blob对象的兼容性写法
 * @param buffer
 * @param format
 * @returns {*}
 */
function getBlob(buffer, format) {
	try {
		return new Blob(buffer, {
			type: format
		});
	} catch(e) {
		var bb = new(window.BlobBuilder || window.WebKitBlobBuilder || window.MSBlobBuilder);
		buffer.forEach(function(buf) {
			bb.append(buf);
		});
		return bb.getBlob(format);
	}
}
/**
 * 获取formdata
 */
function getFormData() {
	var isNeedShim = ~navigator.userAgent.indexOf('Android') &&
		~navigator.vendor.indexOf('Google') &&
		!~navigator.userAgent.indexOf('Chrome') &&
		navigator.userAgent.match(/AppleWebKit\/(\d+)/).pop() <= 534;
	return isNeedShim ? new FormDataShim() : new FormData()
}
/**
 * formdata 补丁, 给不支持formdata上传blob的android机打补丁
 * @constructor
 */
function FormDataShim() {
	console.warn('using formdata shim');
	var o = this,
		parts = [],
		boundary = Array(21).join('-') + (+new Date() * (1e16 * Math.random())).toString(36),
		oldSend = XMLHttpRequest.prototype.send;
	this.append = function(name, value, filename) {
		parts.push('--' + boundary + '\r\nContent-Disposition: form-data; name="' + name + '"');
		if(value instanceof Blob) {
			parts.push('; filename="' + (filename || 'blob') + '"\r\nContent-Type: ' + value.type + '\r\n\r\n');
			parts.push(value);
		} else {
			parts.push('\r\n\r\n' + value);
		}
		parts.push('\r\n');
	};
	// Override XHR send()
	XMLHttpRequest.prototype.send = function(val) {
		var fr,
			data,
			oXHR = this;
		if(val === o) {
			// Append the final boundary string
			parts.push('--' + boundary + '--\r\n');
			// Create the blob
			data = getBlob(parts);
			// Set up and read the blob into an array to be sent
			fr = new FileReader();
			fr.onload = function() {
				oldSend.call(oXHR, fr.result);
			};
			fr.onerror = function(err) {
				throw err;
			};
			fr.readAsArrayBuffer(data);
			// Set the multipart content type and boudary
			this.setRequestHeader('Content-Type', 'multipart/form-data; boundary=' + boundary);
			XMLHttpRequest.prototype.send = oldSend;
		} else {
			oldSend.call(this, val);
		}
	};
}

//对图片旋转处理 added by lzk  
function rotateImg(img, direction, canvas) {
	//alert(img);  
	//最小与最大旋转方向，图片旋转4次后回到原方向    
	var min_step = 0;
	var max_step = 3;
	//var img = document.getElementById(pid);    
	if(img == null) return;
	//img的高度和宽度不能在img元素隐藏后获取，否则会出错    
	var height = img.height;
	var width = img.width;
	//var step = img.getAttribute('step');    
	var step = 2;
	if(step == null) {
		step = min_step;
	}
	if(direction == 'right') {
		step++;
		//旋转到原位置，即超过最大值    
		step > max_step && (step = min_step);
	} else {
		step--;
		step < min_step && (step = max_step);
	}

	//旋转角度以弧度值为参数    
	var degree = step * 90 * Math.PI / 180;
	var ctx = canvas.getContext('2d');
	switch(step) {
		case 0:
			canvas.width = width;
			canvas.height = height;
			ctx.drawImage(img, 0, 0);
			break;
		case 1:
			canvas.width = height;
			canvas.height = width;
			ctx.rotate(degree);
			ctx.drawImage(img, 0, -height);
			break;
		case 2:
			canvas.width = width;
			canvas.height = height;
			ctx.rotate(degree);
			ctx.drawImage(img, -width, -height);
			break;
		case 3:
			canvas.width = height;
			canvas.height = width;
			ctx.rotate(degree);
			ctx.drawImage(img, -width, 0);
			break;
	}
}