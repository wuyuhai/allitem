//对应首字母下没有好友隐藏
for(var i = 0; i < $('.friends_dl').length; i++) {
	if($($('.friends_dl')[i]).find('a').length == 0) {
		$($('.friends_dl')[i]).hide()
	}
}
//定位导航高度
$('.f_nav').css({
	height: document.documentElement.clientHeight - 90 + "px"
})

//导航每一栏的高度
$('li', $('.f_nav_ul')).css({
	height: (document.documentElement.clientHeight - 90) / 30 + "px"
})
console.log($('li', $('.f_nav_ul')).css('height'));

//导航定位
var nav = (function(navObj) {
	navObj.init = function() {
		this.n = 0;
		this.offsetTop = [];
		this.scrolltype = true;
		for(var i = 0; i < $('.friends_dl').length; i++) {
			this.offsetTop.push($('.friends_dl').eq(i).offset().top);
		};
		navObj.bindE();
	};
	navObj.bindE = function() { //滚动条滚动改变导航元素效果
		var self = this; //这里的this等同于上面的this
		var ws = $(window).scrollTop();
		console.log(ws)
		$(window).bind('load scroll', function() {
			console.log(1)
			var stval = $(this).scrollTop();
			if(stval > 45) { //判断滚动条滚动距离大于或小于header高度时，让导航效果对应在第一个上
				if(stval < self.offsetTop[0]) {
					self.n = 0;
				} else {
					for(var j = 0; j < self.offsetTop.length; j++) {
						if(stval > (self.offsetTop[j] + 45) && stval < self.offsetTop[j + 1]) {
							self.n = j + 1;
							break;
						} //这里的45是常量
					};
				};
			}

		});
		$('.f_nav_ul li').delegate('a', 'click', function(e) { //   点击导航定位页面内容			
			self.n = $(this).index('.f_nav_ul li a');
			self.scrolltype = false;
			//1.0.2.1
			var t = self.offsetTop[self.n] - 50;
			if(t != ws-50) {
				$('html,body').animate({
					scrollTop: t
				}, 500, function() { //   滚动条滚动 页面不同内容的offsetTop值实现按钮对应效果
					self.scrolltype = true;
				});
			}
			$('.numkuang').fadeIn();
			$('.numkuang')[0].innerText = $(this)[0].innerText;
			// 阻止默认浏览器动作
			if(e && e.preventDefault) {
				e.preventDefault();
			} else {
				// IE中阻止函数器默认动作的方式		
				window.event.returnValue = false;
			}
			delay_till_last($(this), function() { //注意 id 是唯一的
				//响应事件
				var t2 = setInterval(function() {
					$('.numkuang').fadeOut();
					clearInterval(t2);
				}, 500)
			}, 300);
			
		});
	};
	return navObj;
})(window.navObj || {});
nav.init();

var _timer = {};

function delay_till_last(id, fn, wait) {
	if(_timer[id]) {
		window.clearTimeout(_timer[id]);
		delete _timer[id];
	}
	return _timer[id] = window.setTimeout(function() {
		fn();
		delete _timer[id];
	}, wait);
}