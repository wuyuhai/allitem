//判断是否已经是好友 
var isfriends = 0; //是为1，不是为0

if(isfriends == 1) {
	$('.nf_send').show();
}
if(isfriends == 0) {
	$('.nf_add').show();

}
$('.nf_add').unbind('click').on('click', function() {
	$('.newf_addkuang').show();
	$('.newf_zz,.newf_no').unbind('click').on('click', function() {
		$('.newf_addkuang').hide();
	})
	$('.newf_yes').unbind('click').on('click', function() {
		alert("请求的备注 " + $('#ndwf_input').val())
		//发送好友请求
		//	$.get
		var errcode = 0;
		if(errcode == 0) {
			//已发送好友请求
			alert('等待对方接受')
			$('.newf_addkuang').hide();
			$('#ndwf_input').val('');
		}
	})
})

//1.0.2.1文本框字数限制输入
function textlength(obj1, num) {
	var lenInput = obj1.val().length;
	obj1.keyup(function() {
		lenInput = $(this).val().length;
		if(lenInput > 0 && lenInput <= num) {
			obj1.next().find('.textareaInput').html(lenInput);
		}
	});
}
textlength($('#ndwf_input'), 14)

//更多设置
$('.more_gn').unbind('click').on('click', function() {
	console.log(11)
	$('#sz_kuang').show()

})

//功能块
//黑名单
$('.add_hmd').unbind('click').on('click', function() {
	//发送求请
	//	$.get
	var errcode = 0;
	if(errcode == 0) {
		alert('已经加入黑名单')
	}
})
//限制
$('.ss_nolimit').unbind('click').on('click', function() {
	//发送求请
	//	$.get
	var errcode = 0;
	if(errcode == 0) {
		alert('对方已经可以查看你的所有说说')
	}
})
//删除好友
$('.removefriend').unbind('click').on('click', function() {
	$('#sz_kuang').hide();
	$('.scfriends').show();
	$('.scfriends_zz').unbind('click').on('click', function() {
		$('.scfriends').hide();
	})
	$('.scf_no').unbind('click').on('click', function() {
		$('.scfriends').hide();
	})
	$('.scf_yes').unbind('click').on('click', function() {
		//发送请求
		//		$.get
		var errcode = 0;
		if(errcode == 0) {
			alert('删除好友成功');
			$('.scfriends').hide();
		}
	})

	//	//发送求请
	////	$.get
	//	var errcode = 0;
	//	if(errcode == 0){
	//		alert('删除好友成功')
	//	}	
})
$('.bckuang').unbind('click').on(('click'), function() {
	$('#sz_kuang').hide()
})

$('.xg_bz').unbind('click').on('click', function() {
	$('.xgbzkuang').show();
	var bznamedate = "翠花";
	$('#beizhuname')[0].value = bznamedate;
	$('#beizhuname').focus();
	$('.bz_reback').unbind('click').on('click', function() {
		$('.xgbzkuang').hide();
		$('#sz_kuang').hide();
	})
	$('.wancheng').unbind('click').on('click', function() {
		if($('#beizhuname')[0].value == "") {
			$('.bz_tishi').fadeIn();
			var t = setInterval(function() {
				$('.bz_tishi').fadeOut();
				clearInterval(t);
			}, 1500)
		}
		if($('#beizhuname')[0].value == bznamedate) {
			$('.xgbzkuang').hide();
			$('#sz_kuang').hide();
		}
		if($('#beizhuname')[0].value != bznamedate && $('#beizhuname')[0].value != "") {
			alert("备注名" + $('#beizhuname')[0].value);
			//发送请求
			//$.get
			var errcode = 0;
			if(errcode == 0) {
				//修改备注名成功
				console.log('修改备注名成功');
				$('.xgbzkuang').hide();
				$('#sz_kuang').hide();
			}
		}
	})
})