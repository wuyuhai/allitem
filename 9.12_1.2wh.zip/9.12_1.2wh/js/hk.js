//距离
//设置一个长按的计时器，如果点击这个图层超过0.2秒则触发移动事件
var timeout = undefined;
var x = 0;
var state = 0;
var lastTime = null;
var nowTime = null;
var w = $('.julitiao')[0].clientWidth;
console.log(w)
var s;

//隐藏距离框
$('.juli').unbind('click').on('click', function() {
	if($('.wrapper').css('display') == "none") {
		$('.wrapper').css("display", "block");
		$(this)[0].innerHTML = '<img src="images/1a.png" />';
		//进来获取初始的距离值
				var date0 = 1,
					date1 = 21;
				var mindate = date1 <= date0 ? date1 : date0;
				var maxdate = date1 >= date0 ? date1 : date0;
				if(maxdate >= 0 && maxdate < 10) {
					$('.left_hk').css({
						left: (((mindate * w) / 10) - 14) + 'px'
					})
					$('.right_hk').css({
						left: (((maxdate * w) / 10) - 14) + 'px'
					})
					yidong(julinum, 10)
				} else if(maxdate >= 10 && maxdate < 20) {
					$('.left_hk').css({
						left: (((mindate * w) / 20) - 14) + 'px'
					})
					$('.right_hk').css({
						left: (((maxdate * w) / 20) - 14) + 'px'
					})
					yidong(julinum, 20)
				} else if(maxdate >= 20 && maxdate < 40) {
					$('.left_hk').css({
						left: (((mindate * w) / 40) - 14) + 'px'
					})
					$('.right_hk').css({
						left: (((maxdate * w) / 40) - 14) + 'px'
					})
					yidong(julinum, 40)
				} else if(maxdate >= 40 && maxdate < 80) {
					$('.left_hk').css({
						left: (((mindate * w) / 80) - 14) + 'px'
					})
					$('.right_hk').css({
						left: (((maxdate * w) / 80) - 14) + 'px'
					})
					yidong(julinum, 80)
				} else if(maxdate >= 80 && maxdate < 160) {
					$('.left_hk').css({
						left: (((mindate * w) / 160) - 14) + 'px'
					})
					$('.right_hk').css({
						left: (((maxdate * w) / 160) - 14) + 'px'
					})
					yidong(julinum, 160)
				}
				$('.kuangdu').css({
					width: (parseInt($('.right_hk').css("left").substring(0, $('.right_hk').css("left").length - 2)) - parseInt($('.left_hk').css("left").substring(0, $('.left_hk').css("left").length - 2))) + 'px',
					left: (parseInt($('.left_hk').css("left").substring(0, $('.left_hk').css("left").length - 2)) + 14) + 'px'
				})
				$('.left_juli')[0].innerText = mindate + 'km';
				$('.juli_right')[0].innerText = maxdate + 'km';
	} else {
		$('.wrapper').css("display", "none");
		$(this)[0].innerHTML = '<img src="images/1c.png" />';
	}
})

$('body').on('click', '.julisure_y', function() {
	alert("最小距离为" + $('.left_juli')[0].innerText + "最大距离为" + $('.juli_right')[0].innerText)
	//发送求情
	//	$.get
	var errcode = 0;
	if(errcode == 0) {
		//
		console.log("定位成功");
		$('.wrapper').hide()
	} else {
		alert("定位失败")
	}
})
var markbol = true;
var hdBol = true;
function yidong(comback, num) {
	/*触摸移动*/
	$('.left_hk').on("touchmove", function(event) {
		event.preventDefault(); //阻止触摸时浏览器的缩放、滚动条滚动  
		if(state == 1) {
			var touch = event.originalEvent.targetTouches[0];	
			var markNum = parseInt($('.juli_right')[0].innerText.substring(0, $('.juli_right')[0].innerText.length - 2));
			var leftNum = parseInt($('.left_juli')[0].innerText.substring(0, $('.left_juli')[0].innerText.length - 2));
			var x1 = touch.pageX;
			var start_x = x1 - $('.julitiao')[0].offsetLeft;
			x = start_x - 14;			
			if(hdBol == true){
				$('.left_hk').css("left", x);
			}			
			if(markNum < num / 2) {
				if(num <= 10 && markbol == true) {
					$('.right_hk').css("left", x);
				} else {				
					if(markbol == true) {	
						$('.left_hk').css("left", w - 14);	
						num = num / 2;
						if((parseInt($('.right_hk').css("left").substring(0, $('.right_hk').css("left").length - 2)) - 14)<=0){
							$('.right_hk').css('left',0);
						}else{
							$('.right_hk').css('left', leftNum*w/num - 7);
						}
						
						
						//中间距离条的显示
						comback && comback(num);
						markbol = false;
						hdBol = false;
						return false;
					}					
				}
			}

			if(start_x < 0) {
				$('.left_hk').css("left", -14);
				return false;
			}

			//超过扩大一倍
			if(start_x > w + 5) {
				$('.left_hk').css("left", (w - 14) / 2);
				if(num < 160) {
					if(markNum >= num) {
						if(markbol == true) {
							$('.right_hk').css('left', (parseInt($('.right_hk').css("left").substring(0, $('.right_hk').css("left").length - 2)) - 14) / 2);
							num += num;
							markbol = false;										
						}
						comback && comback(num);
						return false;
					}
				}
				if(num >= 160 && markbol == true) {
					$('.left_hk').css("left", (w - 14));
				}

			}
			comback && comback(num);
		}
	});
	$('.left_hk').on("touchstart", function(event) {
		lastTime = new Date().getTime();
		event.preventDefault(); //阻止触摸时浏览器的缩放、滚动条滚动  
		clearTimeout(timeout);
		state = 0;
		timeout = setTimeout(function() {
			state = 1;
		}, 100);
		markbol = true;		
	});
	$('.left_hk').on("touchend", function(event) {
		event.preventDefault(); //阻止触摸时浏览器的缩放、滚动条滚动  
		clearTimeout(timeout);
		state = 0;
		nowTime = new Date().getTime();
		var timeLength = nowTime - lastTime;
		if(timeLength < 100) {
			//			$("#loadLayer").show();
			window.history.go(-1);
		}
		hdBol = true;
	});
	$('.right_hk').on("touchmove", function(event) {
		event.preventDefault(); //阻止触摸时浏览器的缩放、滚动条滚动  
		if(state == 1) {
			var touch = event.originalEvent.targetTouches[0];
			var markNum = parseInt($('.juli_right')[0].innerText.substring(0, $('.juli_right')[0].innerText.length - 2));
			var leftNum = parseInt($('.left_juli')[0].innerText.substring(0, $('.left_juli')[0].innerText.length - 2));	
			var x1 = touch.pageX;
			var start_x = x1 - $('.julitiao')[0].offsetLeft;
			x = start_x - 14;
			if(hdBol == true){
				$('.right_hk').css("left", x);
			}
			if(markNum < num / 2) {
				if(num <= 10 && markbol == true) {
					$('.right_hk').css("left", x);
				} else {					
					if(markbol == true) {	
						$('.right_hk').css("left", w - 14);
						num = num / 2;
						if((parseInt($('.left_hk').css("left").substring(0, $('.left_hk').css("left").length - 2)) - 14)<0){
							$('.left_hk').css('left',0)
						}else{
							$('.left_hk').css('left', leftNum*w/num - 7);
						}						
												
						comback && comback(num);
						markbol = false;
						hdBol = false;
						return false;						
					}									
				}
			}

			if(start_x < 0) {
				$('.right_hk').css("left", -14);
				return false;
			}
			//超过扩大一倍
			if(start_x > w+5) {
				$('.right_hk').css("left", (w - 14) / 2);
				if(num < 160) {
					if(markNum >= num) {
						if(markbol == true) {
							$('.left_hk').css('left', (parseInt($('.left_hk').css("left").substring(0, $('.left_hk').css("left").length - 2)) - 14) / 2);
							num += num;
							markbol = false;													
						}
						comback && comback(num);
						return false;
					}
				}
				if(num >= 160 && markbol == true) {
					$('.right_hk').css("left", (w - 14));
				}

			}
			comback && comback(num);
		}
	});
	$('.right_hk').on("touchstart", function(event) {
		lastTime = new Date().getTime();
		event.preventDefault(); //阻止触摸时浏览器的缩放、滚动条滚动  
		clearTimeout(timeout);
		state = 0;
		timeout = setTimeout(function() {
			state = 1;
		}, 100);
		markbol = true;
		
	});
	$('.right_hk').on("touchend", function(event) {
		event.preventDefault(); //阻止触摸时浏览器的缩放、滚动条滚动  
		clearTimeout(timeout);
		state = 0;
		nowTime = new Date().getTime();
		var timeLength = nowTime - lastTime;
		if(timeLength < 100) {
			//			$("#loadLayer").show();
			window.history.go(-1);
		}	
		hdBol = true;
	});
}

var ll, rl;
function julinum(num) {
	//	s = w / 50
	s = w / num;
	ll = parseInt($('.left_hk').css("left").substring(0, $('.left_hk').css("left").length - 2));
	rl = parseInt($('.right_hk').css("left").substring(0, $('.right_hk').css("left").length - 2));
	var num1 = parseInt((ll + 14) / s);
	var num2 = parseInt((rl + 14) / s);
	if(ll / s < -14) {
		num1 = 0;
	}
	if(rl / s < 0) {
		num2 = 0;
	}
	//左右距离值的显示
	var maxkm = num1 > num2 ? num1 : num2;
	var minkm = num1 < num2 ? num1 : num2;
	$('.juli_right')[0].innerText = maxkm + "km";
	$('.left_juli')[0].innerText = minkm + 'km';

	//中间距离条的显示
	var rightnum = parseInt($('.right_hk').css("left").substring(0, $('.right_hk').css("left").length - 2));
	var leftnum = parseInt($('.left_hk').css("left").substring(0, $('.left_hk').css("left").length - 2));
	var max = rightnum > leftnum ? rightnum : leftnum;
	var min = rightnum < leftnum ? rightnum : leftnum;

	var t = rightnum < leftnum ? rightnum : leftnum;
	t = t + 14;
	$('.kuangdu').css({
		width: (max - min) + 'px',
		left: t + 'px'
	});
}

//距离初始化
$('.wrapper').hide();