//手机获取位置失败 手填
var shoujioption = 0;
if(shoujioption == 0) {
	//定位失败
	$('.f_go_dw').show();
	$('#sr_addres').focus();
	$('.go_btn_rb').unbind('click').on('click', function() {
		$('.f_go_dw').hide();
	})

	var app = new Vue({
		el: '#app',
		data: {
			message: ''
		}
	})
	var a, b;
	$('#sr_addres').on('keydown', function() {
		b = $('#app_p')[0].innerText
		console.log(b)

	})
	$('#sr_addres').on('keyup', function() {
		a = $('#app_p')[0].innerText;
		$('.sr_add_k').show()
		$('.sr_add_k').html('');
		var value = $(this).val();
		if(value == "") {
			$('.sr_add_k').hide();
			return false;
		}
		if(a != b && a != "") {
			var data = {
				"err_code": 0,
				"err_msg": "请求成功",
				"page": "-1",
				"data": [{
					"id": 1,
					"name": "杭州"
				}, {
					"id": 2,
					"name": "北京"
				}, {
					"id": 3,
					"name": "上海"
				}, {
					"id": 4,
					"name": "老虎沟"
				}]
			}
			if(data.err_code == 0) {
				var addresxy;
				$('.sr_add_k').html('');
				$.each(data.data, function(i, item) {
					$('.sr_add_k').append('<li value="110,110"><span class="addresskey">' + item.name + '</span><span class="fontcolorhui">' + 111 + '</span></li>');
				});
				var tt = $('.sr_add_k');
				var a = "";
				var b = "";
				tt.toggle();
				var tag = tt.toggle();
				$('li', tt).on('click', function() {
					item = $(this).find('.addresskey')[0];
					addresxy = $(this).attr('value');
					$('#sr_addres')[0].value = item.innerText;
					a = item.innerText;
					b = $('#sr_addres')[0].value;
					$('.go_btn_yes').unbind('click').on('click', function() {
						alert('地址是' + $('#sr_addres')[0].value + "请求value" + addresxy);
						//发送请求
						//					$.get
						var errcode = 0;
						if(errcode == 0) {
							//						网页面加载内容
						}
					})
				})
				var flag = true;
				$(document).bind("click", function(e) { //点击空白处，设置的弹框消失
					var target = $(e.target);
					if(flag == true) {
						tag.hide();
						flag = false;
					}
				});
			} else {
				console.log(data.err_msg);
			}
		} else {
			console.log(2)
		}
	})
}

//位置定位成功
//$.get	
var errcode = 0;
if(errcode == 0) {
	$('.jiazIn').show()
	var tim = setTimeout(function() {
		$('.jiazIn').hide();
		clearTimeout(tim)
	}, 10000)
	var divhtml =
		'<div class="ss_right">' +
		'<div class="ss_header">' +
		'<div class="lis_li_img">' +
		'<a href="geren.html" value="1"><img src="images/1.jpg"/></a>' +
		'</div>' +
		'<div>' +
		'<span class="fr_name">' +
		'<a href="geren.html" value="1">夏目君</a>' +
		'</span>' +
		'<span class="pl_time">3分钟前</span>' +
		'<span class="yc_ss">删除</span>' +
		'</div>' +
		'<span class="fr_jl">距我8km</span>' +
		'</div>' +
		'<div class="ss_neirong">' +
		'<p class="fr_ss" value="1">兄我们撸串，管饱的那种，附近有要约的吗兄弟今天晚上我们撸串，管饱的那种，附近有要约的吗饱的那种，附近有要约的吗</p>' +
		'<div class="more fr_ss_more">全文<img src="images/icon-0.png" alt="" /></div>' +
		'</div>' +
		'<div class="tupianji">' +
		'<img data-src="img/48fd8b7452c2ef737c8e7e168286161e.jpg" src="img/morenimg.jpg" value="http://img4.imgtn.bdimg.com/it/u=26089488,3980819576&fm=200&gp=0.jpg" data-num="0"/>' +
		'<img data-src="img/dainpul.png" src="img/morenimg.jpg" value="http://ww4.sinaimg.cn/large/006y8mN6gw1fa5obmqrmvj305k05k3yh.jpg" data-num="1"/>' +
		'<img data-src="img/touxiang.png" src="img/morenimg.jpg" value="http://ww1.sinaimg.cn/large/006y8mN6gw1fa7kaed2hpj30sg0l9q54.jpg" data-num="2"/>' +
		'<img data-src="images/1.jpg" src="img/morenimg.jpg" value="http://cover.read.duokan.com/mfsv2/download/fdsc3/p01N203pHTU7/Wr539kcLAtVCi.jpg!t" data-num="3"/>' +
		'<img data-src="images/2_17.gif" src="img/morenimg.jpg" value="http://pic1.cxtuku.com/00/16/18/b3809a2ba0f3.jpg" data-num="4"/>' +
		'<img data-src="images/2_21.gif" src="img/morenimg.jpg" value="http://scimg.jb51.net/allimg/160120/9-160120164646256.jpg" data-num="5"/>' +
		'</div>' +
		'<div class="ops_store">' +
		'<span class="ops_storeimg"></span>' +
		'<span class="ops_storestr">狼Basdasdakld是打开了多久啊是的市鬼子村百年老字号鸭店</span>' +
		'</div>' +
		//		1.0.2.1
		'<div class="ss_zt">' +
		'<div class="">' +
		'<img src="images/icon1-1.png"/>' +
		'<span>1234</span>' +
		'</div>' +
		'<em>|</em>' +
		'<div class="dianzan">' +
		'<a class="sign_go">' +
		'<img src="images/icon1-2.png"/>' +
		'<span class="dianzan_num">123</span>' +
		'</a>' +
		'</div>' +
		'<em>|</em>' +
		'<div class="cai">' +
		'<a class="sign_go">' +
		'<img src="img/caihui.gif"/>' +
		'<span class="cai_num">123</span>' +
		'</a>' +
		'</div>' +
		'<em>|</em>' +
		'<div class="pinglun">' +
		'<a class="sign_go">' +
		'<img src="images/icon1-3.png"/><span class="pinglun_num">12</span>' +
		'</a>' +
		'</div>' +
		'</div>' +
		//		1.0.2.1
		'<div class="fr_pls">' +
		'<ul class="fr_pls_ul">' +
		'<li value="1">' +
		'<div class="fr_pls_one">' +
		'<div>' +
		'<div class="pls_one_xx">' +
		'<a class="pls_one_name" href="geren.html" value="1">沙皮</a>' +
		'<span class="pl_ctt sign_go" value="1">' +
		'晚要约的吗开的' +
		'</span>' +
		'</div>' +
		//1.0.2.1添加类名
		'<div class="mjs">' +
		'<span class="more more_yi">展开</span>' +
		'<span class="pl_jlme">距我8km</span>' +
		'<span class="yc_pl">删除<span>' +
		'</div>' +
		'<ul class="erjipl_ul">' +
		'<li value="1">' +
		'<div class="fr_pls_two">' +
		'<div class="pls_two_xx">' +
		'<a class="pls_pwo_name" href="geren.html" value="1">大西瓜</a>' +
		'<span class="pltwo_ctt sign_go">' +
		'阿娇的撒赖扩大就ask了多久兄弟今天晚上我们撸串，管饱的那种，附近有要约的吗兄弟今天晚上我们撸串，管饱的那种，附近有要约的吗兄弟今天晚上我们撸串，管饱的那种，附近有要约的吗兄弟今天晚上我们撸串，管饱的那种，附近有要约的吗啊是阿娇阿斯洛克打算离开的' +
		'</span>' +
		'</div>' +
		//1.0.2.1添加类名
		'<div class="mjs">' +
		'<span class="more more_er">展开<img src="images/icon-0.png" alt="" /></span>' +
		'<span class="pl_jlme">距我8km</span>' +
		'<span class="yc_pltwo">删除<span>' +
		'</div>' +
		'</div>' +
		'</li>' +
		'</ul>' +
		'</div>' +
		'</div>' +
		'</li>' +
		'</ul>' +
		'</div>' +
		'</div>' +
		'<div class="pl_more">更多评论<img src="images/icon-0.png" alt="" /></div>';

	var lis = document.createElement('li');
	lis.innerHTML = divhtml;
	lis.setAttribute('value', '1');
	lis.className = 'ss_lis_li';
	$('.ss_lis_ul').append(lis);

	var testhtml = '<div class="ss_right">' +
		'<div class="ss_header">' +
		'<div class="lis_li_img">' +
		'<a href="geren.html" value="1"><img src="images/1.jpg"/></a>' +
		'</div>' +
		'<div>' +
		'<span class="fr_name">' +
		'<a href="geren.html" value="1">夏目君</a>' +
		'</span>' +
		'<span class="pl_time">3分钟前</span>' +
		'</div>' +
		'</div>' +
		'<div class="ss_neirong">' +
		'<p class="fr_test" value="1">主题：你现在的心理状态是怎么样主题：你现在的心理状态是怎么样主题：你现在的心理状态是怎么样主题：你现在的心理状态是怎么样主题：你现在的心理状态是怎么样主题：你现在的心理状态是怎么样主题：你现在的心理状态是怎么样主题：你现在的心理状态是怎么样主题：你现在的心理状态是怎么样主题：你现在的心理状态是怎么样主题：你现在的心理状态是怎么样</p>' +
		'</div>' +
		'<div class="tupianji">' +
		'<img data-src="img/tu.png" src="img/morenimg.jpg" value="img/tu.png" data-num="0"/>' +
		'</div>' +
		'<div class="ss_neirong">' +
		'<p class="fr_test" value="1">题目：在你家附近的公园里站着一个人，在你的直觉中，这个人正在做什么呢？</p>' +
		'<ul class="test_xuanxiang">' +
			'<li class="test_li" value="0">' +
				'<img src="img/weixuan.gif"/><span>A.这个人一定是坏人;他在摸点,打算晚上猥琐从这走过的蛇皮怪</span>' +
			'</li>' +
			'<li class="test_li" value="1">' +
				'<img src="img/weixuan.gif"/><span>B.他明显是在等人,</span>' +
			'</li>' +
			'<li class="test_li" value="2">' +
				'<img src="img/weixuan.gif"/><span>C.他在看附近有没有做小树林生意的女人</span>' +
			'</li>' +
			'<li class="test_li" value="3">' +
				'<img src="img/weixuan.gif"/><span>D.老子一天天闲的,尽瞎猜别人做什么</span>' +
			'</li>' +
		'</ul>' +
		'</div>' +
		'<div class="test_tijiao" datahad="0">提交</div>' +
		'<div class="test_jieguo">' +
						'<p class="tjg_p">' +
//							'<span>我选择了</span><span>C:</span><span>你现在是该加油的时候了，有时候需要学会忍耐，相信自己一定可以克服过来</span>' +
						'</p>' +
						'<div class="tjg_div">' +
							'共有<span class="tjg_div_num">1231</span>人参加了此话题' +
						'</div>' +
					'</div>' +
		'<div class="ss_zt">' +
			'<div class="">' +
				'<img src="images/icon1-1.png"/>' +
				'<span>1234</span>' +
			'</div>' +
			'<em>|</em>' +
			'<div class="dianzan">' +
				'<a class="sign_go">' +
					'<img src="images/icon1-2.png"/>' +
					'<span class="dianzan_num">123</span>' +
				'</a>' +
			'</div>' +
			'<em>|</em>' +
			'<div class="cai">' +
				'<a class="sign_go">' +
					'<img src="img/weicai.gif"/>' +
					'<span class="cai_num">123</span>' +
				'</a>' +
			'</div>' +
			'<em>|</em>' +
			'<div class="pinglun">' +
				'<a class="sign_go">' +
					'<img src="images/icon1-3.png"/><span class="pinglun_num">12</span>' +
				'</a>' +
			'</div>' +
		'</div>' +
		//		1.0.2.1
		'<div class="fr_pls">' +
		'<ul class="fr_pls_ul">' +
		'<li value="1">' +
		'<div class="fr_pls_one">' +
		'<div>' +
		'<div class="pls_one_xx">' +
		'<a class="pls_one_name" href="geren.html" value="1">沙皮</a>' +
		'<span class="pl_ctt sign_go" value="1">' +
		'晚要约的吗开的' +
		'</span>' +
		'</div>' +
		//1.0.2.1添加类名
		'<div class="mjs">' +
		'<span class="more more_yi">展开</span>' +
		'<span class="pl_jlme">距我8km</span>' +
		'<span class="yc_pl">删除<span>' +
		'</div>' +
		'<ul class="erjipl_ul">' +
		'<li value="1">' +
		'<div class="fr_pls_two">' +
		'<div class="pls_two_xx">' +
		'<a class="pls_pwo_name" href="geren.html" value="1">大西瓜</a>' +
		'<span class="pltwo_ctt sign_go">' +
		'阿娇的撒赖扩大就ask了多久兄弟今天晚上我们撸串，管饱的那种，附近有要约的吗兄弟今天晚上我们撸串，管饱的那种，附近有要约的吗兄弟今天晚上我们撸串，管饱的那种，附近有要约的吗兄弟今天晚上我们撸串，管饱的那种，附近有要约的吗啊是阿娇阿斯洛克打算离开的' +
		'</span>' +
		'</div>' +
		//1.0.2.1添加类名
		'<div class="mjs">' +
		'<span class="more more_er">展开<img src="images/icon-0.png" alt="" /></span>' +
		'<span class="pl_jlme">距我8km</span>' +
		'<span class="yc_pltwo">删除<span>' +
		'</div>' +
		'</div>' +
		'</li>' +
		'</ul>' +
		'</div>' +
		'</div>' +
		'</li>' +
		'</ul>' +
		'</div>' +
		'</div>' +
		'<div class="pl_more">更多评论<img src="images/icon-0.png" alt="" /></div>';
	var testLis = document.createElement('li');
	testLis.innerHTML = testhtml;
	testLis.setAttribute('value', '2');
	testLis.setAttribute('datatestvalue', '0');
	testLis.setAttribute('datatesthadxz', '0');
	testLis.className = 'ss_lis_li';
	$('.ss_lis_ul').append(testLis);
	$('.jiazIn').hide()
	khbx()

	//右边框位置
	//	$('.ss_right').css({
	//		'padding-top': $('.lis_li_img').find('img')[0].clientHeight / 2 - 7 + 'px'
	//	})
	$('.friends_pl_tx').css({
		'width': $('.friends_pl_tx').find('img')[0].offsetHeight + 'px'
	})
}

//评论数量超过3提示
function numpl(op, os) {
	for(var i = 0; i < op.length; i++) {
		if($(op[i]).children().length > 3) {
			$(op[i]).parent().find(os).show();
		}
	}
}

//1.0.1修改所有评论只能显示3个的BUG
//超过3的评论隐藏
function moreycc(os) {
	console.log(os.length)
	for(var i = 0; i < os.length; i++) {
		for(var j = 0; j < $(os[i]).children().length; j++) {
			if(j >= 3) {
				$($(os[i]).children()[j]).hide()
			}
		}
	}
}
//1.0.1修改所有评论只能显示3个的BUG

//一级，二级，三级展开更多
$('.ss_lis').unbind('click').on('click', '.more_er,.more_yi,.fr_ss_more', function() {		
	if($(this)[0].className.indexOf('fr_ss_more') != -1) {
		if($(this).parent().find('.fr_ss').css('-webkit-line-clamp') == 6) {
			$(this).parent().find('.fr_ss').css({
				'-webkit-line-clamp': "100"
			})
			$(this)[0].innerHTML = "收起" + "<img src='images/icon0-2.png'>";
			console.log(111)
		} else {
			$(this).parent().find('.fr_ss').css({
				'-webkit-line-clamp': "6"
			})
			$(this)[0].innerHTML = "全文" + "<img src='images/icon-0.png'>";
		}
	}
	if($(this)[0].className.indexOf('more_yi') != -1) {
		if($(this).parent().parent().find('.pls_one_xx').css('-webkit-line-clamp') == 3) {
			$(this).parent().parent().find('.pls_one_xx').css({
				'-webkit-line-clamp': "100"
			})
			$(this)[0].innerHTML = "收起" + "<img src='images/icon0-2.png'>";
		} else {
			$(this).parent().parent().find('.pls_one_xx').css({
				'-webkit-line-clamp': "3"
			})
			$(this)[0].innerHTML = "展开" + "<img src='images/icon-0.png'>";
		}
	}
	if($(this)[0].className.indexOf('more_er') != -1) {
		if($(this).parent().parent().find('.pls_two_xx').css('-webkit-line-clamp') == 3) {
			$(this).parent().parent().find('.pls_two_xx').css({
				'-webkit-line-clamp': "100"
			})
			$(this)[0].innerHTML = "收起" + "<img src='images/icon0-2.png'>";
		} else {
			$(this).parent().parent().find('.pls_two_xx').css({
				'-webkit-line-clamp': "3"
			})
			$(this)[0].innerHTML = "展开" + "<img src='images/icon-0.png'>";
		}
	}
})

//点赞
//1.0.1修改新增说说不能点赞BUG
function wocao(value,obj) {
	var ite = obj.parents('.ss_lis_li')
	for(var i = 0; i < ite.find('.test_li').length;i++){
		if($(ite.find('.test_li')[i]).attr('value') == value){
			var str = ite.find('.test_li')[i].innerText.substring(0,1);
		}
	}
	return str;
}
$('body').unbind('click').on('click', '.dianzan,.cai,.test_li,.test_tijiao', function() {
	if($(this)[0].className.indexOf('test_tijiao') != -1) {
		if($(this).attr('datahad') == 1){
			var item = $(this); 
			var itemparents = $(this).parents('.ss_lis_li');
			var num = +itemparents.find('.tjg_div_num')[0].innerText;
			var datatestvalue = $(this).parents('.ss_lis_li').attr('datatestvalue')
			var datavalue = $(this).attr('datavalue')
			alert('测试题为' + datatestvalue + ",选择的题目" + datavalue);
			//发送i请求
			//$.get
			var errcode = 0;
			if(errcode == 0){
				//
				alert("你真棒");
				$(this).parents('.ss_lis_li').attr('datatesthadxz','1')
				$(this).hide();
				$('.tjg_p')[0].innerHTML = '<span>我选择了</span><span>' + wocao(datavalue,item) + ':</span><span>' + '你现在是该加油的时候了，有时候需要学会忍耐，相信自己一定可以克服过来' + '</span>'
				$('.tjg_div_num')[0].innerText = num + 1;
				$('#test-anwser').show();
				$('.anwser-xx')[0].innerText = "";
				//根据所做的测试题和选择的答案请求到的结果写入
				$('.anwser-xx')[0].innerText = '你现在需要学会忍耐了，你在不好好女里，你会法眼你他妈连母猿都娶不起，不是我说你，你已经跟你现在需要学';
				$('.anwser-zz').unbind('click').on('click',function(){
					$('#test-anwser').hide();
				})
			}
		}
	}
	
	
	if(this.className.indexOf("test_li") != -1){
		if($(this).parents('.ss_lis_li').attr('datatesthadxz') != 1){
			alert($(this).attr('value'));
			var itemvalue = $(this).attr('value');
			if($(this).find('img').attr('src') == 'img/yixuan.gif'){
				$(this).find('img').attr('src','img/weixuan.gif')
				$(this).parents(".ss_right").find('.test_tijiao').attr('datahad','0');	
				$(this).parents(".ss_right").find('.test_tijiao').css('background-color','gainsboro');
			}else{
				$(this).find('img').attr('src','img/yixuan.gif')
				$(this).siblings().find('img').attr('src','img/weixuan.gif');
				$(this).parents(".ss_right").find('.test_tijiao').attr('datahad','1');		
				$(this).parents(".ss_right").find('.test_tijiao').css('background-color','#4cd627');
				$(this).parents(".ss_right").find('.test_tijiao').attr('datavalue',itemvalue);
			}
		}
	}
		
	if(this.className.indexOf("dianzan") != -1) {
		var value = $(this).parents('.ss_lis_li').attr('value');
		alert(value)
		//发送请求
		//$.get
		var err_code = 0;
		if(err_code == 0) {	
			var num = +$(this).parents('.ss_lis_li').find('.dianzan_num')[0].innerText;
			var num2 = +$(this).parents('.ss_lis_li').find('.cai_num')[0].innerText;
			if($(this)[0].innerHTML.indexOf('img/zan.gif') != -1) {
				num = num - 1;
				$(this)[0].innerHTML = "<img src='images/icon1-2.png'/><span class='dianzan_num'>" + num + "</span>";
			} else {
				if($(this).parents('.ss_lis_li').find('.cai')[0].innerHTML.indexOf('img/cai.gif') != -1) {
					num2 = num2 - 1;
					$(this).parents('.ss_lis_li').find('.cai')[0].innerHTML = "<img src='img/caihui.gif'/><span class='cai_num'>" + num2 + "</span>";
				}
				num = num + 1
				$(this)[0].innerHTML = "<img src='img/zan.gif'/><span class='dianzan_num'>" + num + "</span>";
			}
		} else {
			alert("网咯坑爹了")
		}
	}
	if(this.className.indexOf("cai") != -1) {
		var value = $(this).parents('.ss_lis_li').attr('value')
		alert(value)
		//发送请求
		//$.get
		var err_code = 0;
		if(err_code == 0) {
			var num = +$(this).parents('.ss_lis_li').find('.dianzan_num')[0].innerText;
			var num2 = +$(this).parents('.ss_lis_li').find('.cai_num')[0].innerText;
			if($(this)[0].innerHTML.indexOf('img/cai.gif') != -1) {
				num2 = num2 - 1;
				$(this)[0].innerHTML = "<img src='img/caihui.gif'/><span class='cai_num'>" + num2 + "</span>";
			} else {
				if($(this).parents('.ss_lis_li').find('.dianzan')[0].innerHTML.indexOf('img/zan.gif') != -1) {
					num = num - 1;
					$(this).parents('.ss_lis_li').find('.dianzan')[0].innerHTML = "<img src='images/icon1-2.png'/><span class='dianzan_num'>" + num + "</span>";
				}
				num2 = num2 + 1
				$(this)[0].innerHTML = "<img src='img/cai.gif'/><span class='cai_num'>" + num2 + "</span>";
			}
		} else {
			alert("网咯坑爹了")
		}
	}

})

//控制评论的高度
function khbx() {
	//width:document.documentElement.clientHeight
	//超出显示全文按钮显现
	for(var i = 0; i < $('.fr_ss').length; i++) {
		if($('.fr_ss')[i].scrollHeight > 120) {
			$($('.fr_ss')[i]).parent().find('.more').show()
		}
	}
	for(var i = 0; i < $('.pls_one_xx').length; i++) {
		if($('.pls_one_xx')[i].scrollHeight > 60) {
			$($('.pls_one_xx')[i]).parent().find('.more_yi').show()
		}
	}
	for(var i = 0; i < $('.pls_two_xx').length; i++) {
		if($('.pls_two_xx')[i].scrollHeight > 60) {
			$($('.pls_two_xx')[i]).parent().find('.more_er').show()
		}
	}
}
khbx()
var bol;
if($('#header').find('.sign_zc').length != 0) {
	bol = false;
}
$('.sign_go').unbind('click').on('click', function() {
	if(bol == false) {
		document.location = 'sign.html';
	}
})

function pinglun(ob) {
	$('#fasong_sure').unbind('click').on('click', '.sub_btn', function() {
		//	$('button.sub_btn', $('#fasong_sure')).unbind('click').on('click', function() {
		console.log(1)
		var divhtml
		divhtml = '<div class="fr_pls_one">' +
			'<div>' +
			'<div class="pls_one_xx">' +
			'<a class="pls_one_name" href="geren.html">沙皮:</a>' +
			'<a class="sign_go">' +
			'<span class="pl_ctt">' +
			$("#saytext").val() +
			'</span>' +
			'</a>' +
			'</div>' +
			'<div>' +
			'<span class="more more_yi">展开<img src="images/icon-0.png" alt="" /></span>' +
			'<span class="pl_jlme">距我8km</span>' +
			'</div>' +
			'<ul class="erjipl_ul">' +
			'</ul>' +
			'<div class="sjmorepl">更多回复<img src="images/icon-0.png" alt="" /></div>' +
			'</div>' +
			'</div>';
		var lis = document.createElement('li');
		lis.innerHTML = divhtml;
		lis.setAttribute('value', '1');
		//发送请求
		//	$.get
		var errcoed = 0;
		if(errcoed == 0) {
			ob.get(0).appendChild(lis);
			//			var st = $(ob).find('.pl_ctt')[0]
			//			console.log(st)
			console.log($(ob).find('.pl_ctt').length)
			var i = $(ob).find('.pl_ctt').length - 1;
			var str = $(ob).find('.pl_ctt')[i].innerHTML;
			$(ob).find('.pl_ctt')[i].innerHTML = replace_em(str);
			$("#saytext")[0].value = "";
			$('#pl_kuang').hide();
			numpl($('.fr_pls_ul'), '.pl_more');
			khbx();
			moreycc($('.fr_pls_ul'))
		}
	})
}

//一级评论
$('body').on('click', '.pinglun', function() {
	console.log(111)
	var item = $(this).parents('.ss_right');
	$('#pl_kuang').show();
	$('#saytext').focus();
	$('#saytext').attr('placeholder', '');
	//点击其他地方，评论框隐藏
	$('#contant').unbind('click').on('click', function() {
		$('#saytext').blur();
		$('#pl_kuang').hide();
	})
	pinglun(item.find('.fr_pls_ul'));
})

//二级评论
$('body').on('click', '.pls_one_xx', function() {
	var item = $(this).parents('.fr_pls_one');
	$('#pl_kuang').show();
	$('#saytext').focus();
	$('#saytext').attr('placeholder', '回复 ' + $(this).parent().parent().find('.pls_one_name')[0].innerText + ':');
	//点击其他地方，评论框隐藏1.0.2.1
	$('#contant').unbind('click').on('click', function() {
		$('#saytext').blur();
		$('#pl_kuang').hide();
	})
	var divhtmlt = "";
	divhtmlt += '<div class="fr_pls_two">' +
		'<div class="pls_two_xx">' +
		'<a class="pls_pwo_name" href="geren.html" value="1">大西瓜</a>回复' +
		'<a class="pls_pwo_name" href="geren.html" value="1">夏暮君</a>';
	erjipinglun(item.find('.erjipl_ul'), divhtmlt);
})

//二级子评论回复
//1.0.2.1
$('body').on('click', '.pl_ctt,.pltwo_ctt', function() {
	var item = $(this).parents('.fr_pls_one');
	$('#pl_kuang').show();
	$('#saytext').focus();
	$('#saytext').attr('placeholder', '回复 ' + $(this).parent().find('.pls_pwo_name')[0].innerText + ':');
	//点击其他地方，评论框隐藏1.0.2.1
	$('#contant').unbind('click').on('click', function() {
		$('#saytext').blur();
		$('#pl_kuang').hide();
	})
	var divhtmlt = "";
	divhtmlt += '<div class="fr_pls_two">' +
		'<div class="pls_two_xx">' +
		'<a class="pls_pwo_name" href="geren.html" value="1">小西瓜</a>回复' +
		'<a class="pls_pwo_name" href="geren.html" value="1">大西瓜</a>';
	erjipinglun(item.find('.erjipl_ul'), divhtmlt);
})

function erjipinglun(ob, divhtmlt) {
	//	$('button.sub_btn', $('#fasong_sure')).unbind('click').on('click', function() {
	$('#fasong_sure').unbind('click').on('click', '.sub_btn', function() {
		divhtmlt += '<span class="pltwo_ctt" value="1">' +
			$("#saytext").val() +
			'</span>' +
			'</div>' +
			'<div>' +
			'<span class="more more_er">展开<img src="images/icon-0.png" alt="" /></span>' +
			'<span class="pl_jlme">距我8km</span>' +
			'</div>' +
			'</div>';
		var list = document.createElement('li');
		list.innerHTML = divhtmlt;
		list.setAttribute('value', '1');
		//发送请求
		//	$.get
		var errcoed = 0;
		if(errcoed == 0) {
			ob.get(0).appendChild(list);
			console.log($(ob).find('li').length)
			var i = $(ob).find('li').length - 1;
			var str = $(ob).find('.pltwo_ctt')[i].innerHTML;
			$(ob).find('.pltwo_ctt')[i].innerHTML = replace_em(str);
			$("#saytext")[0].value = "";
			$('#pl_kuang').hide();
			numpl($('.erjipl_ul'), '.sjmorepl');
			moreycc($('.erjipl_ul'));
			khbx();
		}
	})
}

//1.0.2.1
$('#saytext').on('click', function() {
	console.log(1)
	$('#facebox').hide();
})

//距离
//设置一个长按的计时器，如果点击这个图层超过0.2秒则触发移动事件
var timeout = undefined;
var x = 0;
var state = 0;
var lastTime = null;
var nowTime = null;

//隐藏距离框
$('.julixs').unbind('click').on('click', function() {
	if($('.wrapper').css('display') == "none") {
		$('.wrapper').css("display", "block");
		$(this)[0].innerHTML = '<img src="images/1a.png" />' +
			'<div class="storeName">' +
			'<span>' +
			'<img src="img/dianpupng.png"/>' +
			'</span>' +
			'<span>' +
			'北京去哪聚的烤鸭店等你来战Gogogo' +
			'</span>' +
			'</div>';
		//进来获取初始的距离值
		var date0 = 25,
			date1 = 40;
		$('.left_hk').css({
			left: (((date0 * w) / 50) - 9) + 'px'
		})
		$('.right_hk').css({
			left: (((date1 * w) / 50) - 9) + 'px'
		})
		$('.kuangdu').css({
			width: (parseInt($('.right_hk').css("left").substring(0, $('.right_hk').css("left").length - 2)) - parseInt($('.left_hk').css("left").substring(0, $('.left_hk').css("left").length - 2))) + 'px',
			left: (parseInt($('.left_hk').css("left").substring(0, $('.left_hk').css("left").length - 2)) + 9) + 'px'
		})
		$('.left_juli')[0].innerText = date0 + 'km';
		$('.juli_right')[0].innerText = date1 + 'km';
	} else {
		$('.wrapper').css("display", "none");
		$(this)[0].innerHTML = '<img src="images/1c.png" />' +
			'<div class="storeName">' +
			'<span>' +
			'<img src="img/dianpupng.png"/>' +
			'</span>' +
			'<span>' +
			'北京去哪聚的烤鸭店等你来战Gogogo' +
			'</span>' +
			'</div>';
	}
})

function julichushihua() {
	var date0 = 0,
		date1 = 5;
	$('.left_hk').css({
		left: (((date0 * w) / 50) - 9) + 'px'
	})
	$('.right_hk').css({
		left: (((date1 * w) / 50) - 9) + 'px'
	})
	$('.kuangdu').css({
		width: (parseInt($('.right_hk').css("left").substring(0, $('.right_hk').css("left").length - 2)) - parseInt($('.left_hk').css("left").substring(0, $('.left_hk').css("left").length - 2))) + 'px',
		left: (parseInt($('.left_hk').css("left").substring(0, $('.left_hk').css("left").length - 2)) + 9) + 'px'
	})
	$('.left_juli')[0].innerText = date0 + 'km';
	$('.juli_right')[0].innerText = date1 + 'km';
}

////获取滑动条的宽度
//$('.right_hk').css({
//	left: -9
//})
var w = $('.julitiao')[0].clientWidth;
var s;
$('body').on('click', '.julisure_y', function() {
	alert("最小距离为" + $('.left_juli')[0].innerText + "最大距离为" + $('.juli_right')[0].innerText)
	//发送求情
	//	$.get
	var errcode = 0;
	if(errcode == 0) {
		//
		console.log("定位成功");
		$('.wrapper').show()
	} else {
		alert("定位失败")
	}
})

function yidong(ob) {
	/*触摸移动*/
	ob.on("touchmove", function(event) {
		event.preventDefault(); //阻止触摸时浏览器的缩放、滚动条滚动  
		if(state == 1) {
			var touch = event.originalEvent.targetTouches[0];
			var x1 = touch.pageX;
			var start_x = x1 - $('.julitiao')[0].offsetLeft;
			x = start_x - 9;
			//			if(parseInt($('.left_hk').css("left").substring(0, $('.left_hk').css("left").length - 2)) > parseInt($('.right_hk').css("left").substring(0, $('.right_hk').css("left").length - 2))) {
			//				parseInt($('.left_hk').css("left").substring(0, $('.left_hk').css("left").length - 2)) == parseInt($('.right_hk').css("left").substring(0, $('.right_hk').css("left").length - 2));
			//			}
			ob.css("left", x);
			//					var left = ob.css("left").substring(0, ob.css("left").length - 2);
			if(start_x < 0) {
				ob.css("left", -9);
				return false;
			}
			if(start_x >= w) {
				ob.css("left", w - 9);
			}
			julinum()
		}
	});
	ob.on("touchstart", function(event) {
		lastTime = new Date().getTime();
		event.preventDefault(); //阻止触摸时浏览器的缩放、滚动条滚动  
		clearTimeout(timeout);
		state = 0;
		timeout = setTimeout(function() {
			state = 1;
		}, 100);

	});
	ob.on("touchend", function(event) {
		event.preventDefault(); //阻止触摸时浏览器的缩放、滚动条滚动  
		clearTimeout(timeout);
		state = 0;
		nowTime = new Date().getTime();
		var timeLength = nowTime - lastTime;
		if(timeLength < 100) {
			//			$("#loadLayer").show();
			window.history.go(-1);
		}
		alert("最小距离为" + $('.left_juli')[0].innerText + "最大距离为" + $('.juli_right')[0].innerText)
		//发送求情
		//	$.get
		var errcode = 0;
		if(errcode == 0) {
			//
			console.log("定位成功");
			$('.wrapper').show()
		} else {
			alert("定位失败")
		}
		});
}

yidong($('.left_hk'))
yidong($('.right_hk'))

var ll, rl;

function julinum() {
	s = w / 50
	ll = parseInt($('.left_hk').css("left").substring(0, $('.left_hk').css("left").length - 2));
	rl = parseInt($('.right_hk').css("left").substring(0, $('.right_hk').css("left").length - 2));
	console.log(ll);
	console.log(rl);
	var num1 = parseInt((ll + 9) / s);
	var num2 = parseInt((rl + 9) / s);
	if(ll / s < -9) {
		num1 = 0;
	}
	if(rl / s < 0) {
		num2 = 0;
	}
	//左右距离值的显示
	var maxkm = num1 > num2 ? num1 : num2;
	var minkm = num1 < num2 ? num1 : num2;
	$('.juli_right')[0].innerText = maxkm + "km";
	$('.left_juli')[0].innerText = minkm + 'km';

	//中间距离条的显示
	var rightnum = parseInt($('.right_hk').css("left").substring(0, $('.right_hk').css("left").length - 2));
	var leftnum = parseInt($('.left_hk').css("left").substring(0, $('.left_hk').css("left").length - 2));
	var max = rightnum > leftnum ? rightnum : leftnum;
	var min = rightnum < leftnum ? rightnum : leftnum;

	var t = rightnum < leftnum ? rightnum : leftnum;
	t = t + 9;
	$('.kuangdu').css({
		width: (max - min) + 'px',
		left: t + 'px'
	})
}

//距离初始化
$('.wrapper').show();
julichushihua()

//加载更多
//加载更多

document.addEventListener("touchmove", ScrollStart, false);
document.addEventListener("scroll", Scroll, false);

var T = 0;
var scrollbol = true;

function scrollBol() {
	scrollbol = true;
}

function ScrollStart() {
	//start of scroll event for iOS
}

function Scroll() {
	T = $(document).scrollTop();
	if(T >= $('body')[0].scrollHeight - document.documentElement.clientHeight) {
		if(scrollbol == true) {
			//		发送请求
			//     ￥。get
			//1.0.2.1		
			$('.jz_more').show();
			console.log(1)
			//		var timer
			//		clearTimeout(timer)
			//		timer = setTimeout(function(){
			//			$('.jz_more').hide();
			//			clearTimeout(timer)
			//		},5000)
			var err_code = 0;
			if(err_code == 0) {
				$('.jz_more').hide();
				for(var i = 0; i < 15; i++) {
					var divhtml = '<div class="lis_li_img">' +
						'<a href="geren.html" value="1"><img src="images/4.png" /></a>' +
						'</div>' +
						'<div class="ss_right">' +
						'<div>' +
						'<span class="fr_name">' +
						'<a href="geren.html" value="1">夏目君</a>' +
						'</span>' +
						'<span class="pl_time">3分钟前</span>' +
						'<span class="yc_ss">删除</span>' +
						'</div>' +
						'<span class="fr_jl">距我8km</span>' +
						'<div class="ss_neirong">' +
						'<p class="fr_ss" value="1">兄弟今天晚上我们撸串，管兄弟今天晚上我们撸串，管饱的那种，附近有要约的吗兄弟今天晚上我们撸串，管饱的那种，附近有要约的吗兄弟今天晚上我们撸串，管饱的那种，附近有要约的吗兄弟今天晚上我们撸串，管饱的那种，附近有要约的吗兄弟今天晚上我们撸串，管饱的那种，附近有要约的吗兄弟今天晚上我们撸串，管饱的那种，附近有要约的吗兄弟今天晚上我们撸串，管饱的那种，附近有要约的吗兄弟今天晚上我们撸串，管饱的那种，附近有要约的吗兄弟今天晚上我们撸串，管饱的那种，附近有要约的吗兄弟今天晚上我们撸串，管饱的那种，附近有要约的吗饱的那种，附近有要约的吗</p>' +
						'<div class="more fr_ss_more">全文<img src="images/icon-0.png" alt="" /></div>' +
						'</div>' +
						'<div class="tupianji">' +
						'<img value="0" src="img/morenimg.jpg" data-src="http://d.hiphotos.baidu.com/zhidao/pic/item/024f78f0f736afc34a24c98eb119ebc4b7451234.jpg"/>' +
						'<img value="2" src="img/morenimg.jpg" data-src="http://pic.58pic.com/58pic/11/09/64/39i58PICmgE.jpg"/>' +
						'<img value="4" src="img/morenimg.jpg" data-src="http://h.hiphotos.baidu.com/zhidao/pic/item/060828381f30e9240ff2cd434c086e061d95f76a.jpg"/>' +
						'<img value="6" src="img/morenimg.jpg" data-src="http://d.hiphotos.baidu.com/zhidao/pic/item/1c950a7b02087bf44969b885f4d3572c10dfcfd1.jpg"/>' +
						'<img value="8" src="img/morenimg.jpg" data-src="http://e.hiphotos.baidu.com/zhidao/pic/item/0bd162d9f2d3572cf556972e8f13632763d0c388.jpg"/>' +
						'<img value="10" src="img/morenimg.jpg" data-src="http://d.hiphotos.baidu.com/zhidao/pic/item/279759ee3d6d55fb2166d92165224f4a20a4dd11.jpg"/>' +
						'</div>' +
						'<div class="ss_zt">' +
						'<span class=""><img src="images/icon1-1.png"/><span>1234</span></span>' +
						'<em>|</em>' +
						'<span class="dianzan">' +
						'<a class="sign_go">' +
						'<img src="images/icon1-2.png"/><span class="dianzan_num">123</span>' +
						'</a>' +
						'</span>' +
						'<em>|</em>' +
						'<span class="pinglun">' +
						'<a class="sign_go">' +
						'<img src="images/icon1-3.png"/><span class="pinglun_num">12</span>' +
						'</a>' +
						'</span>' +
						'</div>' +
						'<div class="fr_pls">' +
						'<ul class="fr_pls_ul">' +
						'<li value="1">' +
						'<div class="fr_pls_one">' +
						'<div>' +
						'<div class="pls_one_xx">' +
						'<a class="pls_one_name" href="geren.html" value="1">沙皮</a>' +
						'<span class="pl_ctt sign_go" value="1">' +
						'晚要约的吗开的' +
						'</span>' +
						'</div>' +
						'<div>' +
						'<span class="more more_yi">展开</span>' +
						'<span class="pl_jlme">距我8km</span>' +
						'<span class="yc_pl">删除<span>' +
						'</div>' +
						'<ul class="erjipl_ul">' +
						'<li value="1">' +
						'<div class="fr_pls_two">' +
						'<div class="pls_two_xx">' +
						'<a class="pls_pwo_name" href="geren.html" value="1">大西瓜</a>' +
						'<span class="pltwo_ctt sign_go">' +
						'阿娇的撒赖扩大就ask了多久兄弟今天晚上我们撸串，管饱的那种，附近有要约的吗兄弟今天晚上我们撸串，管饱的那种，附近有要约的吗兄弟今天晚上我们撸串，管饱的那种，附近有要约的吗兄弟今天晚上我们撸串，管饱的那种，附近有要约的吗啊是阿娇阿斯洛克打算离开的' +
						'</span>' +
						'</div>' +
						'<div>' +
						'<span class="more more_er">展开<img src="images/icon-0.png" alt="" /></span>' +
						'<span class="pl_jlme">距我8km</span>' +
						'<span class="yc_pltwo">删除<span>' +
						'</div>' +
						'</div>' +
						'</li>' +
						'</ul>' +
						'<div class="sjmorepl">更多回复<img src="images/icon-0.png" alt="" /></div>' +
						'</div>' +
						'</div>' +
						'</li>' +
						'</ul>' +
						'<div class="pl_more">更多评论<img src="images/icon-0.png" alt="" /></div>' +
						'</div>' +
						'</div>';
					var lis = document.createElement('li');
					lis.innerHTML = divhtml;
					lis.setAttribute('value', i);
					lis.className = 'ss_lis_li';
					$('.ss_lis_ul').append(lis);
				}
				khbx()
				imgshowkind();
				//1.0.2.1
				lanjz()
			}
			scrollbol = false;
			//			scrollBol();
		}

	}
	//end of scroll event for iOS
	//and
	//start/end of scroll event for other browsers
}

if($('.ss_lis_ul').find('li').length >= 15) {
	$('.jzmore').show();
}

//删除说说或评论
$('#contant').unbind('click').on('click', '.yc_pltwo,.yc_pl,.yc_ss', function() {
	if($(this)[0].className == "yc_ss") {
		$('.sctishi').show();
		var item = $(this).parents('.ss_lis_li');
		$('.sctishi_zz').unbind('click').on('click', function() {
			$('.sctishi').hide();
		})
		$('button.sc_no', $('.sc_yes_no')).unbind('click').on('click', function() {
			$('.sctishi').hide();
		})
		$('button.sc_yes', $('.sc_yes_no')).unbind('click').on('click', function() {
			alert(item.attr('value'));
			//发送请求
			//￥。get
			var errcode = 0;
			if(errcode == 0) {
				item.remove();
			}
			$('.sctishi').hide();
		})
	}
	if($(this)[0].className == "yc_pl") {
		var itempl = $(this).parent().parent().parent().parent();
		console.log(item)
		alert(itempl.attr('value'));
		//发送请求
		//￥。get
		var errcode = 0;
		if(errcode == 0) {
			itempl.remove();
		}
	}
	if($(this)[0].className == "yc_pltwo") {
		var itemtwo = $(this).parent().parent().parent();
		alert(itemtwo.attr('value'));
		//发送请求
		//￥。get
		var errcode = 0;
		if(errcode == 0) {
			itemtwo.remove();
		}
	}

})

//加载中

function noss() {
	if($('.ss_lis_ul').find('.ss_lis_li').length != 0) {
		$('.now_noss').hide();
	} else {
		$('.now_noss').show();
	}
}

//图片懒加载
function lanjz() {
	//  var num = document.getElementsByTagName('img').length;
	var n = 0; //存储图片加载到的位置，避免每次都从第一张图片开始遍历
	lazyload(); //页面载入完毕加载可是区域内的图片

	function getTop(obj) {
		var h = 0;
		while(obj) {
			h += obj.offsetTop;
			obj = obj.offsetParent;
		}
		return h;
	}

	function lazyload() { //监听页面滚动事件
		var seeHeight = document.documentElement.clientHeight; //可见区域高度
		var scrollTop = document.documentElement.scrollTop || document.body.scrollTop; //滚动条距离顶部高度
		var datalength = $("img[data-src]").length;
		var imgs = $("img[data-src]");
		for(var i = 0; i < datalength; i++) {
			//				var mixoffsetTop = $(imgs[i]).parent().get(0).offsetTop + $(imgs[i]).parents('.ss_lis_li').get(0).offsetTop;
			getTop(imgs[i]);
			if(getTop(imgs[i]) < seeHeight + scrollTop && getTop(imgs[i]) > scrollTop) {
				if(imgs[i].getAttribute("src") == "img/morenimg.jpg") {
					imgs[i].src = imgs[i].getAttribute("data-src");
				}
			}

		}
	}

	//节流函数
	function throttle(fun, delay, time) {
		var timeout,
			startTime = new Date();
		return function() {
			var context = this,
				args = arguments,
				curTime = new Date();
			clearTimeout(timeout);
			// 如果达到了规定的触发时间间隔，触发 handler
			if(curTime - startTime >= time) {
				fun.apply(context, args);
				startTime = curTime;
				// 没达到触发间隔，重新设定定时器
			} else {
				timeout = setTimeout(fun, delay);
			}
		};
	};
	window.addEventListener('scroll', throttle(lazyload, 500, 1000));
}
lanjz()

//编辑导航
$('.bj_img').unbind('click').on('click', function() {
	$('.bj_nav').show();
	$('.bj_nav_zz').unbind('click').on('click', function() {
		$('.bj_nav').hide();
	})
	//退出店面
	$('.store_tc').unbind('click').on('click', function() {
		alert('退出编辑');
		//发送求情
		//		$.get
		var errcode = 0;
		if(errcode == 0) {
			//
			$('.bj_nav').hide();
		}
	})
	//重新定位
	$('.repeat_dw').unbind('click').on('click', function() {
		alert('重新定位');
		//发送求情
		//		$.get
		var errcode = 0;
		if(errcode == 0) {
			//
			$('.bj_nav').hide();
		}

	})
})

//查看更早的消息
$('.morezao').unbind('click').on('click',function(){
	$('.morezao').hide();
	//发送请i去
//	$/get?
	var errcode = 0; 
	if(errcode == 0){
		var lis = '<div class="li_left">'+
						'<a href="geren.html" class="f_headimg" value="1">'+
							'<img src="images/2_03.gif" />'+
						'</a>'+
					'</div>'+
					'<div class="li_right" value="1">'+
						'<a href="ssxx.html">'+
							'<h6 class="name">碧浪</h6>'+
							'<p class="xiaoxi">我很丑，但是我很温柔，怎么样，要不要嫁给我</p>'+
							'<p class="times">7月7日 17：46</p>'+
						'</a>'+
					'</div>'+
					'<span class="plssct"><img src="images/2_07.gif"/></span>';
		for(var i = 0;i<10;i++){
			var li = document.createElement('li');
			li.className = "message_li";
			li.setAttribute('value',i);
			li.innerHTML = lis;
			$('.message_ul').append(li)
		}		
	}
})	

//向下划加载更多
var T = 0;
$(window).scroll(function() {
	T = $(document).scrollTop();
	if(T >= $('body')[0].scrollHeight - document.documentElement.clientHeight) {
		//		发送请求
		//     ￥。get
		var err_code = 0;
		if(err_code == 0) {
			for(var i = 0; i < 15; i++) {				
			var	li = '<div class="li_left">'+
						'<a href="geren.html" class="f_headimg" value="1">'+
							'<img src="images/2_03.gif" />'+
						'</a>'+
					'</div>'+
					'<div class="li_right" value="1">'+
						'<a href="ssxx.html">'+
							'<h6 class="name">碧浪</h6>'+
							'<p class="xiaoxi">我很丑，但是我很温柔，怎么样，要不要嫁给我</p>'+
							'<p class="times">7月7日 17：46</p>'+
						'</a>'+
					'</div>'+
					'<span class="plssct"><img src="images/2_07.gif"/></span>';
				var lis = document.createElement('li');
				lis.className = "message_li";
				lis.setAttribute('value',i);
				lis.innerHTML = li;
				$('.message_ul').append(lis)
			}
		}
	}
});

if($('.message_ul').find('li').length >= 15) {
	$('.jzmore').show();
}

function gundong(){
	var num=0;
	var huodongtimer = setInterval(function(){
		num+=1;
		if(num>=300){
			num = -300;
		}
		$('.huodonghuadong').get(0).style.left = - num + 'px';	
	},15)
}
gundong()
