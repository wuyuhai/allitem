/**
 * iSlider 
 * A simple, efficent mobile slider
 * @Author qbatyqi
 *
 * @param {Object}      opts                参数集
 * @param {Element}     opts.dom            外层元素        Outer wrapper
 * @param {Object}      opts.
 * 数据列表        Content data
 * Please refer to README                   请参考README
 * @class 
 */

var url ="http://localhost:8989/atlantang";
var jzt;
var iSlider = function(opts) {
	if(!opts.dom) {
		//  	dom不能为空
		throw new Error("dom element can not be empty!");
	}

	if(!opts.data || !opts.data.length) {
		//  	ops的数据必须是一个数组;并且长度不能为0
		throw new Error("data must be an array and must have more than one element!");
	}

	this._opts = opts;
	//设置滑块参数
	this._setting();
	//渲染
	this._renderHTML();
	//绑定所有处理程序
	this._bindHandler();
	//
	this.fangdasuoxiao();
};

//setting parameters for slider
//设置滑块参数
iSlider.prototype._setting = function() {
	var opts = this._opts;
	//dom element wrapping pics
	//DOM元素包装图片
	this.wrap = opts.dom;
	//pics data
	this.data = opts.data;
	//每张图片的value
	this.values = opts.values;
	//传过来的点击的图片的num
	this.itemNum = opts.itemNum;
	//定位图片集的父元素
	this.itemFather = opts.itemFather;
	//default type
	//默认类型
	this.type = opts.type || 'pic';
	//default slide direction
	//滑块滑动方向
	this.isVertical = opts.isVertical || false;

	//Callback function when your finger is moving
	//手指滑动执行callback函数
	this.onslide = opts.onslide;
	//Callback function when your finger touch the screen
	//当手指触摸屏幕执行callback函数
	this.onslidestart = opts.onslidestart;
	//Callback function when the finger move out of the screen
	//当手指离开屏幕
	this.onslideend = opts.onslideend;
	//Callback function when the finger move out of the screen
	//当手指离开屏幕
	this.onslidechange = opts.onslidechange;
	//Slide time gap
	//滑块时间间隔
	this.duration = opts.duration || 2000;

	//debug mode
	//调试
	this.log = opts.isDebug ? function(str) {
		console.log(str)
	} : function() {};

	this.axis = this.isVertical ? 'Y' : 'X';
	this.width = this.wrap.clientWidth;
	this.height = this.wrap.clientHeight;
	this.ratio = this.height / this.width;
	this.scale = opts.isVertical ? this.height : this.width;

	//start from 0
	this.sliderIndex = this.sliderIndex || 0;

	if(this.data.length < 2) {
		this.isLooping = false;
		this.isAutoPlay = false;
	} else {
		this.isLooping = opts.isLooping || false;
		this.isAutoplay = opts.isAutoplay || false;
	}

	//Autoplay mode
	if(this.isAutoplay) {
		this.play();
	}

	//set Damping function
	this._setUpDamping();

	//set animate Function
	this._animateFunc = (opts.animateType in this._animateFuncs) ?
		this._animateFuncs[opts.animateType] :
		this._animateFuncs['default'];

	//stop autoplay when window blur
	this._setPlayWhenFocus();
	
	//设置图片默认缩放比
	this.sscale=1;
	
	//触碰手指的数量 1 为真， 2以上为true;
	this.istouch = false;
	
	//
	this.wocao = false;
	//
	this.twosz = false;
};

//fixed bug for android device
//固定错误的Android设备
iSlider.prototype._setPlayWhenFocus = function() {
	var self = this;
	window.addEventListener('focus', function() {
		self.isAutoplay && self.play();
	}, false);
	window.addEventListener('blur', function() {
		self.pause();
	}, false);
}

//animate function options
/**
 * animation parmas: 
 *
 * @param {Element}      dom             图片的外层<li>容器       Img wrapper
 * @param {String}       axis            动画方向                animate direction
 * @param {Number}       scale           容器宽度                Outer wrapper
 * @param {Number}       i               <li>容器index           Img wrapper's index
 * @param {Number}       offset          滑动距离                move distance
 */
iSlider.prototype._animateFuncs = {
	'default': function(dom, axis, scale, i, offset) {
		dom.style.webkitTransform = 'translateZ(0) translate' + axis + '(' + (offset + scale * (i - 1)) + 'px)';
	}
}

//enable damping when slider meet the edge
//当滑块碰到边缘时启用阻尼
iSlider.prototype._setUpDamping = function() {
	var oneIn2 = this.scale >> 1;
	var oneIn4 = oneIn2 >> 1;
	var oneIn16 = oneIn4 >> 2;

	this._damping = function(distance) {
		var dis = Math.abs(distance);
		var result;

		if(dis < oneIn2) {
			result = dis >> 1;
		} else if(dis < oneIn2 + oneIn4) {
			result = oneIn4 + ((dis - oneIn2) >> 2);
		} else {
			result = oneIn4 + oneIn16 + ((dis - oneIn2 - oneIn4) >> 3);
		}
		return distance > 0 ? result : -result;
	};
};

//render single item html by idx
//通过IDX渲染单个项目的HTML
iSlider.prototype._renderItem = function(i) {
	var item, html;
	var itemValue;
	var len = this.data.length;
	var lValue = 0;

	if(!this.isLooping) {
		item = this.data[i] || {
			empty: true
		};
		itemValue = this.values[i] || {
			empty: true
		};
	} else {
		if(i < 0) {
			item = this.data[len + i];
			itemValue = this.values[len + i]
		} else if(i > len - 1) {
			item = this.data[i - len];
			itemValue = this.values[i - len]
		} else {
			item = this.data[i];
			itemValue = this.values[i]
		}
	}

	if(item.empty) {
		return '';
	}


	//图片展示形式
	if(this.type === 'pic') {
		if(item.content == itemValue) {
			console.log(11)
			html = item.height / item.width > this.ratio ?
				'<img height="' + item.height + '" src="' + item.content + '" datasrc="' + itemValue + '" dataops="' + 1 + '" datanum="'+item.num+'">' :
				'<img width="' + this.width + '" src="' + item.content + '" datasrc="' + itemValue + '" dataops="' + 1 + '" datanum="'+item.num+'">';
		}else{
			html = item.height / item.width > this.ratio ?
			'<img height="' + this.height + '" src="' + item.content + '" datasrc="' + itemValue + '" dataops="' + 0 + '" datanum="'+item.num+'">' :
			'<img width="' + this.width + '" src="' + item.content + '" datasrc="' + itemValue + '" dataops="' + 0 + '" datanum="'+item.num+'">';
		}
	}	
	return html;
};

//render list html
//渲染列表
iSlider.prototype._renderHTML = function() {
	//添加图片元素
	var outer;
	var itemFather = this.itemFather;
	if(this.outer) {
		//used for reset
		//复位
		this.outer.innerHTML = '';
		outer = this.outer;
	} else {
		//used for initialization
		//初始化
		outer = document.createElement('ul');
	}

	//ul width equels to div#canvas width
	//列表宽度等于画布的宽度
	outer.style.width = this.width + 'px';
	outer.style.height = this.height + 'px';

	//storage li elements, only store 3 elements to reduce memory usage
	//存储LI元素，只存储3个元素以减少内存使用量
	this.els = [];
	for(var i = 0; i < 3; i++) {
		var li = document.createElement('li');
		li.style.width = this.width + 'px';
		li.style.height = this.height + 'px';

		//prepare style animation
		//准备样式动画
		this._animateFunc(li, this.axis, this.scale, i, 0);

		this.els.push(li);
		outer.appendChild(li);

		if(this.isVertical && (this._opts.animateType == 'rotate' || this._opts.animateType == 'flip')) {} else {
			li.innerHTML = this._renderItem(i - 1 + this.sliderIndex);
		}
	}
	//append ul to div#canvas
	//在画布下添加ul
	if(!this.outer) {
		this.outer = outer;
		this.wrap.appendChild(outer);
	}
	var els = this.els;
	var data = this.data;
	var ns;
	var oldsrc = $(els[1]).children('img')[0].getAttribute("src");
	for(var i = 0;i<data.length;i++){	
		if(data[i].content.indexOf(oldsrc) != -1){
			ns = i;
		}
	}

	if($(els[1]).children('img')[0].getAttribute("dataops") == 0) {
		var imgvalue = $(els[1]).children('img')[0].getAttribute("datasrc");
		$(els[1])[0].innerHTML += '<img class="zzjz" src="'+url+'wenhe2.0/images/jiazai.gif"/>';
		clearTimeout(jzt);
		jzt = setTimeout(function() {
			$(els[1]).children('img')[0].setAttribute("dataops", 1)
			$(els[1]).children('img')[0].setAttribute("src", imgvalue);
			$(els[1]).children('img.zzjz').remove();
			console.log(ns)
			data[ns].content = imgvalue;
			
			for(var i = 0; i < itemFather.children().length; i++) {
				if(itemFather.children()[i].getAttribute("value") == imgvalue) {
					itemFather.children()[i].setAttribute("src", imgvalue);
				}
			}
			clearTimeout(jzt);
		}, 1500)
	}

	
	
	
};

//logical slider, control left or right
//逻辑滑块，向左或向右控制
iSlider.prototype._slide = function(n) {
	var data = this.data;
	var els = this.els;
	var idx = this.sliderIndex + n;
	var itemFather = this.itemFather;
	var itemNum = this.itemNum;
	if(data[idx]) {
		this.sliderIndex = idx;
	} else {
		if(this.isLooping) {
			this.sliderIndex = n > 0 ? 0 : data.length - 1;
		} else {
			n = 0;
		}
	}

	this.log('pic idx:' + this.sliderIndex);
	var sEle;
	if(this.isVertical && (this._opts.animateType == 'rotate' || this._opts.animateType == 'flip')) {} else {
		if(n > 0) {
			//删除第一个元素
			sEle = els.shift();
			//末尾添加新元素
			els.push(sEle);
		} else if(n < 0) {
			//删除最后一个元素
			sEle = els.pop();
			els.unshift(sEle);
		}
	}
	if(n !== 0) {
		sEle.innerHTML = this._renderItem(idx + n);
		sEle.style.webkitTransition = 'none';
		sEle.style.visibility = 'hidden';

		setTimeout(function() {
			sEle.style.visibility = 'visible';
		}, 200);
		this.onslidechange && this.onslidechange(this.sliderIndex);
	}	
	//下面黑白小图标
//	var span;
//	idx = idx + parseInt(itemNum);
//	if(idx==6){
//		idx=0;
//	}else if(idx==7){
//		idx=1;
//	}else if(idx==8){
//		idx=2;
//	}else if(idx==9){
//		idx=3;
//	}else if(idx==10){
//		idx=4;
//	}else if(idx==11){
//		idx=5;
//	}
//	if(span == 0) {
//		$($('#ingint').find('span')[$('#ingint').find('span').length-1]).addClass('cur');
//		$($('#ingint').find('span')[$('#ingint').find('span').length-1]).siblings().removeClass('cur');
//		span = $($('#ingint').find('span')[$('#ingint').find('span').length-1]).attr("data-count");
//	} else if(span == $('#ingint').find('span').length-1) {
//		$($('#ingint').find('span')[0]).addClass('cur');
//		$($('#ingint').find('span')[0]).siblings().removeClass('cur');
//		span = 0;
//	} else {		
//		$($('#ingint').find('span')[idx]).addClass('cur');
//		$($('#ingint').find('span')[idx]).siblings().removeClass('cur');
//		span = $($('#ingint').find('span')[idx]).attr("data-count");
//	}


//	$('#ingint').find('span')[idx].sibling().removeClass('cur').addClass('cur');
	for(var i = 0; i < 3; i++) {
		if(els[i] !== sEle) {
			els[i].style.webkitTransition = 'all .3s ease';
		}
		this._animateFunc(els[i], this.axis, this.scale, i, 0);
	}

	if(this.isAutoplay) {
		if(this.sliderIndex === data.length - 1 && !this.isLooping) {
			this.pause();
		}
	}
	
	var els = this.els;
	var data = this.data;
	var ns;
	var oldsrc = $(els[1]).children('img')[0].getAttribute("src");
	var spannum = $(els[1]).children('img')[0].getAttribute("datanum");
	$($('#ingint').find('span')[spannum]).addClass('cur');
	$($('#ingint').find('span')[spannum]).siblings().removeClass('cur');
	for(var i = 0;i<data.length;i++){	
		if(data[i].content.indexOf(oldsrc) != -1){
			ns = i;
		}
	}
	if($(els[1]).children('img')[0].getAttribute("dataops") == 0) {
		console.log(2)
		var imgvalue = $(els[1]).children('img')[0].getAttribute("datasrc");
		$(els[1])[0].innerHTML += '<img class="zzjz" src="'+url+'wenhe2.0/images/jiazai.gif"/>';
		clearTimeout(jzt);
		jzt = setTimeout(function() {
			$(els[1]).children('img')[0].setAttribute("dataops", 1)
			$(els[1]).children('img')[0].setAttribute("src", imgvalue);
			$(els[1]).children('img.zzjz').remove();
			data[ns].content = imgvalue;
			for(var i = 0; i < itemFather.children().length; i++) {
				if(itemFather.children()[i].getAttribute("value") == imgvalue) {
					itemFather.children()[i].setAttribute("src", imgvalue);
				}
			}
			clearTimeout(jzt);
		}, 1500)
	}

};

//bind all event handler
//绑定所有事件处理程序
iSlider.prototype._bindHandler = function() {
	var self = this;
	var scaleW = self.scaleW;
	var outer = self.outer;
	var len = self.data.length;
	var lenValues = self.values.length;

	var startHandler = function(evt) {
		if(evt.touches.length == 1 && self.wocao == true){
		self.twosz = false;
		self.pause();
		self.onslidestart && self.onslidestart();
		self.log('Event: beforeslide');

		self.startTime = new Date().getTime();
		self.startX = evt.targetTouches[0].pageX;
		self.startY = evt.targetTouches[0].pageY;

		var target = evt.target;
		while(target.nodeName != 'LI' && target.nodeName != 'BODY') {
			target = target.parentNode;
		}
		self.target = target;
		self.istouch = false;
		}
	};

	var moveHandler = function(evt) {
		if(self.istouch == false && self.sscale == 1){	
		evt.preventDefault();
		self.onslide && self.onslide();
		self.log('Event: onslide');

		var axis = self.axis;
		var offset = evt.targetTouches[0]['page' + axis] - self['start' + axis];

		if(!self.isLooping) {
			if(offset > 0 && self.sliderIndex === 0 || offset < 0 && self.sliderIndex === self.data.length - 1) {
				offset = self._damping(offset);
			}
		}

		for(var i = 0; i < 3; i++) {
			var item = self.els[i];
			item.style.webkitTransition = 'all 0s';
			self._animateFunc(item, axis, self.scale, i, offset);
		}

		self.offset = offset;
		}
	};

	var endHandler = function(evt) {
		if(self.istouch == false && self.sscale == 1){
		evt.preventDefault();

		var boundary = self.scale / 2;
		var metric = self.offset;
		var endTime = new Date().getTime();

		//a quick slide time must under 300ms
		//快速滑动的时间必须在300ms
		//a quick slide should also slide at least 14 px
		//滑动距离不少于14px;
		if((self.offset == 0 || self.offset == undefined)&&self.twosz==false ){
			$('#img_show').hide();
			return false;
		}
		boundary = endTime - self.startTime > 300 ? boundary : 14;

		if(metric >= boundary) {
			self._slide(-1);
		} else if(metric < -boundary) {
			self._slide(1);
		} else {
			self._slide(0);
		}
		self.gaoqin && self.gaoqin();
		self.isAutoplay && self.play();
		self.offset = 0;
		self.onslideend && self.onslideend();
		self.log('Event: afterslide');
		
		self.fangdasuoxiao();
		}
	};

	var orientationchangeHandler = function(evt) {
		setTimeout(function() {
			self.reset();
			self.log('Event: orientationchange');
		}, 100);
	};

	outer.addEventListener('touchstart', startHandler);
	outer.addEventListener('touchmove', moveHandler);
	outer.addEventListener('touchend', endHandler);
	window.addEventListener('orientationchange', orientationchangeHandler);
};

iSlider.prototype.reset = function() {
	this.pause();
	this._setting();
	this._renderHTML();
	this.isAutoplay && this.play();
};

//enable autoplay
//自动滑动时间函数
iSlider.prototype.play = function() {
	var self = this;
	var duration = this.duration;
	clearInterval(this.autoPlayTimer);
	this.autoPlayTimer = setInterval(function() {
		self._slide(1);
	}, duration);
};

//pause autoplay
//清除自动滑动
iSlider.prototype.pause = function() {
	clearInterval(this.autoPlayTimer);
};

//plugin extend
//插件扩展
iSlider.prototype.extend = function(plugin) {
	var fn = iSlider.prototype;
	Object.keys(plugin).forEach(function(property) {
		Object.defineProperty(fn, property, Object.getOwnPropertyDescriptor(plugin, property));
	})
}

//放大，缩小
iSlider.prototype.fangdasuoxiao = function() {
	var self = this;
	var els = self.els[1];
	var obj = {}; //定义一个对象
	var istouch = self.istouch,isyidong = false;
	var start = [];
	var sscale=self.sscale;
	var startx,starty;
	var sendx=0,sendy=0;
	els.addEventListener("touchstart", function(e) {		
		e.preventDefault();
		if(e.touches.length >= 2) { //判断是否有两个点在屏幕上
			istouch = true;
			self.istouch = true;
			start = e.touches; //得到第一组两个点
			self.gesturestart && self.gesturestart(); //执行gesturestart方法
		}else{
			startx = e.touches[0].pageX;
        	starty = e.touches[0].pageY;
		}
		self.wocao = true;
	}, false);
	els.addEventListener("touchmove", function(e) {
		e.preventDefault();
		if(e.touches.length >= 2 && istouch) {
			var now = e.touches; //得到第二组两个点
			var scale = self.getDistance(now[0], now[1]) / self.getDistance(start[0], start[1]); //得到缩放比例，getDistance是勾股定理的一个方法
//			var rotation = self.getAngle(now[0], now[1]) - self.getAngle(start[0], start[1]); //得到旋转角度，getAngle是得到夹角的一个方法
			scale = sscale*Math.sqrt(scale);		
			if(scale>=2.5){
				scale = 2.5;
			}
			sscale = scale;
			if(scale<=1){
				sscale = 1;
			}
//			rotation = srotation*rotation;
			self.gesturemove && self.gesturemove(els,scale); //执行gesturemove方法		
			self.twosz = true;
//			srotation = rotation;
		}else{
			
		}
	}, false);
	els.addEventListener("touchend", function(e) {
		if(istouch) {
			istouch = false;
			self.istouch = false;
			self.sscale = 0.5;
			self.gestureend && self.gestureend(els,sscale); //执行gestureend方法
			self.sscale = sscale;
			if(sscale != 1){
				isyidong = true;
			}else{
				isyidong = false;
			}
		}else{
        	var endx = e.changedTouches[0].pageX;
        	var endy = e.changedTouches[0].pageY;
        	endx = endx-startx;
        	endy = endy-starty;
        	endx = endx+sendx;
        	endy = endy+sendy;
        	var h = $(els).find('img')[0].clientHeight;
        	var w = $(els).find('img')[0].clientWidth;
        	var maxh = $(els).find('img')[0].clientHeight*sscale;
        	var maxw = $(els).find('img')[0].clientWidth*sscale;
        	if(endx>=(maxw-w)/2){
        		endx = (maxw-w)/2;
        	}
        	if(endx<=(w-maxw)/2){
        		endx = (w-maxw)/2;
        	}
        	if(endy>=(maxh-h)/2){
        		endy = (maxh-h)/2;
        	}
        	if(endy<=(h-maxh)/2){
        		endy = (h-maxh)/2;
        	}
        	if(sscale != 1){
				isyidong = true;
			}else{
				isyidong = false;
			}
        	if(isyidong == true){
        		$(els).find('img')[0].style.webkitTransform = 'translateZ(0) translateX(' + endx + 'px) translateY(' + endy + 'px) scale(' + sscale + ')';
        		sendx = endx;
        		sendy = endy;
        	}
		}
	}, false);
//	return self;
}

iSlider.prototype.getDistance = function(p1, p2) {
	var x = p2.pageX - p1.pageX,
		y = p2.pageY - p1.pageY;
	return Math.sqrt((x * x) + (y * y));
};
iSlider.prototype.getAngle = function(p1, p2) {
	var x = p1.pageX - p2.pageX,
		y = p1.pageY - p2.pageY;
	return Math.atan2(y, x) * 180 / Math.PI;
};

iSlider.prototype.gesturestart = function() { //双指开始
};
iSlider.prototype.gesturemove = function(box,es) { //双指移动
	$(box).find('img')[0].style.transform = "scale(" + es + ")"; //改变目标元素的大小和角度
};
iSlider.prototype.gestureend = function(box,es) { //双指结束
	$(box).find('img')[0].style.transform = "scale(" + es + ")";
};