// QQ表情插件

//兼容低版本的jq中  browser  属性
jQuery.browser = {};
(function() {
	//判断浏览器类型
	jQuery.browser.msie = false;
	jQuery.browser.version = 0;
	if(navigator.userAgent.match(/MSIE ([0-9]+)./)) {
		jQuery.browser.msie = true;
		jQuery.browser.version = RegExp.$1;
	}
})();
(function($) {
	$.fn.qqFace = function(options) {
		var defaults = {
			id: 'facebox',
			path: 'face/',
			assign: 'content',
			tip: 'em_'
		};
		var option = $.extend(defaults, options);
		var assign = $('#' + option.assign);
		var id = option.id;
		var path = option.path;
		var tip = option.tip;

		if(assign.length <= 0) {
			alert('缺少表情赋值对象。');
			return false;
		}

		//点击表情按钮，往表情框中循环添加表情
		$(this).click(function(e) {
			var strFace, labFace;
			if($('#' + id).length <= 0) {
				//拼接字符串
				strFace = '<div id="' + id + '" style="position:relative;display:none;z-index:1000;" class="qqFace">' +
					'<table border="0" cellspacing="0" cellpadding="0"><tr>';
				//循环添加表情			  
				for(var i = 1; i <= 75; i++) {
					labFace = '[' + tip + i + ']';
					strFace += '<td><img src="' + path + i + '.gif" onclick="$(\'#' + option.assign + '\').setCaret();$(\'#' + option.assign + '\').insertAtCaret(\'' + labFace + '\');" /></td>';
					if(i % 13 == 0) strFace += '</tr><tr>';
				}
				strFace += '</tr></table></div>';
			}
			//			父级添加表情节点
			$(this).parent().parent().append(strFace);
			console.log($(this))
//			var offset = $(this).position();
//			var top = offset.top + $(this).outerHeight();
//			//弹出框的位置
//			$('#' + id).css('top', top);
//			$('#' + id).css('left', offset.left);
			$('#' + id).show();
			e.stopPropagation();
		});
		//		点击页面其他位置,隐藏,并删除表情列表
		$('.ss_lis,#header').click(function(e){
			$('#' + id).hide();
			$('#' + id).remove();
		})
	};

})(jQuery);

jQuery.extend({
	unselectContents: function() {
		//移除光标选择的位置的位置，并做兼容
		if(window.getSelection)
			window.getSelection().removeAllRanges();
		else if(document.selection) //ie9以下
			document.selection.empty();
	}
});
jQuery.fn.extend({
	selectContents: function() {
		$(this).each(function(i) {
			var node = this;
			//添加或清除选择的内容，并对所有浏览器做兼容
			var selection, range, doc, win;
			//ownerDocument 属性以 Document 对象的形式返回节点的 owner document。
			//在 HTML 中，HTML 文档本身始终是元素的 ownerDocument。
			//defaultView是document关联的window对象，兼容Firefox 3.6
			//返回一个  Selection 对象，表示用户选择的文本范围或插入符号的当前位置。兼容IE9以上的现在主流浏览器
			//doc.createRange，兼容ie8效果等上；
			if((doc = node.ownerDocument) && (win = doc.defaultView) && typeof win.getSelection != 'undefined' && typeof doc.createRange != 'undefined' && (selection = window.getSelection()) && typeof selection.removeAllRanges != 'undefined') {
				range = doc.createRange();
				range.selectNode(node);
				if(i == 0) {
					//					removeAllRanges();清除所选内容
					selection.removeAllRanges();
				}
				//添加所选内容 addRange(range)
				selection.addRange(range);
			} else if(document.body && typeof document.body.createTextRange != 'undefined' && (range = document.body.createTextRange())) {
				//				createTextRange  主要是用来对一些文本对象进行操作.比如你有一大段文字,都在同一个P标签内,但是你只希望通过JS改变其中的一小部分,这时就可以用createTextRange来创建Range对象操作文本.因为默认情况下文本只是文本,并不是对象,要想像操作对象那样操作文本,只能是创建为Range对象.这是要操作的文本就具有了对象的功能和特性了.
				range.moveToElementText(node);
				//moveToElementText(node);  http://baike.baidu.com/link?url=lMnYz4Rkq5ECxwcw9liN0_M9uvTTa3ioeeHDJfa0CQqPC5ClErZaiqjrqrJ_1lMqSmQZkdHZAbN01pEQKa3tlZ-xWZZAIDi3aTVJb8wDpOa
				range.select();
			}
		});
	},

	setCaret: function() {
		if(!$.browser.msie) return;
		var initSetCaret = function() {
			var textObj = $(this).get(0);
			//document.selection.createRange().duplicate() 获取用户选择文本  http://www.cnblogs.com/yxyht/archive/2013/01/23/2872605.html
			textObj.caretPos = document.selection.createRange().duplicate();
		};
		$(this).click(initSetCaret).select(initSetCaret).keyup(initSetCaret);	
	},
	//caretPos 光标位置
	insertAtCaret: function(textFeildValue) {
		var textObj = $(this).get(0);
		if(document.all && textObj.createTextRange && textObj.caretPos) {
			var caretPos = textObj.caretPos;
			//charAt() 方法可返回指定位置的字符 请注意，JavaScript 并没有一种有别于字符串类型的字符数据类型，所以返回的字符是长度为 1 的字符串。
			caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == '' ?
				textFeildValue + '' : textFeildValue;
		} else if(textObj.setSelectionRange) {
			//selectionStart;  文本框中选定的文本的起始位置。
			var rangeStart = textObj.selectionStart;
			//selectionStart;  文本框中选定的文本的结束位置。
			var rangeEnd = textObj.selectionEnd;
			var tempStr1 = textObj.value.substring(0, rangeStart);
			var tempStr2 = textObj.value.substring(rangeEnd);
			textObj.value = tempStr1 + textFeildValue + tempStr2;
			textObj.focus();
			var len = textFeildValue.length;
			textObj.setSelectionRange(rangeStart + len, rangeStart + len);
			textObj.blur();
			//////
//			console.log(111)
//			var str = $("#saytext").val();
//			$("#show").html(replace_em(str));
		} else {
			textObj.value += textFeildValue;
		}
	}
});
$(function(){
	$('.emotion').qqFace({
		id : 'facebox', //表情盒子的ID
		assign:'saytext', //给那个控件赋值
		path:'face/'	//表情存放的路径
	});
});
