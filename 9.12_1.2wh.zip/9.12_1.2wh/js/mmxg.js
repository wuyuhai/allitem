$('#phonenum').on('blur', function() {
	if(phoneyz() == false) {
		$('#phonenum').next().fadeIn();
		var t2 = setInterval(function() {
			$('#phonenum').next().fadeOut();
			clearInterval(t2);
		}, 1500)
	}
})

//phone手机
function phoneyz() {
	var reg = /^1[3|4|5|7|8][0-9]{9}$/; //验证规则
	var l = reg.test($('#phonenum')[0].value);
	return l;
}

function yzm() {
	$('.huoquyzm').unbind('click').on('click', function() {
		if(phoneyz() == true) {
			time($('.huoquyzm'))
		} else {
			alert('该手机号不存在，或输错')
		}
	})
}
yzm()
//再次获取验证码
var timebol = true;

function time(obj) {
	var num = 60;
	if(timebol) {
		timebol = false;
		var timer = setInterval(function() {
			num--;
			if(num > 0) {
				obj.get(0).innerHTML = num + "s";
			} else {
				clearInterval(timer);
				obj.get(0).innerHTML = '获取验证码';
				timebol = true
			}
		}, 1000)
	}
}

//密码验证
function mimayz(){
	var bol;
	if($('#passwordone')[0].value.length >=6 && $('#passwordone')[0].value != ""){
		bol = true;
	}else{
		bol = false;
	}
	return bol;
}
$('.mmsure').unbind('click').on('click',function(){
	if(mimayz() == false){
		$('#passwordone').next().fadeIn();
		var t5 = setInterval(function(){
			$('#passwordone').next().fadeOut();
			clearInterval(t5);
		},1500)
	}
	if($('#sryzm')[0].value == ""){
		$('#sryzm').next().fadeIn();
		var t6 = setInterval(function(){
			$('#sryzm').next().fadeOut();
			clearInterval(t6);
		},1500)
	}
		
	if(phoneyz() == true && mimayz() == true && $('#sryzm')[0].value != ""){
		alert('手机号码' + $('#phonenum')[0].value +
			'输入的验证码' + $('#sryzm')[0].value +
			'新密码' + $('#passwordone')[0].value);
		//发送请求
//		$.get
		var errcode = 0;
		if(errcode == 0){
			//if(y验证码和信息验证正确)	
		}
	}
})
