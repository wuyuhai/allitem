
//1.0.2.1文本框字数限制输入
function textlength(obj1, num) {
	var lenInput = obj1.val().length;
	obj1.keyup(function() {
		lenInput = $(this).val().length;
		if(lenInput >= 0 && lenInput <= num) {
			obj1.next().find('.textareaInput').html(lenInput);
		}	
	});
}
textlength($('#str_nameinput'), 20);

//1.0.2字数修正函数
function textlength_els(obj1) {
	var lenInput = obj1[0].value.length;
	console.log(obj1[0].value)
	obj1.next().find('.textareaInput').html(lenInput);
}
textlength_els($('#str_nameinput'))

//三级城市选择
var name1, fidpro,name2,fid,name3;
$('.dorpdown-province').unbind('click').on('click', 'li', function() {	
	var jyname = $(this)[0].innerText;
	if($(this).attr('value') == undefined) {
		$('.dorpdown-province').html('');
		$.each(city, function(i, item) {
			if(item.province_id == 4) {
				$('.dorpdown-province').append('<li value="' + item.province_id + '" class="cur">' + item.province_name + '</li>')
			} else {
				$('.dorpdown-province').append('<li value="' + item.province_id + '">' + item.province_name + '</li>')
			}
		});
	} else {
		$(this).addClass('cur').siblings().removeClass('cur');
		var item = $(this);
		fidpro = item.attr('value');
		name1 = item[0].innerText;
		var itemparent = $(this).parent()
		$(this).parent().html("");
		itemparent[0].innerHTML = '<li>' + name1 + '</li>';
		$('ul.dorpdown-city')[0].innerHTML = '<li>未选择</li>';
		$('ul.dorpdown-zhen')[0].innerHTML = '<li>未选择</li>';
	}
	$("#contant").unbind('click').on('click','div,ul',function(){		
		console.log(1)
		if($(this)[0].className.indexOf("dorpdown-province") == -1){
			$('.dorpdown-province').html("");
			$('.dorpdown-province')[0].innerHTML = "<li>" + jyname + "</li>"
		}
	})
})
$('ul.dorpdown-city').unbind('click').on('click', 'li', function() {
	var jyname = $(this)[0].innerText;
	if($(this).attr('value') == undefined) {
		var citylis = city[fidpro-4].cities;
		$('.dorpdown-city').html('');
		$('.dorpdown-city').append('<li>未选择</li>');
		for(i = 0; i < citylis.length; i++) {
			$('.dorpdown-city').append('<li val="' + i + '" value="' + citylis[i].city_id + '">' + citylis[i].city_name + '</li>')
		}
		console.log(2)
	}else{
		console.log(1)
		$(this).addClass('cur').siblings().removeClass('cur');
		var item = $(this);
		fid = item.attr('val');
		name2 = item[0].innerText;
		var itemparent = $(this).parent()
		$(this).parent().html("");
		itemparent[0].innerHTML = '<li>' + name2 + '</li>';
		$('ul.dorpdown-zhen')[0].innerHTML = '<li>未选择</li>';
	}
	$("#contant").unbind('click').on('click','div,ul',function(){		
		console.log(1)
		if($(this)[0].className.indexOf("dorpdown-province") == -1){
			$('.dorpdown-city').html("");
			$('.dorpdown-city')[0].innerHTML = "<li>" + jyname + "</li>"
		}
	})
});
$('ul.dorpdown-zhen').on('click', 'li', function() {
	var jyname = $(this)[0].innerText;
	if($(this).attr('value') == undefined) {
		var zhenlis = city[fidpro-4].cities[fid].areas;
		$('.dorpdown-zhen').html('');
		for(i = 0; i < zhenlis.length; i++) {
			$('.dorpdown-zhen').append('<li value="' + zhenlis[i].id + '">' + zhenlis[i].name + '</li>')
		}
		console.log(1)
	}else{
		console.log(1)
		name3 = $(this)[0].innerText;
		var itemparent = $(this).parent()
		$(this).parent().html("");
		itemparent[0].innerHTML = '<li>' + name3 + '</li>';
	}
	$("#contant").unbind('click').on('click','div,ul',function(){		
		console.log(1)
		if($(this)[0].className.indexOf("dorpdown-province") == -1){
			$('ul.dorpdown-zhen').html("");
			$('ul.dorpdown-zhen')[0].innerHTML = "<li>" + jyname + "</li>"
		}
	})			
});


//详细地址
$('#xxdz_input').unbind('click').on('click',function(){
	console.log(1)
	if($('ul.dorpdown-zhen').find('li')[0].innerText == "未选择"){
			console.log(2)
		alert('请先填写城镇地址')
		$(this).blur();
	}
})

$('.sq_btn_yes').unbind('click').on('click',function(){
	if($('#str_nameinput')[0].value == ""){
		alert("店铺名称未填");
	};
	if($('#xxdz_input')[0].value == ""){
		alert("店铺详细地址未填");
	}
	if($('#str_nameinput')[0].value != "" && $('#xxdz_input')[0].value != ""){
		var imgstr;
		if($('#store_img').children('img').attr('src') == "img/dainpul.png"){
			imgstr = "images/logo.gif";
		}else{
			imgstr = preview(document.getElementById("djsc_input")).value
		}				
		alert("店铺图片" + imgstr +"；店铺名称" + $('#str_nameinput')[0].value + "；店铺位置" +
			$('.dorpdown-province').find('li')[0].innerText + 
			$('.dorpdown-city').find('li')[0].innerText + 
			$('.dorpdown-zhen').find('li')[0].innerText + 
			";详细地址" + $('#xxdz_input')[0].value);
		
		//发送请求
		//￥。get
		var errcode = 0;
		if(errcode == 0){
			alert('发送申请中，请稍等')
		}
	}
})

$('.xgsure').unbind('click').on('click',function(){
	if($('#str_nameinput')[0].value == ""){
		alert("店铺名称未填");
	};
	if($('#xxdz_input')[0].value == ""){
		alert("店铺详细地址未填");
	}
	if($('#str_nameinput')[0].value != "" && $('#xxdz_input')[0].value != ""){
		var synum = + $('.xg_count')[0].innerText;
		var imgstr;
		if($('#store_img').children('img').attr('src') == "img/dainpul.png"){
			imgstr = "images/logo.gif";
		}else{
			imgstr = preview(document.getElementById("djsc_input")).value
		}				
		alert("店铺图片" + imgstr +"；店铺名称" + $('#str_nameinput')[0].value + "；店铺位置" +
			$('.dorpdown-province').find('li')[0].innerText + 
			$('.dorpdown-city').find('li')[0].innerText + 
			$('.dorpdown-zhen').find('li')[0].innerText + 
			";详细地址" + $('#xxdz_input')[0].value);
		
		//发送请求
		//￥。get
		var errcode = 0;
		if(errcode == 0){
			alert('发送申请中，请稍等');
			$('.xg_count')[0].innerText = synum-1;
		}
	}
})



