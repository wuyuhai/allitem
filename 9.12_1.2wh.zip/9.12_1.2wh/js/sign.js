$('button', $('.ljdl')).unbind('click').on('click', function() {
	if(phoneyz() == false) {
		$('.phone').find('.tishi').fadeIn();
		var t1 = setInterval(function() {
			$('.phone').find('.tishi').fadeOut();
			clearInterval(t1);
		}, 1500)
	}
	if(mimayz() == false) {
		$('.password').find('.tishi').fadeIn();
		var t2 = setInterval(function() {
			$('.password').find('.tishi').fadeOut();
			clearInterval(t2);
		}, 1500)
	}
	if($('#yz_code')[0].value == "") {
		$('.yzcode').find('.tishi').fadeIn();
		var t3 = setInterval(function() {
			$('.yzcode').find('.tishi').fadeOut();
			clearInterval(t3);
		}, 1500)
	}
	if(phoneyz() == true && mimayz() == true && $('#yz_code')[0].value != "" && validate() == true) {
		alert('手机号码' + $('#phonenum')[0].value +
			'密码' + $('#phonepassword')[0].value +
			'输入的验证码' + $('#yz_code')[0].value)
		//发送请求
		//￥。get
		var eodecode = 0
		if(eodecode == 0) {
			gnkan()
			//
		} else {
			alert('网络打酱油去了')
		}
	}

})

//phone手机
function phoneyz() {
	var reg = /^1[3|4|5|7|8][0-9]{9}$/; //验证规则
	var l = reg.test($('#phonenum')[0].value);
	return l;
}
//密码验证
function mimayz() {
	var bol;
	if($('#phonepassword')[0].value.length >= 6 && $('#phonepassword')[0].value != "") {
		bol = true;
	} else {
		bol = false;
	}
	return bol;
}

//验证码
window.onload = function() {
	createCode();
}

function createCode() {
	code = "";
	var codeLength = 5; //验证码的长度     
	var checkCode = document.getElementById("checkCode");
	var random = new Array(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R',
		'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'); //随机数     
	for(var i = 0; i < codeLength; i++) { //循环操作     
		var charIndex = Math.floor(Math.random() * 36); //取得随机数的索引     
		code += random[charIndex]; //根据索引取得随机数加到code上     
	}
	checkCode.value = code; //把code值赋给验证码     
}
//校验验证码     
function validate() {
	var inputCode = document.getElementById("yz_code").value.toUpperCase(); //取得输入的验证码并转化为大写           
	if(inputCode.length <= 0) { //若输入的验证码长度为0     
		alert("请输入验证码！"); //则弹出请输入验证码     
	} else if(inputCode != code) { //若输入的验证码与产生的验证码不一致时     
		alert("验证码输入错误！"); //则弹出验证码输入错误     
		createCode(); //刷新验证码     
	} else { //输入正确时     
//		alert("^-^"); //弹出^-^ 
		return true
	}
}

//记住密码自动登陆
$('.gnk_mm').unbind('click').on('click',function(){
	if($(this).find('.zhuangtai').attr('value') == 0){
		$(this).find('.zhuangtai').attr('value',1)
		$(this).find('.zhuangtai')[0].innerHTML = '<img src="images/7b4.png"/>';
		$(this).siblings().find('.zhuangtai').attr('value',0);
		$(this).siblings().find('.zhuangtai')[0].innerHTML = '<img src="images/7b5.png"/>';
		if($(this).find('.zddl_sure').length != 0){
			$(this).siblings().find('.zhuangtai').attr('value',1);
			$(this).siblings().find('.zhuangtai')[0].innerHTML = '<img src="images/7b4.png"/>';
		}
	}else{
		$(this).find('.zhuangtai').attr('value',0)
		$(this).find('.zhuangtai')[0].innerHTML = '<img src="images/7b5.png"/>';
	}
})
function gnkan(){
	for(var i = 0;i<$('.gnk_mm').length;i++){
		console.log(11)
		if($($('.gnk_mm')[i]).find('.zhuangtai').attr('value') == 1){
			console.log(11)
			alert($($('.gnk_mm')[i]).find('.zhuangtai').next()[0].innerText)
		}
	}		
}