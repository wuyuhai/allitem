//1.0.2.1
//右边框位置
//$('.ss_right').css({
//	'padding-top': $('.lis_li_img').find('img')[0].clientHeight / 2 - 7 + 'px'
//})

//控制评论的高度
function khbx() {
	//				width:document.documentElement.clientHeight
	//超出显示全文按钮显现
	for(var i = 0; i < $('.fr_ss').length; i++) {
		if($('.fr_ss')[i].scrollHeight > 120) {
			$($('.fr_ss')[i]).parent().find('.more').show()
		}
	}
	for(var i = 0; i < $('.pls_one_xx').length; i++) {
		if($('.pls_one_xx')[i].scrollHeight > 60) {
			$($('.pls_one_xx')[i]).parent().find('.more_yi').show()
		}
	}
	for(var i = 0; i < $('.pls_two_xx').length; i++) {
		if($('.pls_two_xx')[i].scrollHeight > 60) {
			$($('.pls_two_xx')[i]).parent().find('.more_er').show()
		}
	}
}
khbx()

//判断是否已经登陆，未登陆跳转倒登陆页面
var bol;
if($('#header').find('.sign_zc').length != 0) {
	bol = false;
}
$('.sign_go').unbind('click').on('click', function() {
	if(bol == false) {
		document.location = 'sign.html';
	}
})

//一级展开更多
function more(ob) {
	ob.unbind('click').on('click', function() {
		console.log($(this).parent().find('.fr_ss').css('-webkit-line-clamp'))
		if($(this).parent().find('.fr_ss').css('-webkit-line-clamp') == 6) {
			$(this).parent().find('.fr_ss').css({
				'-webkit-line-clamp': "100"
			})
			$(this)[0].innerHTML = "收起" + "<img src='images/icon0-2.png'>";
			console.log(111)
		} else {
			$(this).parent().find('.fr_ss').css({
				'-webkit-line-clamp': "6"
			})
			$(this)[0].innerHTML = "全文" + "<img src='images/icon-0.png'>";
		}
	})
}
more($('.fr_ss_more'))

//二级，三级展开更多
$('.fr_pls_ul').unbind('click').on('click', '.more_yi', function() {
	console.log($(this).parent().parent().find('.pls_one_xx').css('-webkit-line-clamp'))
	if($(this).parent().parent().find('.pls_one_xx').css('-webkit-line-clamp') == 3) {
		$(this).parent().parent().find('.pls_one_xx').css({
			'-webkit-line-clamp': "100"
		})
		$(this)[0].innerHTML = "收起" + "<img src='images/icon0-2.png'>";
	} else {
		$(this).parent().parent().find('.pls_one_xx').css({
			'-webkit-line-clamp': "3"
		})
		$(this)[0].innerHTML = "展开" + "<img src='images/icon-0.png'>";
	}
})

$('body').unbind('click').on('click', '.more_er', function() {
	if($(this).parent().parent().find('.pls_two_xx').css('-webkit-line-clamp') == 3) {
		$(this).parent().parent().find('.pls_two_xx').css({
			'-webkit-line-clamp': "100"
		})
		$(this)[0].innerHTML = "收起" + "<img src='images/icon0-2.png'>";
	} else {
		$(this).parent().parent().find('.pls_two_xx').css({
			'-webkit-line-clamp': "3"
		})
		$(this)[0].innerHTML = "展开" + "<img src='images/icon-0.png'>";
	}
})

//点赞
//$('.dianzan').unbind('click').on('click', function() {
//	//发送请求
//	//$.get
//	var err_code = 0;
//	if(err_code == 0) {
//		var num = +$('.dianzan_num')[0].innerText;
//		if($(this)[0].innerHTML.indexOf('7b24.png') != -1) {
//			num = num - 1;
//			$(this)[0].innerHTML = "<img src='images/icon1-2.png'/><span class='dianzan_num'>" + num + "</span>";
//		} else {
//			num = num + 1
//			$(this)[0].innerHTML = "<img src='images/7b24.png'/><span class='dianzan_num'>" + num + "</span>";
//		}
//	} else {
//		alert("网咯坑爹了")
//	}
//})

//评论输入框换行
var autoTextarea = function(elem, extra, maxHeight) {
	extra = extra || 0;
	var isFirefox = !!document.getBoxObjectFor || 'mozInnerScreenX' in window,
		isOpera = !!window.opera && !!window.opera.toString().indexOf('Opera'),
		addEvent = function(type, callback) {
			elem.addEventListener ?
				elem.addEventListener(type, callback, false) :
				elem.attachEvent('on' + type, callback);
		},
		getStyle = elem.currentStyle ? function(name) {
			var val = elem.currentStyle[name];

			if(name === 'height' && val.search(/px/i) !== 1) {
				var rect = elem.getBoundingClientRect();
				return rect.bottom - rect.top -
					parseFloat(getStyle('paddingTop')) -
					parseFloat(getStyle('paddingBottom')) + 'px';
			};

			return val;
		} : function(name) {
			return getComputedStyle(elem, null)[name];
		},
		minHeight = parseFloat(getStyle('height'));

	elem.style.resize = 'none';

	var change = function() {
		var scrollTop, height,
			padding = 0,
			style = elem.style;

		if(elem._length === elem.value.length) return;
		elem._length = elem.value.length;

		if(!isFirefox && !isOpera) {
			padding = parseInt(getStyle('paddingTop')) + parseInt(getStyle('paddingBottom'));
		};
		scrollTop = document.body.scrollTop || document.documentElement.scrollTop;

		elem.style.height = minHeight + 'px';
		if(elem.scrollHeight > minHeight) {
			if(maxHeight && elem.scrollHeight > maxHeight) {
				height = maxHeight - padding;
				style.overflowY = 'auto';
			} else {
				height = elem.scrollHeight - padding;
				style.overflowY = 'hidden';
			};
			style.height = height + extra + 'px';
			scrollTop += parseInt(style.height) - elem.currHeight;
			document.body.scrollTop = scrollTop;
			document.documentElement.scrollTop = scrollTop;
			elem.currHeight = parseInt(style.height);
			//			1.0.2.1
			if($('#saytext').val() != "") {
				$('.chat_fs').css({
					background: "#1e8ae8",
				})
			} else {
				$('.chat_fs').css({
					background: "#DCDCDC",
				})
			}
		};
	};

	addEvent('propertychange', change);
	addEvent('input', change);
	addEvent('focus', change);
	change();
};
var text = document.getElementById("saytext");
autoTextarea(text); // 调用

function pinglun(ob) {
	$('#fasong_sure').unbind('click').on('click', '.sub_btn', function() {
		//	$('button.sub_btn', $('#fasong_sure')).unbind('click').on('click', function() {
		if($("#saytext").val() != "") {
			var divhtml
			divhtml = '<div class="fr_pls_one">' +
				'<div>' +
				'<div class="pls_one_xx">' +
				'<a class="pls_one_name" href="geren.html">沙皮:</a>' +
				'<a class="sign_go">' +
				'<span class="pl_ctt">' +
				$("#saytext").val() +
				'</span>' +
				'</a>' +
				'</div>' +
				'<div>' +
				'<span class="more more_yi">展开<img src="images/icon-0.png" alt="" /></span>' +
				'<span class="pl_jlme">距我8km</span>' +
				'</div>' +
				'<ul class="erjipl_ul">' +
				'</ul>' +
				'<div class="sjmorepl">更多回复<img src="images/icon-0.png" alt="" /></div>' +
				'</div>' +
				'</div>';
			var lis = document.createElement('li');
			lis.innerHTML = divhtml;
			lis.setAttribute('value', '1');
			//发送请求
			//	$.get
			var errcoed = 0;
			if(errcoed == 0) {
				ob.get(0).appendChild(lis);
				//			var st = $(ob).find('.pl_ctt')[0]
				//			console.log(st)
				console.log($(ob).find('.pl_ctt').length)
				var i = $(ob).find('.pl_ctt').length - 1;
				var str = $(ob).find('.pl_ctt')[i].innerHTML;
				$(ob).find('.pl_ctt')[i].innerHTML = replace_em(str);
				$("#saytext")[0].value = "";
				$('#pl_kuang').hide();
				khbx();
			}
		}
	})
}

//一级评论
$('body').on('click', '.pinglun', function() {
	console.log(111)
	var item = $(this).parents('.ss_right');
	$('#pl_kuang').show();
	$('#saytext').focus();
	pinglun(item.find('.fr_pls_ul'));
})

//二级评论
$('body').on('click', '.pl_ctt', function() {
	var item = $(this).parents('.fr_pls_one');
	$('#pl_kuang').show();
	$('#saytext').focus();
	var divhtmlt = "";
	divhtmlt += '<div class="fr_pls_two">' +
		'<div class="pls_two_xx">' +
		'<a class="pls_pwo_name" href="geren.html" value="1">大西瓜</a>';
	erjipinglun(item.find('.erjipl_ul'), divhtmlt);
})

//二级子评论回复
$('body').on('click', '.pltwo_ctt', function() {
	var item = $(this).parents('.fr_pls_one');
	$('#pl_kuang').show();
	$('#saytext').focus();
	var divhtmlt = "";
	divhtmlt += '<div class="fr_pls_two">' +
		'<div class="pls_two_xx">' +
		'<a class="pls_pwo_name" href="geren.html" value="1">小西瓜</a>回复' +
		'<a class="pls_pwo_name" href="geren.html" value="1">大西瓜</a>';
	erjipinglun(item.find('.erjipl_ul'), divhtmlt);
})

function erjipinglun(ob, divhtmlt) {
	//	$('button.sub_btn', $('#fasong_sure')).unbind('click').on('click', function() {
	$('#fasong_sure').unbind('click').on('click', '.sub_btn', function() {
		divhtmlt += '<span class="pltwo_ctt" value="1">' +
			$("#saytext").val() +
			'</span>' +
			'</div>' +
			'<div>' +
			'<span class="more more_er">展开<img src="images/icon-0.png" alt="" /></span>' +
			'<span class="pl_jlme">距我8km</span>' +
			'</div>' +
			'</div>';
		var list = document.createElement('li');
		list.innerHTML = divhtmlt;
		list.setAttribute('value', '1');
		//发送请求
		//	$.get
		var errcoed = 0;
		if(errcoed == 0) {
			ob.get(0).appendChild(list);
			console.log($(ob).find('li').length)
			var i = $(ob).find('li').length - 1;
			var str = $(ob).find('.pltwo_ctt')[i].innerHTML;
			$(ob).find('.pltwo_ctt')[i].innerHTML = replace_em(str);
			$("#saytext")[0].value = "";
			console.log(1)
			$('#pl_kuang').hide();
		}
	})
}

//表情转换
function replace_em(str) {
	str = str.replace(/\</g, '&lt;');
	str = str.replace(/\>/g, '&gt;');
	str = str.replace(/\n/g, '<br/>');
	str = str.replace(/\[em_([0-9]*)\]/g, '<img src="face/$1.gif" border="0" />');
	return str;
}

//1.0.1加载更多
//加载更多
//加载更多
//var T = 0;
//$(window).scroll(function() {
//	T = $(document).scrollTop();
//	if(T >= $('body')[0].scrollHeight - document.documentElement.clientHeight) {
//		//		发送请求
//		//     ￥。get
//		var err_code = 0;
//		if(err_code == 0) {
//			for(var i = 0; i < 15; i++) {
//				var divhtml = '<div class="fr_pls_one">' +
//					'<div>' +
//					'<div class="pls_one_xx">' +
//					'<a class="pls_one_name" href="geren.html" value="1">沙皮:</a>' +
//					'<span class="pl_ctt sign_go" value="1">阿娇阿斯洛克打算离兄弟今天晚上我们撸串，管饱的那种，附近有要约的吗兄弟今天晚上我们撸串，管饱的那种，附近有要约的吗兄弟今天晚上我们撸串，管饱的那种，附近有要约的吗兄弟今天晚上我们撸串，管饱的那种，附近有要约的吗兄弟今天晚上我们撸串，管饱的那种，附近有要约的吗开的</span>' +
//					'<span>距我8km</span>' +
//					'</div>' +
//					'<div class="zkmore">' +
//					'<span class="more more_yi">展开<img src="images/icon-0.png" alt="" /></span>' +
//					'<span class="pl_jlme">距我8km</span>' +
//					'</div>' +
//					'<ul class="erjipl_ul">' +
//					'</ul>' +
//					'</div>' +
//					'</div>';
//				var lis = document.createElement('li');
//				lis.innerHTML = divhtml;
//				lis.setAttribute('value', i);
//				$('.fr_pls_ul').append(lis);
//			}
//			khbx()
//		}
//	}
//});

//删除说说或评论
$('#contant').unbind('click').on('click', '.yc_pltwo,.yc_pl,.yc_ss', function() {
	console.log($(this))
	if($(this)[0].className == "yc_ss") {
		var item = $(this).parents('.ss_lis_li');
		alert(item.attr('value'));
		//发送请求
		//￥。get
		var errcode = 0;
		if(errcode == 0) {
			item.remove();
		}
	}
	if($(this)[0].className == "yc_pl") {
		var itempl = $(this).parent().parent().parent().parent();
		console.log(item)
		alert(itempl.attr('value'));
		//发送请求
		//￥。get
		var errcode = 0;
		if(errcode == 0) {
			itempl.remove();
		}
	}
	if($(this)[0].className == "yc_pltwo") {
		var itemtwo = $(this).parent().parent().parent();
		alert(itemtwo.attr('value'));
		//发送请求
		//￥。get
		var errcode = 0;
		if(errcode == 0) {
			itemtwo.remove();
		}
	}

})

//加载中

//评论定位
//导航定位
//导航定位
var nav = (function(navObj) {
	navObj.init = function() {
		this.n = 0;
		this.offsetTop = [];
		this.scrolltype = true;
		for(var i = 0; i < $('li').length; i++) {
			this.offsetTop.push($('li').eq(i).offset().top);
		};
		navObj.bindE();
	};
	navObj.bindE = function() { //滚动条滚动改变导航元素效果
		var self = this; //这里的this等同于上面的this	

		//
		//
		//传过来的value 
		var value = 5;
		self.n = value;
		self.scrolltype = false;
		var t = self.offsetTop[self.n]
		console.log(t)
		if(t > document.documentElement.clientHeight + $('#header')[0].clientHeight - self.offsetTop[0]) {
			t = t - $('#header')[0].clientHeight - document.documentElement.clientHeight + self.offsetTop[0];
		} else {
			t = 0;
		}
		$('body').animate({
			scrollTop: t
		}, 500, function() { //   滚动条滚动 页面不同内容的offsetTop值实现按钮对应效果
			self.scrolltype = true;
		})
	};
	return navObj;
})(window.navObj || {});
nav.init();

function wocao(value,obj) {
	var ite = obj.parents('.ss_lis_li')
	for(var i = 0; i < ite.find('.test_li').length;i++){
		if($(ite.find('.test_li')[i]).attr('value') == value){
			var str = ite.find('.test_li')[i].innerText.substring(0,1);
		}
	}
	return str;
}
$('body').on('click', '.test_li,.test_tijiao,.dianzan,.cai', function() {
	if(this.className.indexOf("test_li") != -1) {
		if($(this).parents('.ss_lis_li').attr('datatesthadxz') != 1) {
			alert($(this).attr('value'));
			var itemvalue = $(this).attr('value');
			if($(this).find('img').attr('src') == 'img/yixuan.gif') {
				$(this).find('img').attr('src', 'img/weixuan.gif')
				$(this).parents(".ss_right").find('.test_tijiao').attr('datahad', '0');
				$(this).parents(".ss_right").find('.test_tijiao').css('background-color', 'gainsboro');
			} else {
				$(this).find('img').attr('src', 'img/yixuan.gif')
				$(this).siblings().find('img').attr('src', 'img/weixuan.gif');
				$(this).parents(".ss_right").find('.test_tijiao').attr('datahad', '1');
				$(this).parents(".ss_right").find('.test_tijiao').css('background-color', '#4cd627');
				$(this).parents(".ss_right").find('.test_tijiao').attr('datavalue', itemvalue);
			}
		}
	}

	if(this.className.indexOf("test_tijiao") != -1) {
		if($(this).attr('datahad') == 1) {
			var item = $(this); 
			var itemparents = $(this).parents('.ss_lis_li');
			var num = +itemparents.find('.tjg_div_num')[0].innerText;
			var datatestvalue = $(this).parents('.ss_lis_li').attr('datatestvalue')
			var datavalue = $(this).attr('datavalue')
			alert('测试题为' + datatestvalue + ",选择的题目" + datavalue);
			//发送i请求
			//$.get
			var errcode = 0;
			if(errcode == 0) {
				//
				alert("你真棒");
				$(this).parents('.ss_lis_li').attr('datatesthadxz', '1')
				$(this).hide();
				$('.tjg_p')[0].innerHTML = '<span>我选择了</span><span>' + wocao(datavalue,item) + ':</span><span>' + '你现在是该加油的时候了，有时候需要学会忍耐，相信自己一定可以克服过来' + '</span>'
				$('.tjg_div_num')[0].innerText = num + 1;
				$('#test-anwser').show();
				$('.anwser-xx')[0].innerText = "";
				//根据所做的测试题和选择的答案请求到的结果写入
				$('.anwser-xx')[0].innerText = '你现在需要学会忍耐了，你在不好好女里，你会法眼你他妈连母猿都娶不起，不是我说你，你已经跟你现在需要学';
				$('.anwser-zz').unbind('click').on('click',function(){
					$('#test-anwser').hide();
				})
			}
		}
	}
	
	if(this.className.indexOf("dianzan") != -1) {
		var value = $(this).parents('.ss_lis_li').attr('value')
		alert(value)
		//发送请求
		//$.get
		var err_code = 0;
		if(err_code == 0) {	
			var num = +$(this).parents('.ss_lis_li').find('.dianzan_num')[0].innerText;
			var num2 = +$(this).parents('.ss_lis_li').find('.cai_num')[0].innerText;
			if($(this)[0].innerHTML.indexOf('img/zan.gif') != -1) {
				num = num - 1;
				$(this)[0].innerHTML = "<img src='images/icon1-2.png'/><span class='dianzan_num'>" + num + "</span>";
			} else {
				if($(this).parents('.ss_lis_li').find('.cai')[0].innerHTML.indexOf('img/cai.gif') != -1) {
					num2 = num2 - 1;
					$(this).parents('.ss_lis_li').find('.cai')[0].innerHTML = "<img src='img/caihui.gif'/><span class='cai_num'>" + num2 + "</span>";
				}
				num = num + 1
				$(this)[0].innerHTML = "<img src='img/zan.gif'/><span class='dianzan_num'>" + num + "</span>";
			}
		} else {
			alert("网咯坑爹了")
		}
	}
	if(this.className.indexOf("cai") != -1) {
		var value = $(this).parents('.ss_lis_li').attr('value')
		alert(value)
		//发送请求
		//$.get
		var err_code = 0;
		if(err_code == 0) {
			var num = +$(this).parents('.ss_lis_li').find('.dianzan_num')[0].innerText;
			var num2 = +$(this).parents('.ss_lis_li').find('.cai_num')[0].innerText;
			if($(this)[0].innerHTML.indexOf('img/cai.gif') != -1) {
				num2 = num2 - 1;
				$(this)[0].innerHTML = "<img src='img/caihui.gif'/><span class='cai_num'>" + num2 + "</span>";
			} else {
				if($(this).parents('.ss_lis_li').find('.dianzan')[0].innerHTML.indexOf('img/zan.gif') != -1) {
					num = num - 1;
					$(this).parents('.ss_lis_li').find('.dianzan')[0].innerHTML = "<img src='images/icon1-2.png'/><span class='dianzan_num'>" + num + "</span>";
				}
				num2 = num2 + 1
				$(this)[0].innerHTML = "<img src='img/cai.gif'/><span class='cai_num'>" + num2 + "</span>";
			}
		} else {
			alert("网咯坑爹了")
		}
	}
})