//修改名字
$('.bodyname').unbind('click').on('click', function() {
	$('.bodyname_kuang').show();
	$('.name_input')[0].value = $('span.name', $('.bodyname'))[0].innerText;
	$('button', $('#bodyname_sure')).unbind('click').on('click', function() {
		if($('.name_input')[0].value == "") {
			alert('昵称不能为空')
		} else if($('.name_input')[0].value == $('span.name', $('.bodyname'))[0].innerText) {
			$('.bodyname_kuang').hide();
		} else {
			alert($('.name_input')[0].value)
			//发送请求
			//$.get
			var errcode = 0;
			if(errcode == 0) {
				$('span.name', $('.bodyname'))[0].innerText = $('.name_input')[0].value;
				$('.bodyname_kuang').hide();
			}
		}
	})
})
//修改性别
$('.sex_xg').unbind('click').on('click', function() {
	$('.xingbie_k').show();
	$('div', $('.xiugai_sex')).unbind('click').on('click', function() {
		console.log($(this).attr('value'))
		//发送请求
		//		$.get
		var errcodr = 0;
		if(errcodr == 0) {
			$(this).find('span')[1].innerHTML = '<img src="img/xb_lan.png"/>';
			$(this).siblings().find('span')[1].innerHTML = '<img src="img/xb_hui.png"/>';
			$('.sex')[0].innerText = $(this).find('span')[0].innerText;
			$('.xingbie_k').hide();
		}
	})
	$('.zz_k').unbind('click').on('click', function() {
		$('.xingbie_k').hide();
	})
})

//个性签名
$('.gx_ss').unbind('click').on('click', function() {
	$('.qianming_k').show();
	//	1.0.2.1
	$('.qianming_text')[0].value = $('span.gx_say', $('.gx_ss'))[0].innerText;
	textlength_els($('.qianming_text'));
	$('button', $('.gx_ss_sure')).unbind('click').on('click', function() {
		if($('.qianming_text')[0].value == $('span.gx_say', $('.gx_ss'))[0].innerText) {
			$('.qianming_k').hide();
		} else {
			alert($('.qianming_text')[0].value)
			//发送请求
			//$.get
			var errcode = 0;
			if(errcode == 0) {
				$('span.gx_say', $('.gx_ss'))[0].innerText = $('.qianming_text')[0].value;
				$('.bodyname_kuang').hide();
				$('.qianming_k').hide();
			}
		}
	})
})

//修改密码
$('.password_ye').unbind('click').on('click', function() {
	$('.passwordxiugai').show();
	$('button', $('.psw_sure')).unbind("click").on('click', function() {
		if(mimayz($('#oldpw')[0]) == false) {
			$('#oldpw').next().fadeIn();
			var t1 = setInterval(function() {
				$('#oldpw').next().fadeOut();
				clearInterval(t1);
			}, 1500)
		}
		if(mimayz($('#newpw')[0]) == false) {
			$('#newpw').next().fadeIn();
			var t2 = setInterval(function() {
				$('#newpw').next().fadeOut();
				clearInterval(t2);
			}, 1500)
		}
		if($('#newpw')[0].value != $('#newpwtwo')[0].value) {
			$('#newpwtwo').next().fadeIn();
			var t2 = setInterval(function() {
				$('#newpwtwo').next().fadeOut();
				clearInterval(t2);
			}, 1500)
		}
		if(mimayz($('#oldpw')[0]) == true && mimayz($('#newpw')[0]) == true && mimayz($('#newpwtwo')[0]) == true && $('#newpwtwo')[0].value == $('#newpw')[0].value) {
			alert('旧密码' + $('#oldpw')[0].value + '新密码' + $('#newpw')[0].value);
			if($('#oldpw')[0].value == $('#newpw')[0].value) {
				alert('旧密码和新密码相同，修改失败')
			} else {
				//发送请求
				//$/get
				var errcode = 0;
				if(errcodr == 0) {

				}
			}

		}
	})
})

//密码验证
function mimayz(ob) {
	var bol;
	if(ob.value.length >= 6 && ob.value != "") {
		bol = true;
	} else {
		bol = false;
	}
	return bol;
}

//距离框
var w = ($('body')[0].clientWidth*0.665);
$('.juli_div').unbind('click').on('click', function() {
	$('.juli_k').show();
	var date0 = 25,
		date1 = 40;
		console.log(w)
		$('.left_hk').css({
			left: (((date0 * w) / 50) - 14) + 'px'
		})
		$('.right_hk').css({
			left: (((date1 * w) / 50) - 14) + 'px'
		})
		$('.kuangdu').css({
			width: (parseInt($('.right_hk').css("left").substring(0, $('.right_hk').css("left").length - 2)) - parseInt($('.left_hk').css("left").substring(0, $('.left_hk').css("left").length - 2))) + 'px',
			left: (parseInt($('.left_hk').css("left").substring(0, $('.left_hk').css("left").length - 2)) + 14) + 'px'
		})
		$('.left_juli')[0].innerText = date0 + 'km';
		$('.juli_right')[0].innerText = date1 + 'km';
	$('.juli_sure').unbind('click').on('click',function(){
		alert("最小距离" + $('.left_juli')[0].innerText + "最大距离" + $('.juli_right')[0].innerText)
		//发送请求
//		$.get
		var errcode = 0;
		if(errcode == 0){			
			$('.jl')[0].innerText = $('.left_juli')[0].innerText + "-" + $('.juli_right')[0].innerText;
			$('.juli_k').hide();		
		}
						
	})
})

//距离
//设置一个长按的计时器，如果点击这个图层超过0.2秒则触发移动事件
var timeout = undefined;
var x = 0;
var state = 0;
var lastTime = null;
var nowTime = null;

//获取滑动条的宽度
$('.right_hk').css({
	left: -14
})
var s;

function yidong(ob) {
	/*触摸移动*/
	ob.on("touchmove", function(event) {
		event.preventDefault(); //阻止触摸时浏览器的缩放、滚动条滚动  
		if(state == 1) {
			var touch = event.originalEvent.targetTouches[0];
			var x1 = touch.pageX;
			var start_x = x1 - $('.julitiao')[0].offsetLeft;
			x = start_x - 14;
			if(parseInt($('.left_hk').css("left").substring(0, $('.left_hk').css("left").length - 2)) > parseInt($('.right_hk').css("left").substring(0, $('.right_hk').css("left").length - 2))) {
				parseInt($('.left_hk').css("left").substring(0, $('.left_hk').css("left").length - 2)) == parseInt($('.right_hk').css("left").substring(0, $('.right_hk').css("left").length - 2));
			}
			ob.css("left", x);
			//					var left = ob.css("left").substring(0, ob.css("left").length - 2);
			if(start_x < 0) {
				ob.css("left", -14);
				return false;
			}
			if(start_x >= w) {
				ob.css("left", w - 14);
			}
			julinum()
		}
	});
	ob.on("touchstart", function(event) {
		lastTime = new Date().getTime();
		event.preventDefault(); //阻止触摸时浏览器的缩放、滚动条滚动  
		clearTimeout(timeout);
		state = 0;
		timeout = setTimeout(function() {
			state = 1;
		}, 100);

	});
	ob.on("touchend", function(event) {
		event.preventDefault(); //阻止触摸时浏览器的缩放、滚动条滚动  
		clearTimeout(timeout);
		state = 0;
		nowTime = new Date().getTime();
		var timeLength = nowTime - lastTime;
		if(timeLength < 100) {
			//			$("#loadLayer").show();
			window.history.go(-1);
		}
	});
}

yidong($('.left_hk'))
yidong($('.right_hk'))

var ll, rl;

function julinum() {
	s = w / 50
	ll = parseInt($('.left_hk').css("left").substring(0, $('.left_hk').css("left").length - 2));
	rl = parseInt($('.right_hk').css("left").substring(0, $('.right_hk').css("left").length - 2));
	console.log(ll);
	console.log(rl);
	var num1 = parseInt((ll + 14) / s);
	var num2 = parseInt((rl + 14) / s);
	if(ll / s < -14) {
		num1 = 0;
	}
	if(rl / s < 0) {
		num2 = 0;
	}
	//左右距离值的显示
	var maxkm = num1 > num2 ? num1 : num2;
	var minkm = num1 < num2 ? num1 : num2;
	$('.juli_right')[0].innerText = maxkm + "km";
	$('.left_juli')[0].innerText = minkm + 'km';

	//中间距离条的显示
	var rightnum = parseInt($('.right_hk').css("left").substring(0, $('.right_hk').css("left").length - 2));
	var leftnum = parseInt($('.left_hk').css("left").substring(0, $('.left_hk').css("left").length - 2));
	var max = rightnum > leftnum ? rightnum : leftnum;
	var min = rightnum < leftnum ? rightnum : leftnum;

	var t = rightnum < leftnum ? rightnum : leftnum;
	t = t + 14;
	$('.kuangdu').css({
		width: (max - min) + 'px',
		left: t + 'px'
	})
}


//城市
$('.quyu_div').unbind('click').on('click', function(event) {
	var item,fid,it,itfid;
	$('.quyu_k').show();
	$('.sheng_ul').html('');
	$.each(city.data, function(i, item) {
		$('.sheng_ul').append('<li value="' + item.province_id + '">' + item.province_name + '</li>');
	});
	$('ul.sheng_ul', $('.xiugai')).unbind('click').on('click', 'li', function() {
		$('.xiugaitwo').show()
		$('.xiugaitwo').find('.shi_ul').html('');
		item = $(this);
		fid = item.attr('value');
		var citylis = city.data[fid - 1].cities;
		for(i = 0; i < citylis.length; i++) {
			$('.xiugaitwo').find('.shi_ul').append('<li value="' + citylis[i].city_id + '">' + citylis[i].city_name + '</li>')
		}
	});
	$('ul.shi_ul', $('.xiugaitwo')).unbind('click').on('click', 'li', function() {
		it = $(this);
		itfid = it.attr('value');
		alert('身份为' + item[0].innerText + '市级为' + it[0].innerText)
		//发送请求
//		$.get
		var errcode = 0;
		if(errcode == 0){
			$('.addresquyu')[0].innerText =  item[0].innerText + " " + it[0].innerText;
			$('.quyu_k').hide();
			$('.xiugaitwo').hide();					
		}
		
	});
})

$('.reback').unbind('click').on('click',function(){
	$(this).parents('.tankuang').hide();
})
$('.reback_t').unbind('click').on('click',function(){
	$(this).parents('.tankuang').hide();
	$('.xiugaitwo').hide();	
})


$('#headimg').unbind('click').on('click',function(){
	$('#headimgjiequ').show();
	$('.jqyes').unbind('click').on('click',function(){
//		console.log($('#view')[0].style.backgroundImage)
		var url = $('#view')[0].style.backgroundImage;
		url = url.slice(5,-2);
		console.log(url);
		var img = new Image();
		img.src = url;
		console.log(img.src)
		if(url != null && url != ""){
			$('#preview')[0].style.backgroundImage = $('#view')[0].style.backgroundImage;
//			$('#preview').html("").append(img);
			$('#headimgjiequ').hide();
		}else{
			alert('未截取任何图片');
		}
	})
	$('.jqno').unbind('click').on('click',function(){
		console.log(1)
		$('#headimgjiequ').hide();
	})
})
