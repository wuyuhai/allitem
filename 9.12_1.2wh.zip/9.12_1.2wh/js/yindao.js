var czyflag = false;
		if(localStorage.getItem("wyhpd")==undefined || localStorage.getItem("wyhpd")==""){
			var ydhtml = '<div id="yindao_kuang">'+
			'<div id="ydanimation-effect" class="iSlider-effect"></div>'+
			'<div id="ydmenu-select">'+
				'<span class="on">default</span>'+
			'</div>'+
			'<div class="ljtyan">'+
				'<button type="button" class="lijitiyan">立即体验</button>'+
			'</div>'+
			'</div>';
			$("body").append(ydhtml);						
			var ydpicList = [{
				content: "img/qidong.jpg",
			}, {
				content: "img/qidong2.jpg",
			}, {
				content: "img/qidong3.jpg",
			}]
			var islider2 = new iSliders({
				data: ydpicList,
				dom: document.getElementById("ydanimation-effect"),
				duration: 2000,
				animateType: 'default',
				isAutoplay: false,
				isLooping: true,
				// isVertical: true, �Ƿ�ֱ����
			});
			var menu = document.getElementById('ydmenu-select').children;


			
			function clickMenuActive(target) {
				for(var i = 0; i < menu.length; i++) {
					menu[i].className = '';
				}
				target.className = 'on';
			}
			
			
			menu[0].onclick = function() {
				clickMenuActive(this);
				islider2._opts.animateType = this.innerHTML;
				islider2.reset();
			};
			$(document).unbind('click').on('click','.lijitiyan',function(){
				$(this).parent().parent().hide();
				localStorage.setItem("wyhpd",1);
//				$("body").remove($(this).parent().parent());
			})
		}