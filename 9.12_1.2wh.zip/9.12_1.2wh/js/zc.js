$('button', $('.zc_sure')).unbind('click').on('click', function() {
	if($('#bobyname')[0].value == ""){
		$('#bobyname').next().fadeIn();
		var t1 = setInterval(function(){
			$('#bobyname').next().fadeOut();
			clearInterval(t1);
		},1500)	
	}
	if(phoneyz() == false){
		$('#phonenum').next().fadeIn();
		var t2 = setInterval(function(){
			$('#phonenum').next().fadeOut();
			clearInterval(t2);
		},1500)
	}
	if($('#passwordone')[0].value != $('#passwordtwo')[0].value){
		$('#passwordtwo').next().fadeIn();
		var t3 = setInterval(function(){
			$('#passwordtwo').next().fadeOut();
			clearInterval(t3);
		},1500)
	}
	if(sexxz() == undefined){
		$('.zcyh_sex').find('.tishi').fadeIn();
		var t4 = setInterval(function(){
			$('.zcyh_sex').find('.tishi').fadeOut();
			clearInterval(t4);
		},1500)
	}
	if(mimayz() == false){
		$('#passwordone').next().fadeIn();
		var t5 = setInterval(function(){
			$('#passwordone').next().fadeOut();
			clearInterval(t5);
		},1500)
	}
	if($('#sryzm')[0].value == ""){
		$('#sryzm').next().fadeIn();
		var t6 = setInterval(function(){
			$('#sryzm').next().fadeOut();
			clearInterval(t6);
		},1500)
	}
	if($('#bobyname')[0].value != "" && phoneyz() == true && $('#passwordone')[0].value == $('#passwordtwo')[0].value && $('#sryzm')[0].value != "" && mimayz() == true && sexxz() != undefined) {
		alert('昵称' + $('#bobyname')[0].value +
			'手机号码' + $('#phonenum')[0].value +
			'输入的验证码' + $('#sryzm')[0].value +
			'注册密码' + $('#passwordone')[0].value +
			'重复密码' + $('#passwordtwo')[0].value +
			'性别' + sexxz()
		)
		//发送请求，
//		$.get
		var errcode = 0;
		if(errcode == 0){
			//if(y验证码和信息验证正确)	
		}	
	}	
})

function yzm() {
	$('.huoquyzm').unbind('click').on('click', function() {
		if(phoneyz() == true) {
			time($('.huoquyzm'))
			
		} else {
			alert('该手机号不存在，或输错')
		}
	})
}
yzm()
//再次获取验证码
var timebol = true;

function time(obj) {
	var num = 60;
	if(timebol) {
		timebol = false;
		var timer = setInterval(function() {
			num--;
			if(num > 0) {
				obj.get(0).innerHTML = num + "s";
			} else {
				clearInterval(timer);
				obj.get(0).innerHTML = '获取验证码';
				timebol = true
			}
		}, 1000)
		//发送请i求
//		$/get
		console.log("send request");
		var errcode = 0;
		if(errcode == 0){
			console.log(11)
		}
	}
}

$('#phonenum').on('blur',function(){
	if(phoneyz() == false){
		$('#phonenum').next().fadeIn();
		var t2 = setInterval(function(){
			$('#phonenum').next().fadeOut();
			clearInterval(t2);
		},1500)
	}
})



//phone手机
function phoneyz() {
	var reg = /^1[3|4|5|7|8][0-9]{9}$/; //验证规则
	var l = reg.test($('#phonenum')[0].value);
	return l;
}
//密码验证
function mimayz(){
	var bol;
	if($('#passwordone')[0].value.length >=6 && $('#passwordone')[0].value != ""){
		bol = true;
	}else{
		bol = false;
	}
	return bol;
}
//性别
function sexxz(){
	for(var i = 0;i<$('.sex_xz').length;i++){
		if($($('.sex_xz')[i]).find('.zhuangtai').attr('value') == 1){
			var value = $($('.sex_xz')[i]).find('.sex_zi').attr('value')
			return value;
		}
	}		
}






$('.sex_xz').unbind('click').on('click',function(){
	if($(this).find('.zhuangtai').attr('value') == 0){
		$(this).find('.zhuangtai').attr('value',1)
		$(this).find('.zhuangtai')[0].innerHTML = '<img src="images/7b4.png"/>';
		$(this).siblings().find('.zhuangtai').attr('value',0);
		$(this).siblings().find('.zhuangtai')[0].innerHTML = '<img src="images/7b5.png"/>';
	}else{
		$(this).find('.zhuangtai').attr('value',0)
		$(this).find('.zhuangtai')[0].innerHTML = '<img src="images/7b5.png"/>';
	}
})
