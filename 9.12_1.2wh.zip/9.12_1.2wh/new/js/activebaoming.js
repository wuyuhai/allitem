$('.join-activeul').unbind('click').on('click', '.lijibm', function() {
	if($(this)[0].className.indexOf('lijibm') != -1) {
		if($(this).children('button')[0].innerText != '已报名') {
			var that = $(this);
			var item = $(this).parent();
			var value = item.attr('value')
			alert(value);
			$('#baoming-k').show();
			$('.baoming-zz').unbind('click').on('click', function() {
				$('#baoming-k').hide();
			})
			$('img', $('.bm-img')).unbind('click').on('click', function() {
				if($('#bm-name')[0].value == "") {
					$('#bm-name').next().show();
					var t1 = setTimeout(function() {
						$('#bm-name').next().hide();
						clearTimeout(t1)
					}, 1500)
				}
				if(phoneyz() == false) {
					$('#bm-phonenum').next().show();
					var t2 = setTimeout(function() {
						$('#bm-phonenum').next().hide();
						clearTimeout(t2)
					}, 1500)
				}
				if($('#bm-name')[0].value != "" && $('#bm-phonenum')[0].value != "" && phoneyz() == true) {
					console.log("QQ"+$("#bm-QQ")[0].value);
					alert('姓名：' + $('#bm-name')[0].value + '；电话' + $('#bm-phonenum')[0].value + ";QQ"+$("#bm-QQ")[0].value);
					//发送请求
					//				$.get
					var errcode = 0;
					if(errcode == 0) {
						alert('报名成功')
						$('#bm-name')[0].value = "";
						$('#bm-phonenum')[0].value = "";
						$("#bm-QQ")[0].value = "";
						$('#baoming-k').hide();
						that.children('button')[0].innerText = "已报名";
					}
				}
			})
		}
	}
})

function phoneyz() {
	var reg = /^1[3|4|5|7|8][0-9]{9}$/; //验证规则
	var l = reg.test($('#bm-phonenum')[0].value);
	return l;
}