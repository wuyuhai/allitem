$('.dianzan').unbind('click').on('click',function(){
	var item = $(this).parents('.join-active');
	var value = item.attr('value')
	alert(value)
	var num = +$(this).children('span')[0].innerText
	if($(this).children('img').attr('src').indexOf('../images/icon1-2.png') != -1){
		console.log(1);
		$(this).children('span')[0].innerText = num + 1;
		$(this).children('img').attr('src','../img/zan.gif')
	}else{
		$(this).children('span')[0].innerText = num - 1;
		$(this).children('img').attr('src','../images/icon1-2.png')
	}
})

//一级评论
$('.pinglun').unbind('click').on('click',function(){
	var item = $(this).parents('.join-active');
	var value = item.attr('value')
	alert(value)
	$('#pl_kuang').show();
	$('#saytext').focus();	
	huadong()
	$('.sub_btn').unbind('click').on('click',function(){
		if($('#saytext')[0].value != ""){
			alert($('#saytext')[0].value)
			var lihtml = '<div class="fr_pls_one">'+
				'<div>'+
					'<div class="pls_one_xx">'+
						'<div class="headimg">'+
							'<img src="../images/2_03.gif"/>'+
							'<a class="pls_one_name" href="geren.html" value="1">沙皮</a>'+
							'<span class="yc_pl">删除</span>'+
						'</div>'+
						'<div class="one-cotent">'+					
							'<span class="pl_ctt" value="1">'+
								$('#saytext')[0].value+
							'</span>'+
						'</div>'+						
					'</div>'+
					'<ul class="erjipl_ul">'+
					'</ul>'+
				'</div>'+
			'</div>';
			var li = document.createElement('li');
			li.innerHTML = lihtml;
			li.setAttribute('value','0')
			$('.fr_pls_ul')[0].append(li);
			var actbol = true;
			var str =$(li).find('.pl_ctt')[0].innerHTML;
			$(li).find('.pl_ctt')[0].innerHTML = replace_em(str,actbol);
			huadong()
			$('#pl_kuang').hide();
			$('#saytext').val("");
		}
	})
})

function huadong(){
	var t = $('body')[0].scrollHeight - document.documentElement.clientHeight-50;
		$('body').animate({
			scrollTop: t
		}, 500, function() { //   滚动条滚动 页面不同内容的offsetTop值实现按钮对应效果
			self.scrolltype = true;
		});
}


//报名
$('body').unbind('click').on('click', '.lijibm,.pl_ctt,.pltwo_ctt,.yc_pltwo,.yc_pl', function(e) {
	//二级评论
	if($(this)[0].className.indexOf('pl_ctt') != -1){
		var item = $(this);
		var name = item.parents('.pls_one_xx').find('.pls_one_name')[0].innerText;
		var value = item.attr('value');
		var userValue = item.parents('.pls_one_xx').find('.pls_one_name')[0].getAttribute('value');
		$('#pl_kuang').show();
		$('#saytext').focus();	
		$('#saytext').attr('placeholder','回复：' + name);
		$('.sub_btn').unbind('click').on('click',function(){
			if($('#saytext')[0].value != ""){
				//发情请求
				//￥。get
				var errcode = 0;
				if(errcode == 0){
					var lihtml = '<div class="fr_pls_two">'+
						'<div class="pls_two_xx">'+
							'<a class="pls_pwo_name" href="geren.html" value="1">大西瓜</a>'+
							'<span style="margin-right: 2.5px;">回复:</span>'+
							'<a class="pls_pwo_name" href="geren.html" value="1">'+name+'</a>'+
							'<span class="pltwo_ctt">'+
								$('#saytext')[0].value+
							'</span>'+
						'</div>'+
						'<div class="mjs">'+
							'<span class="yc_pltwo">删除</span>'+
						'</div>'+
					'</div>';
					var li = document.createElement('li');
					li.innerHTML = lihtml;
					$(li).attr('value',0);
					$('.erjipl_ul').append(li)
					var actbol = true;
					var str =$(li).find('.pltwo_ctt')[0].innerHTML;
					$(li).find('.pltwo_ctt')[0].innerHTML = replace_em(str,actbol);
					
					$('#pl_kuang').hide();
					$('#saytext').val("");
				}						
			}										
		})										
	}
	//二级评论
	if($(this)[0].className.indexOf('pltwo_ctt') != -1){
		var item = $(this);
		var name = item.parents('.pls_two_xx').find('.pls_pwo_name')[0].innerText;
		var value = item.attr('value');
		var userValue = item.parents('.pls_two_xx').find('.pls_pwo_name')[0].getAttribute('value');
		console.log(value)
		console.log(userValue)
		$('#pl_kuang').show();
		$('#saytext').focus();	
		$('#saytext').attr('placeholder','回复：' + name);
		$('.sub_btn').unbind('click').on('click',function(){
			if($('#saytext')[0].value != ""){
				//发情请求
				//￥。get
				var errcode = 0;
				if(errcode == 0){
					var lihtml = '<div class="fr_pls_two">'+
						'<div class="pls_two_xx">'+
							'<a class="pls_pwo_name" href="geren.html" value="1">大西瓜</a>'+
							'<span style="margin-right: 2.5px;">回复:</span>'+
							'<a class="pls_pwo_name" href="geren.html" value="1">'+name+'</a>'+
							'<span class="pltwo_ctt">'+
								$('#saytext')[0].value+
							'</span>'+
						'</div>'+
						'<div class="mjs">'+
							'<span class="yc_pltwo">删除</span>'+
						'</div>'+
					'</div>';
					var li = document.createElement('li');
					li.innerHTML = lihtml;
					$(li).attr('value',0);
					$('.erjipl_ul').append(li)
					var actbol = true;
					var str =$(li).find('.pltwo_ctt')[0].innerHTML;
					console.log(str)
					$(li).find('.pltwo_ctt')[0].innerHTML = replace_em(str,actbol);
					
					$('#pl_kuang').hide();
					$('#saytext').val("");
				}						
			}										
		})										
	}
	
	//删除
	if(e.target.className == 'yc_pl'){
		var item = $(this);
		var value = $(this).parents("li").attr('value');
		console.log(value)
		$('#shanchusure').show();
		$('#sc-no,.shanchu-zz').unbind('click').on('click',function(){
			$('#shanchusure').hide();
		})
		$('#sc-sure').unbind('click').on('click',function(){
			//发送请求
			//￥.get
			var errcode = 0;
			if(errcode == 0){
				alert(value)
				item.parents("li").remove();		
				$('#shanchusure').hide();
			}									
		})
	}
		
	//子评论删除
	if(e.target.className.indexOf('yc_pltwo') != -1){
		var item = $(this);
		console.log(item);
		var value = $(this).parent().parent().parent().attr('value');
		console.log($(this).parent().parent().parent())
		$('#shanchusure').show();
		$('#sc-no,.shanchu-zz').unbind('click').on('click',function(){
			$('#shanchusure').hide();
		})
		$('#sc-sure').unbind('click').on('click',function(){
			//发送请求
			//￥.get
			var errcode = 0;
			if(errcode == 0){
				alert(value)
				item.parent().parent().parent().remove();		
				$('#shanchusure').hide();
			}									
		})
	}
		
	if($(this)[0].className.indexOf('lijibm') != -1) {
		if($(this).children('button')[0].innerText != '已报名') {
			var that = $(this);
			var item = $(this).parent().find('.join-active');
			var value = item.attr('value')
			alert(value);
			$('#baoming-k').show();
			$('.baoming-zz').unbind('click').on('click', function() {
				$('#baoming-k').hide();
			})
			$('img', $('.bm-img')).unbind('click').on('click', function() {
				if($('#bm-name')[0].value == "") {
					$('#bm-name').next().show();
					var t1 = setTimeout(function() {
						$('#bm-name').next().hide();
						clearTimeout(t1)
					}, 1500)
				}
				if(phoneyz() == false) {
					$('#bm-phonenum').next().show();
					var t2 = setTimeout(function() {
						$('#bm-phonenum').next().hide();
						clearTimeout(t2)
					}, 1500)
				}
				if($('#bm-name')[0].value != "" && $('#bm-phonenum')[0].value != "" && phoneyz() == true) {
					alert('姓名：' + $('#bm-name')[0].value + '；电话' + $('#bm-phonenum')[0].value);
					//发送请求
					//				$.get
					var errcode = 0;
					if(errcode == 0) {
						alert('报名成功')
						$('#bm-name')[0].value = "";
						$('#bm-phonenum')[0].value = "";
						$('#baoming-k').hide();
						that.children('button')[0].innerText = "已报名";
					}
				}
			})
		}
	}
})

function phoneyz() {
	var reg = /^1[3|4|5|7|8][0-9]{9}$/; //验证规则
	var l = reg.test($('#bm-phonenum')[0].value);
	return l;
}

$('.pl_kuang-zz').unbind('click').on('click',function(){
	$('#saytext').attr('placeholder','');
	$('#pl_kuang').hide();
})
