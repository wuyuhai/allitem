$('#join-active').unbind('click').on('click', function() {
	$(this)[0].className = "xuanzhong";
	$('#open-active')[0].className = "noxuanzhong";
	$('#myopen').hide();
	$('#myjoin').show();
	$('#myjoin').html("");
	if($('#myjoin').children().length ==0){
		
	}
	//发送请求
	//	$.get
	var errcode = 0;
	if(errcode == 0) {
		for(var i = 0; i < 15; i++) {
			var li =
				'<div class="joinactop">' +
				'<div>' +
				'<img src="img/tu.png" />' +
				'</div>' +
				'<div class="control">' +
				'<h5 class="ctr-title">亲近自然，径山骑行游</h5>' +
				'<div class="ctr-li">' +
				'<img class="ctr-icon" src="img/faqiren.png" />' +
				'<span>发起人:</span>' +
				'<span class="ctr-li-name">小吻君</span>' +
				'</div>' +
				'<div class="ctr-li">' +
				'<img class="ctr-icon" src="img/shijian.png" />' +
				'<span>时间:</span>' +
				'<span>2017-9-9-10:00</span>' +
				'</div>' +
				'<div class="ctr-li">' +
				'<img class="ctr-icon" src="img/dizhi.png" />' +
				'<span>地点:</span>' +
				'<span>杭州市径山</span>' +
				'</div>' +
				'<div class="ctr-li">' +
				'<img class="ctr-icon" src="img/shijian.png" />' +
				'<span>截止报名:</span>' +
				'<span>2017-9-9-10:00</span>' +
				'</div>' +
				'<div>' +
				'<img class="ctr-icon" src="img/canyuzhe.png" />' +
				'<span>参与者</span>' +
				'<span></span>' +
				'</div>' +
				'</div>' +
				'</div>' +
				'<div class="ss_zt">' +
				'<div class="">' +
				'<img src="../images/icon1-1.png" />' +
				'<span>1234</span>' +
				'</div>' +
				'<em>|</em>' +
				'<div class="dianzan">' +
				'<a class="sign_go">' +
				'<img src="../images/icon1-2.png" />' +
				'<span class="dianzan_num">123</span>' +
				'</a>' +
				'</div>' +
				'<em>|</em>' +
				'<div class="pinglun">' +
				'<a class="sign_go">' +
				'<img src="../images/icon1-3.png" /><span class="pinglun_num">12</span>' +
				'</a>' +
				'</div>' +
				'</div>';
			var lis = document.createElement('li');
			lis.className = "join-active";
			lis.setAttribute('value', i);
			lis.innerHTML = li;
			$('#myjoin').append(lis)
			console.log(i)
		}

	}

})

$('#open-active').unbind('click').on('click', function() {
	$(this)[0].className = "xuanzhong";
	$('#join-active')[0].className = "noxuanzhong";
	$('#myjoin').hide();
	$('#myopen').show();
	$('#myopen').html("");
	//发送请求
	//	$.get
	if($('#myopen').children().length ==0)
	var errcode = 0;
	if(errcode == 0) {
		for(var i = 0; i < 15; i++) {
			var li =
				'<div class="joinactop">' +
				'<div>' +
				'<img src="img/tu.png" />' +
				'</div>' +
				'<div class="control">' +
				'<h5 class="ctr-title">嫖娼</h5>' +
				'<div class="ctr-li">' +
				'<img class="ctr-icon" src="img/faqiren.png" />' +
				'<span>发起人:</span>' +
				'<span class="ctr-li-name">小吻君</span>' +
				'</div>' +
				'<div class="ctr-li">' +
				'<img class="ctr-icon" src="img/shijian.png" />' +
				'<span>时间:</span>' +
				'<span>2017-9-9-10:00</span>' +
				'</div>' +
				'<div class="ctr-li">' +
				'<img class="ctr-icon" src="img/dizhi.png" />' +
				'<span>地点:</span>' +
				'<span>杭州市径山</span>' +
				'</div>' +
				'<div class="ctr-li">' +
				'<img class="ctr-icon" src="img/shijian.png" />' +
				'<span>截止报名:</span>' +
				'<span>2017-9-9-10:00</span>' +
				'</div>' +
				'<div>' +
				'<img class="ctr-icon" src="img/canyuzhe.png" />' +
				'<span>参与者</span>' +
				'<span></span>' +
				'</div>' +
				'</div>' +
				'</div>' +
				'<div class="ss_zt">' +
				'<div class="">' +
				'<img src="../images/icon1-1.png" />' +
				'<span>1234</span>' +
				'</div>' +
				'<em>|</em>' +
				'<div class="dianzan">' +
				'<a class="sign_go">' +
				'<img src="../images/icon1-2.png" />' +
				'<span class="dianzan_num">123</span>' +
				'</a>' +
				'</div>' +
				'<em>|</em>' +
				'<div class="pinglun">' +
				'<a class="sign_go">' +
				'<img src="../images/icon1-3.png" /><span class="pinglun_num">12</span>' +
				'</a>' +
				'</div>' +
				'</div>';
			var lis = document.createElement('li');
			lis.className = "join-active";
			lis.setAttribute('value', i);
			lis.innerHTML = li;
			$('#myopen').append(lis)
			console.log(i)
		}

	}
})