//添加字段
function addziduan(obj, ob) {
	obj.unbind('click').on('click', function() {
		var item = $(this)
		var textear = document.createElement('textarea');
		textear.className = 'active_txt';
		item.parents('.text_kuang').find(ob).append(textear)
	})
}
addziduan($('.addziduan1'), '#txt-jj');
addziduan($('.addziduan2'), '#txt-lc');
addziduan($('.addziduan3'), '#txt-ts');

//添加图片
function preview(file, obj) { //预览图片得到图片base64
	console.log(file)
	var imgdiv = document.createElement('div');
	imgdiv.className = 'wokao';
	if(file.files && file.files[0]) {
		var reader = new FileReader();
		reader.onload = function(evt) {
			imgdiv.innerHTML = '<img src="' + evt.target.result + '" />';
		}
		reader.readAsDataURL(file.files[0]);
	} else {
		imgdiv.innerHTML = '<div class="img" style="filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(sizingMethod=scale,src=\'' + file.value + '\'"></div>';
	}
	imgdiv.setAttribute("value", file.value)
	$(file).parents('.text_kuang').find(obj).append(imgdiv);
	//发送请求
	//￥。get
	var errcode = 0;
	if(errcode == 0) {
		imgdiv.setAttribute('data-src', '0');
	}
}

//$('#activetime').unbind('click').on('click', function() {
//
//})

//活动海报
function previewhb(file) { //预览图片得到图片base64
	console.log(file)
	var div = document.getElementById('ctr_divtwo');
	if(file.files && file.files[0]) {
		var reader = new FileReader();
		reader.onload = function(evt) {
			div.innerHTML = '<img src="' + evt.target.result + '" />';
		}
		reader.readAsDataURL(file.files[0]);
	} else {
		div.innerHTML = '<div class="img" style="filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(sizingMethod=scale,src=\'' + file.value + '\'"></div>';
	}
	//发送请求
	//￥。get
	var errcode = 0;
	if(errcode == 0) {
		div.setAttribute('data-src', '0');
		alert("上传成功")
	}
}

//三级城市选择
var name1, fidpro, name2, fid, name3;
$('.dorpdown-province').unbind('click').on('click', 'li', function() {
	var jyname = $(this)[0].innerText;
	if($(this).attr('value') == undefined) {
		$('.dorpdown-province').html('');
		$.each(city, function(i, item) {
			if(item.province_id == 4) {
				$('.dorpdown-province').append('<li value="' + item.province_id + '" class="cur">' + item.province_name + '</li>')
			} else {
				$('.dorpdown-province').append('<li value="' + item.province_id + '">' + item.province_name + '</li>')
			}
		});
	} else {
		$(this).addClass('cur').siblings().removeClass('cur');
		var item = $(this);
		fidpro = item.attr('value');
		name1 = item[0].innerText;
		var itemparent = $(this).parent()
		$(this).parent().html("");
		itemparent[0].innerHTML = '<li>' + name1 + '</li>';
		$('ul.dorpdown-city')[0].innerHTML = '<li>未选择</li>';
		$('ul.dorpdown-zhen')[0].innerHTML = '<li>未选择</li>';
	}
	$("#contant").unbind('click').on('click', 'div,ul', function() {
		console.log(1)
		if($(this)[0].className.indexOf("dorpdown-province") == -1) {
			$('.dorpdown-province').html("");
			$('.dorpdown-province')[0].innerHTML = "<li>" + jyname + "</li>"
		}
	})
})
$('ul.dorpdown-city').unbind('click').on('click', 'li', function() {
	var jyname = $(this)[0].innerText;
	if($(this).attr('value') == undefined) {
		var citylis = city[fidpro - 4].cities;
		$('.dorpdown-city').html('');
		$('.dorpdown-city').append('<li>未选择</li>');
		for(i = 0; i < citylis.length; i++) {
			$('.dorpdown-city').append('<li val="' + i + '" value="' + citylis[i].city_id + '">' + citylis[i].city_name + '</li>')
		}
	} else {
		$(this).addClass('cur').siblings().removeClass('cur');
		var item = $(this);
		fid = item.attr('val');
		name2 = item[0].innerText;
		var itemparent = $(this).parent()
		$(this).parent().html("");
		itemparent[0].innerHTML = '<li>' + name2 + '</li>';
		$('ul.dorpdown-zhen')[0].innerHTML = '<li>未选择</li>';
	}
	$("#contant").unbind('click').on('click', 'div,ul', function() {
		console.log(1)
		if($(this)[0].className.indexOf("dorpdown-province") == -1) {
			$('.dorpdown-city').html("");
			$('.dorpdown-city')[0].innerHTML = "<li>" + jyname + "</li>"
		}
	})
});
$('ul.dorpdown-zhen').on('click', 'li', function() {
	var jyname = $(this)[0].innerText;
	if($(this).attr('value') == undefined) {
		var zhenlis = city[fidpro - 4].cities[fid].areas;
		$('.dorpdown-zhen').html('');
		for(i = 0; i < zhenlis.length; i++) {
			$('.dorpdown-zhen').append('<li value="' + zhenlis[i].id + '">' + zhenlis[i].name + '</li>')
		}
	} else {
		name3 = $(this)[0].innerText;
		var itemparent = $(this).parent()
		$(this).parent().html("");
		itemparent[0].innerHTML = '<li>' + name3 + '</li>';
	}
	$("#contant").unbind('click').on('click', 'div,ul', function() {
		if($(this)[0].className.indexOf("dorpdown-province") == -1) {
			$('ul.dorpdown-zhen').html("");
			$('ul.dorpdown-zhen')[0].innerHTML = "<li>" + jyname + "</li>"
		}
	})
});

function huadong(num){
	$('body').animate({
		scrollTop:num
	}, 500, function() { //   滚动条滚动 页面不同内容的offsetTop值实现按钮对应效果
		self.scrolltype = true;
	});
}
$('.activeopen').unbind('click').on('click', function() {
	if($('#act-zhuti')[0].value == "") {
		huadong(100)
	}
	if($('#ctr_divtwo').children().length == 0) {
		huadong(170)
	}
	if($('#appDateTime')[0].value == "") {
		huadong(290)
	}
	if($('#appDateTime2')[0].value == "") {
		huadong(350)
	}
	if($('#appDateTime3')[0].value == "") {
		huadong(420)
	}
	if(timepdone() == false){
		huadong(290)
	}
	if(timepdtwo() == false){
		huadong(290)
	}
	if($('.dorpdown-province').children('li')[0].innerText == '未选择') {
		huadong(490)
	}
	if($('.dorpdown-city').children('li')[0].innerText == '未选择') {
		huadong(490)
	}
	if($('.dorpdown-zhen').children('li')[0].innerText == '未选择') {
		huadong(490)
	}
	if($('#tt-address')[0].value == "") {
		huadong(560)
	}
	var jh = activetotal($('#txt-jh'));
	var lc = activetotal($('#txt-lc'));
	var ts = activetotal($('#txt-ts'))
	if(jh.value == "" && jh.xxtxt == "") {
		huadong(650)
	}
	if($('#zbf-phone')[0].value == "") {
		huadong($('body')[0].scrollHeight )
	}
	
	if($('#act-zhuti')[0].value != "" && $('#ctr_divtwo').children().length != 0 && 
		$('#appDateTime')[0].value != "" && $('#appDateTime2')[0].value != "" &&
		$('#appDateTime3')[0].value != "" && timepdone() == true && timepdtwo() == true &&
		$('.dorpdown-province').children('li')[0].innerText != '未选择' &&
		$('.dorpdown-city').children('li')[0].innerText != '未选择' && 
		$('.dorpdown-zhen').children('li')[0].innerText != '未选择' &&
		$('#tt-address')[0].value != "" && (jh.value != "" || jh.xxtxt != "") &&
		$('#zbf-phone')[0].value != ""){
			alert("活动主题：" + $('#act-zhuti')[0].value + 
				"<br/>活动海报：" + $('#ctr_divtwo').attr('value') +
				"<br/>开始时间：" + $('#appDateTime')[0].value +
				"<br/>结束时间：" + $('#appDateTime2')[0].value +
				"<br/>报名截止：" + $('#appDateTime3')[0].value +
				"<br/>地点：" + $('.dorpdown-province').children('li')[0].innerText +
				"/" + $('.dorpdown-city').children('li')[0].innerText + 
				"/" + $('.dorpdown-zhen').children('li')[0].innerText + 
				"<br/>详细地点：" + $('#tt-address')[0].value +
				"<br/>活动简介：" + jh.xxtxt + "；活动图片" + jh.value + 
				"<br/>活动流程：" + lc.xxtxt + "；活动图片" + lc.value + 
				"<br/>注意事项：" + ts.xxtxt + "；活动图片" + ts.value + 
				"<br/>主办方联系方式：" + $('#zbf-phone')[0].value 			
			)
			//发送请求
			//￥。get
			var errcode = 0;
			if(errcode== 0){
				$('#act-zhuti')[0].value = "";
				$('#ctr_divtwo').attr('value') = "";
				$('#appDateTime')[0].value = "";
				$('#appDateTime2')[0].value = "";
				$('#appDateTime3')[0].value = "";
				$('.dorpdown-province').children('li')[0].innerText = "未选择";
				$('.dorpdown-city').children('li')[0].innerText = "未选择";
				$('.dorpdown-zhen').children('li')[0].innerText = "未选择";
				$('#tt-address')[0].value = "";
				$('#txt-jh')[0].innerHTML = '<textarea id="actjj" class="active_txt" name="" rows="" cols="" placeholder="活动简介"></textarea>';
				$('#txt-lc')[0].innerHTML = '<textarea class="active_txt" name="" rows="" cols="" placeholder="活动流程"></textarea>';
				$('#txt-ts')[0].innerHTML = '<textarea class="active_txt" name="" rows="" cols="" placeholder="温馨提示"></textarea>';
				$('#zbf-phone')[0].value = "";
				alert('发布成功')
			}
			
		}
	
	
	
	
	function activetotal(ob) {
		var value = ''
		var xxtxt = '';
		var txt, img;
		var its = ob.children();
		for(var i = 0; i < ob.children().length; i++) {
			if($(its[i]).attr('class') == 'wokao') {
				xxtxt += '[img][/img]';
				if(value == "") {
					value += $(its[i]).attr('data-src');
				} else {
					value += '*' + $(its[i]).attr('data-src');
				}

			} else {
				xxtxt += its[i].value;
			}
		}
		xxtxt = replace_em(xxtxt)
		var total = {
			xxtxt: xxtxt, //字符串
			value: value //图片value
		};
		return total;
	}
})

function replace_em(str, bol) {
	//	str = str.replace(/\s</g, '&lt;');
	str = str.replace(/\n/g, '/n');
	return str;
}

