
function timelj(ob){
	var starttime = ob[0].value;
	var arrstartone = starttime.split(" ");
	var arrstartnyr = arrstartone[0].split("-");
	var arrstartsfm = arrstartone[1].split(":");
	var time = {
		year:+arrstartnyr[0],
		month:+arrstartnyr[1],
		day:+arrstartnyr[2],
		hour:+arrstartsfm[0],
		minute:+arrstartsfm[1]
	}
	return time;
}

function timepdone(){
	var starttime = timelj($('#appDateTime'));
	var endtime = timelj($('#appDateTime2'));
	if(starttime.year<endtime.year){
		console.log(1)
		return true;
	}else if(starttime.year==endtime.year){
		console.log(2)
		if(starttime.month<endtime.month){
			console.log(3)
			return true;
		}else if(starttime.month==endtime.month){
			console.log(4)
			if(starttime.day<endtime.day){
				console.log(5)
				return true;
			}else if(starttime.day==endtime.day){
				console.log(6)
				if(starttime.hour<endtime.hour){
					console.log(7)
					return true;
				}else if(starttime.hour==endtime.hour){
					console.log(8)
					if(starttime.minute<endtime.minute){
						console.log(9)
						return true;
					}else{
						return false;
					}
				}else{
					return false;
				}
			}else{
				return false;
			}
		}else{
			return false;
		}
	}else{
		return false;
	}
}

function timepdtwo(){
	var arrstartone = timelj($('#appDateTime3'));
	var endtime = timelj($('#appDateTime2'));
	if(arrstartone.year<endtime.year){
		console.log(1)
		return true;
	}else if(arrstartone.year==endtime.year){
		console.log(2)
		if(arrstartone.month<endtime.month){
			console.log(3)
			return true;
		}else if(arrstartone.month==endtime.month){
			console.log(4)
			if(arrstartone.day<endtime.day){
				console.log(5)
				return true;
			}else if(arrstartone.day==endtime.day){
				console.log(6)
				if(arrstartone.hour<endtime.hour){
					console.log(7)
					return true;
				}else if(arrstartone.hour==endtime.hour){
					console.log(8)
					if(arrstartone.minute<endtime.minute){
						console.log(9)
						return true;
					}else{
						return false;
					}
				}else{
					return false;
				}
			}else{
				return false;
			}
		}else{
			return false;
		}
	}else{
		return false;
	}
}


$('.activebaocun').unbind('click').on('click',function(){
//	timelj($('#appDateTime'))
	console.log(timepdone());
	console.log(timepdtwo());
})
