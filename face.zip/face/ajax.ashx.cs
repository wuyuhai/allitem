﻿using face.db;
using Newtonsoft.Json;
using SolaCore.Security;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;

namespace face
{
    /// <summary>
    /// ajax 的摘要说明
    /// </summary>
    public class ajax : IHttpHandler
    {
        public static string secret = "DD24022FF1E74BEE";
        public static string key = "-*&^_guizhou_face_key_$##$%^&*&$";

        public void ProcessRequest(HttpContext context)
        {
            try
            {
                string str = context.Request.QueryString["type"];
                Stream inputStream = context.Request.InputStream;
                byte[] buffer = new byte[(int)inputStream.Length];
                inputStream.Read(buffer, 0, (int)inputStream.Length);
                Dictionary<string, string> dictionary = JsonConvert.DeserializeObject<Dictionary<string, string>>(Encoding.UTF8.GetString(buffer));

                string id = "";

                if (str == "3")
                {
                    if (!dictionary.ContainsKey("id"))
                    {
                        throw new Exception("请求格式错误！");
                    }

                    id = dictionary["id"];
                }

                string url = "";
                // 人脸搜索
                if (str == "1" || str == "3")
                {
                    url = ConfigurationManager.AppSettings["url"] + "/face/identify";
                }
                // 人脸注册
                else
                {
                    url = ConfigurationManager.AppSettings["url"] + "/face/register";
                    dictionary.Add("isWangTing", "1");
                }

                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
                byte[] bytes = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(dictionary));
                request.Method = "POST";
                request.ContentType = "application/json";
                request.UserAgent = "Mozilla/4.0";
                request.ContentLength = bytes.Length;
                using (Stream stream2 = request.GetRequestStream())
                {
                    stream2.Write(bytes, 0, bytes.Length);
                }
                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                {
                    using (StreamReader reader = new StreamReader(response.GetResponseStream(), Encoding.UTF8))
                    {
                        string str8 = reader.ReadToEnd().ToString();

                        // 人脸搜索
                        if (str == "1")
                        {
                            var res = JsonConvert.DeserializeObject<AjaxResult<IdentifyResponse>>(str8);

                            if (!res.ok)
                            {
                                throw new Exception(res.msg);
                            }

                            str8 = JsonConvert.SerializeObject(new AjaxResult<object>()
                            {
                                ok = true,
                                msg = "成功",
                                obj = new
                                {
                                    cardNo = AesEncrypt(res.obj.idNumber, secret),
                                    sign = (key + res.obj.idNumber + DateTime.Now.ToString("yyyyMMdd")).Encrypt().ToLower()
                                }
                            });
                        }
                        // 手机刷脸
                        else if (str == "3")
                        {
                            var res = JsonConvert.DeserializeObject<AjaxResult<IdentifyResponse>>(str8);

                            using (var db = new MySqlDB(ConfigurationManager.AppSettings["mysqldb"]))
                            {
                                if (!res.ok)
                                {
                                    db.ExecuteSql($@"update zw_face.zw_scan set state = 2, update_time = CURRENT_TIMESTAMP, message = '{res.msg}' where scan_id = '{id}'");
                                }
                                else
                                {
                                    db.ExecuteSql($@"update zw_face.zw_scan set state = 1, update_time = CURRENT_TIMESTAMP, message = '识别成功', user_id = '{res.obj.userId}', id_number = '{res.obj.idNumber}' where scan_id = '{id}'");
                                }

                                str8 = JsonConvert.SerializeObject(new AjaxResult<object>()
                                {
                                    ok = true,
                                    msg = "成功",
                                });
                            }
                        }
                        // 人脸注册
                        else
                        {
                            var res = JsonConvert.DeserializeObject<AjaxResult<RegisterResponse>>(str8);
                            string str10 = DateTime.Now.ToString("yyyyMMddHHmmss");

                            if (!res.ok)
                            {
                                str8 = JsonConvert.SerializeObject(new AjaxResult<object>()
                                {
                                    ok = true,
                                    msg = res.msg,
                                    obj = new
                                    {
                                        time = str10,
                                        sign = ("QUPQAMDBMLSHI8QKKCKLZCKMBXUK4" + str10).Encrypt().ToLower(),
                                        client_id = "QUPQAMDBM"
                                    }
                                });
                            }
                            else
                            {
                                str8 = JsonConvert.SerializeObject(new AjaxResult<object>()
                                {
                                    ok = true,
                                    msg = "已提交人工审核中",
                                    obj = new
                                    {
                                        time = str10,
                                        sign = ("QUPQAMDBMLSHI8QKKCKLZCKMBXUK4" + str10).Encrypt().ToLower(),
                                        client_id = "QUPQAMDBM"
                                    }
                                });
                            }
                        }

                        context.Response.ContentType = "application/json";
                        context.Response.Write(str8);
                    }
                }
            }
            catch (Exception ex)
            {
                context.Response.ContentType = "application/json";
                context.Response.Write(JsonConvert.SerializeObject(new AjaxResult<NULL>()
                {
                    ok = false,
                    msg = ex.Message,
                }));
            }
        }

        public static string AesEncrypt(string str, string key)
        {
            if (string.IsNullOrEmpty(str)) return null;
            Byte[] toEncryptArray = Encoding.UTF8.GetBytes(str);

            System.Security.Cryptography.RijndaelManaged rm = new System.Security.Cryptography.RijndaelManaged
            {
                Key = Encoding.UTF8.GetBytes(key),
                Mode = System.Security.Cryptography.CipherMode.ECB,
                Padding = System.Security.Cryptography.PaddingMode.PKCS7
            };

            System.Security.Cryptography.ICryptoTransform cTransform = rm.CreateEncryptor();
            Byte[] resultArray = cTransform.TransformFinalBlock(toEncryptArray, 0, toEncryptArray.Length);

            return Convert.ToBase64String(resultArray, 0, resultArray.Length);
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }

    public class AjaxResult<T>
    {
        /// <summary>
        /// 获取 Ajax操作结果类型
        /// </summary>
        public bool ok { get; set; }

        /// <summary>
        /// 获取 消息内容
        /// </summary>
        public string msg { get; set; }

        /// <summary>
        /// 获取 返回数据
        /// </summary>
        public T obj { get; set; }
    }

    public class IdentifyResponse
    {
        public string userId { get; set; }
        public string faceId { get; set; }
        public string faceUrl { get; set; }
        public string idNumber { get; set; }
        public string name { get; set; }
        public string mobile { get; set; }
    }

    public class RegisterResponse
    {
        public string userId { get; set; }
        public bool isMatch { get; set; }
    }

    public class NULL
    {
    }
}