﻿using face.db;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;

namespace face
{
    /// <summary>
    /// Handler1 的摘要说明
    /// </summary>
    public class check : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            try
            {
                string str = context.Request.QueryString["id"];

                if (string.IsNullOrEmpty(str))
                {
                    throw new Exception("数据不全！");
                }

                try
                {
                    var guid = new Guid(str);
                }
                catch (Exception)
                {
                    throw new Exception("id格式错误！");
                }

                using (var db = new MySqlDB(ConfigurationManager.AppSettings["mysqldb"]))
                {
                    var dt = db.GetDataTable($"select * from zw_face.zw_scan where scan_id = '{str}'");

                    // 判断id是否存在
                    if (dt == null || dt.Rows.Count == 0)
                    {
                        throw new Exception("id不存在！");
                    }

                    // 判断是否已经扫过
                    if (dt.Rows[0]["is_scan"].ToString() != "0")
                    {
                        throw new Exception("二维码已经失效！");
                    }

                    var now = Convert.ToDateTime(db.GetDataTable("select now()").Rows[0][0]);
                    var create_time = Convert.ToDateTime(dt.Rows[0]["create_time"]);

                    // 判断时间是否有效
                    if ((now - create_time).TotalMinutes > 5)
                    {
                        throw new Exception("二维码已经失效！");
                    }

                    db.ExecuteSql($@"update zw_face.zw_scan set is_scan = 1, update_time = CURRENT_TIMESTAMP, scan_time = CURRENT_TIMESTAMP where scan_id = '{str}'");

                    context.Response.ContentType = "application/json";
                    context.Response.Write(JsonConvert.SerializeObject(new AjaxResult<object>()
                    {
                        ok = true,
                        msg = "成功"
                    }));
                }
            }
            catch (Exception ex)
            {
                context.Response.ContentType = "application/json";
                context.Response.Write(JsonConvert.SerializeObject(new AjaxResult<NULL>()
                {
                    ok = false,
                    msg = ex.Message,
                }));
            }
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}