﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace face.db
{
    public class MySqlDB : IDisposable
    {
        // Fields
        public MySqlCommand cmd;
        public MySqlConnection conn;

        public MySqlDB(string connectionString)
        {
            try
            {
                this.conn = new MySqlConnection(connectionString);
                this.conn.Open();
                this.cmd = new MySqlCommand();
                this.cmd.Connection = this.conn;
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        public void BeginTransaction()
        {
            try
            {
                this.cmd.Transaction = this.conn.BeginTransaction();
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        public void Commit()
        {
            try
            {
                if (this.cmd.Transaction != null)
                {
                    this.cmd.Transaction.Commit();
                }
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        public MySqlDataAdapter CreateAdapter(string strsql)
        {
            MySqlDataAdapter adapter = null;
            try
            {
                adapter = new MySqlDataAdapter(strsql, (MySqlConnection)this.conn);
            }
            catch
            {
            }

            return adapter;
        }

        public void Dispose()
        {
            //if (this.cmd.Transaction != null)
            //{
            //    this.cmd.Transaction.Rollback();
            //}
            //if (this.cmd != null)
            //{
            //    this.cmd.Cancel();
            //    this.cmd.Dispose();
            //}
            //if (this.conn != null)
            //{
            //    this.conn.Close();
            //    this.conn.Dispose();
            //}
            GC.Collect();
        }

        public int ExecuteSql(string strsql)
        {
            int num = 0;
            try
            {
                this.cmd.CommandText = strsql;
                num = this.cmd.ExecuteNonQuery();
            }
            catch (Exception exception)
            {
                this.cmd.Cancel();
                throw exception;
            }
            return num;
        }

        public int ExecuteSql(string strsql, params MySqlParameter[] ps)
        {
            int num = 0;
            try
            {
                this.cmd.CommandText = strsql;
                for (int i = 0; i < ps.Length; i++)
                {
                    this.cmd.Parameters.Add(ps[i]);
                }
                num = this.cmd.ExecuteNonQuery();
            }
            catch (Exception exception)
            {
                this.cmd.Cancel();
                throw exception;
            }
            finally
            {
                this.cmd.Parameters.Clear();
            }
            return num;
        }

        public MySqlDataReader GetDataReader(string strsql)
        {
            MySqlDataReader reader = null;
            try
            {
                this.cmd.CommandText = strsql;
                reader = this.cmd.ExecuteReader();
            }
            catch (Exception exception)
            {
                this.cmd.Cancel();
                throw exception;
            }
            return reader;
        }

        public MySqlDataReader GetDataReader(string strsql, params MySqlParameter[] ops)
        {
            MySqlDataReader reader = null;
            try
            {
                this.cmd.CommandText = strsql;
                for (int i = 0; i < ops.Length; i++)
                {
                    this.cmd.Parameters.Add(ops[i]);
                }
                reader = this.cmd.ExecuteReader();
            }
            catch (Exception exception)
            {
                this.cmd.Cancel();
                throw exception;
            }
            finally
            {
                this.cmd.Parameters.Clear();
            }
            return reader;
        }

        public DataTable GetDataTable(string strsql)
        {
            DataTable table = new DataTable();
            try
            {
                this.cmd.CommandText = strsql;
                table.Load(this.cmd.ExecuteReader());
            }
            catch (Exception exception)
            {
                this.cmd.Cancel();
                throw exception;
            }
            return table;
        }

        public DataTable GetDataTable(string strsql, params MySqlParameter[] ps)
        {
            DataTable table = new DataTable();
            try
            {
                this.cmd.CommandText = strsql;
                for (int i = 0; i < ps.Length; i++)
                {
                    this.cmd.Parameters.Add(ps[i]);
                }
                table.Load(this.cmd.ExecuteReader());
            }
            catch (Exception exception)
            {
                this.cmd.Cancel();
                throw exception;
            }
            finally
            {
                this.cmd.Parameters.Clear();
            }
            return table;
        }

        public void GetDataTableByProcedure(out DataTable dt, string procedureName, params MySqlParameter[] ps)
        {
            dt = new DataTable();
            try
            {
                this.cmd.CommandType = CommandType.StoredProcedure;
                this.cmd.CommandText = procedureName;
                this.cmd.Parameters.AddRange(ps);
                using (MySqlDataAdapter adapter = new MySqlDataAdapter())
                {
                    adapter.SelectCommand = (MySqlCommand)this.cmd;
                    adapter.Fill(dt);
                }
            }
            catch (Exception exception)
            {
                this.cmd.Cancel();
                throw exception;
            }
            finally
            {
                this.cmd.CommandType = CommandType.Text;
                this.cmd.Parameters.Clear();
            }
        }

        public void RollBack()
        {
            try
            {
                if ((this.cmd != null) && (this.cmd.Transaction != null))
                {
                    this.cmd.Transaction.Rollback();
                }
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        public void RunPagingProcedure(out DataTable dt, out long total, string procedureName, params MySqlParameter[] ps)
        {
            dt = new DataTable();
            try
            {
                this.cmd.CommandType = CommandType.StoredProcedure;
                this.cmd.CommandText = procedureName;
                this.cmd.Parameters.AddRange(ps);
                this.cmd.ExecuteNonQuery();
                DataSet dataSet = new DataSet();
                using (MySqlDataAdapter adapter = new MySqlDataAdapter())
                {
                    adapter.SelectCommand = (MySqlCommand)this.cmd;
                    adapter.Fill(dataSet);
                    dt = dataSet.Tables["curData"];
                    total = Convert.ToInt64(dataSet.Tables["pCount"].Rows[0][0]);
                }
            }
            catch (Exception exception)
            {
                this.cmd.Cancel();
                throw exception;
            }
            finally
            {
                this.cmd.CommandType = CommandType.Text;
                this.cmd.Parameters.Clear();
            }

        }

        public void RunProcedure(string procedureName, params MySqlParameter[] ps)
        {
            try
            {
                this.cmd.CommandType = CommandType.StoredProcedure;
                this.cmd.CommandText = procedureName;
                this.cmd.Parameters.AddRange(ps);
                this.cmd.ExecuteNonQuery();
            }
            catch (Exception exception)
            {
                this.cmd.Cancel();
                throw exception;
            }
            finally
            {
                this.cmd.CommandType = CommandType.Text;
                this.cmd.Parameters.Clear();
            }
        }

        // Properties
        public ConnectionState ConnectionState
        {
            get
            {
                return this.conn.State;
            }
        }
    }
}