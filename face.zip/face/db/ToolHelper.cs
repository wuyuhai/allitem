﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Web;
using ThoughtWorks.QRCode.Codec;

namespace face.db
{
    public static class ToolHelper
    {
        public static Bitmap GetDimensionalCode(string link)
        {
            Bitmap bmp = null;
            try
            {
                //创建一个对象
                QRCodeEncoder qrCodeEncoder = new QRCodeEncoder();
                //这里笔者将其设置为字节编码（还有两种编码方式，读者可以自行试验），现在的流行的普遍的二维码都是字节编码。
                qrCodeEncoder.QRCodeEncodeMode = QRCodeEncoder.ENCODE_MODE.BYTE;
                //这里设置规模为：4，版本为：7，其余值读者可以自行试验，这两个值基本只是改变了二维码的大小，读者设置的值都是现在普遍使用的值。
                qrCodeEncoder.QRCodeScale = 8;
                qrCodeEncoder.QRCodeVersion = 0;
                //错误校验（错误更正）的级别,这里设置为中等，一共有四个级别
                qrCodeEncoder.QRCodeErrorCorrect = QRCodeEncoder.ERROR_CORRECTION.M;
                bmp = qrCodeEncoder.Encode(link);
            }
            catch (Exception)
            {
                //MessageBox.Show("Invalid version !");
            }
            return bmp;
        }

        public static byte[] BitmapToBytes(this Bitmap b)
        {
            using (MemoryStream ms = new MemoryStream())
            {
                using (Bitmap res = new Bitmap(b.Width, b.Height))
                {
                    using (Graphics g = Graphics.FromImage(res))
                    {
                        g.CompositingQuality = System.Drawing.Drawing2D.CompositingQuality.HighQuality;
                        g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.High;
                        g.DrawImage(b, 0, 0);
                    }

                    res.Save(ms, ImageFormat.Jpeg);

                    byte[] byteImage = new byte[ms.Length];
                    byteImage = ms.ToArray();
                    return byteImage;
                }
            }
        }
    }
}