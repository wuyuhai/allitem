﻿var utype = "";
var client_id = "";
var scope = "";
var response_type = "";
var state = "";
var goto_url = "";
var uktype = "";

var ctrack = null;
var trackingStarted = false;
faceLength = 0;

var isclose = false;

$(function () {
    // 获取页面传参
    Init();

    if (isIE()) {
        //alert("暂时不支持IE浏览器！");
        $("#video").hide();
        $("#image").show();

        var ocx = document.getElementById("ocx");

        var cam = "";
        try {
            cam = ocx.getCameras()
        } catch (e) {
            window.location.href = "help.html"
        }

        var cameras = JSON.parse(cam);

        if (cameras.length == 0) {
            //alert("没有找到可以使用的摄像头");
            $("#ocx").hide();
            loadQR();
        } else {
            var isSuccess = ocx.openFace(cameras[0].cameraId);

            if (!isSuccess) {
                //alert("打开摄像头失败！");
                $("#ocx").hide();
                loadQR();
            } else {
                window.onbeforeunload = function (event) {
                    ocx.closeFace();
                };
            }
        }


    } else {
        $(".mobile_scan").show();
        openCamera();
    }

    $(".mobile_scan").click(function () {
        isclose = true;

        loadQR();

        try {
            var canvas = document.getElementById('canvas');
            var context = canvas.getContext('2d');
            context.clearRect(0, 0, canvas.width, canvas.height);
            ctrack.stop();
        } catch (e) {

        }
    })

})

function openCamera() {
    vid = document.getElementById('video');

    navigator.getUserMedia = navigator.getUserMedia || navigator.webkitGetUserMedia || navigator.mozGetUserMedia || navigator.msGetUserMedia;
    window.URL = window.URL || window.webkitURL || window.msURL || window.mozURL;

    if (navigator.mediaDevices) {
        try {
            navigator.mediaDevices.getUserMedia({ video: { width: 600, height: 450 } }).then(openCameraSuccess).catch(openCameraFail);
        } catch (e) {
            openCameraFail();
        }

    } else if (navigator.getUserMedia) {
        navigator.getUserMedia({ video: true }, openCameraSuccess, openCameraFail);
    } else {
        open = false;
        //alert("您的浏览器不支持打开摄像头！");
        loadQR()
    }

    vid.addEventListener('canplay', function () {

    }, false);

    ctrack = new clm.tracker();
    ctrack.init();
}

function start() {
    var videoInput = document.getElementById('video');
    var ctracker = new clm.tracker();
    ctracker.init(pModel);
    ctracker.start(videoInput);

    var canvas = document.getElementById('canvas');
    var context = canvas.getContext('2d');
    context.lineWidth = 3;
    context.font = "30px Courier New bold";
    context.fillStyle = "red";
    context.textAlign = 'center';

    var faceArray = [];
    var dt = new Date();

    function interval() {

        context.clearRect(0, 0, canvas.width, canvas.height);
        var positions = ctracker.getCurrentPosition();

        if (positions) {
            // context.fillText("识别到人脸", canvas.width / 2, 40, canvas.width);

            var w = positions[13][0] - positions[0][0];
            var x = positions[0][0] - 10;
            var y = (positions[21][1] + positions[16][1]) / 2 - 20;
            var h = w;

            if (w < 120) {
                context.strokeStyle = "#ff0000";
                context.fillText("请离摄像头近些", canvas.width / 2, 40, canvas.width);
            } else if (w > 320) {
                context.strokeStyle = "#ff0000";
                context.fillText("请离摄像头远些", canvas.width / 2, 40, canvas.width);
            } else if (x < 160 || x > 480 || y < 80 || y > 400) {
                context.strokeStyle = "#ff0000";
                context.fillText("请保持人脸居中", canvas.width / 2, 40, canvas.width);
            } else {
                context.strokeStyle = "#00ff00";
                context.fillText("人脸符合要求", canvas.width / 2, 40, canvas.width);

                if (faceArray.length < 2) {
                    if (new Date().getTime() - dt.getTime() > 1000) {
                        faceArray.push("");
                        dt = new Date();
                        console.log(faceArray.length)
                    }
                } else {
                    // 获取到图片
                    context.clearRect(0, 0, canvas.width, canvas.height);
                    context.drawImage(videoInput, 0, 0, canvas.width, canvas.height);
                    base64 = canvas.toDataURL("image/jpeg");


                    $(".kk").show();
                    $(".line").show();

                    context.strokeStyle = "#00ff00";
                    context.fillText("正在进行人脸比对", canvas.width / 2, 40, canvas.width);

                    // 刷脸登陆
                    var data = {
                        "image": base64.replace("data:image/jpeg;base64,", ""),
                    }

                    $.ajax({
                        url: "ajax.ashx?type=1",
                        type: "POST",
                        data: JSON.stringify(data),
                        dataType: 'json',
                        contentType: 'application/json;charset=utf8',
                        success: function (e) {
                            if (e.ok) {
                                console.log(e)
                                $("#cardNo").val(e.obj.cardNo);
                                $("#sign").val(e.obj.sign);

                                $("#form").submit();
                            } else {
                                alert(e.msg);
                                window.location.reload();
                            }
                        }, error: function (e) {
                            alert("无法连接到服务器！");
                        }
                    })

                    return;
                }
            }

            context.strokeRect(x, y, w, h);
            // context.stroke();
        } else {
            context.fillText("请正对摄像头以识别人脸", canvas.width / 2, 40, canvas.width);
        }

        if (isclose) {
            return;
        }

        requestAnimationFrame(interval);
    }

    interval();
}

function openCameraFail() {
    open = false;
    //alert("打开摄像头失败！");
    loadQR()
}

function openCameraSuccess(stream) {
    if ("srcObject" in vid) {
        vid.srcObject = stream;
    } else {
        vid.src = (window.URL && window.URL.createObjectURL(stream));
    }
    vid.onloadedmetadata = function () {
        vid.play();
        trackingStarted = true;

        start();
    }
    vid.onresize = function () {
        if (trackingStarted) {
            ctrack.stop();
            ctrack.reset();
            ctrack.start(vid);
        }
    }
}

function Init() {
    utype = GetQueryString("utype");
    client_id = GetQueryString("client_id");
    scope = GetQueryString("scope");
    response_type = GetQueryString("response_type");
    state = GetQueryString("state");
    goto_url = GetQueryString("goto_url");
    uktype = GetQueryString("uktype");

    $("#utype").val(utype);
    $("#client_id").val(client_id);
    $("#scope").val(scope);
    $("#response_type").val(response_type);
    $("#state").val(state);
    $("#goto").val(goto_url);
    $("#uktype").val(uktype);
}

function GetQueryString(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
    var r = window.location.search.substr(1).match(reg);
    if (r != null)
        return decodeURI(r[2]);
    return "";
}

function isIE() {
    if (window.navigator.userAgent.indexOf("MSIE") >= 1)
        return true;
    else {
        if (!!window.ActiveXObject || "ActiveXObject" in window)
            return true;
        else
            return false;
    }
}

var time = null;

var shixao = null;

function urlimag(){
	loadQR();
}

function loadQR() {
    $(".qr").hide();
    $(".sm").hide();
    $(".sx").hide();
    $(".qr_tips").text("请使用安卓微信扫描下方二维码");

    if (shixao) {
        clearTimeout(shixao);
    }

    $.ajax({
//      url: "scan.ashx",
        url: "https://gzzw.gzegn.gov.cn:85/face/scan.ashx",
        type: "POST",
        dataType: 'json',
        contentType: 'application/json;charset=utf8',
        success: function (e) {
            if (e.ok) {
                var id = e.obj.id;

                $(".qr_img").attr("src", "data:image/png;base64," + e.obj.base64)
                $(".qr").show();
				clearInterval(time);
                shixao = setTimeout(function () {
                    clearInterval(time);
                    $(".sm").hide();
                    $(".qr_tips").text("二维码已失效");
                    $(".sx img").attr("src", "img/sx.png");
                    $(".sx").show();
                }, 300000);

                // 查询当前状态
                time = setInterval(function () {

                    $.ajax({
                    	url: "https://gzzw.gzegn.gov.cn:85/face/state.ashx?id=" + id,
//                      url: "state.ashx?id=" + id,
                        type: "POST",
                        dataType: 'json',
                        contentType: 'application/json;charset=utf8',
                        success: function (e) {
                            if (e.ok) {
                                // 查询状态

                                if (e.obj.isScan == "1") {
                                    $(".sx").show();
                                    $(".qr_tips").text("请在手机上进行刷脸登录")
                                }

                                if (e.obj.state == "1") {
                                    clearInterval(time);
                                    // 跳转登录

                                    if (!e.obj.cardNo) {
                                        alert("对不起，人脸验证失败！\n请确保在网厅已注册并实名人证！");
                                    }

                                    $("#cardNo").val(e.obj.cardNo);
                                    $("#sign").val(e.obj.sign);
                                    $("#form").submit();
                                } else if (e.obj.state == "2") {
                                    clearInterval(time);
                                    $(".qr_tips").text(e.obj.message + "，请重新扫码！")
                                    alert(e.obj.message + ", 请重新扫码！");

                                    loadQR();
                                }

                            } else {

                            }
                        }, error: function (e) {

                        }
                    })

                }, 1500);
            } else {
                alert(e.msg);
                window.location.reload();
            }
        }, error: function (e) {
            alert("无法连接到服务器！");
        }
    })
}
console.log(111)
function guanbiqr(){
	$(".qr").hide()
}