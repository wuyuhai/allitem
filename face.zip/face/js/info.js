var idNumber = "";
var name = "";
var uid = "";

var ctrack = null;
var trackingStarted = false;

$(function () {
    if (isIE()) {
        alert("暂时不支持IE浏览器！");
        return;
    }

    init();


})

function init() {
    idNumber = GetQueryString("cardNo");
    name = GetQueryString("userName");
    uid = GetQueryString("lname");

    $("#name").val(name);
    $("#idNumber").val(idNumber);

    if (uid == "") {
        uid = "Tozt";
    }

    if (idNumber == "") {
        alert("身份证号不能为空！");
    }

    if (name == "") {
        alert("姓名不能为空！");
    }

    initPCC(0, "province");

    layui.use('laydate', function () {
        var laydate = layui.laydate;

        laydate.render({
            elem: '#startDate',
            format: 'yyyy-MM-dd'
        });

        laydate.render({
            elem: '#endDate',
            format: 'yyyy-MM-dd'
        });
    })

    layui.use(['form', 'layedit', 'laydate'], function () {
        var form = layui.form
            , layer = layui.layer
            , layedit = layui.layedit
            , laydate = layui.laydate;
        form.verify({
            idNumber: function (value, item) {
                var city = { 11: "北京", 12: "天津", 13: "河北", 14: "山西", 15: "内蒙古", 21: "辽宁", 22: "吉林", 23: "黑龙江 ", 31: "上海", 32: "江苏", 33: "浙江", 34: "安徽", 35: "福建", 36: "江西", 37: "山东", 41: "河南", 42: "湖北 ", 43: "湖南", 44: "广东", 45: "广西", 46: "海南", 50: "重庆", 51: "四川", 52: "贵州", 53: "云南", 54: "西藏 ", 61: "陕西", 62: "甘肃", 63: "青海", 64: "宁夏", 65: "新疆", 71: "台湾", 81: "香港", 82: "澳门", 91: "国外 " };
                var tip = "";
                var pass = true;

                var reg = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/;

                if (!value || !reg.test(value)) {
                    tip = "身份证号格式错误";
                    pass = false;
                }
                else if (!city[value.substr(0, 2)]) {
                    tip = "地址编码错误";
                    pass = false;
                }
                else {
                    //18位身份证需要验证最后一位校验位
                    if (value.length == 18) {
                        value = value.split('');
                        //加权因子
                        var factor = [7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2];
                        //校验位
                        var parity = [1, 0, 'X', 9, 8, 7, 6, 5, 4, 3, 2];
                        var sum = 0;
                        var ai = 0;
                        var wi = 0;
                        for (var i = 0; i < 17; i++) {
                            ai = value[i];
                            wi = factor[i];
                            sum += ai * wi;
                        }
                        var last = parity[sum % 11];
                        if (parity[sum % 11] != value[17]) {
                            tip = "校验位错误";
                            pass = false;
                        }
                    }
                }
                if (!pass) {
                    return "身份证号填写有误：" + tip;
                };
            },
            mobile: function (value, item) {
                if (!new RegExp(/^1[34578]\d{9}$/).test(value)) {
                    return "手机号格式错误！";
                }
            },
            startDate: function (value, item) {
                if (value == "") {
                    return "身份证有效期开始不能为空！";
                } else {
                    if (!value.match(/^((?:19|20)\d\d)-(0[1-9]|1[012])-(0[1-9]|[12][0-9]|3[01])$/)) {
                        return "开始日期格式错误！";
                    }
                }
            },
            endDate: function (value, item) {
                if (value == "") {
                    return "身份证有效期结束不能为空！";
                } else {
                    if (!value.match(/^((?:19|20)\d\d)-(0[1-9]|1[012])-(0[1-9]|[12][0-9]|3[01])$/)) {
                        return "结束日期格式错误！";
                    }
                }
            },
            front: function (value, item) {
                if (value == "") {
                    return "请上传身份证正面图片！";
                }
            },
            after: function (value, item) {
                if (value == "") {
                    return "请上传身份证反面图片！";
                }
            },
        });

        form.on('select(province)', function (data) {
            var province = data.value;
            if (province == "") {
                $("#city option[value!='']").remove();
                $("#county option[value!='']").remove();
            } else {
                $("#city option[value!='']").remove();
                $("#county option[value!='']").remove();

                initPCC(province, "city");
            }

            layui.form.render('select');
        });

        form.on('select(city)', function (data) {
            var city = data.value;
            if (city == "") {
                $("#county option[value!='']").remove();
            } else {
                $("#county option[value!='']").remove();

                initPCC(city, "county");
            }

            layui.form.render('select');
        });
    });

    layui.use('layer', function () { //独立版的layer无需执行这一句
        var $ = layui.jquery, layer = layui.layer; //独立版的layer无需执行这一句

        //触发事件
        var active = {
            cardPhoto: function () {
                //示范一个公告层
                layer.open({
                    type: 1
                    , title: false //不显示标题栏
                    , closeBtn: true
                    , area: '600px;'
                    , shade: 0.5
                    , id: 'LAY_layuipro' //设定一个id，防止重复弹出
                    //, btn: ['确定拍摄']
                    , shadeClose: true
                    , btnAlign: 'c'
                    , moveType: 0
                    , move: false //拖拽模式，0或者1
                    , content: '<div class="title1">温馨提示</div><div style="padding:30px 30px;">    <div class="tip">        <div>请拍摄身份证正面</div>        <div>拍摄时请确保身份证<span style="color:#2196f3;">边框完整，字体清晣，亮度均匀</span>:</div>    </div>    <div class="layui-fluid">        <div class="layui-row">            <div class="layui-col-sm3 div_show">                <div class="div_icon">                    <img src="img/icon1.png" /> </div>                <div class="div_tips">                    <i class="layui-icon" style="font-size: 25px; color: #0eb43d;">&#xe616;</i>标准 </div>            </div>            <div class="layui-col-sm3 div_show">                <div class="div_icon">                    <img src="img/icon2.png" style="width:80px;left:90px;"/> </div>                <div class="div_tips">                    <i class="layui-icon" style="font-size: 25px; color: #ed393a;">&#x1007;</i>边框缺失 </div>            </div>            <div class="layui-col-sm3 div_show">                <div class="div_icon">                    <img src="img/icon3.png" /> </div>                <div class="div_tips">                    <i class="layui-icon" style="font-size: 25px; color: #ed393a;">&#x1007;</i>照片模糊 </div>            </div>            <div class="layui-col-sm3 div_show">                <div class="div_icon">                    <img src="img/icon4.png" /> </div>                <div class="div_tips">                    <i class="layui-icon" style="font-size: 25px; color: #ed393a;">&#x1007;</i>闪光强烈 </div>            </div>        </div>    </div></div><button class="layui-btn layui-btn-lg layui-btn-normal shot" onclick="photo()">拍摄身份证正面</button>'
                    , success: function (layero) {
                        if (card == "front") {
                            $(".shot").text("上传身份证正面");
                        } else {
                            $(".shot").text("上传身份证反面");
                        }
                    }
                });
            },
            submit: function () {
                layer.open({
                    type: 1
                    , title: false //不显示标题栏
                    , closeBtn: false
                    , area: '700px;'
                    , shade: 0.5
                    , id: 'LAY_submit' //设定一个id，防止重复弹出
                    , shadeClose: false
                    , btnAlign: 'c'
                    , moveType: 0
                    , move: false //拖拽模式，0或者1
                    , content: '<div class="title1">刷脸</div><div style="padding:30px 30px;">    <div class="face_div" style="">        <video id="video" width="600" height="450" autoplay>请尝试在Edge或者火狐浏览器中尝试打开！</video>        <canvas id="canvas" width="600" height="450"></canvas>        <div class="kk"></div>        <div class="line"></div>    </div></div>'
                    , success: function (layero) {
                        openCamera();
                    }
                });
            }
        };

        $('.upload_btn').on('click', function () {
            var othis = $(this), method = othis.data('method');
            card = othis.data('card');
            active[method] ? active[method].call(this, othis) : '';
        });

        $('.upload').on('click', function () {
            var name = $("#name").val();
            var idNumber = $("#idNumber").val();
            var mobile = $("#mobile").val();
            var province = $("#province").val();
            var city = $("#city").val();
            var county = $("#county").val();
            var address = $("#address").val();

            var startDate = $("#startDate").val();;
            var endDate = $("#endDate").val();

            var idCardFm = $("#after").val();
            var idCardZm = $("#front").val();

            try {
                if (parseInt(idNumber.substr(16, 1)) % 2 == 1) {
                    $("#sex").val(0);
                } else {
                    $("#sex").val(1);
                }

                $("#birthday").val(idNumber.substring(6, 10) + "-" + idNumber.substring(10, 12) + "-" + idNumber.substring(12, 14))
            } catch (e) {
                layer.alert("身份证格式错误！")
                return;
            }

            // 判断时间比较
            if ((new Date(startDate.replace(/-/g, "\/"))) > (new Date(endDate.replace(/-/g, "\/")))) {
                layer.alert("结束时间不能大于开始时间！")
                return;
            }

            var sex = $("#sex").val();
            var birthday = $("#birthday").val();;

            if (!name || !idNumber || !province || !city || !county || !mobile || !address || !startDate || !endDate || !idCardFm || !idCardZm || !sex || !birthday) {
                return;
            }

            var othis = $(this), method = othis.data('method');
            active[method] ? active[method].call(this, othis) : '';
        });

        $("#idNumber").on('change', function () {
            var num = $(this).val();
            if (IdentityCodeValid(num)) {
                if (parseInt(num.substr(16, 1)) % 2 == 1) {
                    $("#sex").val(0);
                } else {
                    $("#sex").val(1);
                }

                $("#birthday").val(num.substring(6, 10) + "-" + num.substring(10, 12) + "-" + num.substring(12, 14));
            } else {
                $("#sex").val("");
                $("#birthday").val("");
                $("#idNumber").val("");
                layer.alert("身份证格式有误！");
            }
        });

        $(".userDate").on('change', function () {
            $(this).val("");
            layer.alert("请选择日期，不要手动输入！")
        })
    });
}

function isIE() {
    if (window.navigator.userAgent.indexOf("MSIE") >= 1)
        return true;
    else {
        if (!!window.ActiveXObject || "ActiveXObject" in window)
            return true;
        else
            return false;
    }
}

function initPCC(id, type) {
    if (type == "province") {

    }

    var list = country.filter(function (item) {
        return item.p == id;
    });

    for (var i = 0; i < list.length; i++) {
        $("#" + type).append("<option value='" + list[i].id + "' " + (type == "province" && list[i].n == "贵州省" ? "selected" : "") + " >" + list[i].n + "</option>")
        if (type == "province" && list[i].n == "贵州省") {
            initPCC(list[i].id, "city")
        }
    }
    try {
        layui.form.render('select');
    } catch (e) {

    }
}

function photo() {
    GetImageBase64(card == "front" ? $("#fileFront") : $("#fileAfter"), card);
    layer.closeAll();
    if (card == "front") {
        $("#fileFront").click();
    } else {
        $("#fileAfter").click();
    }
}

function GetImageBase64(file, type) {
    file.change(function () {
        selectFileImage(this, type);
    });
}

function selectFileImage(fileObj, type) {
    var file = fileObj.files['0'];
    //图片方向角
    var Orientation = null;

    if (file) {
        var rFilter = /^(image\/jpeg|image\/png)$/i; // 检查图片格式  
        if (!rFilter.test(file.type)) {
            alert("请选择jpeg、png格式的图片！");
            return;
        }
        // var URL = URL || webkitURL;  
        //获取照片方向角属性，用户旋转控制  
        EXIF.getData(file, function () {
            // alert(EXIF.pretty(this));  
            EXIF.getAllTags(this);
            //alert(EXIF.getTag(this, 'Orientation'));   
            Orientation = EXIF.getTag(this, 'Orientation');
            //return;  
        });

        var oReader = new FileReader();
        oReader.readAsDataURL(file);
        oReader.onload = function (e) {
            var image = new Image();
            image.src = e.target.result;
            image.onload = function () {
                var expectWidth = this.naturalWidth;
                var expectHeight = this.naturalHeight;

                if (this.naturalWidth > this.naturalHeight && this.naturalWidth > 1400) {
                    expectWidth = 1400;
                    expectHeight = expectWidth * this.naturalHeight / this.naturalWidth;
                } else if (this.naturalHeight > this.naturalWidth && this.naturalHeight > 1400) {
                    expectHeight = 1400;
                    expectWidth = expectHeight * this.naturalWidth / this.naturalHeight;
                }
                var canvas = document.createElement("canvas");
                var ctx = canvas.getContext("2d");
                canvas.width = expectWidth;
                canvas.height = expectHeight;
                ctx.drawImage(this, 0, 0, expectWidth, expectHeight);
                var base64 = null;
                //修复ios
                if (!!navigator.userAgent.match(/\(i[^;]+;( U;)? CPU.+Mac OS/)) {
                    //如果方向角不为1，都需要进行旋转
                    if (Orientation != "" && Orientation != 1) {
                        // alert('旋转处理');  
                        switch (Orientation) {
                            case 6://需要顺时针（向左）90度旋转  
                                // alert('需要顺时针（向左）90度旋转');  
                                rotateImg(this, 'left', canvas);
                                break;
                            case 8://需要逆时针（向右）90度旋转  
                                // alert('需要顺时针（向右）90度旋转');  
                                rotateImg(this, 'right', canvas);
                                break;
                            case 3://需要180度旋转  
                                // alert('需要180度旋转');  
                                rotateImg(this, 'right', canvas);//转两次  
                                rotateImg(this, 'right', canvas);
                                break;
                        }
                    }

                    base64 = canvas.toDataURL("image/jpeg");
                } else if (navigator.userAgent.match(/Android/i)) {// 修复android
                    try {
                        var encoder = new JPEGEncoder();
                        base64 = encoder.encode(ctx.getImageData(0, 0, expectWidth, expectHeight));
                    } catch (e) {
                        base64 = canvas.toDataURL("image/jpeg");
                    }
                } else {
                    if (Orientation != "" && Orientation != 1) {
                        //alert('旋转处理');  
                        switch (Orientation) {
                            case 6://需要顺时针（向左）90度旋转  
                                // alert('需要顺时针（向左）90度旋转');  
                                rotateImg(this, 'left', canvas);
                                break;
                            case 8://需要逆时针（向右）90度旋转  
                                // alert('需要顺时针（向右）90度旋转');  
                                rotateImg(this, 'right', canvas);
                                break;
                            case 3://需要180度旋转  
                                // alert('需要180度旋转');  
                                rotateImg(this, 'right', canvas);//转两次  
                                rotateImg(this, 'right', canvas);
                                break;
                        }
                    }

                    base64 = canvas.toDataURL("image/jpeg");
                }

                if (type == "front") {
                    $("#front_img").attr("src", base64);
                    $("#front").val(base64.replace("data:image/jpeg;base64,", ""));
                } else {
                    $("#after_img").attr("src", base64);
                    $("#after").val(base64.replace("data:image/jpeg;base64,", ""));
                }
            };
        };
    }
}
//对图片旋转处理
function rotateImg(img, direction, canvas) {
    //alert(img);  
    //最小与最大旋转方向，图片旋转4次后回到原方向    
    var min_step = 0;
    var max_step = 3;
    //var img = document.getElementById(pid);    
    if (img == null) return;
    //img的高度和宽度不能在img元素隐藏后获取，否则会出错    
    var height = img.height;
    var width = img.width;
    //var step = img.getAttribute('step');    
    var step = 2;
    if (step == null) {
        step = min_step;
    }
    if (direction == 'right') {
        step++;
        //旋转到原位置，即超过最大值    
        step > max_step && (step = min_step);
    } else {
        step--;
        step < min_step && (step = max_step);
    }

    //旋转角度以弧度值为参数    
    var degree = step * 90 * Math.PI / 180;
    var ctx = canvas.getContext('2d');
    switch (step) {
        case 0:
            canvas.width = width;
            canvas.height = height;
            ctx.drawImage(img, 0, 0);
            break;
        case 1:
            canvas.width = height;
            canvas.height = width;
            ctx.rotate(degree);
            ctx.drawImage(img, 0, -height);
            break;
        case 2:
            canvas.width = width;
            canvas.height = height;
            ctx.rotate(degree);
            ctx.drawImage(img, -width, -height);
            break;
        case 3:
            canvas.width = height;
            canvas.height = width;
            ctx.rotate(degree);
            ctx.drawImage(img, -width, 0);
            break;
    }
}

function openCamera() {
    $(".kk").hide();
    $(".line").hide();

    vid = document.getElementById('video');

    navigator.getUserMedia = navigator.getUserMedia || navigator.webkitGetUserMedia || navigator.mozGetUserMedia || navigator.msGetUserMedia;
    window.URL = window.URL || window.webkitURL || window.msURL || window.mozURL;

    if (navigator.mediaDevices) {
        try {
            navigator.mediaDevices.getUserMedia({ video: { width: 600, height: 450 } }).then(openCameraSuccess).catch(openCameraFail);
        } catch (e) {
            openCameraFail();
        }

    } else if (navigator.getUserMedia) {
        navigator.getUserMedia({ video: true }, openCameraSuccess, openCameraFail);
    } else {
        open = false;
        alert("您的浏览器不支持getUserMedia，请尝试在Edge或者火狐浏览器中尝试打开！");
    }

    vid.addEventListener('canplay', function () {

    }, false);

    ctrack = new clm.tracker();
    ctrack.init();
}

function start() {
    var videoInput = document.getElementById('video');
    var ctracker = new clm.tracker();
    ctracker.init(pModel);
    ctracker.start(videoInput);

    var canvas = document.getElementById('canvas');
    var context = canvas.getContext('2d');
    context.lineWidth = 3;
    context.font = "30px Courier New bold";
    context.fillStyle = "red";
    context.textAlign = 'center';

    var faceArray = [];
    var dt = new Date();

    function interval() {
        context.clearRect(0, 0, canvas.width, canvas.height);
        var positions = ctracker.getCurrentPosition();

        if (positions) {
            // context.fillText("识别到人脸", canvas.width / 2, 40, canvas.width);

            var w = positions[13][0] - positions[0][0];
            var x = positions[0][0] - 10;
            var y = (positions[21][1] + positions[16][1]) / 2 - 20;
            var h = w;

            if (w < 120) {
                context.strokeStyle = "#ff0000";
                context.fillText("请离摄像头近些", canvas.width / 2, 40, canvas.width);
            } else if (w > 320) {
                context.strokeStyle = "#ff0000";
                context.fillText("请离摄像头远些", canvas.width / 2, 40, canvas.width);
            } else if (x < 160 || x > 480 || y < 80 || y > 400) {
                context.strokeStyle = "#ff0000";
                context.fillText("请保持人脸居中", canvas.width / 2, 40, canvas.width);
            } else {
                context.strokeStyle = "#00ff00";
                context.fillText("人脸符合要求", canvas.width / 2, 40, canvas.width);

                if (faceArray.length < 2) {
                    if (new Date().getTime() - dt.getTime() > 1000) {
                        faceArray.push("");
                        dt = new Date();
                        console.log(faceArray.length)
                    }
                } else {
                    // 获取到图片
                    context.clearRect(0, 0, canvas.width, canvas.height);
                    context.drawImage(videoInput, 0, 0, canvas.width, canvas.height);
                    base64 = canvas.toDataURL("image/jpeg");


                    $(".kk").show();
                    $(".line").show();

                    context.strokeStyle = "#00ff00";
                    context.fillText("正在进行人脸比对", canvas.width / 2, 40, canvas.width);

                    // 实名认证
                    var data = {
                        liveImage: base64.replace("data:image/jpeg;base64,", ""),
                        frontImage: $("#front").val(),
                        backImage: $("#after").val(),
                        name: $("#name").val(),
                        mobile: $("#mobile").val(),
                        idNumber: $("#idNumber").val(),
                        address: $("#province").find("option:selected").text() + $("#city").find("option:selected").text() + $("#county").find("option:selected").text() + $("#address").val(),
                        start_date: $("#startDate").val(),
                        end_date: $("#endDate").val(),

                    }

                    $.ajax({
                        url: "ajax.ashx?type=2",
                        type: "POST",
                        data: JSON.stringify(data),
                        dataType: 'json',
                        contentType: 'application/json;charset=utf8',
                        success: function (e) {
                            alert(e.msg);

                            $("#uid").val(uid);
                            $("#sign").val(e.obj.sign);
                            $("#client_id").val(e.obj.client_id);
                            $("#time").val(e.obj.time);

                            $("#form").submit();
                        }, error: function (e) {
                            alert("无法连接到服务器！");
                        }
                    })

                    return;
                }
            }

            context.strokeRect(x, y, w, h);
            // context.stroke();
        } else {
            context.fillText("请正对摄像头以识别人脸", canvas.width / 2, 40, canvas.width);
        }

        requestAnimationFrame(interval);
    }

    interval();
}

function openCameraFail() {
    open = false;
    alert("打开摄像头失败！");
}

function openCameraSuccess(stream) {
    if ("srcObject" in vid) {
        vid.srcObject = stream;
    } else {
        vid.src = (window.URL && window.URL.createObjectURL(stream));
    }
    vid.onloadedmetadata = function () {
        vid.play();
        trackingStarted = true;

        start();
    }
    vid.onresize = function () {
        if (trackingStarted) {
            ctrack.stop();
            ctrack.reset();
            ctrack.start(vid);
        }
    }
}