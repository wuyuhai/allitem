﻿var vid = null;
var vid_width = null;
var vid_height = null;
var overlay = null;
var overlayCC = null;
var trackingStarted = false;
var ctrack = null;
var showpos = false;
var isRealName = "";
var open = true;
var base64 = "";
var isReShot = false;

var card = "front";

$(function () {
    console.log(window.location.href)
    initPCC(0, "province");
    var cardNo = GetQueryString("cardNo");
    var userName = GetQueryString("userName");
    uid = GetQueryString("lname");

    if (isIE()) {
        window.location.href = "infoPcIE.html?cardNo=" + cardNo + "&userName=" + userName + "&lname=" + uid
    }

    if (uid == "") {
        uid = "Tozt";
    }

    if (cardNo == "") {
        alert("身份证号不能为空！");
    }

    if (userName == "") {
        alert("姓名不能为空！");
    }

    $("#name").val(userName);
    $("#idNumber").val(cardNo);


    var data = {
        "idNumber": cardNo,
    }

    $.post({
        url: url + "?type=3",
        type: "POST",
        data: JSON.stringify(data),
        dataType: 'json',
        contentType: 'application/json;charset=utf8',
        success: function (e) {
            if (e.errno == 0) {
                $("#mobile").val(e.rst.userInfo.mobile);
                $("#mobile").val(e.rst.userInfo.mobile);
                $("#startDate").val(e.rst.userInfo.startDate);
                $("#endDate").val(e.rst.userInfo.endDate);

                //var areaId = e.ret.userInfo.endDate;
                //var cityId = e.ret.userInfo.cityId;
                //var provinceId = e.ret.userInfo.provinceId;

                //$("#province").val()

                //$("")
            } else {
                layui.layer.alert(e.errmsg);
            }
        }, error: function (e) {
            layui.layer.alert("无法连接到服务器！");
        }
    })

    layui.use('laydate', function () {
        var laydate = layui.laydate;

        laydate.render({
            elem: '#startDate',
            format: 'yyyy-MM-dd'
        });

        laydate.render({
            elem: '#endDate',
            format: 'yyyy-MM-dd'
        });
    })

    layui.use(['form', 'layedit', 'laydate'], function () {
        var form = layui.form
        , layer = layui.layer
        , layedit = layui.layedit
        , laydate = layui.laydate;
        form.verify({
            idNumber: function (value, item) {
                var city = { 11: "北京", 12: "天津", 13: "河北", 14: "山西", 15: "内蒙古", 21: "辽宁", 22: "吉林", 23: "黑龙江 ", 31: "上海", 32: "江苏", 33: "浙江", 34: "安徽", 35: "福建", 36: "江西", 37: "山东", 41: "河南", 42: "湖北 ", 43: "湖南", 44: "广东", 45: "广西", 46: "海南", 50: "重庆", 51: "四川", 52: "贵州", 53: "云南", 54: "西藏 ", 61: "陕西", 62: "甘肃", 63: "青海", 64: "宁夏", 65: "新疆", 71: "台湾", 81: "香港", 82: "澳门", 91: "国外 " };
                var tip = "";
                var pass = true;

                var reg = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/;

                if (!value || !reg.test(value)) {
                    tip = "身份证号格式错误";
                    pass = false;
                }
                else if (!city[value.substr(0, 2)]) {
                    tip = "地址编码错误";
                    pass = false;
                }
                else {
                    //18位身份证需要验证最后一位校验位
                    if (value.length == 18) {
                        value = value.split('');
                        //加权因子
                        var factor = [7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2];
                        //校验位
                        var parity = [1, 0, 'X', 9, 8, 7, 6, 5, 4, 3, 2];
                        var sum = 0;
                        var ai = 0;
                        var wi = 0;
                        for (var i = 0; i < 17; i++) {
                            ai = value[i];
                            wi = factor[i];
                            sum += ai * wi;
                        }
                        var last = parity[sum % 11];
                        if (parity[sum % 11] != value[17]) {
                            tip = "校验位错误";
                            pass = false;
                        }
                    }
                }
                if (!pass) {
                    return "身份证号填写有误：" + tip;
                };
            },
            mobile: function (value, item) {
                if (!new RegExp(/^1[34578]\d{9}$/).test(value)) {
                    return "手机号格式错误！";
                }
            },
            startDate: function (value, item) {
                if (value == "") {
                    return "身份证有效期开始不能为空！";
                } else {
                    if (!value.match(/^((?:19|20)\d\d)-(0[1-9]|1[012])-(0[1-9]|[12][0-9]|3[01])$/)) {
                        return "开始日期格式错误！";
                    }
                }
            },
            endDate: function (value, item) {
                if (value == "") {
                    return "身份证有效期结束不能为空！";
                } else {
                    if (!value.match(/^((?:19|20)\d\d)-(0[1-9]|1[012])-(0[1-9]|[12][0-9]|3[01])$/)) {
                        return "结束日期格式错误！";
                    }
                }
            },
            front: function (value, item) {
                if (value == "") {
                    return "请上传身份证正面图片！";
                }
            },
            after: function (value, item) {
                if (value == "") {
                    return "请上传身份证反面图片！";
                }
            },
        });


        form.on('select(province)', function (data) {
            var province = data.value;
            if (province == "") {
                $("#city option[value!='']").remove();
                $("#county option[value!='']").remove();
            } else {
                $("#city option[value!='']").remove();
                $("#county option[value!='']").remove();
                
                initPCC(province, "city");
            }

            layui.form.render('select');
        });

        form.on('select(city)', function (data) {
            var city = data.value;
            if (city == "") {
                $("#county option[value!='']").remove();
            } else {
                $("#county option[value!='']").remove();
                
                initPCC(city, "county");
            }

            layui.form.render('select');
        });
    });

    layui.use('layer', function () { //独立版的layer无需执行这一句
        var $ = layui.jquery, layer = layui.layer; //独立版的layer无需执行这一句

        //触发事件
        var active = {
            cardPhoto: function () {
                //示范一个公告层
                layer.open({
                    type: 1
                  , title: false //不显示标题栏
                  , closeBtn: true
                  , area: '600px;'
                  , shade: 0.5
                  , id: 'LAY_layuipro' //设定一个id，防止重复弹出
                    //, btn: ['确定拍摄']
                  , shadeClose: true
                  , btnAlign: 'c'
                  , moveType: 0
                  , move: false //拖拽模式，0或者1
                  , content: '<div class="title1">温馨提示</div><div style="padding:30px 30px;">    <div class="tip">        <div>请拍摄身份证正面</div>        <div>拍摄时请确保身份证<span style="color:#2196f3;">边框完整，字体清晣，亮度均匀</span>:</div>    </div>    <div class="layui-fluid">        <div class="layui-row">            <div class="layui-col-sm3 div_show">                <div class="div_icon">                    <img src="img/icon1.png" /> </div>                <div class="div_tips">                    <i class="layui-icon" style="font-size: 25px; color: #0eb43d;">&#xe616;</i>标准 </div>            </div>            <div class="layui-col-sm3 div_show">                <div class="div_icon">                    <img src="img/icon2.png" style="width:80px;left:90px;"/> </div>                <div class="div_tips">                    <i class="layui-icon" style="font-size: 25px; color: #ed393a;">&#x1007;</i>边框缺失 </div>            </div>            <div class="layui-col-sm3 div_show">                <div class="div_icon">                    <img src="img/icon3.png" /> </div>                <div class="div_tips">                    <i class="layui-icon" style="font-size: 25px; color: #ed393a;">&#x1007;</i>照片模糊 </div>            </div>            <div class="layui-col-sm3 div_show">                <div class="div_icon">                    <img src="img/icon4.png" /> </div>                <div class="div_tips">                    <i class="layui-icon" style="font-size: 25px; color: #ed393a;">&#x1007;</i>闪光强烈 </div>            </div>        </div>    </div></div><button class="layui-btn layui-btn-lg layui-btn-normal shot" onclick="photo()">拍摄身份证正面</button>'
                  , success: function (layero) {
                      if (card == "front") {
                          $(".shot").text("上传身份证正面");
                      } else {
                          $(".shot").text("上传身份证反面");
                      }
                  }
                });
            },
            submit: function () {
                layer.open({
                    type: 1
                  , title: false //不显示标题栏
                  , closeBtn: false
                  , area: '600px;'
                  , shade: 0.5
                  , id: 'LAY_submit' //设定一个id，防止重复弹出
                  , shadeClose: false
                  , btnAlign: 'c'
                  , moveType: 0
                  , move: false //拖拽模式，0或者1
                  , content: '<div class="title1">刷脸</div><div style="padding:30px 30px;">    <div class="face_div" style="">        <video id="video" width="480" height="360" autoplay>请尝试在Edge或者火狐浏览器中尝试打开！</video>        <canvas id="canvas" width="480" height="360"></canvas>        <div class="kk"></div>        <div class="line"></div>    </div></div><button class="layui-btn layui-btn-lg layui-btn-normal submit" style="margin-top:10px;width:20%;float:right;margin-right:30px;margin-bottom:10px;" id="submit">满意上传</button><button class="layui-btn layui-btn-primary" style="margin-top:10px;width:30%;height: 44px;float:right;margin-right:30px;margin-bottom:10px;" id="reShot">不满意重新拍摄</button>'
                  , success: function (layero) {
                      vid = document.getElementById('video');
                      vid_width = vid.width;
                      vid_height = vid.height;
                      overlay = document.getElementById('canvas');
                      overlayCC = overlay.getContext('2d');

                      navigator.getUserMedia = navigator.getUserMedia || navigator.webkitGetUserMedia || navigator.mozGetUserMedia || navigator.msGetUserMedia;
                      window.URL = window.URL || window.webkitURL || window.msURL || window.mozURL;

                      if (navigator.mediaDevices) {
                          try {
                              navigator.mediaDevices.getUserMedia({ video: true }).then(gumSuccess)
                          } catch (e) {
                              gumFail();
                          }
                      } else if (navigator.getUserMedia) {
                          navigator.getUserMedia({ video: true }, gumSuccess, gumFail);
                      } else {
                          layui.layer.closeAll();
                          layer.alert("您的浏览器不支持getUserMedia，请尝试在Edge或者火狐浏览器中尝试打开！");
                      }

                      vid.addEventListener('canplay', enablestart, false);

                      ctrack = new clm.tracker();
                      ctrack.init();

                      allChceck();

                      $("#reShot").click(function () {
                          if (index != 5 && !isReShot) {
                              return false;
                          }
                          index = 0;
                          var media = document.getElementById("media");
                          var videoInput = document.getElementById('video');
                          var canvasInput = document.getElementById('canvas');
                          var cc = canvasInput.getContext('2d');
                          cc.clearRect(0, 0, canvasInput.width, canvasInput.height);

                          cc.font = ($("#canvas").height() / 3) + "px Courier New bold";
                          //设置字体填充颜色
                          cc.fillStyle = "red";

                          var w = $("#canvas").width() / 10;
                          var h = $("#canvas").height() / 6;

                          var buzhou = 0;

                          var aa = setInterval(function () {
                              if (buzhou == 0) {
                                  cc.clearRect(0, 0, canvasInput.width, canvasInput.height);
                                  cc.fillText("3", canvasInput.width / 2 - w, canvasInput.height / 2) + h;
                                  media.src = "wav/3.wav";
                                  media.play();
                              } else if (buzhou == 1) {
                                  cc.clearRect(0, 0, canvasInput.width, canvasInput.height);
                                  cc.fillText("2", canvasInput.width / 2 - w, canvasInput.height / 2) + h;
                                  media.src = "wav/2.wav";
                                  media.play();
                              } else if (buzhou == 2) {
                                  cc.clearRect(0, 0, canvasInput.width, canvasInput.height);
                                  cc.fillText("1", canvasInput.width / 2 - w, canvasInput.height / 2) + h;
                                  media.src = "wav/1.wav";
                                  media.play();
                              } else if (buzhou == 3) {
                                  cc.clearRect(0, 0, canvasInput.width, canvasInput.height);
                                  media.src = "wav/拍摄.wav";
                                  media.play();
                              } else if (buzhou == 4) {
                                  cc.drawImage(videoInput, 0, 0, canvasInput.width, canvasInput.height);
                                  media.src = "wav/请确认效果.wav";
                                  media.play();
                              } else {
                                  isReShot = true;
                                  clearInterval(aa);
                              }
                              buzhou++;
                          }, 800);
                      })

                      $("#submit").click(function () {
                          base64 = document.getElementById("canvas").toDataURL("image/jpeg");

                          var index = base64.indexOf("data:image/jpeg;base64,");

                          if (index < 0 || base64.indexOf("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA") > 0) {
                              layer.alert("人像不能为空");
                              return;
                          }
                          base64 = base64.replace("data:image/jpeg;base64,", "");

                          var name = $("#name").val();
                          var idNumber = $("#idNumber").val();
                          var mobile = $("#mobile").val();

                          var provinceId = $("#province").val();
                          var provinceName = $("#province").find("option:selected").text();
                          var cityId = $("#city").val();
                          var cityName = $("#city").find("option:selected").text();
                          var areaId = $("#county").val();
                          var areaName = $("#county").find("option:selected").text();

                          var address = $("#address").val();
                          var startDate = $("#startDate").val();
                          var endDate = $("#endDate").val();
                          var idCardFm = $("#after").val();
                          var idCardZm = $("#front").val();
                          var sex = $("#sex").val();
                          var birthday = $("#birthday").val();;

                          if (!name || !idNumber || !mobile || !provinceId || !provinceName || !cityId || !cityName || !areaId || !areaName || !address || !startDate || !endDate || !idCardFm || !idCardZm || !sex || !birthday) {
                              layer.alert("数据异常！");
                              return false;
                          }

                          var data = {
                              "scenePhoto": encodeURIComponent(base64),
                              "idCardZm": encodeURIComponent(idCardZm),
                              "idCardFm": encodeURIComponent(idCardFm),
                              "mobile": mobile,
                              "idNumber": idNumber,
                              "name": encodeURIComponent(name),
                              "sex": sex,
                              "birthday": birthday,

                              "provinceId": provinceId,
                              "provinceName": encodeURIComponent(provinceName),
                              "cityId": cityId,
                              "cityName": encodeURIComponent(cityName),
                              "areaId": areaId,
                              "areaName": encodeURIComponent(areaName),

                              "address": encodeURIComponent(address),
                              "startDate": startDate,
                              "endDate": endDate
                          }

                          $.post({
                              url: url + "?type=0",
                              type: "POST",
                              data: JSON.stringify(data),
                              dataType: 'json',
                              contentType: 'application/json;charset=utf8',
                              success: function (e) {
                                  if (e.errno == 0) {
                                      alert("实名认证成功！");
                                      // 跳转
                                      $("#uid").val(uid);
                                      $("#sign").val(e.sign);
                                      $("#client_id").val(e.client_id);
                                      $("#time").val(e.time);

                                      $("#form").submit();
                                  } else if (e.errno == 104) {
                                      alert("正在审核！");
                                      // 跳转
                                      $("#uid").val(uid);
                                      $("#sign").val(e.sign);
                                      $("#client_id").val(e.client_id);
                                      $("#time").val(e.time);

                                      $("#form").submit();
                                  } else {
                                      alert(e.errmsg);

                                      $("#uid").val(uid);
                                      $("#sign").val(e.sign);
                                      $("#client_id").val(e.client_id);
                                      $("#time").val(e.time);

                                      $("#form").submit();
                                  }
                              }, error: function (e) {
                                  layer.alert("无法连接到服务器！");
                              }
                          })
                      })
                  }
                });
            }
        };

        $('.upload_btn').on('click', function () {
            var othis = $(this), method = othis.data('method');
            card = othis.data('card');
            active[method] ? active[method].call(this, othis) : '';
        });

        $('.upload').on('click', function () {
            var name = $("#name").val();
            var idNumber = $("#idNumber").val();
            var mobile = $("#mobile").val();
            var province = $("#province").val();
            var city = $("#city").val();
            var county = $("#county").val();
            var address = $("#address").val();

            var startDate = $("#startDate").val();;
            var endDate = $("#endDate").val();

            var idCardFm = $("#after").val();
            var idCardZm = $("#front").val();

            try {
                if (parseInt(idNumber.substr(16, 1)) % 2 == 1) {
                    $("#sex").val(0);
                } else {
                    $("#sex").val(1);
                }

                $("#birthday").val(idNumber.substring(6, 10) + "-" + idNumber.substring(10, 12) + "-" + idNumber.substring(12, 14))
            } catch (e) {
                layer.alert("身份证格式错误！")
                return;
            }

            // 判断时间比较
            if ((new Date(startDate.replace(/-/g, "\/"))) > (new Date(endDate.replace(/-/g, "\/"))))
            {
                layer.alert("结束时间不能大于开始时间！")
                return;
            }

            var sex = $("#sex").val();
            var birthday = $("#birthday").val();;

            if (!name || !idNumber || !province || !city || !county || !mobile || !address || !startDate || !endDate || !idCardFm || !idCardZm || !sex || !birthday) {
                return;
            }

            var othis = $(this), method = othis.data('method');
            active[method] ? active[method].call(this, othis) : '';
        });

        $("#idNumber").on('change', function () {
            var num = $(this).val();
            if (IdentityCodeValid(num)) {
                if (parseInt(num.substr(16, 1)) % 2 == 1) {
                    $("#sex").val(0);
                } else {
                    $("#sex").val(1);
                }

                $("#birthday").val(num.substring(6, 10) + "-" + num.substring(10, 12) + "-" + num.substring(12, 14))

                var data = {
                    "idNumber": num,
                }

                $.post({
                    url: url + "?type=2",
                    type: "POST",
                    data: JSON.stringify(data),
                    dataType: 'json',
                    contentType: 'application/json;charset=utf8',
                    success: function (e) {
                        if (e.errno != 105) {
                            layer.alert(e.errmsg);
                            return;
                        }
                    }, error: function (e) {
                        layer.alert("验证是否认证错误：无法连接到服务器！");
                    }
                });
            } else {
                $("#sex").val("");
                $("#birthday").val("");
                $("#idNumber").val("");
                layer.alert("身份证格式有误！");
            }
        });

        $(".userDate").on('change', function () {
            $(this).val("");
            layer.alert("请选择日期，不要手动输入！")
        })
    });
})

function initPCC(id, type) {
    $.get(getZoneListUrl + "?id=" + id, function (e) {

        if (e.errno == 0) {
            var list = e.rst.dataList;

            for (var i = 0; i < list.length; i++) {
                $("#" + type).append("<option value='" + list[i].id + "' " + (type == "province" && list[i].name == "贵州省" ? "selected" : "") + " >" + list[i].name + "</option>")
                if (type == "province" && list[i].name == "贵州省") {
                    initPCC(list[i].id, "city")
                }
            }
            try {
                layui.form.render('select');
            } catch (e) {

            }
        }
    })
}

function enablestart() {
}

function adjustVideoProportions() {
}

function gumSuccess(stream) {
    if ("srcObject" in vid) {
        vid.srcObject = stream;
    } else {
        vid.src = (window.URL && window.URL.createObjectURL(stream));
    }
    vid.onloadedmetadata = function () {
        adjustVideoProportions();
        vid.play();
    }
    vid.onresize = function () {
        adjustVideoProportions();
        if (trackingStarted) {
            ctrack.stop();
            ctrack.reset();
            ctrack.start(vid);
        }
    }
}

function gumFail() {
    layui.layer.closeAll();
    layui.layer.alert("从摄像头获取视频失败，请尝试在Edge或者火狐浏览器中尝试打开！");
}

/******** 人脸跟踪 *********/
var last_time = 0;//时间因素  
var last_nose_left = 0;
var last_nose_top = 0;
var is_mouse_ok = false;
var is_alive_mouse = false;
var last_dis_eye_norse = 0;
var last_dis_mouse = 0;
var is_head_ok = false;
var is_alive_head = false;
var last_dis_left_right = 100000000;
var is_alive_eye = false;
var is_eye_ok = false;
var index = 0;
var timeout = null;
var last_time = 0;
function yuyin() {

    var canvasInput = document.getElementById('canvas');
    var cc = canvasInput.getContext('2d');

    cc.font = "30px Courier New bold";
    //设置字体填充颜色
    cc.fillStyle = "red";

    if (index == 1) {
        var media = document.getElementById("media");
        media.src = "wav/请左右来回扭扭头.wav";
        media.play();

        cc.clearRect(0, 0, canvasInput.width, canvasInput.height);
        cc.fillText("请左右来回扭扭头", 130, 50);

    } else if (index == 2) {
        var media = document.getElementById("media");
        media.src = "wav/请张张嘴.wav";
        media.play();

        cc.clearRect(0, 0, canvasInput.width, canvasInput.height);
        cc.fillText("请张张嘴", 180, 50);

    }
}


function allChceck() {
    base64 = "";

    index = Math.ceil(Math.random() * 2);
    var videoInput = document.getElementById('video');
    var ctracker = new clm.tracker();
    ctracker.init(pModel);
    ctracker.start(videoInput);
    var canvasInput = document.getElementById('canvas');
    var cc = canvasInput.getContext('2d');
    cc.clearRect(0, 0, canvasInput.width, canvasInput.height);
    cc.lineWidth = 3;

    var media = document.getElementById("media");
    media.src = "wav/请正对摄像头以识别人脸.wav";
    media.play();
    cc.font = "30px Courier New bold";
    //设置字体填充颜色
    cc.fillStyle = "red";

    cc.clearRect(0, 0, canvasInput.width, canvasInput.height);
    cc.fillText("请正对摄像头以识别人脸", 80, 50);
    var num = 0;
    function allDrawLoop() {
        var positions = ctracker.getCurrentPosition();

        if (positions) {

            if (base64 == "") {
                var xdiff_left = positions[62][0] - positions[2][0];
                var ydiff_left = positions[62][1] - positions[2][1];
                var dis_left = Math.pow((xdiff_left * xdiff_left + ydiff_left * ydiff_left), 0.5);

                var xdiff_right = positions[12][0] - positions[62][0];
                var ydiff_right = positions[12][1] - positions[62][1];
                var dis_right = Math.pow((xdiff_right * xdiff_right + ydiff_right * ydiff_right), 0.5);

                if (Math.abs(dis_left - dis_right) < 10) {
                    num ++;
                    //console.log(num)
                    if (num >=5) {
                        cc.clearRect(0, 0, canvasInput.width, canvasInput.height);
                        cc.drawImage(videoInput, 0, 0, canvasInput.width, canvasInput.height);
                        base64 = document.getElementById("canvas").toDataURL("image/jpeg");
                        cc.clearRect(0, 0, canvasInput.width, canvasInput.height);
    
                        yuyin();
    
                        timeout = setTimeout(function () {
                            if (index == 1 || index == 2 || index == 3) {
                                last_dis_left_right = 100000000;
                                last_time = 0;
                                index = 0;
                                ctracker.stop();
    
                                var media = document.getElementById("media");
                                media.src = "wav/活体检测失败.wav";
                                media.play();
    
                                layui.layer.closeAll();
    
                                cc.clearRect(0, 0, canvasInput.width, canvasInput.height);
                                base64 == "";
                            }
                        }, 20000);
                    }
                } else {
                    num ++;
                }

            } else {
                //head  
                if (index == 1) {
                    if (last_time == 0 || (new Date().getTime() - last_time > 500 && new Date().getTime() - last_time < 10000)) {
                        var xdiff_left = positions[62][0] - positions[2][0];
                        var ydiff_left = positions[62][1] - positions[2][1];
                        var dis_left = Math.pow((xdiff_left * xdiff_left + ydiff_left * ydiff_left), 0.5);

                        var xdiff_right = positions[12][0] - positions[62][0];
                        var ydiff_right = positions[12][1] - positions[62][1];
                        var dis_right = Math.pow((xdiff_right * xdiff_right + ydiff_right * ydiff_right), 0.5);

                        var xdiff_side = positions[12][0] - positions[2][0];
                        var ydiff_side = positions[12][1] - positions[2][1];
                        var dis_side = Math.pow((xdiff_side * xdiff_side + ydiff_side * ydiff_side), 0.5);


                        var dis_left_right = dis_left - dis_right;
                        $("#result").text(dis_left_right);

                        if (last_dis_left_right > 0 && dis_left_right > dis_side / 4) {
                            clearTimeout(timeout);
                            index = 4;
                        }

                        last_dis_left_right = dis_left_right;
                        last_time = new Date().getTime();
                    }
                }

                /////////////////////////////////////  
                //mouse   
                if (index == 2) {
                    if (last_time == 0 || (new Date().getTime() - last_time > 500 && new Date().getTime() - last_time < 10000)) {

                        //研究和鼻子距离  
                        var xdiff = positions[62][0] - positions[27][0];
                        var ydiff = positions[62][1] - positions[27][1];
                        var dis_eye_norse = Math.pow((xdiff * xdiff + ydiff * ydiff), 0.5);

                        //上嘴唇 和下嘴唇距离  
                        var xdiff_mouse = positions[53][0] - positions[47][0];
                        var ydiff_mouse = positions[53][1] - positions[47][1];
                        var dis_mouse = Math.pow((xdiff_mouse * xdiff_mouse + ydiff_mouse * ydiff_mouse), 0.5);

                        //上次的眼鼻距离和这次的眼鼻距离差  
                        var dn = Math.abs(dis_eye_norse - last_dis_eye_norse);

                        //上次的嘴距离和本次的嘴距离差  
                        var dm = Math.abs(dis_mouse - last_dis_mouse);

                        //鼻子的位置确保变化不大  
                        if (last_nose_left > 0 && last_nose_top > 0
                            && Math.abs(positions[62][0] - last_nose_left) < 4
                            && Math.abs(positions[62][1] - last_nose_top) < 4
                        ) {
                            $("#result").text(dn);
                            if (last_dis_eye_norse > 0 && dn < dis_eye_norse * 1 / 50) {

                                if (last_dis_mouse > 0 && dm > dis_mouse / 10) {
                                    clearTimeout(timeout);
                                    index = 4;
                                }
                            }
                        }

                        last_dis_mouse = dis_mouse;
                        last_dis_eye_norse = dis_eye_norse;
                        last_time = new Date().getTime();

                        last_nose_left = positions[62][0];
                        last_nose_top = positions[62][1];
                    }
                }

                if (index == 4) {
                    index = 5;
                    ctracker.stop();
                    cc.clearRect(0, 0, canvasInput.width, canvasInput.height);

                    clearTimeout(timeout);
                    last_dis_left_right = 100000000;
                    last_time = 0;

                    $("#reShot").click();
                }
            }
        } else {
            num = 0;
        }
        requestAnimationFrame(allDrawLoop);
    }
    allDrawLoop();
}

function photo() {
    GetImageBase64(card == "front" ? $("#fileFront") : $("#fileAfter"), card);
    layer.closeAll();
    if (card == "front") {
        $("#fileFront").click();
    } else {
        $("#fileAfter").click();
    }
}

function GetImageBase64(file, type) {
    file.change(function () {
        selectFileImage(this, type);
    });
}

function selectFileImage(fileObj, type) {
    var file = fileObj.files['0'];
    //图片方向角
    var Orientation = null;

    if (file) {
        var rFilter = /^(image\/jpeg|image\/png)$/i; // 检查图片格式  
        if (!rFilter.test(file.type)) {
            alert("请选择jpeg、png格式的图片！");
            return;
        }
        // var URL = URL || webkitURL;  
        //获取照片方向角属性，用户旋转控制  
        EXIF.getData(file, function () {
            // alert(EXIF.pretty(this));  
            EXIF.getAllTags(this);
            //alert(EXIF.getTag(this, 'Orientation'));   
            Orientation = EXIF.getTag(this, 'Orientation');
            //return;  
        });

        var oReader = new FileReader();
        oReader.readAsDataURL(file);
        oReader.onload = function (e) {
            var image = new Image();
            image.src = e.target.result;
            image.onload = function () {
                var expectWidth = this.naturalWidth;
                var expectHeight = this.naturalHeight;

                if (this.naturalWidth > this.naturalHeight && this.naturalWidth > 1400) {
                    expectWidth = 1400;
                    expectHeight = expectWidth * this.naturalHeight / this.naturalWidth;
                } else if (this.naturalHeight > this.naturalWidth && this.naturalHeight > 1400) {
                    expectHeight = 1400;
                    expectWidth = expectHeight * this.naturalWidth / this.naturalHeight;
                }
                var canvas = document.createElement("canvas");
                var ctx = canvas.getContext("2d");
                canvas.width = expectWidth;
                canvas.height = expectHeight;
                ctx.drawImage(this, 0, 0, expectWidth, expectHeight);
                var base64 = null;
                //修复ios
                if (!!navigator.userAgent.match(/\(i[^;]+;( U;)? CPU.+Mac OS/)) {
                    //如果方向角不为1，都需要进行旋转
                    if (Orientation != "" && Orientation != 1) {
                        // alert('旋转处理');  
                        switch (Orientation) {
                            case 6://需要顺时针（向左）90度旋转  
                                // alert('需要顺时针（向左）90度旋转');  
                                rotateImg(this, 'left', canvas);
                                break;
                            case 8://需要逆时针（向右）90度旋转  
                                // alert('需要顺时针（向右）90度旋转');  
                                rotateImg(this, 'right', canvas);
                                break;
                            case 3://需要180度旋转  
                                // alert('需要180度旋转');  
                                rotateImg(this, 'right', canvas);//转两次  
                                rotateImg(this, 'right', canvas);
                                break;
                        }
                    }

                    base64 = canvas.toDataURL("image/jpeg");
                } else if (navigator.userAgent.match(/Android/i)) {// 修复android
                    try {
                        var encoder = new JPEGEncoder();
                        base64 = encoder.encode(ctx.getImageData(0, 0, expectWidth, expectHeight));
                    } catch (e) {
                        base64 = canvas.toDataURL("image/jpeg");
                    }
                } else {
                    if (Orientation != "" && Orientation != 1) {
                        //alert('旋转处理');  
                        switch (Orientation) {
                            case 6://需要顺时针（向左）90度旋转  
                                // alert('需要顺时针（向左）90度旋转');  
                                rotateImg(this, 'left', canvas);
                                break;
                            case 8://需要逆时针（向右）90度旋转  
                                // alert('需要顺时针（向右）90度旋转');  
                                rotateImg(this, 'right', canvas);
                                break;
                            case 3://需要180度旋转  
                                // alert('需要180度旋转');  
                                rotateImg(this, 'right', canvas);//转两次  
                                rotateImg(this, 'right', canvas);
                                break;
                        }
                    }

                    base64 = canvas.toDataURL("image/jpeg");
                }

                if (type == "front") {
                    $("#front_img").attr("src", base64);
                    $("#front").val(base64.replace("data:image/jpeg;base64,", ""));
                } else {
                    $("#after_img").attr("src", base64);
                    $("#after").val(base64.replace("data:image/jpeg;base64,", ""));
                }
            };
        };
    }
}
//对图片旋转处理
function rotateImg(img, direction, canvas) {
    //alert(img);  
    //最小与最大旋转方向，图片旋转4次后回到原方向    
    var min_step = 0;
    var max_step = 3;
    //var img = document.getElementById(pid);    
    if (img == null) return;
    //img的高度和宽度不能在img元素隐藏后获取，否则会出错    
    var height = img.height;
    var width = img.width;
    //var step = img.getAttribute('step');    
    var step = 2;
    if (step == null) {
        step = min_step;
    }
    if (direction == 'right') {
        step++;
        //旋转到原位置，即超过最大值    
        step > max_step && (step = min_step);
    } else {
        step--;
        step < min_step && (step = max_step);
    }

    //旋转角度以弧度值为参数    
    var degree = step * 90 * Math.PI / 180;
    var ctx = canvas.getContext('2d');
    switch (step) {
        case 0:
            canvas.width = width;
            canvas.height = height;
            ctx.drawImage(img, 0, 0);
            break;
        case 1:
            canvas.width = height;
            canvas.height = width;
            ctx.rotate(degree);
            ctx.drawImage(img, 0, -height);
            break;
        case 2:
            canvas.width = width;
            canvas.height = height;
            ctx.rotate(degree);
            ctx.drawImage(img, -width, -height);
            break;
        case 3:
            canvas.width = height;
            canvas.height = width;
            ctx.rotate(degree);
            ctx.drawImage(img, -width, 0);
            break;
    }
}

function isIE() {
    var userAgent = navigator.userAgent; //取得浏览器的userAgent字符串  
    var isIE = userAgent.indexOf("compatible") > -1 && userAgent.indexOf("MSIE") > -1; //判断是否IE<11浏览器  
    var isEdge = userAgent.indexOf("Edge") > -1 && !isIE; //判断是否IE的Edge浏览器  
    var isIE11 = userAgent.indexOf('Trident') > -1 && userAgent.indexOf("rv:11.0") > -1;
    if (isIE) {
        return true;
    } else if (isEdge) {
        return false;
    } else if (isIE11) {
        return true;
    } else {
        return false;
    }
}