﻿var ctrack = null;
var trackingStarted = false;
var id = "";

$(function () {
    id = GetQueryString("id");

    if (!id) {
        // 跳转到失败页面
        window.location.href = "error.html?tip=数据不全！";
    }

    resize();

    // 验证id是否有效
    $.ajax({
        url: "check.ashx?id=" + id,
        type: "POST",
        dataType: 'json',
        contentType: 'application/json;charset=utf8',
        success: function (e) {
            if (e.ok) {
                openCamera();
            } else {
                window.location.href = "error.html?tip=" + e.msg;
            }
        }, error: function (e) {
            window.location.href = "error.html?tip=无法连接到服务器！";
        }
    })
})

function resize() {
    var cw = $('body').width() - 30;
    var h = cw / 3 * 4;
    var titleHeight = $(".face_title").height();
    var ch = h + titleHeight;

    $('.center').css({ 'width': cw + 'px' });
    $('.center').css({ 'height': ch + 'px' });
    $('.face_title').css({ 'width': cw + 'px' });

    $('.face_div').css({ 'width': cw + 'px' });
    $('.face_div').css({ 'height': h + 'px' });

    $('.kk').css({ 'width': cw + 'px' });
    $('.kk').css({ 'height': h + 'px' });

    $('.line').css({ 'width': cw + 'px' });


    $('#video').css({ 'width': cw + 'px' });
    $('#video').css({ 'height': h + 'px' });

    $('#canvas').css({ 'width': cw + 'px' });
    $('#canvas').css({ 'height': h + 'px' });

    
    $('.center').css("top", (($('body').height() - ch) / 2 - 20) + "px");

    resizeCanvas(cw, h);
}


function resizeCanvas(w, h) {
    $('#canvas').attr("width", w);
    $('#canvas').attr("height", h);
};


function openCamera() {
    vid = document.getElementById('video');

    navigator.getUserMedia = navigator.getUserMedia || navigator.webkitGetUserMedia || navigator.mozGetUserMedia || navigator.msGetUserMedia;
    window.URL = window.URL || window.webkitURL || window.msURL || window.mozURL;

    if (navigator.mediaDevices) {

        try {
            navigator.mediaDevices.getUserMedia({ video: true }).then(openCameraSuccess).catch(openCameraFail);
        } catch (e) {
            openCameraFail();
        }

    } else if (navigator.getUserMedia) {

        navigator.getUserMedia({ video: true }, openCameraSuccess, openCameraFail);

    } else {
        open = false;
        window.location.href = "error.html?tip=此浏览器不支持！";
    }

    vid.addEventListener('canplay', function () {

    }, false);

    ctrack = new clm.tracker();
    ctrack.init();
}




function start() {
    var videoInput = document.getElementById('video');
    var ctracker = new clm.tracker();
    ctracker.init(pModel);
    ctracker.start(videoInput);

    var canvas = document.getElementById('canvas');
    var context = canvas.getContext('2d');
    context.lineWidth = 3;
    context.font = "30px Courier New bold";
    context.fillStyle = "red";
    context.textAlign = 'center';

    var faceArray = [];
    var dt = new Date();

    function interval() {
        context.clearRect(0, 0, canvas.width, canvas.height);
        var positions = ctracker.getCurrentPosition();

        if (positions) {
            var w = positions[13][0] - positions[0][0];
            var x = positions[0][0] - 10;
            var y = (positions[21][1] + positions[16][1]) / 2 - 20;
            var h = w;

            context.strokeStyle = "#00ff00";
            context.fillText("人脸符合要求", canvas.width / 2, 40, canvas.width);

            if (faceArray.length < 2) {
                if (new Date().getTime() - dt.getTime() > 1000) {
                    faceArray.push("");
                    dt = new Date();
                    console.log(faceArray.length)
                }
            } else {
                // 获取到图片
                context.clearRect(0, 0, canvas.width, canvas.height);
                context.drawImage(videoInput, 0, 0, canvas.width, canvas.height);
                base64 = canvas.toDataURL("image/jpeg");


                $(".kk").show();
                $(".line").show();

                context.strokeStyle = "#00ff00";
                context.fillText("正在进行人脸比对", canvas.width / 2, 40, canvas.width);

                // 刷脸登陆
                var data = {
                    "image": base64.replace("data:image/jpeg;base64,", ""),
                    "id" : id
                }

                $.ajax({
                    url: "ajax.ashx?type=3",
                    type: "POST",
                    data: JSON.stringify(data),
                    dataType: 'json',
                    contentType: 'application/json;charset=utf8',
                    success: function (e) {
                        if (e.ok) {
                            window.location.href = "success.html?tip=请在电脑端确认登录结果！";
                        } else {
                            window.location.href = "error.html?tip=" + e.msg;

                        }
                    }, error: function (e) {
                        window.location.href = "error.html?tip=无法连接到服务器！";
                    }
                })

                return;
            }

            context.strokeRect(x, y, w, h);
            // context.stroke();
        }
        requestAnimationFrame(interval);
    }

    interval();
}

function openCameraFail() {
    open = false;
    window.location.href = "error.html?tip=打开摄像头失败！";
}

function openCameraSuccess(stream) {
    if ("srcObject" in vid) {
        vid.srcObject = stream;
    } else {
        vid.src = (window.URL && window.URL.createObjectURL(stream));
    }
    vid.onloadedmetadata = function () {
        vid.play();
        trackingStarted = true;

        start();
    }
    vid.onresize = function () {
        if (trackingStarted) {
            ctrack.stop();
            ctrack.reset();
            ctrack.start(vid);
        }
    }
}

function GetQueryString(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
    var r = window.location.search.substr(1).match(reg);
    if (r != null)
        return decodeURI(r[2]);
    return "";
}