﻿using face.db;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Linq;
using System.Web;

namespace face
{
    /// <summary>
    /// scan 的摘要说明
    /// </summary>
    public class scan : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            try
            {
                string scan_id = Guid.NewGuid().ToString().Replace("-", "").ToLower();

                string url = HttpContext.Current.Request.Url.AbsoluteUri.Substring(0, HttpContext.Current.Request.Url.AbsoluteUri.LastIndexOf("/") + 1) + "mobile.html?id=" + scan_id;

                using (var db = new MySqlDB(ConfigurationManager.AppSettings["mysqldb"]))
                {
                    db.ExecuteSql($@"INSERT INTO zw_face.zw_scan(scan_id) VALUES('{scan_id}')");

                    var b = ToolHelper.GetDimensionalCode(url).BitmapToBytes();

                    context.Response.ContentType = "application/json";
                    context.Response.Write(JsonConvert.SerializeObject(new AjaxResult<object>()
                    {
                        ok = true,
                        msg = "获取成功",
                        obj = new
                        {
                            id = scan_id,
                            base64 = Convert.ToBase64String(b)
                        }
                    }));
                }
            }
            catch (Exception ex)
            {
                context.Response.ContentType = "application/json";
                context.Response.Write(JsonConvert.SerializeObject(new AjaxResult<NULL>()
                {
                    ok = false,
                    msg = ex.Message,
                }));
            }
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}