﻿using face.db;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Data;
using SolaCore.Security;

namespace face
{
    /// <summary>
    /// state 的摘要说明
    /// </summary>
    public class state : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            try
            {
                string id = context.Request.QueryString["id"];

                using (var db = new MySqlDB(ConfigurationManager.AppSettings["mysqldb"]))
                {
                    var dt = db.GetDataTable($"select * from zw_face.zw_scan where scan_id = '{id}'");

                    if (dt == null || dt.Rows.Count == 0)
                    {
                        throw new Exception("id不存在！");
                    }

                    string sign = "";
                    string cardNo = "";

                    if (dt.Rows[0]["state"].ToString() == "1")
                    {
                        string idNumber = dt.Rows[0]["id_number"].ToString();

                        cardNo = ajax.AesEncrypt(idNumber, ajax.secret);
                        sign = (ajax.key + idNumber + DateTime.Now.ToString("yyyyMMdd")).Encrypt().ToLower();
                    }

                    context.Response.ContentType = "application/json";
                    context.Response.Write(JsonConvert.SerializeObject(new AjaxResult<object>()
                    {
                        ok = true,
                        msg = "成功",
                        obj = new
                        {
                            id = id,
                            isScan = dt.Rows[0]["is_scan"].ToString(),
                            state = dt.Rows[0]["state"].ToString(),
                            message = dt.Rows[0]["message"].ToString(),
                            cardNo = cardNo,
                            sign = sign
                        }
                    }));
                }
            }
            catch (Exception ex)
            {
                context.Response.ContentType = "application/json";
                context.Response.Write(JsonConvert.SerializeObject(new AjaxResult<NULL>()
                {
                    ok = false,
                    msg = ex.Message,
                }));
            }
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}