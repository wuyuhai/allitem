
<template>
    <!--<h2>sdflkhh</h2>-->
    <!--<index></index>-->
    <!--<login></login>-->
    <router-view></router-view>
</template>
<script>
	//引入组件
//	import Users from './components/Users'
//	import Index from './components/Index'
//	import Login from './components/Login'
//  export default {
//      name:'app',
//      components:{
////			Login
////			Index
//      }
//  }
    
</script>
<style>
	*{
		margin: 0 auto;
		font-family: "微软雅黑";
	}
	.header{
		width: 100%;
		height: 55px;
		/*border: 1px solid #567;*/
		-moz-box-shadow:  0px 1px 3px 1px #cad5e4;
		-webkit-box-shadow:  0px 1px 3px 1px #cad5e4;
    	box-shadow: 0px 1px 3px 1px #cad5e4;
	}
	
	.header a{
		text-decoration: none;
		color: #000;
		font-size: 21px;
		line-height: 54px;
	}
	.header>span{
		float: left;
		padding-left:30px ;
		letter-spacing: 1.6px;
	}

.layout{
    border: 1px solid #d7dde4;
    /*background: #f5f7f9;*/
    position: relative;
    border-radius: 4px;
    overflow: hidden;
}
.layout-logo{
    width: 100px;
    height: 30px;
    /*background: #5b6270;*/
    border-radius: 3px;
    float: left;
    position: relative;
    top: 15px;
    left: 20px;
}
.layout-nav{
    width: 420px;
    margin: 0 auto;
    margin-right: 20px;
}
footer{
    position: absolute;
    bottom: 3.5px;
    right: 0;
    width: 100%;
    height: 40px;
    -webkit-box-shadow: 0px 0px 3px 1px #cad5e4;
    box-shadow: 0px 0px 3px 1px #cad5e4;
    letter-spacing: 0.8px;
    font-size: 13px;
    line-height: 39px;
    text-align: right;
    padding-right: 32px;
    background: #fff;
}
</style>
