$(function(){
	alert('lianjiesdasd');
//	首页自动滚动
	var $this = $("#jiekou"); 
var scrollTimer; 
$this.hover(function() { 
clearInterval(scrollTimer); 
}, function() { 
scrollTimer = setInterval(function() { 
scrollNews($this); 
}, 2000); 
}).trigger("mouseleave"); 
function scrollNews(obj) { 
var $self = $this; 
var lineHeight = $self.find("tr:first").height(); 
$self.animate({ 
"marginTop": -(lineHeight-20) + "px" 
},10, function() { 
$self.css({ 
marginTop: 0 
}).find("tr:first").appendTo($self); 
}) 
} //滚动结束
var $this2 = $("#shenqinggl2"); 
var scrollTimer2; 
$this2.hover(function() { 
clearInterval(scrollTimer2); 
}, function() { 
scrollTimer2 = setInterval(function() { 
scrollNews2($this2); 
}, 2000); 
}).trigger("mouseleave"); 
function scrollNews2(obj) { 
var $self2 = $this2; 
var lineHeight = $self2.find("tr:first").height(); 
$self2.animate({ 
"marginTop": -(lineHeight-20) + "px" 
},10, function() { 
$self2.css({ 
marginTop: 0 
}).find("tr:first").appendTo($self2); 
}) 
} //滚动结束

//var username=window.location.search.substr(1);
var userid=localStorage.getItem('userId');
var username=localStorage.getItem('userName');
if(username==""||username==null||userid==null){
//layer.msg('您没有登录，请登录！',function(){
setTimeout(function(){
//		    location.href='login.html';
},2000);
//		}) 
}else{
$('#username').text(username);
}
})
var api = 'http://202.98.195.208:83/APIManagement';
