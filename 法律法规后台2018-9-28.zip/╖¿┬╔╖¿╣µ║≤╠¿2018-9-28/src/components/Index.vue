<template>
	<div class="layout">
		<Layout>
			<Header>
				<span class="title_a">
    				法律服务后台管理系统
    			</span>
				<Menu mode="horizontal"  class="headeraruto">
					<Submenu name="3" id="user_name">
			            <template slot="title">
			                <Avatar src="https://i.loli.net/2017/08/21/599a521472424.jpg" />
			                <i id="username">{{username}}</i>
			            </template>
			            <li class="ivu-menu-item ivu-menu-item-active" @click="login_out()">{{loginout}}</li>
			        	<li class="ivu-menu-item ivu-menu-item-active" @click="modal1 = true">{{changepassword}}</li>
					</Submenu>
			    </Menu>
			</Header>
			<Layout>
				<Sider hide-trigger :style="{background: '#fff'}" class="dw-nav">
					<!--<Menu active-name="1-1" theme="light" width="auto" :open-names="['1']">-->
					<Menu theme="light" width="auto" :open-names="['1']">
						<MenuItem name="1-1">
						<span><router-link to="/tongji?nowpage=0" class="dw_link nowpages">统计分析</router-link></span>
						</MenuItem>
						<MenuItem name="1-2" v-if="roleid==1">
							<router-link :to="{path:'/Users',query:{nowpage:1}}" class="dw_link nowpages">用户管理</router-link>
						</MenuItem>
						<MenuItem name="1-2" v-else>
							<span @click="usersmager()"><router-link to="" class="dw_link">用户管理</router-link></span>
						</MenuItem>
						<Submenu name="2">
							<template slot="title">
								政策法规分类管理
							</template>
							<MenuItem name="2-1">
							<router-link :to="{path:'/lawyers', query:{id:2,nowpage:2}}" class="dw_link nowpages" id="nozzle_a">法律</router-link>
							</MenuItem>
							<MenuItem name="2-2">
							<router-link :to="{path:'/lawyers', query:{id:3,nowpage:3}}" class="dw_link nowpages">政策法规</router-link>
							</MenuItem>
							<MenuItem name="2-3">
							<router-link :to="{path:'/lawyers', query:{id:4,nowpage:4}}" class="dw_link nowpages">国务院部门规章</router-link>
							</MenuItem>
							<MenuItem name="2-4">
							<router-link :to="{path:'/lawyers', query:{id:5,nowpage:5}}" class="dw_link nowpages">地方性法规</router-link>
							</MenuItem>
							<MenuItem name="2-5">
							<router-link :to="{path:'/lawyers', query:{id:6,nowpage:6}}" class="dw_link nowpages">地方政府规章</router-link>
							</MenuItem>
						</Submenu>
						<Submenu name="3">
							<template slot="title">
								政策法规关联信息管理
							</template>
							<MenuItem name="3-1">
							<router-link to="/itemcontect?nowpage=7" class="dw_link nowpages">与事项系统关联</router-link>
							</MenuItem>
							<!--<MenuItem name="3-2">
							<router-link to="/Add_user" class="dw_link">与电子监察系统关联</router-link>
							</MenuItem>-->
						</Submenu>
						<MenuItem name="1-3" v-if="roleid==1">
							<router-link :to="{path:'/changeeffectlis',query:{nowpage:8}}" class="dw_link nowpages">修订审批表</router-link>
						</MenuItem>
						<MenuItem name="1-3" v-else>
							<span @click="usersmager()"><router-link to="" class="dw_link">修订审批表</router-link></span>
						</MenuItem>
						<MenuItem name="1-4" v-if="username=='李双喜'">
							<router-link to="/LawTool" class="dw_link">法律入库</router-link>
						</MenuItem>
						<!--<MenuItem name="1-4">
						<span><router-link to="/Today_data" class="dw_link">接口管理</router-link></span>
						</MenuItem>-->
					</Menu>
				</Sider>
				<Layout :style="{padding: '1px'}" id="layout">
					<router-view/>				
				</Layout>				
			</Layout>	
			<footer>Copyright ©2018 fotoit-admin v1.2 All Rights Reserved. 本后台系统由珠海方图智能科技有限公司提供技术支持</footer>
		</Layout>		
		<Modal v-model="modal1" title="修改密码" style="position: relative;">
			<Form :model="formItem" :label-width="80">
				<FormItem label="旧密码">
					<Input type="password" v-model="formItem.oldpass" placeholder="请输入旧密码"></Input>
				</FormItem>
				<FormItem label="新密码">
					<Input type="password" v-model="formItem.newpass" placeholder="请输入新密码"></Input>
				</FormItem>
				<FormItem label="确认新密码">
					<Input type="password" v-model="formItem.newpassagain" placeholder="请确认新密码"></Input>
				</FormItem>
				<FormItem class="changebtn">
					<Button @click="changepasswordok()">提交</Button>
					<Button @click="changepasswordcancel()">取消</Button>
				</FormItem>
			</Form>
		</Modal>
	</div>
</template>

<script>
	//	import Vue from 'vue'
	//	import VueRouter from 'vue-router'
	//	import Home from './Home'
	export default {
		name: 'index',
		data() {
			return {
				api: 'http://202.98.195.208:83/APIManagement',
				loginout: '退出',
				userid: '',
				changepassword: '修改密码',
				username: '',
				modal1: false,
				formItem: {
					oldpass: '',
					newpass: '',
					newpassagain: '',
				},
				roleid:"",
				canbol:false,
				
			}
		},
		components: {
			//			Home,
		},
		created: function() {
			var userid = localStorage.getItem('userId');
			var username = localStorage.getItem('userName');
			this.userid = userid;
			this.username = username;
			this.roleid = localStorage.getItem('roleid');
		},
		methods: {
			login_out() {
				var re = require('qs'); //创建传输数据对象
				this.$axios.post('/law_management/logout', re.stringify())
					.then(function(data) {
						console.log(data)
						if(data.data.ok) {
							location.href = '/';
							localStorage.clear();
						} else {
							this.$Message.error(obj.data.msg);
						}
					})
					.catch(function(error) {
						console.log(error);
					}); //ajax end
			},
			changepasswordok() {
				console.log(this.formItem)
				if(this.formItem.oldpass == "") {
					this.$Message.info('旧密码不能为空');
					return
				}
				if(this.formItem.newpass == "") {
					this.$Message.info('新密码不能为空');
					return
				}
				if(this.formItem.newpass != this.formItem.newpassagain) {
					this.$Message.info('两次输入的新密码不一样');
					return
				}
				var data = {
					newPassword:this.formItem.newpass,
					oldPassword:this.formItem.oldpass,
					id:localStorage.userId
				}
				console.log(data)
				var that = this;
				var re = require('qs'); //创建传输数据对象
				this.$axios.post('/law_management/updatePassword', re.stringify(data))
					.then(function(data) {
						console.log(data)
						if(data.data.ok) {
//							location.href = '/';
//							localStorage.clear();
							alert('密码修改成功');
							that.modal1 = false;
						} else {
							alert('密码失败');
						}
					})
					.catch(function(error) {
						console.log(error);
					}); //ajax end
			},
			changepasswordcancel() {
				//              this.$Message.info('Clicked cancel');
				console.log("取消")
				this.modal1 = false;
			},
			usersmager(){
				console.log(1)
				if(this.roleid!=1){
					alert("你没有权限进行该模块的操作");
					return
				}else{
//					location.href = 'Users';
					this.canbol = true;
				}
			},
		},
	}
</script>

<style>
	#username {
		font-style: normal;
		position: relative;
		color: #fff;
		left: -105px;
		top: 12.5px!important;
	}
	#user_name{
		padding: 0;
		padding-top: 12.5px;
	}

	.ivu-menu-submenu-title-icon{
		position: relative!important;
		top: 20px!important;
		font-size: 12px;
	}
	.changebtn {
		position: absolute;
		bottom: -20px;
		width: 100%;
		background: #fff;
		left: 0;
		height: 50px;
	}
	
	.changebtn button {
		float: right;
		margin-top: 10px;
	}
	
	.changebtn button:nth-child(1) {
		margin-right: 25px;
		background: #0168F3;
		color: #fff;
	}
	.ivu-menu-item a {
		display: block;
		width: 100%;
	}
	.changebtn button:nth-child(2) {
		margin-right: 25px;
	}
	.user_boxmoveli{
		z-index: 99;
	}
	footer{
		text-align: center;
	}
	.ivu-menu-item-selected{
		background: #014E9E!important;	
	}
	.ivu-menu-item-selected span a{
		color: #fff!important;
	}.ivu-menu-item-selected a{
		color: #fff!important;
	}
	
</style>