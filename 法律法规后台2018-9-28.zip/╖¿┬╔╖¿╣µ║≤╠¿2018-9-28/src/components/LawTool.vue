<template>
	<div class="container-box">
		<div class="old-law">
			<h1>原文</h1>
			<div class="law_title">{{law_title}}</div>
			<div class="old-law-html" v-html="oldHtml"></div>
		</div>
		<div class="new-law">
			<h1>结构化结果</h1>
			<div class="law_title"></div>
			<div class="new-law-html">
				<div v-for="(bian , bianindex) in bians">
					<div class="law-box">
						<div v-html="bian.item.html"></div>
						<div class="btns">
							<i-button type="primary" :nextnum="getNextNum(bians , bianindex)" :num="bian.item.num" :dataindex="bianindex" :parent="bian.item.parentId" datatype="0" @click="showEditorWin($event , false)">添加</i-button>
							<i-button type="primary" :datahtml="bian.item.html" :dataid="bian.item.id" :num="bian.item.num" :dataindex="bianindex" :parent="bian.item.parentId" datatype="0" @click="showEditorWin($event , true)">编辑</i-button>
							<i-button type="primary" :dataid="bian.item.id" @click="showDeleteWin($event)">删除</i-button>
						</div>
					</div>
					<div v-for="(zhang,zhangindex) in bian.children">
						<div class="law-box">
							<div v-html="zhang.item.html"></div>
							<div class="btns">
								<i-button type="primary" :nextnum="getNextNum(bian.children , zhangindex)" :num="zhang.item.num" :dataindex="zhangindex" :parent="zhang.item.parentId" datatype="1" @click="showEditorWin($event , false)">添加</i-button>
								<i-button type="primary" :datahtml="zhang.item.html" :dataid="zhang.item.id" :num="zhang.item.num" :dataindex="zhangindex" :parent="zhang.item.parentId" datatype="1" @click="showEditorWin($event , true)">编辑</i-button>
								<i-button type="primary" :dataid="bian.item.id" @click="showDeleteWin($event)">删除</i-button>
							</div>
						</div>
						<div v-for="(jie,jieindex) in zhang.children">
							<div class="law-box">
								<div v-html="jie.item.html"></div>
								<div class="btns">
									<i-button type="primary" :nextnum="getNextNum(zhang.children , jieindex)" :num="jie.item.num" :dataindex="jieindex" :parent="jie.item.parentId" datatype="2" @click="showEditorWin($event , false)">添加</i-button>
									<i-button type="primary" :datahtml="jie.item.html" :dataid="jie.item.id" :num="jie.item.num" :dataindex="jieindex" :parent="jie.item.parentId" datatype="2" @click="showEditorWin($event , true)">编辑</i-button>
									<i-button type="primary" :dataid="jie.item.id" @click="showDeleteWin($event)">删除</i-button>
								</div>
							</div>
							<div v-for="(tiao,tiaoindex) in jie.children">
								<div class="law-box">
									<div class="tiao" v-html="tiao.item.html"></div>
									<div class="btns">
										<i-button type="primary" :nextnum="getNextNum(jie.children , tiaoindex)" :num="tiao.item.num" :dataindex="tiaoindex" :parent="tiao.item.parentId" datatype="3" @click="showEditorWin($event , false)">添加</i-button>
										<i-button type="primary" :datahtml="tiao.item.html" :dataid="tiao.item.id" :num="tiao.item.num" :dataindex="tiaoindex" :parent="tiao.item.parentId" datatype="3" @click="showEditorWin($event , true)">编辑</i-button>
										<i-button type="primary" :dataid="tiao.item.id" @click="showDeleteWin($event)">删除</i-button>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<Modal v-model="showEditor" title="编辑" @on-ok="addLaw" @on-cancel="cancel()">
				<div id="editorElem" style="text-align:left">
				</div>
			</Modal>
			<Modal v-model="deleteEditor" title="删除提示" @on-ok="deleteLaw" @on-cancel="cancel()">
				<p>确定要删除吗？</p>
			</Modal>
			<div class="next-btn">
				<i-button type="primary" v-on:click="prevLaw()">上一部</i-button>
				<i-button type="primary" v-on:click="tongguo()">通过</i-button>
				<i-button type="primary" v-on:click="nextLaw()">下一部</i-button>
			</div>
		</div>
	</div>
</template>
<script>
	import wangeditor from 'wangeditor'
	export default {
		name: 'LawTool',
		data: function() {
			return {
				lawID: localStorage.lawID ? localStorage.lawID : 1,
				law_title: '',
				oldHtml: '',
				editHtml: "",
				currentEditId: "",
				showEditor: false,
				editorTitle: "",
				nextNum: '',
				type: 0,
				num: 0,
				parent: '',
				bians: [],
				zhangs: [],
				jies: [],
				tiaos: [],
				isEdit: false,
				currEditId: '',
				editorContent: "<p></p>",
				editor: {},
				deleteId: "",
				deleteEditor: false,
				apihost: "https://face.fotoit.cn:84/law_management",
				preornext:'next'
			}
		},
		methods: {
			getNextNum(items, currIndex) {
				if(items.length > currIndex + 1) {
					var nextNum = (parseFloat(items[currIndex].item.num) + parseFloat(items[currIndex + 1].item.num)) / 2;
					return
				} else {
					return parseFloat(items[currIndex].item.num) + 1;
				}
				return 1;
			},
			showEditorWin(e, isEdit) {
				this.num = parseFloat(e.currentTarget.getAttribute('num'));
				this.type = e.currentTarget.getAttribute('datatype');
				var dataIndex = e.currentTarget.getAttribute('dataindex');
				this.currEditId = e.currentTarget.getAttribute('dataid');
				this.parent = e.currentTarget.getAttribute('parent');
				this.nextNum = e.currentTarget.getAttribute('nextnum');
				this.isEdit = isEdit;
				if(isEdit) {
					this.editorContent = e.currentTarget.getAttribute('datahtml');
				} else {
					this.editorContent = "<p></p>";
				}
				this.showEditor = true;
			},
			tongguo() {
				var vm = this;
				var re = require('qs'); //创建传输数据对象
				this.$axios.post('/law_management/chinaLaw/tongGuo', re.stringify({
					lawId: vm.lawID,
				})).then(function(data) {					
					if(data.data.ok == true){
						if(vm.preornext=="next"){
							vm.nextLaw()
						}else{
							vm.prevLaw()
						}
					}
				})
			},
			addLaw() {
				var vm = this;
				var re = require('qs'); //创建传输数据对象
				this.$axios.post('/law_management/lawItem/add', re.stringify({
					lawid: vm.lawID,
					type: vm.type,
					num: vm.isEdit ? vm.num : vm.nextNum,
					html: vm.editorContent,
					parent: vm.parent,
					id: vm.isEdit ? vm.currEditId : null
				})).then(function(data) {
					vm.loadNewHtml();
					vm.editorContent = "<p></p>";
				})
			},
			prevLaw(){
				this.lawID--;
				localStorage.lawID = this.lawID;
				this.loadOldHtml();
				this.loadNewHtml();
				this.preornext = "pre";
			},
			nextLaw() {
				this.lawID++;
				localStorage.lawID = this.lawID;
				this.loadOldHtml();
				this.loadNewHtml();
				this.preornext = "next";
			},
			addItem(e) {
				this.addTiao = e.currentTarget.getAttribute('datanum');
				this.showEditor = true;
			},
			cancel() {

			},
			saveLaw() {
				var html = this.$refs['editHtml'].innerHTML;
				var vm = this;
				var re = require('qs'); //创建传输数据对象
				this.$axios.post('/law_management/lawItem/editHtml', re.stringify({
					tiaoId: vm.currentEditId,
					html: html
				})).then(function(data) {
					vm.loadNewHtml();
				})
			},
			editTiao(e) {
				this.currentEditId = e.currentTarget.getAttribute('dataid');
				var html = e.currentTarget.getAttribute('datahtml');
				this.editHtml = html;
			},
			showDeleteWin(e) {
				this.deleteId = e.currentTarget.getAttribute('dataid');
				this.deleteEditor = true;
			},
			deleteLaw() {
				var vm = this;
				var re = require('qs'); //创建传输数据对象
				this.$axios.post('/law_management/lawItem/deleteById', re.stringify({
					id: vm.deleteId
				})).then(function(data) {
					vm.loadNewHtml();
				})
			},
			loadOldHtml() {
				let vm = this;
				var re = require('qs'); //创建传输数据对象
				this.$axios.post('/law_management/lawOld/oldInfo', re.stringify({
					id: vm.lawID
				})).then(function(data) {
					vm.law_title = data.data.obj.title;
					vm.oldHtml = data.data.obj.html;
				})
			},
			loadNewHtml() {
				let vm = this;
				var re = require('qs'); //创建传输数据对象
				this.$axios.post('/law_management/lawItem/newInfo', re.stringify({
					id: vm.lawID
				})).then(function(data) {
					console.log(data)
					if(data.data.ok == true){
						if(data.data.obj.chinaLaw.dataSource == 1){
							if(vm.preornext=="next"){
								vm.nextLaw()
							}else{
								vm.prevLaw()
							}							
						}else{
							vm.bians = data.data.obj.nodes;
						}
					}									
				})
			}
		},
		created() {
			this.loadOldHtml();
			this.loadNewHtml();
		},
		mounted() {
			var vm = this;
			this.editor = new wangeditor('#editorElem');
			// 自定义菜单配置
			this.editor.customConfig.menus = [];
			this.editor.customConfig.onchange = (html) => {
				vm.editorContent = html
			}
			this.editor.create()
		},
		watch: {
			editorContent: {
				handler(val, oldVal) {
					console.log(val)
					this.editor.txt.html(val);
				},
			}
		}
	}
</script>

<style scoped>
	.container-box {
		display: flex;
		flex-direction: row;
		background-color: #fff;
		text-align: left;
		font-size: 14px;
		height: 100%;
		overflow: hidden;
	}
	
	.old-law {
		padding: 5px;
		flex: 1;
		height: 100%;
		overflow-y: scroll;
		border-right: 1px solid #333;
	}
	
	.new-law {
		padding: 5px;
		flex: 1;
		overflow-y: scroll;
	}
	
	.old-law h1,
	.new-law h1 {
		text-align: left;
		font-size: 20px;
		margin: 10px;
	}
	
	.law_title {
		font-size: 22px;
		text-align: center;
		font-weight: bold;
		padding: 20px 0px;
	}
	
	.next-btn {
		position: fixed;
		right: 15px;
		bottom: 5px;
	}
	
	.item {
		margin-bottom: 20px;
	}
	
	.top {
		margin-bottom: 20px;
	}
	
	.bian,
	.zhang,
	.jie {
		padding: 5px;
	}
	
	.law-box {
		border: 1px solid #333;
		padding: 5px;
		margin: 20px 0px;
	}
	
	.editHtml {
		font-size: 16px;
		padding: 10px;
	}
	
	.btns {
		width: 100%;
		text-align: right;
	}
</style>