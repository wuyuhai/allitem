<template>
	<section>
		<div class="login_box">
			<div class="login_boxheader">法律法规事项后台管理</div>
			<div class="login_boxheadernext">
				<img src="../assets/img/728026277093139564.png" />
			</div>
			<div class="form_b">
				<form class="layui-form layui-form-pane" action="">
					<div class="dw-form-item">
						<img src="./../assets/img/zhanghao.png" />
						<input type="text" id="usernames" name="username" lay-verify="required" placeholder="请输入帐号" autocomplete="off" class="layui-input">
					</div>
					<div class="dw-form-item">
						<img src="./../assets/img/mima.png" />
						<input type="password" id="password" name="password" lay-verify="required" placeholder="请输入密码" autocomplete="on" class="layui-input">
					</div>
					<div class="dw-item">
						<input type="checkbox" name="like[write]" class="rd" checked="checked">
						<label class="" id="checkbox-id" name="switch" for="rememberMe">记住密码</label>
					</div>
					<!--<router-link to="/Index" class="dw_link">-->
					<div class="login_btn" id="login_btn" @click="info">
						登录
						<!--接口部门-->
					</div>
					<!--</router-link>-->
				</form>
			</div>
			<img class="daoyin" src="../assets/img/368651121872954087.png" />
		</div>
	</section>
</template>
<script>
	export default {
		name: 'login',
		components: {},
		methods: {
			info() {
				var str = $("input[type='checkbox']").prop('checked');
				var data1 = {};
				data1.loginName = $('#usernames').val();
				data1.loginPassword = $('#password').val();
				data1.rememberMe = str;
				var qs = require('qs');
				this.$axios.post('/law_management/login', qs.stringify(data1))
					.then(function(data) {
						console.log(data)
						if(data.data.ok) {
//							console.log(data);
							localStorage.userId = data.data.obj.id;
							localStorage.userName = data.data.obj.nickName;
							localStorage.roleid = data.data.obj.role.id;
							localStorage.roleaddrName = data.data.obj.addrName;
//							return
							location.href = '/tongji?nowpage=0';
						} else {
							alert('账号或密码错误！！');
						}
					})
					.catch(function(error) {
					console.log(error);
				});
			}
		}
	}
</script>
<style>
	section {
		width: 100%;
		height: 100%;
		background: #014E9E;
		/*border: 1px solid red;*/
		/*position: relative;*/
	}
	
	.login_box {
		width: 498px;
		height: 350px;
		border: 1px solid #fff;
		/*border: 1px solid #cad5e4;*/
		position: absolute;
		top: 40%;
		left: 50%;
		transform: translateX(-50%)translateY(-50%);
		background: #fff;
		border-radius: 10px;
		/*-webkit-box-reflect: below 0 -webkit-linear-gradient(top,rgba(250,250,250,0),rgba(250,250,250,.0) 60%,rgba(250,250,250,0.3));
	box-reflect: below 0 -webkit-linear-gradient(top,rgba(250,250,250,0),rgba(250,250,250,.0) 60%,rgba(250,250,250,0.3));*/
	}
	
	.login_boxheader {
		background: #2264AA;
		height: 65px;
		line-height: 55px;
		text-align: center;
		font-size: 18px;
		color: #fff;
		border-radius: 10px;
	}
	
	.login_boxheadernext {
		width: 100%;
		background: #fff;
		margin-top: -10px;
		height: 12px;
		position: relative;
	}
	
	.login_boxheadernext img {
		position: absolute;
		top: 1px;
		width: 250px;
		left: 125px;
		height: 25px;
	}
	
	.form_b {
		width: 100%;
		height: 283px;
		background: #0168f3;
		text-align: center;
		float: left;
		-webkit-display: flex;
		display: flex;
		-webkit-align-items: center;
		align-items: center;
		-webkit-justify-content: center;
		justify-content: center;
		text-align: center;
	}
	
	.form_b {
		background: transparent;
		-ms-user-select: none;
		user-select: none;
		text-align: center;
	}
	
	.dw-form-item {
		width: 255px;
		height: 32px;
		margin: 0 auto;
		border-bottom: 1px solid #bebebe;
		overflow: hidden;
		margin-bottom: 23px;
	}
	
	.dw-form-item img {
		float: left;
		margin-top: 3px;
	}
	
	.dw-form-item input {
		float: right;
		width: 220px;
		height: 32px;
		border: 0;
		outline: none;
		font-size: 15px;
		display: block;
		border-color: transparent;
	}
	
	.dw-item {
		width: 255px;
		height: 32px;
		overflow: hidden;
		margin-bottom: 5px;
		margin: 0 auto;
	}
	
	.dw-item input {
		height: 17px;
		width: 17px;
		float: left;
		cursor: pointer;
		outline: none;
	}
	
	.dw-item label {
		float: left;
		font-size: 12px;
		margin-left: 6px;
	}
	
	.login_btn {
		position: absolute;
		bottom: -1.5px;
		width: 153px;
		left: 172px;
		background: url(../assets/img/476929563221228758.png);
		color: #fff;
		height: 33px;
		line-height: 33px;
		font-size: 16px;
	}
	
	input:-webkit-autofill {
		-webkit-box-shadow: 0 0 0px 1000px white inset;
	}
	
	.daoyin {
		margin-left: -60px;
	}
	
	* {
		/*margin: 0 auto;*/
		padding: 0;
		letter-spacing: 1px;
		word-wrap: break-word;
		word-break: break-all;
		box-sizing: border-box;
		-moz-box-sizing: border-box;
		-webkit-box-sizing: border-box;
	}
	
	a {
		text-decoration: none;
		color: #312520;
	}
	
	ul li {
		list-style: none;
	}
</style>