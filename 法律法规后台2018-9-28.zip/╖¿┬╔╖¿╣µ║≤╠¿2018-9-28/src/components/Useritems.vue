<template>
	<div>
		<div class="router_header">
			<div class="return" @click="retrunlastpage()"><返回</div>
			<div class="title">用户详情</div>
			<div class="bianji">
				<router-link style="margin-right: 5px;" :to="{path:'/Useritemsedit', query:{id:id,addorchange:1}}">
					编辑
				</router-link>
			</div>
		</div>
		<div class="useritems">
			<div>
				<div>姓名：</div>
				<div>{{formItem.name?formItem.name:"-"}}</div>
			</div>
			<div>
				<div>性别：</div>
				<div>{{formItem.sex?formItem.sex:'-'}}</div>
			</div>
			<div>
				<div>电话：</div>
				<div>{{formItem.callnum?formItem.callnum:'-'}}</div>
			</div>
			<div>
				<div>账号：</div>
				<div>{{formItem.usernum}}</div>
			</div>
			<div>
				<div>密码：</div>
				<div>***</div>
			</div>
			<div>
				<div>所属市区：</div>
				<div>{{formItem.selectcity?formItem.selectcity:'-'}}</div>
			</div>
			<div>
				<div>账号级别：</div>
				<div>{{formItem.selectlv}}</div>
			</div>
			<div>
				<div>最后登录时间：</div>
				<div>{{formItem.zhtime}}</div>
			</div>
			<div>
				<div>权限：</div>
				<div class="quanxians">
					<p v-for="item in quanli">{{item.name}}</p>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	export default {
        data () {
            return {
            	id:"",
                formItem: {
                    name: '',                   
                    usernum: '',
                    passwordw: '',
                    sex: '男',
                    callnum:'',
                    selectcity: '',
                    selectlv: '',
                    zhtime:'',
                    roleid:''
                },
                quanli:[]
            }
        },
        components: {
			//			Home,
		},
		created: function() {
			var userid = localStorage.getItem('userId');
			var username = localStorage.getItem('userName');
			this.userid = userid;
			this.username = username;
			this.id = this.$route.query.id;
			console.log(this.id)			
			var _this = this; //在数据加载之前的操作
				var data = {
					id:this.id
				}
				var qs = require('qs');
				this.$axios.post('/law_management/user/findById', qs.stringify(data))
					.then(function(obj) {
						console.log(obj)
						if(obj.data.ok) {
							console.log(1)
							var formItem = {
								name: obj.data.obj.nickName,                   
			                    usernum: obj.data.obj.loginName,
			                    passwordw: obj.data.obj.loginPassword,
			                    sex: obj.data.obj.sex,
			                    callnum:obj.data.obj.tel,			                    
			                    selectcity: obj.data.obj.addrName,
			                    selectlv: obj.data.obj.role.name,
			                    roleid:obj.data.obj.role.id,
//			                    zhtime:
							}
							var quanli = [];
							for(var i=0;i<obj.data.obj.role.permissions.length;i++){
								if(obj.data.obj.role.permissions[i].id<=5||obj.data.obj.role.permissions[i].id>13){
									quanli.push(obj.data.obj.role.permissions[i])
								}
							}
							_this.formItem = formItem;
							_this.quanli = quanli
							console.log(_this.formItem)
						}
					})
					.catch(function(error) {
					console.log(error);
					_this.modaldeluser = false;
				});
		},
		methods: {
			retrunlastpage(){
				console.log(1)
				this.$router.go(-1);
			}
		},       
    }
</script>

<style>
	.useritems{
		width: 100%;
	}
	.useritems>div{
		position: relative;
		overflow: hidden;
		margin-top: 8px;
	}
	.useritems>div>div{
		float: left;
		font-size: 16px;
	}
	.useritems>div>div:nth-child(1){
		width: 15%;
		text-align: right;
		color: #262626;
	}
	.useritems>div>div:nth-child(2){
		color: #606060;
	}
	.quanxians{
		padding-top: 5px;
	}
	.quanxians p{
		margin-bottom: 7.5px;
		font-size: 12px;
		color: gray;
	}
	.return{
		cursor: pointer;
	}
</style>