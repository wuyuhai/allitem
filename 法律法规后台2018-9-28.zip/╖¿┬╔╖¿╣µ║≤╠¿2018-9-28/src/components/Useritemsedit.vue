<template>
	<div>
		<div class="router_header">
			<div class="return" @click="retrunlastpage()"><返回</div>
			<div class="title">用户详情</div>
		</div>
		<div class="useritems">
			<Form :model="formItem" :label-width="80">
				<FormItem label="姓名">
					<Input v-model="formItem.name" placeholder="请输入姓名"></Input>
				</FormItem>
				<FormItem label="账号">
					<Input v-model="formItem.usernum" @on-blur="chaxunusername()" :disabled="addorchange==1" placeholder="请设置管理员账号"></Input>
				</FormItem>
				<FormItem label="密码">
					<Input type="password" v-model="formItem.passwordw" :disabled="addorchange==1" placeholder="请设置管理员密码"></Input>
				</FormItem>
				<FormItem label="性别">
					<RadioGroup v-model="formItem.sex">
						<Radio label="男">男</Radio>
						<Radio label="女">女</Radio>
					</RadioGroup>
				</FormItem>
				<FormItem label="电话">
					<Input v-model="formItem.callnum" placeholder="请输入用户电话"></Input>
				</FormItem>

				<FormItem label="所属市区">
					<Select v-model="formItem.selectcity">
						<Option value="贵州省">贵州省</Option>
						<Option value="贵阳市">贵阳市</Option>
						<Option value="六盘水市">六盘水市</Option>
						<Option value="遵义市">遵义市</Option>
					</Select>
				</FormItem>
				<FormItem label="管理员级别">		
					<select class="lvselect" v-model="formItem.selectlv" name="">
						<option v-for="(item, index) in mangers" :value="item.id">{{item.name}}</option>
					</select>
					<!--<Select v-model="formItem.selectlv">
						<Option v-for="(item, index) in mangers" :value="item.name">{{item.name}}</Option>
					</Select>-->
				</FormItem>
				<p class="tit">注：高级管理员具有法律法规的，修改，删订，增加，审核等权利；普通管理员只有法律法规的修改权限；</p>
				<FormItem>
					<Button type="primary" @click="adduser()">{{addorchange==0?"增加":"保存"}}</Button>
					<Button style="margin-left: 12.5px;">返回</Button>
				</FormItem>
			</Form>
		</div>
	</div>
</template>

<script>
	export default {
		data() {
			return {
				addorchange: 1,
				library_id: "",
				formItem: {
					name: '',
					usernum: '',
					passwordw: '',
					sex: '男',
					callnum: '',
					selectcity: '',
					selectlv: '',
				},
				mangers:[],
			}
		},
		components: {
			//			Home,
		},
		created: function() {
			var userid = localStorage.getItem('userId');
			var username = localStorage.getItem('userName');
			localStorage.nowpage = this.$route.query.nowpage;
			this.userid = userid;
			this.username = username;
			this.id = this.$route.query.id;
			this.addorchange = this.$route.query.addorchange;
			//console.log(this.id, this.addorchange)

			var _this = this; //在数据加载之前的操作
			var data = {
				id: this.id
			}
			var qs = require('qs');
			this.$axios.post('/law_management/user/findById', qs.stringify(data))
				.then(function(obj) {
					console.log(obj)
					if(obj.data.ok) {
						console.log(1)
						var formItem = {
							name: obj.data.obj.nickName,
							usernum: obj.data.obj.loginName,
							passwordw: '***',
							sex: obj.data.obj.sex,
							callnum: obj.data.obj.tel,
							selectcity: obj.data.obj.addrName,
							selectlv: obj.data.obj.role.id,
						}
						_this.formItem = formItem;
						console.log(_this.formItem)
					}
				})
				.catch(function(error) {
					//console.log(error);
					_this.modaldeluser = false;
				});
			this.$axios.post('/law_management/role/list', qs.stringify(data))
				.then(function(obj) {
					console.log(obj)
					if(obj.data.ok) {
						var mangers = obj.data.obj.content
						var ms=[];
						for(var i in mangers){
							if(mangers[i].id != 1){
								ms.push(mangers[i])
							}
						}
						_this.mangers = ms;
					}
				})
				.catch(function(error) {
					//console.log(error);
					_this.modaldeluser = false;
				});	
		},
		methods: {
			adduser() {
				console.log(this.formItem)
				if(this.formItem.name == "") {
					this.$Message.info('请设置新管理姓名');
					return
				}
				if(this.formItem.usernum == "") {
					this.$Message.info('请设置新管理员账户');
					return
				}
				if(this.formItem.passwordw == "") {
					this.$Message.info('请设置新管理员密码');
					return
				}
				if(this.formItem.callnum == "" || this.formItem.callnum == null) {
					this.$Message.info('电话号码不能为空');
					return
				}
				if(this.formItem.selectcity == "" || this.formItem.selectcity == null) {
					this.$Message.info('新用户所在省市不能为空');
					return
				}
				if(this.formItem.selectlv == "") {
					this.$Message.info('请选择新用户的管理员等级');
					return
				}
				var data = {
					nickName: this.formItem.name,
					addrName: this.formItem.selectcity,
					rId: this.formItem.selectlv,
					sex: this.formItem.sex,
					tel: this.formItem.callnum,
				}
				var that = this;
				var re = require('qs'); //创建传输数据对象
				if(this.addorchange == 0) {
					data.loginName = this.formItem.usernum;
					data.loginPassword = this.formItem.passwordw;
					this.$axios.post('/law_management/user/add', re.stringify(data))
						.then(function(data) {
							//console.log(data)
							if(data.data.ok) {
								that.$Message.info('添加新管理员成功');
								location.href = '/Users';
							} else {
								that.$Message.error(obj.data.msg);
							}
						})
						.catch(function(error) {
							//console.log(error);
						});
				} else {
					data.id = this.id
					this.$axios.post('/law_management/user/update', re.stringify(data))
						.then(function(data) {
							//console.log(data)
							if(data.data.ok) {
								that.$Message.info('修改新管理员成功');
								location.href = '/Users';
							} else {
								that.$Message.error(obj.data.msg);
							}
						})
						.catch(function(error) {
							//console.log(error);
						});
				}

			},
			retrunlastpage(){
				this.$router.go(-1);
			},
			chaxunusername(){
				var that = this;
				if(this.formItem.usernum!=""){
					var re = require('qs'); //创建传输数据对象
					var data = {
						loginName:this.formItem.usernum
					}
					this.$axios.post('/law_management/checkLoginName', re.stringify(data))
							.then(function(data) {
								//console.log(data)
								if(data.data.ok) {
									that.$Message.info('账户可用');
								} else {
									that.$Message.error('账户不可使用');
								}
							})
							.catch(function(error) {
								//console.log(error);
						});
				}
				
			}
		},
		mounted(){
		    //定位当前位置
			isnowpages(localStorage.getItem('nowpage'))
		}
	}
	
	function isnowpages(a){
		//console.log($(".nowpages")[a])
		$(".nowpages").parents('li').removeClass("ivu-menu-item-selected")
		$($(".nowpages")[a]).addClass('router-link-exact-active router-link-active')
		$($(".nowpages")[a]).parents('li').addClass("ivu-menu-item-selected");		
	}
</script>

<style>
	.useritems {
		width: 100%;
		padding-top: 7.5px;
	}
	
	.useritems>div {
		position: relative;
		overflow: hidden;
		margin-top: 8px;
	}
	
	.useritems .ivu-form-item-label {
		width: 150px!important;
	}
	
	.useritems .ivu-form-item-content {
		margin-left: 150px!important;
		width: 360px;
	}
	
	.useritems .tit {
		margin-left: 150px;
	}
	
	.useritems button {
		width: 120px;
		margin-top: 22.5px;
	}
	.lvselect{
		height: 30px;
		color: #495060;
		border-radius: 5px;	
		border: solid gainsboro 1px;
		box-sizing: border-box;
		padding-left: 5px;
		
	}
	.lvselect option{
		padding-top: 5px!important;
		padding-bottom: 5px!important;
		line-height: 32px!important;
	}
</style>