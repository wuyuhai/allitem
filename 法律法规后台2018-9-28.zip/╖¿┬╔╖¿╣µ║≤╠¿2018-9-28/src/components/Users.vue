<template>
	<div>
		<div>
			<div class="right-header">
				<Icon type="md-arrow-dropright" />
				<span>当前位置</span>：用户管理
			</div>
			<div class="gongneng_box">
				<div class="add_user">
					<router-link :to="{path:'/Useritemsedit', query:{addorchange:0,nowpage:1}}">
						<Icon custom="i-icon i-icon-add" size="24" /> 新增管理员
					</router-link>
				</div>
			</div>
			<div class="users_box">
				<table class="tables" border="0" cellspacing="0" cellpadding="0">
					<thead class="table_header">
						<tr>
							<th colspan="7">序号</th>
							<th colspan="10">姓名</th>
							<th colspan="20">用户账号</th>
							<th colspan="20">密码</th>
							<th colspan="10">所属市区</th>
							<th colspan="10">账号级别</th>
							<th colspan="8">权限</th>
							<th colspan="15">操作</th>
						</tr>
					</thead>
					<tbody class="dw_tbody">
						<tr v-for="(item, index) in userslist">
							<td colspan="7" title="点击查看用户详情">
								<router-link :to="{path:'/Useritems', query:{id:item.id}}">
									{{index + 1}}
								</router-link>
							</td>
							<td colspan="10" title="点击查看用户详情">
								<router-link :to="{path:'/Useritems', query:{id:item.id}}">
									{{item.nickName}}
								</router-link>
							</td>
							<td colspan="20" title="点击查看用户详情">
								<router-link :to="{path:'/Useritems', query:{id:item.id}}">
									{{item.loginName}}
								</router-link>
							</td>
							<td colspan="20" title="点击查看用户详情">
								<router-link :to="{path:'/Useritems', query:{id:item.id}}">
									***
								</router-link>
							</td>
							<td colspan="10" title="点击查看用户详情">
								<router-link :to="{path:'/Useritems', query:{id:item.id}}">
									{{item.addrName?item.addrName:"-"}}
								</router-link>
							</td>
							<td colspan="10" title="点击查看用户详情">
								<router-link :to="{path:'/Useritems', query:{id:item.id}}">
									{{item.role.name}}
								</router-link>
							</td>
							<td colspan="8" title="点击查看用户详情">
								<router-link :to="{path:'/Useritems', query:{id:item.id}}">
									详情
								</router-link>
							</td>
							<td colspan="15" style="font-size: 16px;" class="td-manage">
								<router-link style="margin-right: 5px;" :to="{path:'/Useritemsedit', query:{id:item.id,addorchange:1}}">
									<Icon type="edit" title="编辑" class="dw_ed"></Icon>
								</router-link>
								<router-link to="">
									<Icon @click="deletebtn(item.id)" type="trash-a" title="删除"></Icon>
								</router-link>
							</td>
						</tr>
					</tbody>
				</table>
				<div class="pages">
					<Page :total="usersnum" />
				</div>
			</div>
		</div>
		<Modal
	        v-model="modaldeluser"
	        title="删除用户"
	        @on-ok="deluserok"
	        @on-cancel="delusercancel">
	        <p>确认删除该用户？</p>
	    </Modal>
	</div>
</template>

<script>
	export default {
		name: 'users',
		data() {
			return {
				page: 1,
				usersnum: 0,
				userslist: [],
				modaldeluser:false,
				delid:"",
			}
		},
		created: function() {
			localStorage.nowpage = this.$route.query.nowpage;
			var _this = this; //在数据加载之前的操作
			var data = {
				page: this.page,
				size: 20
			}
			var qs = require('qs');
			this.$axios.post('/law_management/user/list', qs.stringify(data))
				.then(function(obj) {
					console.log(obj)
					if(obj.data.ok) {
						_this.usersnum = obj.data.obj.totalElements;
						_this.userslist = obj.data.obj.content;
					}
					//					_this.user_list = obj.data.data.list;
					//					_this.num = obj.data.data.count;
				})
				.catch(function(error) {
					console.log(error);
				});
		},
		mounted: function() {
			isnowpages(localStorage.getItem('nowpage'))
		},
		methods: {
			deletebtn(e){
				console.log(e)
				if(e == 1){
					this.$Message.info('超级管理员不能删除');
					return;
				}
				this.delid = e;
				this.modaldeluser = true;
			},		
			deluserok(){
				if(this.delid == 1){
					this.$Message.info('超级管理员不能删除');
					return;
				}
				var _this = this; //在数据加载之前的操作
				var data = {
					id:this.delid
				}
				var qs = require('qs');
				this.$axios.post('/law_management/user/delete', qs.stringify(data))
					.then(function(obj) {
						console.log(obj)
						if(obj.data.ok) {
							_this.$Message.info('删除成功');
							_this.getusers()
							_this.delid = "";
							_this.modaldeluser = false;
						}
						//					_this.user_list = obj.data.data.list;
						//					_this.num = obj.data.data.count;
					})
					.catch(function(error) {
					console.log(error);
					_this.modaldeluser = false;
				});
			},
			delusercancel(){
				this.modaldeluser = false
			},
			getusers(){
				var _this = this; //在数据加载之前的操作
				var data = {
					page: this.page,
					size: 20
				}
				var qs = require('qs');
				this.$axios.post('/law_management/user/list', qs.stringify(data))
					.then(function(obj) {
						console.log(obj)
						if(obj.data.ok) {
							_this.usersnum = obj.data.obj.totalElements;
							_this.userslist = obj.data.obj.content;
						}
					})
					.catch(function(error) {
						console.log(error);
					});
			}
		},
	}
	
	function isnowpages(a){
		console.log($(".nowpages")[a])
		$(".nowpages").parents('li').removeClass("ivu-menu-item-selected")
		$($(".nowpages")[a]).addClass('router-link-exact-active router-link-active')
		$($(".nowpages")[a]).parents('li').addClass("ivu-menu-item-selected");		
	}
</script>

<style>
	.users_box {
		position: relative;
		height: 700px;
	}
	
	.add_user {
		float: right;
		line-height: 39px;
		font-size: 18px;
		margin-right: 20px;
		color: #4A90E2;
	}
	
	.users_box {}
	
	.tables {
		width: 100%;
		max-height: 650px;
	}
	
	.tables tr td {
		text-align: center;
		line-height: 29px;
		font-size: 12px;
		-o-text-overflow: ellipsis;
		text-overflow: ellipsis;
		overflow: hidden;
		white-space: nowrap;
		width: 100%;
		border-bottom: 1px solid gainsboro;
		border-right: 1px solid gainsboro;
	}
	
	.pages {
		position: absolute;
		bottom: 12.5px;
		text-align: center;
		width: 100%;
	}
</style>