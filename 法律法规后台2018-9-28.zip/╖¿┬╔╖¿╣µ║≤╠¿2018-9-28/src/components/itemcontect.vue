<template>
	<div>
		<div>
			<div class="right-header">
				<Icon type="md-arrow-dropright" />
				<span>当前位置</span>：项目与法律关联列表
			</div>
			<div class="users_box">
				<table class="tables" border="0" cellspacing="0" cellpadding="0">
					<thead class="table_header">
						<tr>
							<th colspan="30">事项名称</th>
							<th colspan="10">关联日期</th>
							<th colspan="30">关联法律</th>
							<th colspan="7">市</th>
							<th colspan="7">区</th>
							<th colspan="10">法律类型</th>
							<th colspan="10">所属类别</th>
							<th colspan="10">发布日期</th>
							<th colspan="10">施行日期</th>
						</tr>
					</thead>
					<tbody class="dw_tbody">
						<tr v-for="(item, index) in itemslist">
							<td colspan="30" title="点击查看用户详情">
								<router-link :to="{path:'/lawyeritem/lawyeritem', query:{id:item.id}}">
									{{item.itemName}}
								</router-link>
							</td>
							<td colspan="10" title="点击查看用户详情">
								<router-link :to="{path:'/lawyeritem/lawyeritem', query:{id:item.id}}">
									{{item.createTime}}
								</router-link>
							</td>
							<td colspan="30" title="点击查看用户详情">
								<router-link :to="{path:'/lawyeritem/lawyeritem', query:{id:item.id}}">
									{{lawlist[index].title}}
								</router-link>
							</td>
							<td colspan="7" title="点击查看用户详情">
								<router-link :to="{path:'/lawyeritem/lawyeritem', query:{id:item.id}}">
									{{item.orgName}}
								</router-link>
							</td>
							<td colspan="7" title="点击查看用户详情">
								<router-link :to="{path:'/lawyeritem/lawyeritem', query:{id:item.id}}">
									{{item.regionName}}
								</router-link>
							</td>
							<td colspan="10" title="点击查看用户详情">
								<router-link :to="{path:'/lawyeritem/lawyeritem', query:{id:item.id}}">
									{{lawlist[index].category}}
								</router-link>
							</td>
							<td colspan="10" title="点击查看用户详情">
								<router-link :to="{path:'/lawyeritem/lawyeritem', query:{id:item.id}}">
									{{lawlist[index].category}}
								</router-link>
							</td>
							<td colspan="10" title="点击查看用户详情">
								<router-link :to="{path:'/lawyeritem/lawyeritem', query:{id:item.id}}">
									{{lawlist[index].publishDate}}
								</router-link>
							</td>
							<td colspan="10" title="点击查看用户详情">
								<router-link :to="{path:'/lawyeritem/lawyeritem', query:{id:item.id}}">
									{{lawlist[index].executeDate}}
								</router-link>
							</td>
						</tr>
					</tbody>
				</table>
				<div class="pages">
					<Page :total="itemsnum" />
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	export default {
		name: 'users',
		data() {
			return {
				page: 1,
				itemsnum: 0,
				itemslist: [],
				lawlist:[],
				modaldeluser:false,
				delid:"",
			}
		},
		created: function() {
			localStorage.nowpage = this.$route.query.nowpage;
			var _this = this; //在数据加载之前的操作
			var data = {
				page: this.page,
				size: 20
			}
			var qs = require('qs');
			this.$axios.post('/law_management/chinaLaw/relateList', qs.stringify(data))
				.then(function(obj) {
					console.log(obj)
					if(obj.data.ok) {
						_this.itemsnum = obj.data.obj.totalElements;
						_this.itemslist = obj.data.obj.content;
						_this.lawlist = obj.data.ext;
					}
					//					_this.user_list = obj.data.data.list;
					//					_this.num = obj.data.data.count;
				})
				.catch(function(error) {
					console.log(error);
				});
		},
		mounted: function() {
			isnowpages(localStorage.getItem('nowpage'))
		},
		methods: {
					
		},
	}
	function isnowpages(a){	
		$(".nowpages").parent().removeClass("ivu-menu-item-selected")	
		
		$($(".nowpages")[a]).parent().parent().parent().addClass("ivu-menu-item-active ivu-menu-opened ivu-menu-child-item-active");
		$($(".nowpages")[a]).parent().parent().css({"display":"block"});
		$($(".nowpages")[a]).parent().addClass("ivu-menu-item-selected");		
		//console.log($($(".nowpages")[a]).parent())
	}
</script>

<style>
	.users_box {
		position: relative;
		height: 700px;
	}
	
	.add_user {
		float: right;
		line-height: 39px;
		font-size: 18px;
		margin-right: 20px;
		color: #4A90E2;
	}
	
	.users_box {}
	
	.tables {
		width: 100%;
		max-height: 650px;
	}
	
	.tables tr td {
		text-align: center;
		line-height: 29px;
		font-size: 12px;
		-o-text-overflow: ellipsis;
		text-overflow: ellipsis;
		overflow: hidden;
		white-space: nowrap;
		width: 100%;
		border-bottom: 1px solid gainsboro;
		border-right: 1px solid gainsboro;
	}
	
	.pages {
		position: absolute;
		bottom: 12.5px;
		text-align: center;
		width: 100%;
	}
</style>