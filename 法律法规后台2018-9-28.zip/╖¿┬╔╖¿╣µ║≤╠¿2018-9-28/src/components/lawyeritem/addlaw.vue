<template>
	<div class="layout">
		<Layout>
			<Header>
				<span class="title_a">
    				法律服务后台管理系统
    			</span>
				<Menu mode="horizontal" class="headeraruto">
					<Submenu name="3" id="user_name">
						<template slot="title">
							<Avatar src="https://i.loli.net/2017/08/21/599a521472424.jpg" />
							<i id="username">{{username}}</i>
						</template>
						<li class="ivu-menu-item ivu-menu-item-active" @click="login_out()">{{loginout}}</li>
						<li class="ivu-menu-item ivu-menu-item-active" @click="modal1 = true">{{changepassword}}</li>
					</Submenu>
				</Menu>
			</Header>
		</Layout>
		<div class="lawyersitem">
			<div class="sm_he">
				<span>当前位置：</span> 政策法律法规分类管理>增加
			</div>
			<div class="sm_contant">			
				<Form :model="formItemlaw" :label-width="80">
			        <FormItem label="名称">
			            <Input v-model="formItemlaw.title" placeholder="请输入法律法规名称"></Input>
			        </FormItem>
			        <FormItem label="公布部门">
			            <Input v-model="formItemlaw.bumen" placeholder="请输入公布部门"></Input>
			        </FormItem>
			        <FormItem label="公布日期">
			            <Row>
			                <Col span="24">
			                    <DatePicker type="date" placeholder="Select date" v-model="formItemlaw.pbdate"></DatePicker>
			                </Col>
			            </Row>
			        </FormItem>
			        <FormItem label="执行日期">
			            <Row>
			                <Col span="24">
			                    <DatePicker type="date" placeholder="Select date" v-model="formItemlaw.zxdate"></DatePicker>
			                </Col>
			            </Row>
			        </FormItem>
			        <FormItem label="法律类型">
			            <Select v-model="formItemlaw.lawtype">
			                <Option value="5">地方性法规</Option>
			                <Option value="6">地方政府规章</Option>
			            </Select>
			        </FormItem>
			        <FormItem label="省份">
			            <Select v-model="formItemlaw.province">
			                <Option value="贵州省">贵州省</Option>
			            </Select>
			        </FormItem>
			        <FormItem label="市区" v-show="citybol">
			            <Select v-model="formItemlaw.city">
			                <Option value="贵阳市">贵阳市</Option>
			                <Option value="六盘水市">六盘水市</Option>
			                <Option value="遵义市">遵义市</Option>
			                <Option value="安顺市">安顺市</Option>
			                <Option value="毕节市">毕节市</Option>
			                <Option value="贵安新区">贵安新区</Option>
			                <Option value="铜仁市">铜仁市</Option>
			                <Option value="黔西南州">黔西南州</Option>
			                <Option value="黔东南州">黔东南州</Option>
			                <Option value="黔南州">黔南州</Option>
			            </Select>
			        </FormItem>
			        <FormItem label="门类">
			            <Input v-model="formItemlaw.mls" placeholder="请输入法律法规名称"></Input>
			        </FormItem>
			        <FormItem label="Text">
			            <Input v-model="formItemlaw.note" type="textarea" :autosize="{minRows: 2,maxRows: 5}" placeholder="Enter something..."></Input>
			        </FormItem>
			        <div class="ivu-form-item" style="width: 50%;margin-left: 25%;">
			        	<label for="" class="ivu-form-item-label" style="width: 80px;position: relative;top: -5px;">导入文件</label>
			        	<input type="file" id="filse_law"/>
			        </div>
			        <FormItem>
			            <Button type="primary" @click="addnewlaw()">添加</Button>
			        </FormItem>
			    </Form>
			</div>
		</div>
		<footer>Copyright ©2018 fotoit-admin v1.2 All Rights Reserved. 本后台系统由珠海方图智能科技有限公司提供技术支持</footer>
		<Modal v-model="modal1" title="修改密码" style="position: relative;">
			<Form :model="formItem" :label-width="80">
				<FormItem label="旧密码">
					<Input type="password" v-model="formItem.oldpass" placeholder="请输入旧密码"></Input>
				</FormItem>
				<FormItem label="新密码">
					<Input type="password" v-model="formItem.newpass" placeholder="请输入新密码"></Input>
				</FormItem>
				<FormItem label="确认新密码">
					<Input type="password" v-model="formItem.newpassagain" placeholder="请确认新密码"></Input>
				</FormItem>
				<FormItem class="changebtn">
					<Button @click="changepasswordok()">提交</Button>
					<Button @click="changepasswordcancel()">取消</Button>
				</FormItem>
			</Form>
		</Modal>
	</div>
</template>

<script>
	
	export default {
		name: 'index',
		data() {
			return {
				loginout: '退出',
				userid: '',
				changepassword: '修改密码',
				username: 'test',
				modal1: false,
				formItem: {
					oldpass: '',
					newpass: '',
					newpassagain: '',
				},

				roleid:'',
				roleaddrName:'',
				
				formItemlaw:{
					title:'',
					bumen:'',
					pbdate:'',
					zxdate:'',
					lawtype:'',
					mls:'',	
					note:'',
					city:'',
					province:'贵州省',
				},
				files:'',
				citybol:false,
			}
		},
		watch:{
			"formItemlaw.lawtype"(a,b){
				if(a == 5){
					this.citybol = false;
				}else{
					this.citybol = true;
				}
			}
		},
		mounted() {
		},
		components: {

		},
		created: function() {
			var userid = localStorage.getItem('userId');
			var username = localStorage.getItem('userName');
			this.userid = userid;
			this.username = username;
			this.roleid = localStorage.getItem('roleid');
			this.roleaddrName = localStorage.getItem('roleaddrName');
		},
		methods: {
			addnewlaw(){
				console.log(this.formItemlaw)
				var that = this;
				if(!that.formItemlaw.bumen){
					this.$Message.info('请选择法律所属部门');
					return
				}
				if(!that.formItemlaw.lawtype){
					this.$Message.info('请选择法律所属类型');
					return
				}
				if(!that.formItemlaw.title){
					this.$Message.info('请填写法律标题');
					return
				}
				if(!that.formItemlaw.pbdate){
					this.$Message.info('请选择公布日期');
					return
				}
				if(!that.formItemlaw.note){
					this.$Message.info('请填写法律备注');
					return
				}
				if(!that.formItemlaw.zxdate){
					this.$Message.info('请选择执行日期');
					return
				}
				if(that.formItemlaw.lawtype == 6){
					if(!that.formItemlaw.city){
						this.$Message.info('请选择所属城市');
						return
					}
				}		
				if(!that.formItemlaw.mls){
					this.$Message.info('请填写所属门类');
					return
				}
				if($("#filse_law")[0].files[0]){
					var re = require('qs'); //创建传输数据对象
					let formData = new FormData();
        			formData.append('file', $("#filse_law")[0].files[0]);
        			let config = {
			          headers:{'Content-Type':'multipart/form-data'}
			        };
        			this.$axios.post('/law_management/word/upDoc',formData, config).then(function (response) {
			          console.log(response)
						if(response.data.ok == true){
							var datas = {
								department:that.formItemlaw.bumen,
								type:that.formItemlaw.lawtype,
								title:that.formItemlaw.title,
								publishDate:that.formItemlaw.pbdate,
								province:that.formItemlaw.province,
								note:that.formItemlaw.note,	
								lawId:response.data.obj,
								executeDate:that.formItemlaw.zxdate,
								effect:"新增未审核",
								city:that.formItemlaw.city,
								category:that.formItemlaw.mls,
							}
							that.$axios.post('/law_management/chinaLaw/add', re.stringify(datas))
								.then(function(data) {
									console.log(data)
									if(data.data.ok) {
										that.$Message.info('添加成功');
									} else {
										that.$Message.error(obj.data.msg);
									}
								})
								.catch(function(error) {
									console.log(error);
							});
						}
			        })
//					this.$axios.post('/law_management/word/upDoc', re.stringify(data))
//						.then(function(data) {
//							console.log(data)
//							if(data.data.ok) {
//								
//							} else {
//								this.$Message.error(obj.data.msg);
//							}
//						})
//						.catch(function(error) {
//							console.log(error);
//					});
				}else{
					this.$Message.info('请选择导入的word文档');
				}
			},
			login_out() {
				var re = require('qs'); //创建传输数据对象
				this.$axios.post('/law_management/logout', re.stringify())
					.then(function(data) {
						console.log(data)
						if(data.data.ok) {
							location.href = '/';
							localStorage.clear();
						} else {
							this.$Message.error(obj.data.msg);
						}
					})
					.catch(function(error) {
						console.log(error);
					}); //ajax end
			},
			changepasswordok() {
				console.log(this.formItem)
				if(this.formItem.oldpass == "") {
					this.$Message.info('旧密码不能为空');
					return
				}
				if(this.formItem.newpass == "") {
					this.$Message.info('新密码不能为空');
					return
				}
				if(this.formItem.newpass != this.formItem.newpassagain) {
					this.$Message.info('两次输入的新密码不一样');
					return
				}
				var data = {
					newPassword:this.formItem.newpass,
					oldPassword:this.formItem.oldpass,
					id:localStorage.userId
				}
				console.log(data)
				var that = this;
				var re = require('qs'); //创建传输数据对象
				this.$axios.post('/law_management/updatePassword', re.stringify(data))
					.then(function(data) {
						console.log(data)
						if(data.data.ok) {
//							location.href = '/';
//							localStorage.clear();
							alert('密码修改成功');
							that.modal1 = false;
						} else {
							alert('密码失败');
						}
					})
					.catch(function(error) {
						console.log(error);
					}); //ajax end
			},
			changepasswordcancel() {
				//              this.$Message.info('Clicked cancel');
				console.log("取消")
				this.modal1 = false;
			},
		},
	}
</script>

<style>
	#username {
		font-style: normal;
	}
	
	.changebtn {
		position: absolute;
		bottom: -20px;
		width: 100%;
		background: #fff;
		left: 0;
		height: 50px;
	}
	
	.changebtn button {
		float: right;
		margin-top: 10px;
	}
	
	.changebtn button:nth-child(1) {
		margin-right: 25px;
		background: #0168F3;
		color: #fff;
	}
	
	.changebtn button:nth-child(2) {
		margin-right: 25px;
	}
	
	.user_boxmoveli {
		z-index: 99;
	}
	
	.lawyersitem {
		position: absolute;
		width: 100%;
		height: 100%;
		background: #F2F2F2;
		z-index: 99;
		top: 60px;
		left: 0;
	}
	
	.sm_he {
		height: 40px;
		padding: 0 20px 0 20px;
		line-height: 40px;
		font-size: 16px;
	}
	
	.sm_he>span:nth-child(1) {
		font-size: 18px;
		color: #014E9E;
	}
	
	.sm_contant {
		width: 100%;
		box-sizing: border-box;
		padding: 0 20px 20px 20px;
		height: 100%;
	}
	
	footer {
		text-align: center;
		z-index: 99;
	}	
	.ivu-form-item{
		width: 50%;
		margin-left: 25%;
	}
	.nfile .ivu-input{
		background: none;
		border: none;
	}
</style>