<template>
	<div class="layout">
		<Layout>
			<Header>
				<span class="title_a">
    				法律服务后台管理系统
    			</span>
				<Menu mode="horizontal" class="headeraruto">
					<Submenu name="3" id="user_name">
						<template slot="title">
							<Avatar src="https://i.loli.net/2017/08/21/599a521472424.jpg" />
							<i id="username">{{username}}</i>
						</template>
						<li class="ivu-menu-item ivu-menu-item-active" @click="login_out()">{{loginout}}</li>
						<li class="ivu-menu-item ivu-menu-item-active" @click="modal1 = true">{{changepassword}}</li>
					</Submenu>
				</Menu>
			</Header>
		</Layout>
		<div class="lawyersitem">
			<div class="sm_he">
				<span>当前位置：</span> 政策法律法规分类管理>增加
			</div>
			<div class="sm_contant">	
				<div class="change_left">
					<div class="l_title">{{zhanshipage.title}}</div>
					<div class="l_content"><label for="">公布部门：</label>{{zhanshipage.bumen}}</div>
					<div class="l_content"><label for="">公布日期：</label>{{zhanshipage.pbdate}}</div>
					<div class="l_content"><label for="">执行日期：</label>{{zhanshipage.zxdate}}</div>
					<div class="l_content"><label for="">法律类型：</label>{{uli[zhanshipage.lawtype]}}</div>
					<div class="l_content"><label for="">门类：</label>{{zhanshipage.mls}}</div>
					<div class="l_content"><label for="">备注：</label>{{zhanshipage.note}}</div>
					<div id="sssss">
						<div v-for="(item, index) in items">
							<div class="scollpian" style="font-size:16px;font-weight:600;margin-bottom:5.5px" v-html="item.html">																
							</div>
							<div v-for="(item2, index1) in item.children">
								<div class="scollzhang" v-html="item2.html">
								</div>
								<div v-for="(item3, index2) in item2.children">
									<div class="scolljie" style="padding-left:7.5px;margin-bottom:7.5px;" v-html="item3.html">
									</div>
									<div v-for="(item4, index3) in item3.children">
										<div class="scolltiao" style="padding-left:7.5px;margin-bottom:7.5px;" v-html="item4.html">
										</div>
									</div>
								</div>
							</div>								
						</div>							
					</div>
				</div>
				<div class="change_right">
					<div class="l_title">{{zhanshipage.title}}</div>
					<!--<Form :model="formItemlaw" :label-width="80">
				        <FormItem label="公布部门">
				            <Input v-model="formItemlaw.bumen" placeholder="请输入公布部门"></Input>
				        </FormItem>
				        <FormItem label="公布日期">
				            <Row>
				                <Col span="24">
				                    <DatePicker type="date" placeholder="Select date" v-model="formItemlaw.pbdate"></DatePicker>
				                </Col>
				            </Row>
				        </FormItem>
				        <FormItem label="执行日期">
				            <Row>
				                <Col span="24">
				                    <DatePicker type="date" placeholder="Select date" v-model="formItemlaw.zxdate"></DatePicker>
				                </Col>
				            </Row>
				        </FormItem>
				        <FormItem label="法律类型">
				            <Select v-model="formItemlaw.lawtype">
				                <Option value="5">地方性法规</Option>
				                <Option value="6">地方政府规章</Option>
				            </Select>
				        </FormItem>
				        <FormItem label="省份">
				            <Select v-model="formItemlaw.province">
				                <Option value="贵州省">贵州省</Option>
				            </Select>
				        </FormItem>
				        <FormItem label="市区" v-show="citybol">
				            <Select v-model="formItemlaw.city">
				                <Option value="贵阳市">贵阳市</Option>
				                <Option value="六盘水市">六盘水市</Option>
				                <Option value="遵义市">遵义市</Option>
				                <Option value="安顺市">安顺市</Option>
				                <Option value="毕节市">毕节市</Option>
				                <Option value="贵安新区">贵安新区</Option>
				                <Option value="铜仁市">铜仁市</Option>
				                <Option value="黔西南州">黔西南州</Option>
				                <Option value="黔东南州">黔东南州</Option>
				                <Option value="黔南州">黔南州</Option>
				            </Select>
				        </FormItem>
				        <FormItem label="门类">
				            <Input v-model="formItemlaw.mls" placeholder="请输入法律法规名称"></Input>
				        </FormItem>
				        <FormItem label="Text">
				            <Input v-model="formItemlaw.note" type="textarea" :autosize="{minRows: 2,maxRows: 5}" placeholder="Enter something..."></Input>
				        </FormItem>
				        <FormItem>
				            <Button type="primary" @click="addnewlaw()">修改</Button>
				        </FormItem>
				    </Form>-->
				    <div class="l_content"><label for="">公布部门：</label>{{zhanshipage.bumen}}</div>
					<div class="l_content"><label for="">公布日期：</label>{{zhanshipage.pbdate}}</div>
					<div class="l_content"><label for="">执行日期：</label>{{zhanshipage.zxdate}}</div>
					<div class="l_content"><label for="">法律类型：</label>{{uli[zhanshipage.lawtype]}}</div>
					<div class="l_content"><label for="">门类：</label>{{zhanshipage.mls}}</div>
					<div class="l_content"><label for="">备注：</label>{{zhanshipage.note}}</div>
					<div class="new-law">
						<div class="new-law-html">
							<div v-for="(bian , bianindex) in bians">
								<div class="law-box">
									<div v-html="bian.html"></div>
									<div class="btns">
										<!--<Button type="primary" :datanum="bian.children.length" :datapid="bian.id" @click="showaddEditorWin($event)">添加章</Button>-->
									</div>
									<div style="clear: both;"></div>
								</div>
								<div v-for="(zhang,zhangindex) in bian.children">
									<div class="law-box">
										<div v-html="zhang.html"></div>
										<div class="btns">
											<!--<Button type="primary" :datanum="zhang.children.length" :datapid="zhang.id" @click="showaddEditorWin($event)">添加节</Button>-->
											<Button type="primary" :datahtml="zhang.html" :dataid="zhang.id" @click="showEditorWin($event)">编辑</Button>
											<Button type="primary" :dataid="zhang.id" @click="showDeleteWin($event)">删除</Button>
										</div>
										<div style="clear: both;"></div>
									</div>
									<div v-for="(jie,jieindex) in zhang.children">
										<div class="law-box">
											<div v-html="jie.html"></div>
											<div class="btns">
												<!--<Button type="primary" :datanum="jie.children.length" :datapid="jie.id" @click="showaddEditorWin($event)">添加条</Button>-->
												<Button type="primary" :datahtml="jie.html" :dataid="jie.id" @click="showEditorWin($event)">编辑</Button>
												<Button type="primary" :dataid="jie.id" @click="showDeleteWin($event)">删除</Button>
											</div>
											<div style="clear: both;"></div>
										</div>
										<div v-for="(tiao,tiaoindex) in jie.children">
											<div class="law-box">
												<div class="tiao" v-html="tiao.html"></div>
												<div class="btns">
													<!--<Button type="primary">添加</Button>-->
													<Button type="primary" :datahtml="tiao.html" :dataid="tiao.id" @click="showEditorWin($event)">编辑</Button>
													<Button type="primary" :dataid="tiao.id" @click="showDeleteWin($event)">删除</Button>
												</div>
												<div style="clear: both;"></div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<Modal v-model="showEditor" title="编辑" @on-ok="addLaw" @on-cancel="cancel()">
							<div id="editorElem" style="text-align:left">
							</div>
						</Modal>
						<Modal v-model="deleteEditor" title="删除提示" @on-ok="deleteLaw" @on-cancel="cancel()">
							<p>确定要删除吗？</p>
						</Modal>
						<div class="next-btn" style="text-align: center;">
							<Button type="primary" v-on:click="baocunlay()">保存</Button>
						</div>
					</div>
				</div>
				
			</div>
		</div>
		<footer>Copyright ©2018 fotoit-admin v1.2 All Rights Reserved. 本后台系统由珠海方图智能科技有限公司提供技术支持</footer>
		<Modal v-model="modal1" title="修改密码" style="position: relative;">
			<Form :model="formItem" :label-width="80">
				<FormItem label="旧密码">
					<Input type="password" v-model="formItem.oldpass" placeholder="请输入旧密码"></Input>
				</FormItem>
				<FormItem label="新密码">
					<Input type="password" v-model="formItem.newpass" placeholder="请输入新密码"></Input>
				</FormItem>
				<FormItem label="确认新密码">
					<Input type="password" v-model="formItem.newpassagain" placeholder="请确认新密码"></Input>
				</FormItem>
				<FormItem class="changebtn">
					<Button @click="changepasswordok()">提交</Button>
					<Button @click="changepasswordcancel()">取消</Button>
				</FormItem>
			</Form>
		</Modal>
	</div>
</template>

<script>
	import wangeditor from 'wangeditor'
	export default {
	name: 'index',
	data() {
		return {
			loginout: '退出',
			userid: '',
			changepassword: '修改密码',
			username: 'test',
			modal1: false,
			formItem: {
				oldpass: '',
				newpass: '',
				newpassagain: '',
			},
			id: "",

			roleid: '',
			roleaddrName: '',

			formItemlaw: {
				title: '',
				bumen: '',
				pbdate: '',
				zxdate: '',
				lawtype: '',
				mls: '',
				note: '',
				city: '',
				province: '贵州省',
			},
			files: '',
			citybol: false,

			zhanshipage: {
				title: '',
				bumen: '',
				pbdate: '',
				zxdate: '',
				lawtype: '',
				mls: '',
				note: '',
				city: '',
				province: '贵州省',
			},

			uli: ['', '', '法律', '政策法规', '国务院部门规章', '地方性法规', '地方性政府规章'],
			items: [],
			bians:"",
			
			deleteEditor:false,
			deleteId:"",
			jsonarr:[],
			showEditor:false,
			editorContent: "<p></p>",
			appId:"",
		}
	},
	watch: {
		"formItemlaw.lawtype" (a, b) {
			if(a == 5) {
				this.citybol = false;
			} else {
				this.citybol = true;
			}
		},
		editorContent: {
			handler(val, oldVal) {
				this.editor.txt.html(val);
			},
		}
	},
	mounted() {
		var vm = this;
		this.editor = new wangeditor('#editorElem');
		// 自定义菜单配置
		this.editor.customConfig.menus = [];
		this.editor.customConfig.onchange = (html) => {
			vm.editorContent = html
		}
		this.editor.create()
	},
	components: {

	},
	created: function() {
		var userid = localStorage.getItem('userId');
		var username = localStorage.getItem('userName');
		this.id = this.$route.query.id;
		this.appId = this.$route.query.appId;
		this.userid = userid;
		this.username = username;
		this.roleid = localStorage.getItem('roleid');
		this.roleaddrName = localStorage.getItem('roleaddrName');
		console.log(this.id)
		if(this.id != undefined) {
			var _this = this; //在数据加载之前的操作
			var data = {
				id: this.id,
			}
			var qs = require('qs');
			this.$axios.post('/law_management/lawItem/newInfo', qs.stringify(data))
				.then(function(obj) {
					console.log(obj)
					if(obj.data.ok) {
						_this.formItemlaw.title = obj.data.obj.chinaLaw.title;
						_this.formItemlaw.bumen = obj.data.obj.chinaLaw.department;
						_this.formItemlaw.pbdate = obj.data.obj.chinaLaw.publishDate.split(" ")[0];
						_this.formItemlaw.zxdate = obj.data.obj.chinaLaw.executeDate.split(" ")[0];
						_this.formItemlaw.lawtype = obj.data.obj.chinaLaw.type;
						_this.formItemlaw.province = obj.data.obj.chinaLaw.province;
						_this.formItemlaw.mls = obj.data.obj.chinaLaw.category;
						_this.formItemlaw.note = obj.data.obj.chinaLaw.note;
						if(obj.data.obj.chinaLaw.type == 6) {
							_this.formItemlaw.city = obj.data.obj.chinaLaw.city;
						}
						_this.zhanshipage.title = obj.data.obj.chinaLaw.title;
						_this.zhanshipage.bumen = obj.data.obj.chinaLaw.department;
						_this.zhanshipage.pbdate = obj.data.obj.chinaLaw.publishDate.split(" ")[0];
						_this.zhanshipage.zxdate = obj.data.obj.chinaLaw.executeDate.split(" ")[0];
						_this.zhanshipage.lawtype = obj.data.obj.chinaLaw.type;
						_this.zhanshipage.province = obj.data.obj.chinaLaw.province;
						_this.zhanshipage.mls = obj.data.obj.chinaLaw.category;
						_this.zhanshipage.note = obj.data.obj.chinaLaw.note;
						_this.zhanshipage.lawid = obj.data.obj.chinaLaw.lawid;
						if(obj.data.obj.chinaLaw.type == 6) {
							_this.zhanshipage.city = obj.data.obj.chinaLaw.city;
						}
						_this.items = obj.data.obj.nodes;
					} else {
						_this.$Message.error(obj.data.msg);
					}
				})
				.catch(function(error) {
					console.log(error);
				});
		}
		this.loadNewHtml(this.id)
	},
	methods: {
		addnewlaw() {
			console.log(this.formItemlaw)
			var that = this;
			if(!that.formItemlaw.bumen) {
				this.$Message.info('请选择法律所属部门');
				return
			}
			if(!that.formItemlaw.lawtype) {
				this.$Message.info('请选择法律所属类型');
				return
			}
			if(!that.formItemlaw.title) {
				this.$Message.info('请填写法律标题');
				return
			}
			if(!that.formItemlaw.pbdate) {
				this.$Message.info('请选择公布日期');
				return
			}
			if(!that.formItemlaw.note) {
				this.$Message.info('请填写法律备注');
				return
			}
			if(!that.formItemlaw.zxdate) {
				this.$Message.info('请选择执行日期');
				return
			}
			if(that.formItemlaw.lawtype == 6) {
				if(!that.formItemlaw.city) {
					this.$Message.info('请选择所属城市');
					return
				}
			}
			if(!that.formItemlaw.mls) {
				this.$Message.info('请填写所属门类');
				return
			}
			if($("#filse_law")[0].files[0]) {
				var re = require('qs'); //创建传输数据对象
				let formData = new FormData();
				formData.append('file', $("#filse_law")[0].files[0]);
				let config = {
					headers: {
						'Content-Type': 'multipart/form-data'
					}
				};
				this.$axios.post('/law_management/word/upDoc', formData, config).then(function(response) {
					console.log(response)
					if(response.data.ok == true) {
						//							return
						var datas = {
							department: that.formItemlaw.bumen,
							type: that.formItemlaw.lawtype,
							title: that.formItemlaw.title,
							publishDate: that.formItemlaw.pbdate,
							province: that.formItemlaw.province,
							note: that.formItemlaw.note,
							lawId: response.data.obj,
							xecuteDate: that.formItemlaw.zxdate,
							effect: "新增未审核",
							city: that.formItemlaw.city,
							category: that.formItemlaw.mls,
						}
						that.$axios.post('/law_management/chinaLaw/add', re.stringify(datas))
							.then(function(data) {
								console.log(data)
								if(data.data.ok) {
									that.$Message.info('添加成功');
								} else {
									that.$Message.error(obj.data.msg);
								}
							})
							.catch(function(error) {
								console.log(error);
							});
					}
				})
			} else {
				this.$Message.info('请选择导入的word文档');
			}
		},
		login_out() {
			var re = require('qs'); //创建传输数据对象
			this.$axios.post('/law_management/logout', re.stringify())
				.then(function(data) {
					console.log(data)
					if(data.data.ok) {
						location.href = '/';
						localStorage.clear();
					} else {
						this.$Message.error(obj.data.msg);
					}
				})
				.catch(function(error) {
					console.log(error);
				}); //ajax end
		},
		changepasswordok() {
			console.log(this.formItem)
			if(this.formItem.oldpass == "") {
				this.$Message.info('旧密码不能为空');
				return
			}
			if(this.formItem.newpass == "") {
				this.$Message.info('新密码不能为空');
				return
			}
			if(this.formItem.newpass != this.formItem.newpassagain) {
				this.$Message.info('两次输入的新密码不一样');
				return
			}
			var data = {
				newPassword: this.formItem.newpass,
				oldPassword: this.formItem.oldpass,
				id: localStorage.userId
			}
			console.log(data)
			var that = this;
			var re = require('qs'); //创建传输数据对象
			this.$axios.post('/law_management/updatePassword', re.stringify(data))
				.then(function(data) {
					console.log(data)
					if(data.data.ok) {
						//							location.href = '/';
						//							localStorage.clear();
						alert('密码修改成功');
						that.modal1 = false;
					} else {
						alert('密码失败');
					}
				})
				.catch(function(error) {
					console.log(error);
				}); //ajax end
		},
		changepasswordcancel() {
			//              this.$Message.info('Clicked cancel');
			console.log("取消")
			this.modal1 = false;
		},
		loadNewHtml(a) {
			let vm = this;
			var re = require('qs'); //创建传输数据对象
			this.$axios.post('/law_management/lawItem/newInfo', re.stringify({
				id: a
			})).then(function(data) {
				console.log(data)
				if(data.data.ok == true){							
					vm.bians = data.data.obj.nodes;
				}									
			})
		},
		showDeleteWin(e) {
			this.deleteId = e.currentTarget.getAttribute('dataid');
			this.deleteEditor = true;
		},
		deleteLaw() {
			var that = this;
			var items = this.bians;
			var jsonarr = this.jsonarr;	
			jsonarr.push({
				id:this.deleteId,
				addType:"delete",
			})
			this.jsonarr = jsonarr;
			for(var i = 0;i<items[0].children.length;i++){
				if(items[0].children[i].id == this.deleteId){
					items[0].children.splice(i,1);									
					this.bians = items;
					return;
				}else{
					for(var j = 0;j<items[0].children[i].children.length;j++){
						if(items[0].children[i].children[j].id == this.deleteId){
							items[0].children[i].children.splice(j,1);
							this.bians = items;
							return;
						}else{
							for(var k = 0;k<items[0].children[i].children[j].children.length;k++){
								if(items[0].children[i].children[j].children[k].id == this.deleteId){
									items[0].children[i].children[j].children.splice(k,1);
									this.bians = items;
									return;
								}
							}
						}
					}
				}
			}
		},
		cancel() {
			
		},
		showEditorWin(e) {
			this.currEditId = e.currentTarget.getAttribute('dataid');
			this.editorContent = e.currentTarget.getAttribute('datahtml');
			this.showEditor = true;
			this.newkind = 1;
			console.log(this.editorContent)
		},
		addLaw(){
			if(this.editorContent != "<p></p>"){
				var that = this;
				var items = this.bians;
				var jsonarr = this.jsonarr;
				if(this.newkind == 1){
					jsonarr.push({
						id:this.currEditId,
						html: this.editorContent,
						addType:"update",
					})
					this.jsonarr = jsonarr;
					for(var i = 0;i<items[0].children.length;i++){
						if(items[0].children[i].id == this.currEditId){
							items[0].children[i].html = this.editorContent;									
							this.bians = items;
							return;
						}else{
							for(var j = 0;j<items[0].children[i].children.length;j++){
								if(items[0].children[i].children[j].id == this.currEditId){
									items[0].children[i].children[j].html=this.editorContent;
									this.bians = items;
									return;
								}else{
									for(var k = 0;k<items[0].children[i].children[j].children.length;k++){
										if(items[0].children[i].children[j].children[k].id == this.currEditId){
											items[0].children[i].children[j].children[k].html=this.editorContent;
											this.bians = items;
											console.log(this.bians)
											return;
										}
									}
								}
							}
						}
					}
				}else{
					jsonarr.push({
						num:this.editornum,
						html: this.editorContent,
						parentId:this.currEditpId,
						addType:"add",
					})
					this.jsonarr = jsonarr;
//					for(var i = 0;i<items[0].children.length;i++){
//						if(items[0].children[i].id == this.currEditpId){
//							items[0].children.push({
//								item:{
//									html: this.editorContent,
//									num:this.editornum,
//								}
//							})								
//							this.bians = items;
//							return;
//						}else{
//							for(var j = 0;j<items[0].children[i].children.length;j++){
//								if(items[0].children[i].children[j].id == this.currEditpId){
//									items[0].children[i].children.push({
//										item:{
//											html: this.editorContent,
//											num:this.editornum,
//										}
//									})
//									this.bians = items;
//									return;
//								}
//							}
//						}
//					}
					console.log(jsonarr)
				}
			}else{
				this.$Message.error("内容不能为空");
			}													
		},
		showaddEditorWin(e){
			this.currEditpId = e.currentTarget.getAttribute('datapid');
			this.editornum = + e.currentTarget.getAttribute('datanum') + 1;
			this.editorContent = "<p></p>";
			this.showEditor = true;
			this.newkind = 2;
			console.log(this.editornum)
			console.log(this.editorContent)
		},
		baocunlay(){
			let that = this;
			var re = require('qs'); //创建传输数据对象
			var data = {
				jsonObj:JSON.stringify(this.jsonarr),
				lawId:this.zhanshipage.lawid,
			}
			this.$axios.post('/law_management/app/add', re.stringify(data)).then(function(data) {
				console.log(data)
				if(data.data.ok == true){			
					that.$Message.info("添加成功");
					location.href = '/changeeffectlis';
					//vm.bians = data.data.obj.nodes;
				}									
			})
		},
	},
}
</script>

<style>#username {
	font-style: normal;
}

.change_left,
.change_right {
	float: left;
	width: 50%;
	height: 87%;
	overflow-x: hidden;
}

.change_right {
	border-left: 2px solid #1E8AE8;
}

.changebtn {
	position: absolute;
	bottom: -20px;
	width: 100%;
	background: #fff;
	left: 0;
	height: 50px;
}

.changebtn button {
	float: right;
	margin-top: 10px;
}

.changebtn button:nth-child(1) {
	margin-right: 25px;
	background: #0168F3;
	color: #fff;
}

.changebtn button:nth-child(2) {
	margin-right: 25px;
}

.user_boxmoveli {
	z-index: 99;
}

.lawyersitem {
	position: absolute;
	width: 100%;
	height: 100%;
	background: #F2F2F2;
	z-index: 99;
	top: 60px;
	left: 0;
}

.sm_he {
	height: 40px;
	padding: 0 20px 0 20px;
	line-height: 40px;
	font-size: 16px;
}

.sm_he>span:nth-child(1) {
	font-size: 18px;
	color: #014E9E;
}

.sm_contant {
	width: 100%;
	box-sizing: border-box;
	padding: 0 20px 20px 20px;
	height: 100%;
}

footer {
	text-align: center;
	z-index: 99;
}

.nfile .ivu-input {
	background: none;
	border: none;
}

.l_title {
	width: 100%;
	text-align: center;
	font-weight: 600;
	font-size: 20px;
}

.l_content {
	padding-left: 82px;
	position: relative;
	font-size: 14px;
	margin-bottom: 7.5px;
}

.l_content label {
	width: 80px;
	display: block;
	position: absolute;
	left: 0;
	text-align: right;
}

#sssss {
	padding-top: 12.5px;
	padding-left: 20px;
	padding-right: 20px;
}

* {
	margin: 0;
}

#sssss p {
	border: none;
}

#sssss table {
	border: none;
	margin-bottom: 3.5px;
}

#sssss hr {
	display: none;
}

.r1 td:nth-child(1) p {
	width: 68px;
}

.scollzhang {
	margin-bottom: 12.5px;
	margin-top: 5px;
}

.btns{
	float: right;
	margin-bottom: 7.5px;
	margin-top: 7.5px;
}

.bian,
.zhang,
.jie {
	padding: 5px;
}

.law-box {
	border: 1px solid #333;
	padding: 5px;
	margin: 20px 0px;
}

.editHtml {
	font-size: 16px;
	padding: 10px;
}
#editorElem table{
	border: none;
}
#editorElem table td{
	border: none;
}
</style>