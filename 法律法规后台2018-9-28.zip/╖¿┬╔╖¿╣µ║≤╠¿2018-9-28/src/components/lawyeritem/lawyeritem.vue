<template>
	<div class="layout">
		<Layout>
			<Header>
				<span class="title_a">
    				法律服务后台管理系统
    			</span>
				<Menu mode="horizontal" class="headeraruto">
					<Submenu name="3" id="user_name">
						<template slot="title">
							<Avatar src="https://i.loli.net/2017/08/21/599a521472424.jpg" />
							<i id="username">{{username}}</i>
						</template>
						<li class="ivu-menu-item ivu-menu-item-active" @click="login_out()">{{loginout}}</li>
						<li class="ivu-menu-item ivu-menu-item-active" @click="modal1 = true">{{changepassword}}</li>
					</Submenu>
				</Menu>
			</Header>
		</Layout>
		<div class="lawyersitem">
			<div class="sm_he">
				<span>当前位置：</span> 政策法律法规分类管理>法律
			</div>
			<div class="sm_contant">
				<div class="sm_title">{{title}}</div>
				<div class="sm_box">
					<div class="zhangjieul">
						<p class="til" @click="gotop()">目录</p>
						<ul class="ulone" id="muluul">
							<li v-for="(item, index) in items" class="uloneli" >
								<div class="ulonep scollpianclick" v-html="item.html" @click="scollgo(index, 1)"></div>
								<ul class="ultwo">
									<li v-for="(item2, index2) in item.children" class="ultwoli">
										<div class="ulonep" v-html="item2.html" @click="scollgo(index2, 2)"></div>
										<div class="ulonediv" >
											<ul class="ulthree">
												<li v-for="(item3, index3) in item2.children" class="ulthreeli">
													<div v-html="item3.html" @click="scollgo(item3.gonum, 3)"></div>
													<div class="ulthreediv">
														<ul class="ulfour">
															<li v-for="(item4, index4) in item3.children" class="ulfourli" @click="scollgo(item4.gonum, 4)">
																{{item4.tit}}											
															</li>
														</ul>
													</div>	
												</li>												
											</ul>
										</div>	
									</li>
								</ul>	
							</li>
						</ul>
					</div>
					<div class="wenzhangtotal" id="wenzhangtotal" ref="viewBox">
						<div class="wzt_one">
							<div>
								<div style="width: 10%;">公布部门：</div>
								<div>{{tititem.department}}</div>
							</div>
							<div>
								<div>公布日期：</div>
								<div>{{tititem.publishDate}}</div>
							</div>
							<div>
								<div>执行日期：</div>
								<div>{{tititem.executeDate}}</div>
							</div>
							<div>
								<div>效力：</div>
								<div>{{tititem.effect}}</div>
							</div>
							<div>
								<div>门类：</div>
								<div>{{tititem.category}}</div>
							</div>
						</div>
						<div class="gl_item" style="color: #262626;">{{tititem.note}}</div>
						<div class="gl_item">
							<span>关联项目：固定资产投资项目节能评估和审查(无子项)</span>
						</div>
						<div id="sssss">
							<div v-for="(item, index) in items">
								<div class="scollpian" style="font-size:16px;font-weight:600;margin-bottom:5.5px" v-html="item.html">																
								</div>
								<div v-for="(item2, index1) in item.children">
									<div class="scollzhang" v-html="item2.html">
									</div>
									<div v-for="(item3, index2) in item2.children">
										<div class="scolljie" style="padding-left:7.5px;margin-bottom:7.5px;" v-html="item3.html">
										</div>
										<div v-for="(item4, index3) in item3.children">
											<div class="scolltiao" style="padding-left:7.5px;margin-bottom:7.5px;" v-html="item4.html">
											</div>
										</div>
									</div>
								</div>								
							</div>							
						</div>
						<div class="gn_btn">							
							<span v-if="tititem.effect=='失效'||tititem.effect=='暂停实施'" :style="{display:Btndisplay}">
								<router-link :to="{path:'/lawyeritem/lawchange', query:{id:id}}" class="dw_link">
									<button>修改</button>
								</router-link>											
								<button @click="zantingshishi('有效')">实施</button>
							</span>	
							<span v-else :style="{display:Btndisplay}">
								<router-link :to="{path:'/lawyeritem/lawchange', query:{id:id}}" class="dw_link">
									<button>修改</button>
								</router-link>
								<button @click="zantingshishi('暂停实施')">暂停实施</button>
							</span>					
							<!--<button>同步更新</button>-->
							<!--<button>版本管理</button>-->
						</div>
					</div>
				</div>
			</div>
		</div>
		<footer>Copyright ©2018 fotoit-admin v1.2 All Rights Reserved. 本后台系统由珠海方图智能科技有限公司提供技术支持</footer>
		<Modal v-model="modal1" title="修改密码" style="position: relative;">
			<Form :model="formItem" :label-width="80">
				<FormItem label="旧密码">
					<Input type="password" v-model="formItem.oldpass" placeholder="请输入旧密码"></Input>
				</FormItem>
				<FormItem label="新密码">
					<Input type="password" v-model="formItem.newpass" placeholder="请输入新密码"></Input>
				</FormItem>
				<FormItem label="确认新密码">
					<Input type="password" v-model="formItem.newpassagain" placeholder="请确认新密码"></Input>
				</FormItem>
				<FormItem class="changebtn">
					<Button @click="changepasswordok()">提交</Button>
					<Button @click="changepasswordcancel()">取消</Button>
				</FormItem>
			</Form>
		</Modal>
	</div>
</template>

<script>
	function SectionToChinese(section){
		var chnNumChar = ["零","一","二","三","四","五","六","七","八","九"];
        var chnUnitSection = ["","万","亿","万亿","亿亿"];
        var chnUnitChar = ["","十","百","千"];
        
        var strIns = '', chnStr = '';
        var unitPos = 0;
        var zero = true;
        while(section > 0){
            var v = section % 10;
            if(v === 0){
                if(!zero){
                    zero = true;
                    chnStr = chnNumChar[v] + chnStr;
                }
            }else{
                zero = false;
                strIns = chnNumChar[v];
                strIns += chnUnitChar[unitPos];
                chnStr = strIns + chnStr;
            }
            unitPos++;
            section = Math.floor(section / 10);
        }
        return chnStr;
    } 
	export default {
		name: 'index',
		data() {
			return {
				loginout: '退出',
				userid: '',
				changepassword: '修改密码',
				username: 'test',
				modal1: false,
				formItem: {
					oldpass: '',
					newpass: '',
					newpassagain: '',
				},
				id: '',
				type:'',
				title: '',
				tititem: [],
				jytiaonum: 0,
				items: [],

				scollpian: [],
				scollzhang: [],
				scolljie: [],
				scolltiao: [],
				Btndisplay:'none',
				roleid:'',
				roleaddrName:'',
			}
		},
		mounted() {
			this.box = this.$refs.viewBox
			// 监听这个dom的scroll事件
			this.box.addEventListener('scroll', () => {
				this.isScroll = this.$refs.viewBox.scrollTop > 0
			}, false)
		},
		components: {
			//			Home,
		},
		created: function() {
			var userid = localStorage.getItem('userId');
			var username = localStorage.getItem('userName');
			this.userid = userid;
			this.username = username;
			this.id = this.$route.query.id;
			this.type = this.$route.query.type;
			this.roleid = localStorage.getItem('roleid');
			this.roleaddrName = localStorage.getItem('roleaddrName');
			var _this = this; //在数据加载之前的操作
			var data = {
				id: this.id,
			}
			var qs = require('qs');
			this.$axios.post('/law_management/lawItem/newInfo', qs.stringify(data))
				.then(function(obj) {
					console.log(obj)
					if(obj.data.ok) {
						var data = obj.data.obj;
						//						$("#sssss").html(obj.data.obj.html)
						_this.title = data.chinaLaw.title;
						_this.tititem = data.chinaLaw;
						if(data.chinaLaw.province == "贵州省"){
							if(_this.roleid == 1){						
									_this.Btndisplay = "inline";														
							}else if(_this.roleid == 2){
								if(data.chinaLaw.city != null){
									if(_this.roleaddrName == "贵州省" || _this.roleaddrName == data.chinaLaw.city){
										_this.Btndisplay = "inline";
									}
								}else{
									if(_this.roleaddrName == "贵州省"){
										_this.Btndisplay = "inline";
									}
								}								
							}else{
								_this.Btndisplay = "none";
							}
						}					
						var num1=0,num2=0;
						console.log(data)
						if(data.nodes.length>0){
							for(var i = 0; i < data.nodes.length; i++) {
								if(data.nodes[i].children.length>0){
									for(var j = 0; j < data.nodes[i].children.length; j++) {
										if(data.nodes[i].children[j].children.length>0){
											for(var n = 0; n < data.nodes[i].children[j].children.length; n++) {											
												data.nodes[i].children[j].children[n].gonum=num1;
												num1+=1;
												if(data.nodes[i].children[j].children[n].children.length>0){
													for(var m = 0; m < data.nodes[i].children[j].children[n].children.length; m++) {
//														console.log(SectionToChinese(num2))
														data.nodes[i].children[j].children[n].children[m].tit="第"+SectionToChinese(num2+1)+"条"
														data.nodes[i].children[j].children[n].children[m].gonum=num2;	
														num2+=1;
													}
												}												
											}
										}										
									}
								}								
							}
						}
						
						_this.items = data.nodes;
						console.log(_this.items)
						_this.n = 0;
						
						var timer = setTimeout(function(){
							clearTimeout(timer)
							_this.scollpian = [];						
							for(var i = 0; i < $('.scollpian').length; i++) {
								var top = $('.scollpian').eq(i).offset().top - 160;
								_this.scollpian.push(top);
							};
							_this.scollzhang = [];
							for(var i = 0; i < $('.scollzhang').length; i++) {
								var top = $('.scollzhang').eq(i).offset().top - 160;
								_this.scollzhang.push(top);
							};
							_this.scolljie = [];
							for(var j = 0; j < $('.scolljie').length; j++) {
								var top = $('.scolljie').eq(j).offset().top - 160;
								_this.scolljie.push(top);
							};
	
							_this.scolltiao = [];
							for(var j = 0; j < $('.scolltiao').length; j++) {
								var top = $('.scolltiao').eq(j).offset().top - 160;
								_this.scolltiao.push(top);
							};
						},1000)
					} else {
						_this.$Message.error(obj.data.msg);
					}
				})
				.catch(function(error) {
					console.log(error);
				});
		},
		methods: {
			zantingshishi(e){
				var re = require('qs'); //创建传输数据对象
				var data={
					addrName:this.roleaddrName,
					createUserName:this.username,
					lawId:this.id,
					lawTitle:this.title,
					willEffect:e,
					lawType:this.type,
				}
				this.$axios.post('/law_management/ztss/add', re.stringify(data))
					.then(function(obj) {
						alert("已提交到审核。请联系超级管理员去审核")
					})
					.catch(function(error) {
						console.log(error);
					}); //ajax end				
			},
			login_out() {
				var re = require('qs'); //创建传输数据对象
				this.$axios.post('/law_management/buser/logout', re.stringify())
					.then(function(obj) {
						if(obj.data.code == 200) {
							location.href = '/';
							localStorage.clear();
						} else {
							this.$Message.error(obj.data.msg);
						}
					})
					.catch(function(error) {
						console.log(error);
					}); //ajax end
			},
			changepasswordok() {
				//              this.$Message.info('Clicked ok');
				console.log(this.formItem)
				if(this.formItem.oldpass == "") {
					this.$Message.info('旧密码不能为空');
					return
				}
				if(this.formItem.newpass == "") {
					this.$Message.info('新密码不能为空');
					return
				}
				if(this.formItem.newpass != this.formItem.newpassagain) {
					this.$Message.info('两次输入的新密码不一样');
					return
				}
			},
			changepasswordcancel() {
				//              this.$Message.info('Clicked cancel');
				console.log("取消")
				this.modal1 = false;
			},
			gotop() {
				this.box = this.$refs.viewBox;
				var that = this;
				var num2 = this.jytiaonum;
				var num1 = 0;
				var n = (num2 - num1) / 100
				//console.log(num1,num2,n);					
				var timer = setInterval(function() {
					num2 -= n;
					$(that.box).scrollTop(num2)
					if(num1 >= num2) {
						clearInterval(timer)
						return
					}
				}, 5)
				this.jytiaonum = 0;
			},
			scollgo(e, kind) {
				console.log(e)
				this.box = this.$refs.viewBox
				var that = this;
				if(kind == 1) {
					var kind = this.scollpian;
				}
				if(kind == 2) {
					var kind = this.scollzhang;
				}
				if(kind == 3) {
					var kind = this.scolljie;
				}
				if(kind == 4) {
					var kind = this.scolltiao;
				}
				if(kind[e] > this.jytiaonum) {
					var num1 = this.jytiaonum;
					var num2 = kind[e];
					var n = (num2 - num1) / 100
					//console.log(num1,num2,n);					
					var timer = setInterval(function() {
						num1 += n;
						$(that.box).scrollTop(num1)
						if(num1 >= num2) {
							clearInterval(timer)
							return
						}
					}, 5)
				} else {
					var num2 = this.jytiaonum;
					var num1 = kind[e];
					var n = (num2 - num1) / 100
					//console.log(num1,num2,n);					
					var timer = setInterval(function() {
						num2 -= n;
						$(that.box).scrollTop(num2)
						if(num1 >= num2) {
							clearInterval(timer)
							return
						}
					}, 5)
				}
				this.jytiaonum = kind[e];
			},
		},
	}
</script>

<style>
	#username {
		font-style: normal;
	}
	
	.changebtn {
		position: absolute;
		bottom: -20px;
		width: 100%;
		background: #fff;
		left: 0;
		height: 50px;
	}
	
	.changebtn button {
		float: right;
		margin-top: 10px;
	}
	
	.changebtn button:nth-child(1) {
		margin-right: 25px;
		background: #0168F3;
		color: #fff;
	}
	
	.changebtn button:nth-child(2) {
		margin-right: 25px;
	}
	
	.user_boxmoveli {
		z-index: 99;
	}
	
	.lawyersitem {
		position: absolute;
		width: 100%;
		height: 100%;
		background: #F2F2F2;
		z-index: 99;
		top: 60px;
		left: 0;
	}
	
	.sm_he {
		height: 40px;
		padding: 0 20px 0 20px;
		line-height: 40px;
		font-size: 16px;
	}
	
	.sm_he>span:nth-child(1) {
		font-size: 18px;
		color: #014E9E;
	}
	
	.sm_contant {
		width: 100%;
		box-sizing: border-box;
		padding: 0 20px 20px 20px;
		height: 100%;
	}
	
	.sm_title {
		width: 100%;
		line-height: 40px;
		background: #fff;
		text-align: center;
		color: #262626;
		font-size: 18px;
		letter-spacing: 0.5px;
	}
	
	.sm_box {
		margin-top: 2px;
		height: 100%;
		position: relative;
	}
	
	.sm_box>div {
		float: left;
	}
	
	.zhangjieul {
		width: 20%;
		height: 480px;
		background: #fff;
		overflow-x: hidden;
		padding-bottom: 12.5px;
		padding-top: 7.5px;
	}
	
	.zhangjieul .til {
		padding-left: 17.5px;
		font-size: 14px;
		font-weight: 600;
	}
	
	.wenzhangtotal {
		width: 79%;
		margin-left: 1%;
		height: 80%;
		background: #fff;
		position: relative;
		box-sizing: border-box;
		padding-bottom: 45px;
		overflow-x: hidden;
	}
	
	footer {
		text-align: center;
		z-index: 99;
	}
	
	.ulone {
		padding-left: 17.5px;
	}
	
	ul li p {
		font-size: 14px;
		position: relative;
		margin: 0;
		padding-bottom: 0!important;
	}
	
	.ultwo {
		padding-left: 12.5px;
	}
	
	.ultwoli {
		font-size: 12px;
		line-height: 24px;
	}
	
	.ulthree {
		padding-left: 17.5px;
	}
	
	.ulthreeli {
		font-size: 12px;
		line-height: 24px;
	}
	
	.ulfour {
		padding-left: 22.5px;
	}
	
	.ulfourli {
		font-size: 12px;
		line-height: 24px;
	}
	
	.ulonep>div {
		position: absolute;
	}
	
	.ulonep>div:nth-child(1) {
		width: 70px;
	}
	
	.ulonep>div:nth-child(2) {
		position: relative;
		width: 60%;
		left: 70px;
	}
	
	.wzt_one {
		width: 100%;
		overflow: hidden;
		padding-top: 5px;
	}
	
	.wzt_one>div {
		float: left;
		width: 50%;
		overflow: hidden;
		margin-top: 5px;
	}
	
	.wzt_one>div:nth-child(1) {
		width: 100%;
	}
	
	.wzt_one>div>div {
		float: left;
		font-size: 14px;
	}
	
	.wzt_one>div>div:nth-child(1) {
		width: 20%;
		text-align: right;
	}
	
	.wzt_one>div>div:nth-child(2) {
		width: 80%;
	}
	
	.gl_item {
		padding-left: 20px;
		font-size: 12px;
		margin-top: 7.5px;
		color: #014E9E;
	}
	
	.wzt_two {
		width: 100%;
		box-sizing: border-box;
		padding-left: 20px;
		padding-right: 20px;
	}
	
	.wzt_two_zhang {
		width: 100%;
		text-align: center;
		margin-top: 7.5px;
		font-size: 14px;
		font-weight: 600;
		margin-bottom: 7.5px;
	}
	
	.wzt_two_li {
		width: 100%;
		position: relative;
		overflow: hidden;
		margin-bottom: 9px;
	}
	
	.wzt_two_li>div {
		float: left;
		font-size: 14px;
	}
	
	.wzt_two_li>div:nth-child(1) {
		width: 75px;
	}
	
	.wzt_two_li>div:nth-child(2) {
		width: 90%;
	}
	
	.wzt_two_li>div:nth-child(2) p {
		margin-bottom: 3px;
	}
	
	.gn_btn {
		text-align: right;
	}
	
	.gn_btn button {
		width: 80px;
		padding-bottom: 2.5px;
		padding-top: 2.5px;
		font-size: 14px;
		margin-right: 17.5px;
	}
	
	#sssss {
		padding-top: 12.5px;
		padding-left: 20px;
		padding-right: 20px;
	}
	
	* {
		margin: 0;
	}
	
	#sssss p {
		border: none;
	}
	
	#sssss table {
		border: none;
		margin-bottom: 3.5px;
	}
	
	#sssss hr {
		display: none;
	}
	
	.ulfourli {
		padding: 0!important;
	}
</style>