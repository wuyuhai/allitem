<template>
	<div class="layout">
		<Layout>
			<Header>
				<span class="title_a">
    				法律服务后台管理系统
    			</span>
				<Menu mode="horizontal"  class="headeraruto">
					<Submenu name="3" id="user_name">
			            <template slot="title">
			                <Avatar src="https://i.loli.net/2017/08/21/599a521472424.jpg" />
			                <i id="username">{{username}}</i>
			            </template>
			            <li class="ivu-menu-item ivu-menu-item-active" @click="login_out()">{{loginout}}</li>
			        	<li class="ivu-menu-item ivu-menu-item-active" @click="modal1 = true">{{changepassword}}</li>
					</Submenu>
			    </Menu>
			</Header>
		</Layout>
		<div class="lawyersitem">
			<div class="sm_he">
				<span>当前位置：</span>
				政策法律法规分类管理>法律
			</div>	
			<div class="sm_contant">
				<div class="sm_title">中火人民共和国宪法</div>
				<div class="sm_box">
					<div class="zhangjieul">
						<p class="til">目录</p>
						<ul class="ulone">
							<li class="uloneli">
								<div class="ulonep">
									<div>第一章</div>
									<div>总则</div> 
								</div>
								<div class="ulonediv">
									<ul class="ultwo">
										<li class="ultwoli">第一条</li>
										<li class="ultwoli">第二条</li>
										<li class="ultwoli">第三条</li>
										<li class="ultwoli">第四条</li>
										<li class="ultwoli">第五条</li>
										<li class="ultwoli">第六条</li>
										<li class="ultwoli">第七条</li>
									</ul>
								</div>
							</li>
							<li class="uloneli">
								<div class="ulonep">
									<div>第二章</div>
									<div>内容</div> 
								</div>
								<div class="ulonediv">
									<ul class="ultwo">
										<li class="ultwoli">第八条</li>
										<li class="ultwoli">第九条</li>
										<li class="ultwoli">第十条</li>
										<li class="ultwoli">第十一条</li>
										<li class="ultwoli">第十二条</li>
										<li class="ultwoli">第十三条</li>
										<li class="ultwoli">第十四条</li>
									</ul>
								</div>
							</li>
							<li class="uloneli">
								<div class="ulonep">
									<div>第三章</div>
									<div>发送卡仕达阿啥的卡萨丁阿斯达克安顺</div> 
								</div>
								<div class="ulonediv">
									<ul class="ultwo">
										<li class="ultwoli">第十五条</li>
										<li class="ultwoli">第十六条</li>
										<li class="ultwoli">第十七条</li>
										<li class="ultwoli">第十八条</li>
										<li class="ultwoli">第十九条</li>
										<li class="ultwoli">第二十条</li>
										<li class="ultwoli">第二十一条</li>
									</ul>
								</div>
							</li>
						</ul>
					</div>
					<div class="wenzhangtotal">
						<div class="wzt_one">
							<div>
								<div style="width: 10%;">公布部门：</div>
								<div>国务院</div>
							</div>
							<div>
								<div>公布日期：</div>
								<div>2018.03.29</div>
							</div>
							<div>
								<div>执行日期：</div>
								<div>2018.03.29</div>
							</div>
							<div>
								<div>效力：</div>
								<div>有效</div>
							</div>
							<div>
								<div>门类w：</div>
								<div>林业</div>
							</div>
						</div>
						<div class="wzt_two">
							<div class="wzt_two_zhang">
								<div>第一章 总则</div>
							</div>
							<ul class="wzt_two_ul">
								<li class="wzt_two_li">
									<div>第一条</div>
									<div>
										<p>为了防止传染病由国外传入或者由国内传出，实施国境卫生检疫，保护人体健康，制定
										本法。</p>
									</div>
								</li>
								<li class="wzt_two_li">
									<div>第二条</div>
									<div>
										<p>在中华人民共和国国际通航的港口、机场以及陆地边境和国界江河的口岸（以下简称国境口
										岸），设立国境卫生检疫机关，依照本法规定实施传染病检疫、监测和卫生监督。</p>
									</div>
								</li>
								<li class="wzt_two_li">
									<div>第三条</div>
									<div>
										<p>国境卫生检疫机关发现检疫传染病或者疑似检疫传染病时，除采取必要措施外，必须立即
										通知当地卫生行政部门，同时用最快的方法报告国务院卫生行政部门，最迟不得超过二十四
										小时。邮电部门对疫情报告应当优先传送。</p>
									</div>
								</li>
								<li class="wzt_two_li">
									<div>第四条</div>
									<div>
										<p>本法规定的传染病是指检疫传染病和监测传染病。</p>
										<p>检疫传染病，是指鼠疫、霍乱、黄热病以及国务院确定和公布的其他传染病。</p>
										<p>监测传染病，由国务院卫生行政部门确定和公布。</p>
									</div>
								</li>
							</ul>
						</div>
						<div></div>
					</div>
				</div>
			</div>			
		</div>
		<footer>Copyright ©2018 fotoit-admin v1.2 All Rights Reserved. 本后台系统由珠海方图智能科技有限公司提供技术支持</footer>
		<Modal v-model="modal1" title="修改密码" style="position: relative;">
			<Form :model="formItem" :label-width="80">
				<FormItem label="旧密码">
					<Input type="password" v-model="formItem.oldpass" placeholder="请输入旧密码"></Input>
				</FormItem>
				<FormItem label="新密码">
					<Input type="password" v-model="formItem.newpass" placeholder="请输入新密码"></Input>
				</FormItem>
				<FormItem label="确认新密码">
					<Input type="password" v-model="formItem.newpassagain" placeholder="请确认新密码"></Input>
				</FormItem>
				<FormItem class="changebtn">
					<Button @click="changepasswordok()">提交</Button>
					<Button @click="changepasswordcancel()">取消</Button>
				</FormItem>
			</Form>
		</Modal>
	</div>
</template>

<script>
	//	import Vue from 'vue'
	//	import VueRouter from 'vue-router'
	//	import Home from './Home'
	export default {
		name: 'index',
		data() {
			return {
				api: 'http://202.98.195.208:83/APIManagement',
				loginout: '退出',
				userid: '',
				changepassword: '修改密码',
				username: 'test',
				modal1: false,
				formItem: {
					oldpass: '',
					newpass: '',
					newpassagain: '',
				}
			}
		},
		components: {
			//			Home,
		},
		created: function() {
			var userid = localStorage.getItem('userId');
			var username = localStorage.getItem('userName');
			this.userid = userid;
			this.username = username;
		},
		methods: {
			login_out() {
				var re = require('qs'); //创建传输数据对象
				this.$axios.post(this.api + '/buser/logout', re.stringify())
					.then(function(obj) {
						if(obj.data.code == 200) {
							location.href = '/';
							localStorage.clear();
						} else {
							this.$Message.error(obj.data.msg);
						}
					})
					.catch(function(error) {
						console.log(error);
					}); //ajax end
			},
			changepasswordok() {
				//              this.$Message.info('Clicked ok');
				console.log(this.formItem)
				if(this.formItem.oldpass == "") {
					this.$Message.info('旧密码不能为空');
					return
				}
				if(this.formItem.newpass == "") {
					this.$Message.info('新密码不能为空');
					return
				}
				if(this.formItem.newpass != this.formItem.newpassagain) {
					this.$Message.info('两次输入的新密码不一样');
					return
				}
			},
			changepasswordcancel() {
				//              this.$Message.info('Clicked cancel');
				console.log("取消")
				this.modal1 = false;
			},
		},
	}
</script>

<style>
	#username {
		font-style: normal;
	}
	
	.changebtn {
		position: absolute;
		bottom: -20px;
		width: 100%;
		background: #fff;
		left: 0;
		height: 50px;
	}
	
	.changebtn button {
		float: right;
		margin-top: 10px;
	}
	
	.changebtn button:nth-child(1) {
		margin-right: 25px;
		background: #0168F3;
		color: #fff;
	}
	
	.changebtn button:nth-child(2) {
		margin-right: 25px;
	}
	.user_boxmoveli{
		z-index: 99;
	}
	
	.lawyersitem{
		position: absolute;
		width: 100%;
		height: 100%;
		background: #F2F2F2;
		z-index: 99;
		top: 60px;
		left: 0;
	}
	.sm_he{
		height: 40px;
		padding: 0 20px 0 20px;
		line-height: 40px;
		font-size: 16px;
	}
	.sm_he>span:nth-child(1){
		font-size: 18px;
		color: #014E9E;
	}
	.sm_contant{
		width: 100%;
		box-sizing: border-box;
		padding: 0 20px 20px 20px;
		height: 100%;
	}
	.sm_title{
		width: 100%;
		line-height: 40px;
		background: #fff;
		text-align: center;
		color: #262626;
		font-size: 18px;
		letter-spacing: 0.5px;
	}
	.sm_box{
		margin-top: 2px;
		height: 100%;
	}
	.sm_box>div{
		float: left;
	}
	.zhangjieul{
		width: 20%;
		height: 480px;
		background: #fff;
		overflow-x: hidden;
		padding-bottom: 12.5px;
		padding-top: 7.5px;
	}
	.zhangjieul .til{
		padding-left: 17.5px;
		font-size: 14px;
		font-weight: 600;
		
	}
	.wenzhangtotal{
		width: 79%;
		margin-left: 1%;
		height: 80%;
		background: #fff;
	}
	footer{
		text-align: center;
		z-index: 99;
	}
	.ulone{
		padding-left: 17.5px;
	}
	.ulonep{
		font-size: 14px;
		position: relative;
	}
	.ultwo{
		padding-left: 37.5px;
	}
	.ultwoli{
		font-size: 12px;
		line-height: 24px;
	}
	.ulonep>div{		
		position: absolute;
	}
	.ulonep>div:nth-child(1){
		width: 70px;
	}
	.ulonep>div:nth-child(2){
		position: relative;	
		width: 60%;
		left: 70px;
	}
	.wzt_one{
		width: 100%;
		overflow: hidden;
		padding-top: 5px;
	}
	.wzt_one>div{
		float: left;
		width: 50%;
		overflow: hidden;
		margin-top: 5px;
	}
	.wzt_one>div:nth-child(1){
		width: 100%;
	}
	.wzt_one>div>div{
		float: left;
		font-size: 14px;
	}
	.wzt_one>div>div:nth-child(1){
		width: 20%;
		text-align: right;
	}
	.wzt_one>div>div:nth-child(2){
		width: 80%;	
	}
	.wzt_two{
		width: 100%;
		box-sizing: border-box;
		padding-left: 20px;
		padding-right: 20px;
	}
	.wzt_two_zhang{
		width: 100%;
		text-align: center;
		margin-top: 7.5px;
		font-size: 14px;
		font-weight: 600;
		margin-bottom: 7.5px;
	}
	.wzt_two_li{
		width: 100%;
		position: relative;
		overflow: hidden;
		margin-bottom: 9px;
	}
	.wzt_two_li>div{
		float: left;
		font-size: 14px;
	}
	.wzt_two_li>div:nth-child(1){
		width: 75px;
	}
	.wzt_two_li>div:nth-child(2){
		width: 90%;
	}
	.wzt_two_li>div:nth-child(2) p {
		margin-bottom: 3px;
	}
</style>