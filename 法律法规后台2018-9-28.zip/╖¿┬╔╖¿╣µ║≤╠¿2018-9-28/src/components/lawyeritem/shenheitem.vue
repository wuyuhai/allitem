<template>
	<div class="layout">
		<Layout>
			<Header>
				<span class="title_a">
    				法律服务后台管理系统
    			</span>
				<Menu mode="horizontal" class="headeraruto">
					<Submenu name="3" id="user_name">
						<template slot="title">
							<Avatar src="https://i.loli.net/2017/08/21/599a521472424.jpg" />
							<i id="username">{{username}}</i>
						</template>
						<li class="ivu-menu-item ivu-menu-item-active" @click="login_out()">{{loginout}}</li>
						<li class="ivu-menu-item ivu-menu-item-active" @click="modal1 = true">{{changepassword}}</li>
					</Submenu>
				</Menu>
			</Header>
		</Layout>
		<div class="lawyersitem">
			<div class="sm_he">
				<span>当前位置：</span> 政策法律法规分类管理>增加
			</div>
			<div class="sm_contant">	
				<div class="change_left">
					<div class="l_title">{{zhanshipage.title}}</div>
					<div class="l_content"><label for="">公布部门：</label>{{zhanshipage.bumen}}</div>
					<div class="l_content"><label for="">公布日期：</label>{{zhanshipage.pbdate}}</div>
					<div class="l_content"><label for="">执行日期：</label>{{zhanshipage.zxdate}}</div>
					<div class="l_content"><label for="">法律类型：</label>{{uli[zhanshipage.lawtype]}}</div>
					<div class="l_content"><label for="">门类：</label>{{zhanshipage.mls}}</div>
					<div class="l_content"><label for="">备注：</label>{{zhanshipage.note}}</div>
					<div id="sssss">
						<div v-for="(item, index) in items">
							<div class="scollpian" style="font-size:16px;font-weight:600;margin-bottom:5.5px" v-html="item.html">																
							</div>
							<div v-for="(item2, index1) in item.children">
								<div class="scollzhang" v-html="item2.html">
								</div>
								<div v-for="(item3, index2) in item2.children">
									<div class="scolljie" style="padding-left:7.5px;margin-bottom:7.5px;" v-html="item3.html">
									</div>
									<div v-for="(item4, index3) in item3.children">
										<div class="scolltiao" style="padding-left:7.5px;margin-bottom:7.5px;" v-html="item4.html">
										</div>
									</div>
								</div>
							</div>								
						</div>							
					</div>
				</div>
				<div class="change_right">
					<div class="l_title">{{zhanshipage.title}}</div>
				    <div class="l_content"><label for="">公布部门：</label>{{zhanshipage.bumen}}</div>
					<div class="l_content"><label for="">公布日期：</label>{{zhanshipage.pbdate}}</div>
					<div class="l_content"><label for="">执行日期：</label>{{zhanshipage.zxdate}}</div>
					<div class="l_content"><label for="">法律类型：</label>{{uli[zhanshipage.lawtype]}}</div>
					<div class="l_content"><label for="">门类：</label>{{zhanshipage.mls}}</div>
					<div class="l_content"><label for="">备注：</label>{{zhanshipage.note}}</div>
					<div id="sssss">
						<div v-for="(item, index) in newitems">
							<div class="scollpian" style="font-size:16px;font-weight:600;margin-bottom:5.5px" v-html="item.html">																
							</div>
							<div v-for="(item2, index1) in item.children">
								<div class="scollzhang" v-html="item2.html">
								</div>
								<div v-for="(item3, index2) in item2.children">
									<div class="scolljie" style="padding-left:7.5px;margin-bottom:7.5px;" v-html="item3.html">
									</div>
									<div v-for="item4 in item3.children">
										<div v-if="item4.kis==1" class="scolltiao"  style="padding-left:7.5px;margin-bottom:7.5px;color: #f75000;" v-html="item4.html">
										</div>
										<div v-else-if="!item4.kis" class="scolltiao"  style="padding-left:7.5px;margin-bottom:7.5px;" v-html="item4.html">
										</div>
										<div v-else-if="!item4.kis==2" class="scolltiao"  style="padding-left:7.5px;margin-bottom:7.5px;color: red;" v-html="item4.html">
										</div>
										<div v-else-if="!item4.kis==3" class="scolltiao"  style="padding-left:7.5px;margin-bottom:7.5px;color: green;" v-html="item4.html">
										</div>
									</div>
								</div>
							</div>								
						</div>							
					</div>
				</div>			
			</div>
		</div>
		<footer>Copyright ©2018 fotoit-admin v1.2 All Rights Reserved. 本后台系统由珠海方图智能科技有限公司提供技术支持</footer>
		<Modal v-model="modal1" title="修改密码" style="position: relative;">
			<Form :model="formItem" :label-width="80">
				<FormItem label="旧密码">
					<Input type="password" v-model="formItem.oldpass" placeholder="请输入旧密码"></Input>
				</FormItem>
				<FormItem label="新密码">
					<Input type="password" v-model="formItem.newpass" placeholder="请输入新密码"></Input>
				</FormItem>
				<FormItem label="确认新密码">
					<Input type="password" v-model="formItem.newpassagain" placeholder="请确认新密码"></Input>
				</FormItem>
				<FormItem class="changebtn">
					<Button @click="changepasswordok()">提交</Button>
					<Button @click="changepasswordcancel()">取消</Button>
				</FormItem>
			</Form>
		</Modal>
	</div>
</template>

<script>
	import wangeditor from 'wangeditor'
	export default {
	name: 'index',
	data() {
		return {
			loginout: '退出',
			userid: '',
			changepassword: '修改密码',
			username: 'test',
			modal1: false,
			formItem: {
				oldpass: '',
				newpass: '',
				newpassagain: '',
			},
			id: "",

			roleid: '',
			roleaddrName: '',

			citybol: false,

			zhanshipage: {
				title: '',
				bumen: '',
				pbdate: '',
				zxdate: '',
				lawtype: '',
				mls: '',
				note: '',
				city: '',
				province: '贵州省',
			},

			uli: ['', '', '法律', '政策法规', '国务院部门规章', '地方性法规', '地方性政府规章'],
			items: [],
			jsonarr:[],
			appId:"",
			newitems:[],
		}
	},
	watch: {
		"formItemlaw.lawtype" (a, b) {
			if(a == 5) {
				this.citybol = false;
			} else {
				this.citybol = true;
			}
		},
		editorContent: {
			handler(val, oldVal) {
				this.editor.txt.html(val);
			},
		}
	},
	mounted() {
		var vm = this;
		this.editor = new wangeditor('#editorElem');
		// 自定义菜单配置
		this.editor.customConfig.menus = [];
		this.editor.customConfig.onchange = (html) => {
			vm.editorContent = html
		}
		this.editor.create()
	},
	components: {

	},
	created: function() {
		var userid = localStorage.getItem('userId');
		var username = localStorage.getItem('userName');
		this.id = this.$route.query.id;
		this.appId = this.$route.query.appId;
		this.userid = userid;
		this.username = username;
		this.roleid = localStorage.getItem('roleid');
		this.roleaddrName = localStorage.getItem('roleaddrName');
		if(this.id != undefined) {
			var _this = this; //在数据加载之前的操作
			var data = {
				id: this.id,
			}
			var qs = require('qs');
			this.$axios.post('/law_management/lawItem/newInfo', qs.stringify(data))
				.then(function(obj) {
					console.log(obj)
					if(obj.data.ok) {
						_this.zhanshipage.title = obj.data.obj.chinaLaw.title;
						_this.zhanshipage.bumen = obj.data.obj.chinaLaw.department;
						_this.zhanshipage.pbdate = obj.data.obj.chinaLaw.publishDate.split(" ")[0];
						_this.zhanshipage.zxdate = obj.data.obj.chinaLaw.executeDate.split(" ")[0];
						_this.zhanshipage.lawtype = obj.data.obj.chinaLaw.type;
						_this.zhanshipage.province = obj.data.obj.chinaLaw.province;
						_this.zhanshipage.mls = obj.data.obj.chinaLaw.category;
						_this.zhanshipage.note = obj.data.obj.chinaLaw.note;
						_this.zhanshipage.lawid = obj.data.obj.chinaLaw.lawid;
						if(obj.data.obj.chinaLaw.type == 6) {
							_this.zhanshipage.city = obj.data.obj.chinaLaw.city;
						}
						_this.items = obj.data.obj.nodes;
					} else {
						_this.$Message.error(obj.data.msg);
					}
				})
				.catch(function(error) {
					console.log(error);
				});
				
			this.$axios.post('/law_management/app/newInfo', qs.stringify({
				appId:this.appId,
				id:this.id,
			}))
				.then(function(obj) {
					console.log(obj)
					if(obj.data.ok) {
						_this.jsonarr = JSON.parse(obj.data.ext.jsonObj);
						console.log(_this.jsonarr)
							var newitems = obj.data.obj.nodes;
							var addarr=[],updatearr=[],delarr=[];
							for(var i=0;i<_this.jsonarr.length;i++){
								if(_this.jsonarr[i].addType == "add"){
									addarr.push(_this.jsonarr[i]);
								}
								if(_this.jsonarr[i].addType == "delete"){
									delarr.push(_this.jsonarr[i]);
								}
								if(_this.jsonarr[i].addType == "update"){
									updatearr.push(_this.jsonarr[i]);
								}
							}
							//删除
							for(var m=0;m<delarr.length;m++){
								for(var n=0;n<newitems[0].children.length;n++){
									if(newitems[0].children[n].id==delarr[m].id){
										newitems[0].children[n].children[q].children[t].kis = 2
										m++
									}else{
										for(var q=0;q<newitems[0].children[n].children.length;q++){
											if(newitems[0].children[n].children[q].id==delarr[m].id){
												newitems[0].children[n].children[q].children[t].kis = 2
												m++
											}else{
												for(var t=0;t<newitems[0].children[n].children[q].children.length;t++){
													if(newitems[0].children[n].children[q].children[t].id==delarr[m].id){
														//newitems[0].children[n].children[q].children.slice(t,1);
														newitems[0].children[n].children[q].children[t].kis = 2
														m++
													}								
												}
											}			
										}
									}
								}
							}
							//修改
							for(var m=0;m<updatearr.length;m++){
								console.log(newitems[0].children.length)
								for(var n=0;n<newitems[0].children.length;n++){
									if(updatearr[m]){
										if(newitems[0].children[n].id==updatearr[m].id){
											newitems[0].children[n].html = updatearr[m].html
											newitems[0].children[n].kis = 1
											m++
										}else{
											console.log(newitems[0].children[n].children.length)
											for(var q=0;q<newitems[0].children[n].children.length;q++){
												if(updatearr[m]){
													if(newitems[0].children[n].children[q].id==updatearr[m].id){
														newitems[0].children[n].children[q].html = updatearr[m].html;
														newitems[0].children[n].children[q].kis = 1
														m++
													}else{
														console.log(newitems[0].children[n].children[q].children.length)
														for(var t=0;t<newitems[0].children[n].children[q].children.length;t++){
															if(updatearr[m]){
																if(newitems[0].children[n].children[q].children[t].id==updatearr[m].id){
																	newitems[0].children[n].children[q].children[t].html = updatearr[m].html
																	newitems[0].children[n].children[q].children[t].kis = 1
																	m++
																}
															}else{
																t=newitems[0].children[n].children[q].children.length
															}
														}
													}
												}												
											}
										}
									}	
								}
							}
							//增加
//							for(var m=0;m<addarr.length;m++){
//								console.log(addarr[m])
//								if(newitems[0].id==addarr[m].parentId){
//									newitems[0].children.push({
//										item:{
//											num:addarr[m].num,
//											html:addarr[m].html,
//											kis:3
//										}					
//									})
//									m++
//								}else{
//									for(var n=0;n<newitems[0].children.length;n++){
//										console.log(addarr[m])
//										if(addarr[m]){
//											if(newitems[0].children[n].id==addarr[m].parentId){
//												newitems[0].children[n].children.push({
//													item:{
//														num:addarr[m].num,
//														html:addarr[m].html,
//														kis:3
//													}
//												})
//												m++
//											}else{
//												for(var q=0;q<newitems[0].children[n].children.length;q++){
//													console.log(addarr[m])
//													if(newitems[0].children[n].children[q].id==addarr[m].parentId){
//														newitems[0].children[n].children[q].children.push({
//															item:{
//																num:addarr[m].num,
//																html:addarr[m].html,
//																kis:3
//															}
//														})
//														m++
//													}			
//												}
//											}
//										}									
//									}
//								}								
//							}							
							_this.newitems = newitems;		
							console.log(_this.newitems)
					} else {
						_this.$Message.error(obj.data.msg);
					}
				})
				.catch(function(error) {
					console.log(error);
				});	
		}
	},
	methods: {
		login_out() {
			var re = require('qs'); //创建传输数据对象
			this.$axios.post('/law_management/logout', re.stringify())
				.then(function(data) {
					console.log(data)
					if(data.data.ok) {
						location.href = '/';
						localStorage.clear();
					} else {
						this.$Message.error(obj.data.msg);
					}
				})
				.catch(function(error) {
					console.log(error);
				}); //ajax end
		},
		changepasswordok() {
			console.log(this.formItem)
			if(this.formItem.oldpass == "") {
				this.$Message.info('旧密码不能为空');
				return
			}
			if(this.formItem.newpass == "") {
				this.$Message.info('新密码不能为空');
				return
			}
			if(this.formItem.newpass != this.formItem.newpassagain) {
				this.$Message.info('两次输入的新密码不一样');
				return
			}
			var data = {
				newPassword: this.formItem.newpass,
				oldPassword: this.formItem.oldpass,
				id: localStorage.userId
			}
			console.log(data)
			var that = this;
			var re = require('qs'); //创建传输数据对象
			this.$axios.post('/law_management/updatePassword', re.stringify(data))
				.then(function(data) {
					console.log(data)
					if(data.data.ok) {
						//							location.href = '/';
						//							localStorage.clear();
						alert('密码修改成功');
						that.modal1 = false;
					} else {
						alert('密码失败');
					}
				})
				.catch(function(error) {
					console.log(error);
				}); //ajax end
		},
		changepasswordcancel() {
			//              this.$Message.info('Clicked cancel');
			console.log("取消")
			this.modal1 = false;
		},
	},
}
</script>

<style>
	#username {
		font-style: normal;
}

.change_left,
.change_right {
	float: left;
	width: 50%;
	height: 87%;
	overflow-x: hidden;
}

.change_right {
	border-left: 2px solid #1E8AE8;
}

.changebtn {
	position: absolute;
	bottom: -20px;
	width: 100%;
	background: #fff;
	left: 0;
	height: 50px;
}

.changebtn button {
	float: right;
	margin-top: 10px;
}

.changebtn button:nth-child(1) {
	margin-right: 25px;
	background: #0168F3;
	color: #fff;
}

.changebtn button:nth-child(2) {
	margin-right: 25px;
}

.user_boxmoveli {
	z-index: 99;
}

.lawyersitem {
	position: absolute;
	width: 100%;
	height: 100%;
	background: #F2F2F2;
	z-index: 99;
	top: 60px;
	left: 0;
}

.sm_he {
	height: 40px;
	padding: 0 20px 0 20px;
	line-height: 40px;
	font-size: 16px;
}

.sm_he>span:nth-child(1) {
	font-size: 18px;
	color: #014E9E;
}

.sm_contant {
	width: 100%;
	box-sizing: border-box;
	padding: 0 20px 20px 20px;
	height: 100%;
}

footer {
	text-align: center;
	z-index: 99;
}

.nfile .ivu-input {
	background: none;
	border: none;
}

.l_title {
	width: 100%;
	text-align: center;
	font-weight: 600;
	font-size: 20px;
}

.l_content {
	padding-left: 82px;
	position: relative;
	font-size: 14px;
	margin-bottom: 7.5px;
}

.l_content label {
	width: 80px;
	display: block;
	position: absolute;
	left: 0;
	text-align: right;
}

#sssss {
	padding-top: 12.5px;
	padding-left: 20px;
	padding-right: 20px;
}

* {
	margin: 0;
}

#sssss p {
	border: none;
}

#sssss table {
	border: none;
	margin-bottom: 3.5px;
}

#sssss hr {
	display: none;
}

.r1 td:nth-child(1) p {
	width: 68px;
}

.scollzhang {
	margin-bottom: 12.5px;
	margin-top: 5px;
}

.btns{
	float: right;
	margin-bottom: 7.5px;
	margin-top: 7.5px;
}

.bian,
.zhang,
.jie {
	padding: 5px;
}

.law-box {
	border: 1px solid #333;
	padding: 5px;
	margin: 20px 0px;
}

.editHtml {
	font-size: 16px;
	padding: 10px;
}
#editorElem table{
	border: none;
}
#editorElem table td{
	border: none;
}
</style>