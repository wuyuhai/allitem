<template>
	<div>
		<div class="right-header">
			<Icon type="md-arrow-dropright" />
			<span>当前位置</span>：{{uli[id]}}
		</div>
		<div class="gongneng_box">
			<Form :model="formItem" :label-width="80" inline>
				<FormItem label="发布时间">
					<Row>
						<Col span="11">
						<DatePicker type="date" @on-change="time1" format="yyyy-MM-dd" placeholder="开始日期"></DatePicker>
						</Col>
						<Col span="2" style="text-align: center">至</Col>
						<Col span="11">
						<DatePicker type="date" @on-change="time2" format="yyyy-MM-dd" placeholder="结束日期"></DatePicker>
						</Col>
					</Row>
				</FormItem>
				<FormItem label="实施时间">
					<Row>
						<Col span="11">
						<DatePicker type="date" @on-change="time3" format="yyyy-MM-dd" placeholder="开始日期"></DatePicker>
						</Col>
						<Col span="2" style="text-align: center">至</Col>
						<Col span="11">
						<DatePicker type="date" @on-change="time4" format="yyyy-MM-dd" placeholder="结束日期"></DatePicker>
						</Col>
					</Row>
				</FormItem>
				<FormItem label="标题" class="biaotiwidth">
					<Input v-model="formItem.biaoti" placeholder="请输入法规标题"></Input>
				</FormItem>
				<FormItem class="searchbtn">
					<Button type="primary" @click="searchlawyers()">搜索</Button>
				</FormItem>
			</Form>
		</div>
		<div class="lawyers_box">
			<table class="tables" border="0" cellspacing="0" cellpadding="0">
				<thead class="table_header">
					<tr>
						<th colspan="37">名称</th>
						<th colspan="25">公布机关</th>
						<th colspan="7.5">公布日期</th>
						<th colspan="7.5">实施日期</th>
						<th colspan="10">门类</th>
						<th colspan="5">效力</th>
						<th colspan="8">操作</th>
					</tr>
				</thead>
				<tbody class="dw_tbody">
					<tr v-for="(item, index) in lawyers">
						<td colspan="37" title="点击查看法律详情">
							<router-link :to="{path:'/lawyeritem/lawyeritem', query:{id:item.id,type:id}}">
								{{item.title}}
							</router-link>
						</td>
						<td colspan="25" title="点击查看法律详情">
							<router-link :to="{path:'/lawyeritem/lawyeritem', query:{id:item.id,type:id}}">
								{{item.department}}
							</router-link>
						</td>
						<td colspan="7.5" title="点击查看法律详情">
							<router-link :to="{path:'/lawyeritem/lawyeritem', query:{id:item.id,type:id}}">
								{{item.publishDate}}
							</router-link>
						</td>
						<td colspan="7.5" title="点击查看法律详情">
							<router-link :to="{path:'/lawyeritem/lawyeritem', query:{id:item.id,type:id}}">
								{{item.executeDate}}
							</router-link>
						</td>
						<td colspan="10" title="点击查看法律详情">
							<router-link :to="{path:'/lawyeritem/lawyeritem', query:{id:item.id,type:id}}">
								{{item.category}}
							</router-link>
						</td>
						<td colspan="5" title="点击查看法律详情">
							<router-link :to="{path:'/lawyeritem/lawyeritem', query:{id:item.id,type:id}}">
								{{item.effect}}
							</router-link>
						</td>
						<td colspan="8" title="">						
							<span @click="removemodal(item.lawid)" class="removelaw">删除</span>
						</td>
					</tr>
				</tbody>
			</table>
			<div class="pages">
				<Page :total="allsize" :page-size="20" show-elevator @on-change="changepage" />
				<Button class="addlaws" type="primary" @click="goaddlaw()">增加</Button>
			</div>
		</div>
		<Modal v-model="modal12" 
			@on-ok="delsure"
        	@on-cancel="delcancel" draggable scrollable title="提示">
	        <div>是否确定删除该条法律</div>
	    </Modal>
	</div>
</template>

<script>
	export default {
		data() {
			return {
				formItem: {
					date1: '',
					date2: '',
					date3: '',
					date4: '',
					biaoti: '',
				},
				id: '',
				page: 1,
				lawyers: [],
				allsize: 0,
				uli:['','','法律','政策法规','国务院部门规章','地方性法规','地方性政府规章'],
				
				modal12:false,
				lid:"",
				
				roleid:"",
			}
		},
		created: function() {
			var userid = localStorage.getItem('userId');
			var username = localStorage.getItem('userName');
			this.userid = userid;
			this.username = username;
			this.roleid = localStorage.getItem('roleid');
			
			this.id = this.$route.query.id;
			localStorage.nowpage = this.$route.query.nowpage;
						
			var _this = this; //在数据加载之前的操作
			var data = {
				type: this.id,
				page: this.page,
				size: 20
			}
			var qs = require('qs');
			this.$axios.post('/law_management/chinaLaw/list', qs.stringify(data))
				.then(function(obj) {
					//console.log(obj)
					if(obj.data.ok) {
						var data = obj.data.obj;
						if(data.content) {
							_this.lawyers = data.content;
							_this.allsize = data.totalElements;
							if(data.content.length==0){
								_this.$Message.info("没有查到相关的法规");
							}
						}
					} else {
						_this.$Message.error(obj.data.msg);
					}
				})
				.catch(function(error) {
					//console.log(error);
				});
		},
		watch: {
			$route() {
				var formItem={
					date1: '',
					date2: '',
					date3: '',
					date4: '',
					biaoti: '',
				};
				this.formItem = formItem;
				this.id = this.$route.query.id;
				localStorage.nowpage = this.$route.query.nowpage;
				var _this = this; //在数据加载之前的操作
				var data = {
					type: this.id,
					page: this.page,
					size: 20
				}
				var qs = require('qs');
				this.$axios.post('/law_management/chinaLaw/list', qs.stringify(data))
					.then(function(obj) {
						//console.log(obj)
						if(obj.data.ok) {
							var data = obj.data.obj;
							if(data.content) {
								_this.lawyers = data.content;
								_this.allsize = data.totalElements;
								if(data.content.length==0){
									_this.$Message.info("没有查到相关的法规");
								}
							}
						} else {
							_this.$Message.error(obj.data.msg);
						}
					})
					.catch(function(error) {
						//console.log(error);
				});
				isnowpages(localStorage.getItem('nowpage'))
			},
		},
		methods: {
			goaddlaw(){
				if(this.roleid != 1){
					this.$Message.error("该用户没有操作权限");
					return
				}
				location.href = '/lawyeritem/addlaw';
			},
			lawlist(data){
				var _this = this;
				var qs = require('qs');
				this.$axios.post('/law_management/chinaLaw/list', qs.stringify(data))
					.then(function(obj) {
						//console.log(obj)
						if(obj.data.ok) {
							var data = obj.data.obj;
							if(data.content) {
								_this.lawyers = data.content;
								_this.allsize = data.totalElements;
								if(data.content.length==0){
									_this.$Message.info("没有查到相关的法规");
								}
							}
						} else {
							_this.$Message.error(obj.data.msg);
						}
					})
					.catch(function(error) {
						//console.log(error);
				});
			},
			removemodal(e){
				//console.log(e)
				if(this.roleid != 1){
					this.$Message.error("该用户没有操作权限");
					return
				}			
				this.modal12 = true;
				this.lid = e;
			},
			delsure(){
				if(this.lid == ""){
					return
				}
				var that = this;
				var qs = require('qs');
				var data = {
					lawId:this.lid
				}
				this.$axios.post('/law_management/lawItem/deleteByLawId', qs.stringify(data))
					.then(function(obj) {
						//console.log(obj)
						if(obj.data.ok) {
							that.$Message.info("删除成功");
							var datas = {
								type: that.id,
								page: that.page,
								size: 20
							}
							that.lawlist(datas)
						} else {
							that.$Message.error(obj.data.msg);
						}
					})
					.catch(function(error) {
						//console.log(error);
				});
			},
			delcancel(){
				this.modal12 = false;
			},
			handleSubmit(name) {
				this.$refs[name].validate((valid) => {
					if(valid) {
						this.$Message.success('Success!');
					} else {
						this.$Message.error('Fail!');
					}
				})
			},
			changepage(index) {
				//console.log(index)
				var _this = this; //在数据加载之前的操作
				var data = {
					type: this.id,
					page: index,
					size: 20
				}
				var qs = require('qs');
				this.$axios.post('/law_management/chinaLaw/list', qs.stringify(data))
					.then(function(obj) {
						//console.log(obj)
						if(obj.data.ok) {
							var data = obj.data.obj;
							if(data.content) {
								_this.lawyers = data.content;
								_this.allsize = data.totalElements;
								if(data.content.length==0){
									_this.$Message.info("没有查到相关的法规");
								}
							}
						} else {
							_this.$Message.error(obj.data.msg);
						}
					})
					.catch(function(error) {
						//console.log(error);
					});
			},
			searchlawyers(){
				//console.log(this.formItem)
				var _this = this; //在数据加载之前的操作
				var data = {
					type: this.id,
					page: 1,
					size: 20,
				}
				if(this.formItem.date1 != ""){
					console.log(1)
					data.publishTimeFrom = this.formItem.date1;
				}
				if(this.formItem.date2 != ""){
					console.log(2)
					data.publishTimeTo = this.formItem.date2;
				}
				if(this.formItem.date3 != ""){
					console.log(3)
					data.executeTimeFrom = this.formItem.date3;
				}
				if(this.formItem.date4 != ""){
					console.log(4)
					data.executeTimeTo = this.formItem.date4;
				}
				if(this.formItem.biaoti != ""){
					data.title = this.formItem.biaoti;
				}
				//console.log(data)
				var qs = require('qs');
				this.$axios.post('/law_management/chinaLaw/search', qs.stringify(data))
					.then(function(obj) {
						//console.log(obj)
						if(obj.data.ok) {
							var data = obj.data.obj;
							if(data.content) {
								_this.lawyers = data.content;
								_this.allsize = data.totalElements
								if(data.content.length==0){
									_this.$Message.info("没有查到相关的法规");
								}
							}
						} else {
							_this.$Message.error(obj.data.msg);
						}
					})
					.catch(function(error) {
						//console.log(error);
					});
			},
			time1(e) {
                this.formItem.date1 = e;
            },
            time2(e) {
                this.formItem.date2 = e;
            },
            time3(e) {
                this.formItem.date3 = e;
            },
            time4(e) {
                this.formItem.date4 = e;
            },
		},
		mounted(){
		    //定位当前位置
			isnowpages(localStorage.getItem('nowpage'))
		},
	}
	
	function isnowpages(a){	
		$(".nowpages").parent().removeClass("ivu-menu-item-selected")	
		
		$($(".nowpages")[a]).parent().parent().parent().addClass("ivu-menu-item-active ivu-menu-opened ivu-menu-child-item-active");
		$($(".nowpages")[a]).parent().parent().css({"display":"block"});
		$($(".nowpages")[a]).parent().addClass("ivu-menu-item-selected");		
		//console.log($($(".nowpages")[a]).parent())
	}		
</script>

<style>
	.ivu-form-item-label {
		padding-right: 0!important;
		width: 60px!important;
	}
	
	.ivu-row {
		width: 240px;
	}
	
	.ivu-form-item-content {
		width: 180px;
		margin-left: 65px!important;
	}
	
	.searchbtn {
		width: 60px;
	}
	
	.searchbtn .ivu-form-item-content {
		margin-left: 0!important;
	}
	
	.biaotiwidth {
		width: 27%;
	}
	
	.biaotiwidth .ivu-form-item-content {
		width: 75%;
	}
	
	.tables {
		width: 100%;
		max-height: 650px;
	}
	
	.gongneng_box form .ivu-form-item {
		position: absolute;
	}
	
	.gongneng_box form .ivu-form-item:nth-child(1) {
		left: 0;
	}
	
	.gongneng_box form .ivu-form-item:nth-child(2) {
		left: 300px;
	}
	
	.gongneng_box form .ivu-form-item:nth-child(3) {
		right: 65px;
	}
	
	.gongneng_box form .ivu-form-item:nth-child(4) {
		right: 0;
	}
	
	.lawyers_box {
		position: relative;
		height: 700px;
	}
	
	.tables tr td {
		text-align: center;
		line-height: 29px;
		font-size: 12px;
		-o-text-overflow: ellipsis;
		text-overflow: ellipsis;
		overflow: hidden;
		white-space: nowrap;
		width: 100%;
		border-bottom: 1px solid gainsboro;
		border-right: 1px solid gainsboro;
	}
	
	.pages {
		position: absolute;
		bottom: 12.5px;
		text-align: center;
		width: 100%;
	}
	.addlaws{
		position: absolute;
		top: 0;
		right: 22.5px;
	}
	.removelaw{
		padding: 2.5px 7.5px 2.5px;
		background: #1e8ae8;
		color: #fff;
		border-radius: 2px;
		cursor: pointer;
	}
</style>