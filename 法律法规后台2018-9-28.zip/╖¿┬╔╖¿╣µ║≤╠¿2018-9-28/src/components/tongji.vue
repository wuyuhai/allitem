<template>
	<div>
		<div class="right-header">
			<Icon type="md-arrow-dropright" />
			<span>当前位置</span>：统计分析
		</div>
		<div class="tingjicontont">
			<div>
				<div>
					<div class="oneimg">
						<p class="title_img">法律法规库分类统计</p>
						<div class="title_imgliubai">
							<div id="myChart" style="height: 350px;width: 100%"></div>
						</div>
					</div>
				</div>
				<div>
					<div class="twoimg">
						<p class="title_img">法律法规下载及浏览量统计</p>
						<div class="title_imgliubai">
							<div class="dtchuangk">
								<ul id="data1list">
									<li v-for="item in movedata1">
										{{item.createTime}} <span style="margin-left: 5px;">《{{item.lawTitle}}》</span><span>被{{item.downCount==0?"阅读":"下载"}}</span>
									</li>
								</ul>
							</div>
							<div class="xztj">
								<table cellspacing="0" cellpadding="0">
									<tr>
										<th colspan="80">名称</th>
										<th colspan="20">下载次数</th>
									</tr>
									<tr v-for="item in downcount">
										<td colspan="80">{{item.lawTitle}}</td>
										<td colspan="20">{{item.downCount}}</td>
									</tr>
								</table>
							</div>
							<div class="lltj">
								<table cellspacing="0" cellpadding="0">
									<tr>
										<th colspan="80">名称</th>
										<th colspan="20">浏览次数</th>
									</tr>
									<tr v-for="item in readcount">
										<td colspan="80">{{item.lawTitle}}</td>
										<td colspan="20">{{item.readCount}}</td>
									</tr>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div>
				<div class="threeimg">
					<p class="title_img">事项法规关联统计</p>
					<div class="title_imgliubai">
						<div id="zhutu" style="height: 350px;width: 40%"></div>
						<div class="movedata2">
							<ul id="data2list">
								<li v-for="(item, index) in movedata2.content">								
									<span>{{item.createTime}} </span><span>“{{item.itemName}}”</span> 关联了 <span>《{{movedata2.lay[index].title}}》</span>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	export default {
		name: 'tongji',
		data() {
			return {
				readcount: [],
				downcount: [],
				websock: null,
				movedata1:[],
				movedata2:{},
			}
		},
		created: function() {
			localStorage.nowpage = this.$route.query.nowpage;
			this.initWebSocket()　　
			var that = this
			var qs = require('qs');
			var data = {
				order: 'readCount',
				size: 10,
			}
			this.$axios.post('/law_management/lawLog/listOrder', qs.stringify(data)).then(function(obj) {
					console.log(obj)
					if(obj.data.ok == true) {
						that.readcount = obj.data.obj.content
					}
				})
				.catch(function(error) {
					console.log(error);
					that.modaldeluser = false;
				});
			var data1 = {
				order: 'downCount',
				size: 10,
			}
			this.$axios.post('/law_management/lawLog/listOrder', qs.stringify(data1)).then(function(obj) {
					console.log(obj)
					if(obj.data.ok == true) {
						that.downcount = obj.data.obj.content
					}
				})
				.catch(function(error) {
					console.log(error);
					that.modaldeluser = false;
				});
				
			//初始返回值data2
			var data2={
				size:20,
			}
			this.$axios.post('/law_management/chinaLaw/relateList', qs.stringify(data2)).then(function(obj) {
					console.log(obj)
					if(obj.data.ok == true) {
						that.movedata2 = {
							content:obj.data.obj.content,
							lay:obj.data.ext
						}
					}
				})
				.catch(function(error) {
					console.log(error);
					that.modaldeluser = false;
				});
				
			//初始返回值data1
			var data3={
				size:10,
			}
			this.$axios.post('/law_management/lawLog/list', qs.stringify(data3)).then(function(obj) {
					console.log(obj)
					if(obj.data.ok == true) {
						that.movedata1 = obj.data.obj.content
					}
				})
				.catch(function(error) {
					console.log(error);
					that.modaldeluser = false;
				});	
		},
		destroyed: function() {　　　　　　
			//			this.websocketclose();　　　　
		},
		beforeMount: function() {

			this.msg = 'mount前';
		},
		mounted: function() {
			//console.log("mount之后")   			
			this.pietu();
			this.zhutu();
			this.msg = 'mount后'
			isnowpages(localStorage.getItem('nowpage'))
		},
		methods: {
			pietu() {
				var that = this;
				let myChart = this.$echarts.init(document.getElementById('myChart'))
				var qs = require('qs');
				var data = {}
				this.$axios.post('/law_management/chinaLaw/typeCount', qs.stringify(data))
					.then(function(obj) {
						console.log(obj)
						if(obj.data.ok == true) {
							var datas = [{
									value: obj.data.obj[2],
									name: '法律'
								},
								{
									value: obj.data.obj[3],
									name: '行政法规'
								},
								{
									value: obj.data.obj[4],
									name: '国务院部门规章'
								},
								{
									value: obj.data.obj[5],
									name: '地方性法规'
								},
								{
									value: obj.data.obj[6],
									name: '地方性政府规章'
								}
							];
							myChart.setOption({
								backgroundColor: '#fff',
								title: {
									text: '',
									left: 'center',
									top: 20,
									textStyle: {
										color: '#999999'
									}
								},
								tooltip: {
									//						        trigger: 'item',
									formatter: "{a} <br/>{b} : {c} ({d}%)"
								},

								legend: {
									type: 'scroll',
									orient: 'vertical',
									right: 30,
									top: 20,
									bottom: 20,
									//	        data: data.legendData,
									selected: datas
								},
								series: [{
									name: '法律法规库',
									type: 'pie',
									radius: '50%',
									center: ['40%', '50%'],
									label: {
										normal: {
											formatter: '{a|{a}}{abg|}\n{hr|}\n  {b|{b}：}{c}  {per|{d}%}  ',
											backgroundColor: '#fff',
											borderColor: '#gainsboro',
											borderWidth: 0.5,
											borderRadius: 4,
											// shadowBlur:3,
											// shadowOffsetX: 2,
											// shadowOffsetY: 2,
											// shadowColor: '#999',
											// padding: [0, 7],
											rich: {
												a: {
													color: '#222222',
													lineHeight: 20,
													align: 'center'
												},
												hr: {
													borderColor: 'gainsboro',
													width: '100%',
													borderWidth: 0.5,
													height: 0
												},
												b: {
													fontSize: 10,
													lineHeight: 20
												},
												per: {
													color: '#111111',
													backgroundColor: '#fff',
												}
											}
										}
									},
									data: datas,
								}]
							});
						}
					})
					.catch(function(error) {
						console.log(error);
						that.modaldeluser = false;
					});
			},
			zhutu() {
				let myChart = this.$echarts.init(document.getElementById('zhutu'))
				var qs = require('qs');
				var data = {}
				this.$axios.post('/law_management/chinaLaw/relateCount', qs.stringify(data))
					.then(function(obj) {
						console.log(obj)
						if(obj.data.ok == true) {
							var datas = [obj.data.obj[2], obj.data.obj[3], obj.data.obj[4], obj.data.obj[5], obj.data.obj[6], ]
							myChart.setOption({
								color: ['#3398DB'],
								tooltip: {
									trigger: 'axis',
									axisPointer: { // 坐标轴指示器，坐标轴触发有效
										type: 'shadow' // 默认为直线，可选为：'line' | 'shadow'
									}
								},
								grid: {
									left: '3%',
									right: '4%',
									bottom: '3%',
									containLabel: true
								},
								xAxis: [{
									type: 'category',
									data: ['法律', '行政法规', '国务院部门规章', '地方性法规', '地方性政府规章'],
									axisTick: {
										alignWithLabel: true,
										default: true
									},

								}],
								yAxis: [{
									type: 'value'
								}],
								series: [{
									name: '直接访问',
									type: 'bar',
									barWidth: '60%',
									label: {
										normal: {
											show: true,
											position: 'top'
										}
									},
									data: datas
								}]
							});
						}

					})
					.catch(function(error) {
						console.log(error);
						_this.modaldeluser = false;
					});
			},
			threadPoxi() { // 实际调用的方法
				//参数
				const agentData = "mymessage";
				//若是ws开启状态
				if(this.websock.readyState === this.websock.OPEN) {
					this.websocketsend(agentData)
				}
				// 若是 正在开启状态，则等待300毫秒
				else if(this.websock.readyState === this.websock.CONNECTING) {
					let that = this; //保存当前对象this
					setTimeout(function() {
						that.websocketsend(agentData)
					}, 300);
				}
				// 若未开启 ，则等待500毫秒
				else {
					this.initWebSocket();
					let that = this; //保存当前对象this
					setTimeout(function() {
						that.websocketsend(agentData)
					}, 500);
				}
			},
			initWebSocket() { //初始化weosocket
				//ws地址
				const wsuri = 'ws://202.98.195.208:81/law_management/chatServer';
				this.websock = new WebSocket(wsuri);
				this.websock.onmessage = this.websocketonmessage;
				this.websock.onclose = this.websocketclose;
			},
			websocketonmessage(e) { //数据接收
				const redata = JSON.parse(e.data)
				console.log(redata);	
				var myDate = new Date().format("yyyy-MM-dd hh:mm:ss");
				if(redata.type == "阅读"){
					var movedata1 = this.movedata1;
					movedata1.pop();
					movedata1.unshift({
						createTime:myDate,
						lawTitle:redata.message,
						downCount:0,
					})
					this.movedata1 = movedata1;
				}
				if(redata.type == "下载"){
					var movedata1 = this.movedata1;
					movedata1.pop();
					movedata1.unshift({
						createTime:myDate,
						lawTitle:redata.message,
						downCount:1,
					})
					this.movedata1 = movedata1;
				}
				if(redata.type == "关联"){
					var movedata2 = this.movedata2;
					movedata2.content.pop();
					movedata2.lay.pop();
					movedata2.content.unshift({
						createTime:myDate,
						itemName:redata.message,
					})
					movedata2.lay.unshift({
						title:redata.lawTitle
					})
					this.movedata2 = movedata2;
				}				
			},
			websocketsend(agentData) { //数据发送
				this.websock.send(agentData);
			},
			websocketclose(e) { //关闭
				console.log("connection closed (" + e.code + ")");
			},		
		}
	};
	Date.prototype.format = function (format) {
       var args = {
           "M+": this.getMonth() + 1,
           "d+": this.getDate(),
           "h+": this.getHours(),
           "m+": this.getMinutes(),
           "s+": this.getSeconds(),
           "q+": Math.floor((this.getMonth() + 3) / 3),  //quarter
           "S": this.getMilliseconds()
       };
       if (/(y+)/.test(format))
           format = format.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
       for (var i in args) {
           var n = args[i];
           if (new RegExp("(" + i + ")").test(format))
               format = format.replace(RegExp.$1, RegExp.$1.length == 1 ? n : ("00" + n).substr(("" + n).length));
       }
       return format;
   };
   
   function isnowpages(a){
		console.log($(".nowpages")[a])
		$(".nowpages").parents('li').removeClass("ivu-menu-item-selected")		
		$($(".nowpages")[a]).addClass('router-link-exact-active router-link-active')
		$($(".nowpages")[a]).parents('li').addClass("ivu-menu-item-selected");		
	}
</script>

<style>
	.tingjicontont {
		width: 100%;
	}
	
	.tingjicontont>div {
		width: 100%;
		height: 420px;
	}
	
	.tingjicontont>div:nth-child(1)>div {
		float: left;
		width: 50%;
		min-width: 440px;
		height: 408px;
		padding: 15px 25px 7.5px 25px;
		box-sizing: border-box;
	}
	
	.tingjicontont>div .oneimg {
		width: 100%;
		height: 100%;
		border-radius: 10px;
		box-shadow: 0 1px 0 1px #909090;
	}
	
	.tingjicontont>div .twoimg {
		width: 100%;
		height: 100%;
		border-radius: 10px;
		box-shadow: 0 1px 0 1px #909090;
	}
	
	.tingjicontont>div:nth-child(2) {
		width: 100%;
		box-sizing: border-box;
		padding: 0 25px 0 25px;
		height: 398px;
	}
	
	.threeimg {
		width: 100%;
		height: 100%;
		border-radius: 10px;
		box-shadow: 0 1px 1px 1px #909090;
	}
	
	.title_img {
		width: 100%;
		height: 40px;
		line-height: 30px;
		font-size: 18px;
		color: #fff;
		background: #014E9E;
		text-align: center;
		border-radius: 10px;
	}
	
	.title_imgliubai {
		background: #fff;
		width: 100%;
		margin-top: -10px;
		height: 10px;
		position: relative;
	}
	
	#myChart>div:nth-child(1) {
		width: 100%!important;
	}
	
	#myChart canvas {
		width: 100%!important;
	}
	
	.xztj,
	.lltj {
		float: left;
		width: 50%;
	}
	
	.xztj table,
	.lltj table {
		margin-top: 7.5px;
		table-layout: fixed;
		word-break: break-all;
		word-wrap: break-word;
		width: 90%;
		margin-left: 5%;
		border: 1px solid gray;
	}
	
	.xztj table tr th,
	.lltj table tr th {
		background: #0177FF;
		color: #fff;
		font-size: 12px;
		height: 28px;
		font-weight: normal;
		border-right: 1px solid gray;
		border-bottom: 1px solid gray;
	}
	
	.xztj table tr td,
	.lltj table tr td {
		-o-text-overflow: ellipsis;
		text-overflow: ellipsis;
		overflow: hidden;
		white-space: nowrap;
		text-align: center;
		border-right: 1px solid gray;
		border-bottom: 1px solid gray;
		line-height: 24px;
		font-size: 10px;
	}
	
	.dtchuangk {
		height: 48px;
		overflow: hidden;
		position: relative;
	}
	
	.dtchuangk>ul {
		position: absolute;
		padding-left: 20px;
		padding-right: 20px;
	}
	.movedata2{
		height: 320px;
		width: 45%;
		position: absolute;
		top: 7.5px;
		right: 7.5px;
		box-sizing: border-box;	
		overflow: hidden;
		border: 1px solid gainsboro;	
	}
	.movedata2 ul{
		position: absolute;	
		padding-right: 12.5px;
		padding-left: 12.5px;
		padding-top: 7.5px;
	}
	.movedata2 ul li {
		text-indent: 24px;
		font-size: 12px;
		margin-bottom: 7.5px;
	}
	#data2list{
		animation:mymove 20s infinite;
		-webkit-animation:mymove 20s infinite;
	}
	@keyframes mymove{
		from {top: 0;}
		to {top: -300px;}
	}
	#data1list{
		animation:mymove1 10s infinite;
		-webkit-animation:mymove1 10s infinite;
	}
	@keyframes mymove1{
		from {top: 0;}
		to {top: -50px;}
	}
</style>