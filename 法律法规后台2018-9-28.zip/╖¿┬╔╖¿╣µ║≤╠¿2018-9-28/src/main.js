
import Vue from 'vue'
import App from './App'
import VueRouter from 'vue-router'
import VueResource from 'vue-resource'
import iView from 'iview'
import axios from 'axios'
import layer from 'vue-layer'

import 'babel-polyfill'
import 'iview/dist/styles/iview.css' // 使用 CSS
import style from './assets/css/style.css' // 使用 CSS

import Login from './components/Login'
import Index from './components/Index'
import Users from './components/Users'
import Tongji from './components/tongji'
import Useritems from './components/Useritems'
import Useritemsedit from './components/Useritemsedit'
import lawyers from './components/lawyers'
import lawyeritem from './components/lawyeritem/lawyeritem'
import lawyeritemdetial from './components/lawyeritem/lawyeritemdetial'
import itemcontect from './components/itemcontect'
import Lawtool from './components/LawTool'
import changeeffectlis from './components/changeeffectlis'
import addlaw from './components/lawyeritem/addlaw'
import lawchange from './components/lawyeritem/lawchange'
import shenheitem from './components/lawyeritem/shenheitem'

//安装echarts后引入
import Echarts from 'echarts'
import $ from 'jquery'
//
axios.defaults.withCredentials = true; //让ajax携带cookie
Vue.prototype.$echarts = Echarts
Vue.config.productionTip = false
Vue.use(iView)
Vue.use(VueRouter)
Vue.use(VueResource)
Vue.use(axios)
Vue.prototype.$layer = layer(Vue)
Vue.prototype.$axios = axios
///* eslint-disable no-new */
const router = new VueRouter({
	mode: 'history', //地址分配  清除http://localhost:8080/#/ 里面的#号
	//	base:__dirname,//当前路径
	routes: [ //
		{
			path: "/",
			component: Login
		}, //组件地址
		{
			path: "/lawyeritem/lawyeritem",
			component: lawyeritem
		}, 
		{
			path: "/lawyeritem/lawyeritemdetial",
			component: lawyeritemdetial
		}, 
		{
			path: "/LawTool",
			component: Lawtool
		},
		{
			path: "/lawyeritem/addlaw",
			component: addlaw
		},
		{
			path: "/lawyeritem/lawchange",
			component: lawchange
		},
		{
			path: "/lawyeritem/shenheitem",
			component: shenheitem
		},
		{
			path: "/Index",
			component: Index,
			children: [ //子路由
				{
					path: "/Users",
					component: Users
				},
				{
					path: "/tongji",
					component: Tongji
				},
				{
					path: "/Useritems",
					component: Useritems
				},
				{
					path: "/Useritemsedit",
					component: Useritemsedit
				},
				{
					path: "/lawyers",
					component: lawyers
				},
				{
					path: "/itemcontect",
					component: itemcontect
				},
				{
					path: "/changeeffectlis",
					component: changeeffectlis
				},
			]
		},
	],

})
new Vue({
	el: '#app',
	router,
	components: {
		App
	},
	template: '<App/>',
})